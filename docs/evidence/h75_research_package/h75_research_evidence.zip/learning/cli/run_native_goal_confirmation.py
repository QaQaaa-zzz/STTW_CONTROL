"""Explicit prepare/shape/execute for one fixed native-permission80 panel."""
import argparse
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode=True

def notify_after_execution(root,title,body):
    """Late notification imports must never alter native runtime initialization."""
    try:
        source=Path(__file__).resolve().parents[1]/'src'
        sys.path.insert(0,str(source))
        # A frozen package can already be loaded; sys.path alone cannot add its
        # missing notification-only submodules. Extend only after run returns.
        package=sys.modules.get('sttw_control')
        if package is not None and hasattr(package,'__path__'):
            package_path=str(source/'sttw_control')
            if package_path not in package.__path__:package.__path__=list(package.__path__)+[package_path]
        from engineer_reference_bias import notify
        notify(Path(root),title,body)
        return True
    except BaseException as exc:
        import json
        print(f'Native evaluation notification failed: {exc!r}',file=sys.stderr)
        try:
            with (Path(root)/'notification_errors.jsonl').open('a') as f:f.write(json.dumps(dict(title=title,error=repr(exc)))+'\n')
        except Exception:pass
        return False


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['prepare','prefix-shape','prefix','shape','execute']);parser.add_argument('root',type=Path)
    parser.add_argument('--source',type=Path,default=Path('runs/native_zero_preference_v1'))
    parser.add_argument('--mode',choices=['fixed_h75_capability','native_five_alpha_online','native_h75_source_prefix','five_alpha_tolerance_labels','middle_selection','frozen_transfer_evaluation','guard_fallback_evaluation','speed_query_online60','frozen_confirmation200','task_aware_fallback72','user_prior_online72','h75_user_late_state192','user_preference120','tolerance_broaden120','tolerance_online40','h75_late_state_tolerance48','tolerance_online120','legacy','h75_channel_response','h75_channel_switching','h75_switching_continuation','h75_online_scalar','h75_online_confirmation100','h75_samestate_tolerance72','h75_samestate_bank144'],default='legacy')
    parser.add_argument('--protocol',type=Path,default=None)
    parser.add_argument('--charged-source',type=Path)
    args=parser.parse_args()
    if args.protocol is None:args.protocol=Path('learning/configs/h75_friction08_capability.json' if args.mode=='fixed_h75_capability' else 'learning/configs/h75_five_alpha_online.json' if args.mode=='native_five_alpha_online' else 'learning/configs/h75_bank4_source_prefix.json' if args.mode=='native_h75_source_prefix' else 'learning/configs/h75_five_alpha_tolerance_labels.json' if args.mode=='five_alpha_tolerance_labels' else 'learning/configs/middle_selection.json' if args.mode=='middle_selection' else 'learning/configs/h75_frozen_transfer48.json' if args.mode=='frozen_transfer_evaluation' else 'learning/configs/h75_guard_fallback_extension72.json' if args.mode=='guard_fallback_evaluation' else 'learning/configs/h75_speed_query_online60.json' if args.mode=='speed_query_online60' else 'learning/configs/h75_frozen_confirmation200.json' if args.mode=='frozen_confirmation200' else 'learning/configs/h75_task_aware_fallback72.json' if args.mode=='task_aware_fallback72' else 'learning/configs/h75_user_prior_online72.json' if args.mode=='user_prior_online72' else 'learning/configs/h75_user_late_state192.json' if args.mode=='h75_user_late_state192' else 'learning/configs/h75_user_preference120.json' if args.mode=='user_preference120' else 'learning/configs/h75_tolerance_broaden120.json' if args.mode=='tolerance_broaden120' else 'learning/configs/h75_tolerance_online40.json' if args.mode=='tolerance_online40' else 'learning/configs/h75_late_state_tolerance48.json' if args.mode=='h75_late_state_tolerance48' else 'learning/configs/h75_tolerance_online120.json' if args.mode=='tolerance_online120' else 'learning/configs/h75_samestate_bank144.json' if args.mode=='h75_samestate_bank144' else 'learning/configs/h75_samestate_tolerance72.json' if args.mode=='h75_samestate_tolerance72' else 'learning/configs/h75_online_confirmation100.json' if args.mode=='h75_online_confirmation100' else 'learning/configs/h75_online_scalar.json' if args.mode=='h75_online_scalar' else 'learning/configs/h75_switching_continuation.json' if args.mode=='h75_switching_continuation' else 'learning/configs/h75_channel_switching.json' if args.mode=='h75_channel_switching' else 'learning/configs/h75_channel_response.json')
    file=Path(__file__).resolve().parents[1]/'src/sttw_control/native_goal_run.py'
    spec=importlib.util.spec_from_file_location('_sttw_native_goal_runner',file)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    try:
        if args.stage=='prepare':
            if args.mode=='fixed_h75_capability':module.prepare_fixed_h75_capability(args.source,args.root,args.protocol)
            elif args.mode=='native_five_alpha_online':module.prepare_five_alpha_online(args.source,args.root,args.protocol)
            elif args.mode=='native_h75_source_prefix':module.prepare_native_source_prefix(args.source,args.root,args.protocol)
            elif args.mode=='five_alpha_tolerance_labels':module.prepare_five_alpha_labels(args.source,args.root,args.protocol)
            elif args.mode=='middle_selection':module.prepare_middle_selection(args.source,args.root,args.protocol)
            elif args.mode=='frozen_transfer_evaluation':module.prepare_frozen_transfer(args.source,args.root,args.protocol)
            elif args.mode=='guard_fallback_evaluation':module.prepare_guard_fallback(args.source,args.root,args.protocol)
            elif args.mode=='speed_query_online60':module.prepare_speed_query(args.source,args.root,args.protocol)
            elif args.mode=='frozen_confirmation200':module.prepare_frozen_confirmation(args.source,args.root,args.protocol)
            elif args.mode=='task_aware_fallback72':module.prepare_task_aware(args.source,args.root,args.protocol)
            elif args.mode=='user_prior_online72':module.prepare_prior_online(args.source,args.root,args.protocol)
            elif args.mode=='h75_user_late_state192':module.prepare_late_state(args.source,args.root,args.protocol)
            elif args.mode=='user_preference120':module.prepare_user_preference(args.source,args.root,args.protocol)
            elif args.mode=='tolerance_broaden120':module.prepare_broaden(args.source,args.root,args.protocol)
            elif args.mode=='tolerance_online40':module.prepare_temporal_online(args.source,args.root,args.protocol)
            elif args.mode=='h75_late_state_tolerance48':module.prepare_late_state(args.source,args.root,args.protocol)
            elif args.mode=='tolerance_online120':module.prepare_tolerance(args.source,args.root,args.protocol)
            elif args.mode=='h75_samestate_bank144':module.prepare_bank144(args.source,args.root,args.protocol)
            elif args.mode=='h75_samestate_tolerance72':module.prepare_samestate(args.source,args.root,args.protocol)
            elif args.mode=='h75_online_confirmation100':module.prepare_confirmation(args.source,args.root,args.protocol)
            elif args.mode=='h75_online_scalar':module.prepare_online(args.source,args.root,args.protocol)
            elif args.mode=='h75_switching_continuation':module.prepare_continuation(args.source,args.root,args.protocol,charged_source=args.charged_source)
            elif args.mode=='h75_channel_switching':module.prepare_switching(args.source,args.root,args.protocol)
            elif args.mode=='h75_channel_response':module.prepare_response(args.source,args.root,args.protocol)
            else:module.prepare(args.source,args.root)
        elif args.stage in ('prefix','prefix-shape'):module.run_prefix(args.root,shape_only=args.stage=='prefix-shape')
        else:module.run(args.root,shape_only=args.stage=='shape')
    except BaseException:
        if args.stage=='execute':
            notify_after_execution(args.root,'STTW native goal比较报错','已停止并保存partial原始数据和计费，不自动重试或扩力。')
        raise
    else:
        if args.stage=='execute':
            notify_after_execution(args.root,'STTW native goal比较完成','冻结面板比较完成，无训练；随后分析原目标到达、实际触地、偏好代价及完整XY。')

"""Offline retrospective true-query substitution under protocol.json, on two DEV maps."""
import csv
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
VALUE = OUT.parent
P = VALUE.parents[1]
sys.path[:0] = [str(VALUE), str(P/'model')]
from exit_value import ExitValue, KnownMap
from frozen_exit_value import FrozenExits, mapped_arrays

G = ['map_id', 'root', 'gate_x', 'side']
PAIR = G + ['force']
SOURCE = VALUE/'development_entry'
OLD5, ALL16, FIXED = 'true_query_old5', 'true_query_all16', 'old_train_rule'

def score_map(name, value):
    folder = P/'export/dev'/name
    ix = pd.read_csv(folder/'prefix_index.csv', usecols=['map_id','row','root','action_slot','geometry','alpha','lane','hidden_force_N_grouping_only'])
    ix = ix.rename(columns={'hidden_force_N_grouping_only':'force', 'lane':'canonical_lane'})
    assert ix.groupby(['root','action_slot']).force.agg(lambda v: sorted(v)==[-5,0,5]).all()
    np.testing.assert_array_equal(ix.row, np.arange(576))
    cfg = json.loads((P/'batches'/name/'config.json').read_text())['paired_departures']
    # Use exactly FrozenExits.branch_ids and the physical bank; no dynamics rollout is needed.
    engine = FrozenExits.__new__(FrozenExits)
    engine.bank = mapped_arrays(cfg['route_bank'])
    engine.bank_len = len(engine.bank['s'])
    with np.load(cfg['approach_file']) as a:
        engine.approach = a['xy']
    world = KnownMap(P/'maps'/name)
    with np.load(folder/'measured_targets.npz') as z:
        verified = z['verified_relock']
        assert np.array_equal(verified,z['observed_query'])
        rows = np.flatnonzero(verified)
        q,v,prev,t = [z[k][rows] for k in ('query_qpos_native','query_velocity_state9','previous_velocity_state9','query_s')]
        assert all(np.isfinite(f).all() for f in (q,v,prev,t))
    ids = np.stack([engine.branch_ids(g,pose) for g,pose in zip(ix.geometry[rows],q)])
    records = []
    for side,col in ((1,0),(-1,2)):
        for gate in (12.7,15.):
            frame = ix.assign(gate_x=gate, side=side, verified_relock=verified,
                              true_query_s=np.nan, bank_id=-1, score=0.)
            frame.loc[rows,'true_query_s'] = t
            frame.loc[rows,'bank_id'] = ids[:,col]
            for i in range(0,len(rows),64):
                select = slice(i,i+64)
                refs = [engine.bank[k][ids[select,col]] for k in ('xy','heading','curvature')]
                frame.loc[rows[select],'score'] = value.score(world,q[select],v[select],prev[select],t[select],gate,side,side,*refs)
            records.append(frame)
    return pd.concat(records,ignore_index=True)

def aggregate(data, pairs=False):
    rows=[]
    for panel,part in [('all',data),('complete_roots',data[data.complete_root])]:
        id_cols=['method','baseline'] if pairs else ['method']
        for scope in [[],['map_id'],['map_id','root'],['map_id','gate_x','side']]:
            for key,group in part.groupby(id_cols+scope,sort=True):
                if not isinstance(key,tuple): key=(key,)
                row=dict(panel=panel, scope='_'.join(scope) or 'pooled', **dict(zip(id_cols+scope,key)),
                         roots=group.groupby(['map_id','root']).ngroups, conditions=len(group),
                         lower=int(group.lower.sum()),upper=int(group.upper.sum()))
                if pairs:
                    row.update(rescued_certain=int(group.lower.eq(1).sum()), lost_certain=int(group.upper.eq(-1).sum()),
                               unknown_differences=int(group.lower.ne(group.upper).sum()))
                else:
                    row['unobserved_selected']=int((~group.known).sum())
                rows.append(row)
    return pd.DataFrame(rows)

def main():
    start=time.monotonic()
    contract=json.loads((OUT/'protocol.json').read_text())
    weights=VALUE/'train_model.npz'
    assert hashlib.sha256(weights.read_bytes()).hexdigest()==contract['weights_sha256']
    value=ExitValue(weights)
    cond=pd.concat([score_map(name,value) for name in ('dev_00','dev_01')],ignore_index=True)
    assert len(cond)==4608 and cond.verified_relock.sum()==4*534
    cond.to_csv(OUT/'all_candidate_push_scores.csv.gz',index=False)
    scores=cond.groupby(G+['action_slot'],sort=True).agg(score=('score','mean'),verified_pushes=('verified_relock','sum')).reset_index()
    choices=[]
    for key,group in scores.groupby(G):
        meta=dict(zip(G,key))
        for n,method in [(5,OLD5),(16,ALL16)]:
            a=group[group.action_slot.lt(n)].sort_values('action_slot')
            best=a.loc[a.score.idxmax()]
            choices.append(dict(**meta,method=method,selected=int(best.action_slot),mean_score=best.score,
                                verified_pushes_selected=int(best.verified_pushes),ties=int(a.score.eq(best.score).sum())))
        choices.append(dict(**meta,method=FIXED,selected=4 if key[-1]==1 else 0,ties=1))
    # Commit the retrospective policy's shared choices before consulting physical fixed-exit outcomes.
    c=pd.DataFrame(choices)
    c.to_csv(OUT/'true_query_choices.csv',index=False)
    baseline=pd.read_csv(SOURCE/'time_zero_choices.csv')
    base_key=G+['method','selected']
    assert c[c.method.eq(FIXED)][base_key].reset_index(drop=True).equals(baseline[baseline.method.eq(FIXED)][base_key].reset_index(drop=True))
    c=pd.concat([c,baseline[~baseline.method.eq(FIXED)]],ignore_index=True)
    truth=pd.read_csv(SOURCE/'physical_conditions.csv.gz')
    complete=truth.groupby(['map_id','root']).known.all().rename('complete_root').reset_index()
    assert len(complete)==24 and complete.complete_root.sum()==22
    f=c.merge(truth,left_on=G+['selected'],right_on=G+['action_slot'],validate='many_to_many').merge(complete,validate='many_to_one')
    assert len(f)==288*c.method.nunique() and not f.duplicated(PAIR+['method']).any()
    f.to_csv(OUT/'case_outcomes.csv.gz',index=False)
    result=aggregate(f)
    result.to_csv(OUT/'outcomes.csv',index=False)
    paired=[]
    for m,b in [(OLD5,FIXED),(ALL16,FIXED),(ALL16,OLD5),(OLD5,'mixture3_old5'),(ALL16,'mixture3_all16'),(OLD5,'mean_old5'),(ALL16,'mean_all16')]:
        keep=PAIR+['selected','known','lower','upper','complete_root']
        d=f[f.method.eq(m)][keep].merge(f[f.method.eq(b)][keep],on=PAIR+['complete_root'],suffixes=('_a','_b'),validate='one_to_one')
        same=d.selected_a.eq(d.selected_b)
        d=d.assign(method=m,baseline=b,lower=np.where(same,0,d.lower_a-d.upper_b),upper=np.where(same,0,d.upper_a-d.lower_b))
        paired.append(d)
    paired=pd.concat(paired,ignore_index=True)
    paired.to_csv(OUT/'paired_case_differences.csv.gz',index=False)
    agg=aggregate(paired,True)
    agg.to_csv(OUT/'paired.csv',index=False)
    ref=pd.read_csv(SOURCE/'by_map_and_side.csv')
    for name_scope,source_panel in [('all','all_tasks_with_bounds'),('complete_roots','complete_roots')]:
        now=result[result.panel.eq(name_scope)&result.scope.eq('pooled')].set_index('method')
        saved=ref[ref.panel.eq(source_panel)&ref.map_id.isna()&ref.gate_x.isna()&ref.side.isna()].set_index('method')
        ids=[FIXED,'mean_old5','mean_all16','mixture3_old5','mixture3_all16']
        np.testing.assert_array_equal(now.loc[ids,['lower','upper']],saved.loc[ids,['lower','upper']])
    receipt=dict(registered=contract['registered_utc'],role=contract['role'],conditional_states=534,pre_relock_failures=618,
                 canonical_rows=1152,decision_groups=96,all16_physical_conditions=len(truth),unknown_all_options=int((~truth.known).sum()),
                 all_physical_conditions_per_method=288,complete_physical_conditions_per_method=264,complete_roots=22,
                 incompletely_observed_map_roots=complete[~complete.complete_root][['map_id','root']].to_dict('records'),
                 official_time_zero_pooled_exact='old, mean and mixture (5 or 16) each match the original two panel bounds',
                 physical_rollouts=0,new_fits=0,seconds_cpu_wall=time.monotonic()-start,weights_sha256=contract['weights_sha256'])
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(result[result.scope.eq('pooled')].to_string(index=False));print(agg[agg.scope.eq('pooled')].to_string(index=False))

if __name__=='__main__':
    main()

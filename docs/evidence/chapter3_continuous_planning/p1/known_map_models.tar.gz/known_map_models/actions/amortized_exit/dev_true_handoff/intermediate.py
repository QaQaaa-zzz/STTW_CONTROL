"""Retrospective intermediate score: observed treatment relock fraction times original conditional score."""
import json
from pathlib import Path
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
SOURCE=OUT.parent/'development_entry'
G=['map_id','root','gate_x','side']
KEY=G+['action_slot']
MID='true_relock_predicted_state_all16'
FIRST='mixture3_all16'
LAST='true_query_all16'

def main():
    spec=json.loads((OUT/'intermediate_protocol.json').read_text())
    old=pd.read_csv(SOURCE/'time_zero_scores.csv.gz').query("method=='mixture3'")
    pts=pd.read_csv(OUT/'all_candidate_push_scores.csv.gz')
    frac=pts.groupby(KEY).verified_relock.agg(['size','mean']).rename(columns={'mean':'true_relock_fraction'})
    assert frac['size'].eq(3).all()
    frame=old.merge(frac.reset_index(),validate='one_to_one')
    assert len(frame)==1536 and frame.particles.eq(16).all()
    frame['intermediate_score']=frame.true_relock_fraction*frame.conditional_exit_probability
    frame.to_csv(OUT/'intermediate_candidate_scores.csv.gz',index=False)
    order=frame.sort_values('action_slot')
    mid=order.loc[order.groupby(G).intermediate_score.idxmax()].copy()
    mid['ties']=mid[G].merge(frame.merge(mid[G+['intermediate_score']],on=G+['intermediate_score']).groupby(G).size().rename('ties').reset_index(),on=G,sort=False).ties.to_numpy()
    mid['method']=MID
    mid=mid.rename(columns={'action_slot':'selected'})
    mid.to_csv(OUT/'intermediate_choices.csv',index=False)
    old_choices=pd.read_csv(SOURCE/'time_zero_choices.csv')
    other=pd.read_csv(OUT/'true_query_choices.csv')
    c=pd.concat([old_choices[old_choices.method.eq(FIRST)],mid,other[other.method.eq(LAST)]],ignore_index=True)
    phy=pd.read_csv(SOURCE/'physical_conditions.csv.gz')
    roots=phy.groupby(['map_id','root']).known.all().rename('complete_root').reset_index()
    f=c[G+['method','selected']].merge(phy,left_on=G+['selected'],right_on=KEY).merge(roots,validate='many_to_one')
    gid=G+['force','complete_root']
    assert len(f)==3*288 and not f.duplicated(gid+['method']).any()
    f.to_csv(OUT/'intermediate_case_outcomes.csv.gz',index=False)
    paired=[]
    for m,b in ((MID,FIRST),(LAST,MID)):
        keep=gid+['selected','lower','upper','known','source_trajectory']
        d=f[f.method.eq(m)][keep].merge(f[f.method.eq(b)][keep],on=gid,suffixes=('_new','_base'),validate='one_to_one')
        same=d.selected_new.eq(d.selected_base)
        d=d.assign(method=m,baseline=b,lower=np.where(same,0,d.lower_new-d.upper_base),upper=np.where(same,0,d.upper_new-d.lower_base))
        paired.append(d)
    d=pd.concat(paired,ignore_index=True)
    d.to_csv(OUT/'intermediate_paired_cases.csv.gz',index=False)
    totals=[]; changes=[]
    for name in ('all','complete_roots'):
        included=f if name=='all' else f[f.complete_root]
        p=d if name=='all' else d[d.complete_root]
        for dims in ([],['map_id'],['map_id','gate_x','side']):
            def groups(table,methods):
                cols=methods+dims
                for k,g in table.groupby(cols,sort=True):
                    record=dict(zip(cols, k if isinstance(k,tuple) else (k,)))
                    yield dict(panel=name,scope='_'.join(dims) or 'pooled',**record,conditions=len(g),lower=int(g.lower.sum()),upper=int(g.upper.sum())),g
            for row,g in groups(included,['method']):
                totals.append(dict(**row,unknown_selected=int((~g.known).sum())))
            for row,g in groups(p,['baseline','method']):
                changes.append(dict(**row,known_rescues=int(g.lower.eq(1).sum()),known_losses=int(g.upper.eq(-1).sum()),unknown_differences=int(g.lower.ne(g.upper).sum())))
    pd.DataFrame(totals).to_csv(OUT/'intermediate_outcomes.csv',index=False)
    pd.DataFrame(changes).to_csv(OUT/'intermediate_paired.csv',index=False)
    report=dict(role=spec['role'],registered=spec['registered_utc'],decision_groups=96,choices_per_group=16,hidden_pushes_per_choice=3,
                pooled=[r for r in totals if r['scope']=='pooled'],paired_pooled=[r for r in changes if r['scope']=='pooled'],
                physical_rollouts=0,fit_updates=0,new_model_inference=0)
    (OUT/'intermediate_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print(pd.DataFrame(report['pooled']).to_string(index=False))
    print(pd.DataFrame(report['paired_pooled']).to_string(index=False))

if __name__=='__main__':
    main()

"""Use each vehicle's published approach to construct its three frozen exit geometries at handback."""
from copy import copy
import numpy as np
import torch


def departure_route(ref, lane, join, target, length, far_gate, goal_start):
    s = ref['s']
    xy = ref['xy'][lane]
    x, nominal = xy[join:].T.copy()
    def blend(x):
        u = x.clip(0,1)
        return u**3*(10-15*u+6*u**2)
    w = blend((x-x[0])/length)*(1-blend((x-far_gate)/(goal_start-far_gate)))
    y = nominal + (target-nominal)*w
    arc = np.r_[s[join],s[join]+np.cumsum(np.hypot(np.diff(x),np.diff(y)))]
    xy[join:,0] = np.interp(s[join:],arc,x) + np.maximum(s[join:]-arc[-1],0)
    xy[join:,1] = np.interp(s[join:],arc,y)
    heading = np.arctan2(np.gradient(xy[:,1]),np.gradient(xy[:,0]))
    ref['heading'][lane,join+1:] = heading[join+1:]
    ref['curvature'][lane,join+1:] = np.gradient(heading,s)[join+1:]


class ContinuousHandoffRoutes:
    def __init__(self, initial, goal_x):
        self.goal_x = float(goal_x)
        lanes = len(initial.route_ids)
        self.lanes = torch.arange(lanes, device=initial.s.device)
        self.branch_rows = lanes + 3*self.lanes[:, None] + torch.arange(3, device=initial.s.device)
        self.route = copy(initial)
        self.route.route_ids = self.lanes.clone()
        for key in ('xy', 'heading', 'curvature'):
            data = getattr(initial, key)[initial.route_ids]
            setattr(self.route,key,torch.cat((data,data.repeat_interleave(3,dim=0))))
        self.published_tick = torch.full_like(self.lanes, -1)
        self.handoff_join = torch.full_like(self.lanes, -1)

    def publish(self, adapter, proposal, committed, ready, deadline, eligible, expected_version):
        """Publish to approach lanes through the ordinary H75 same-grid prefix and clock check."""
        middle = adapter.middle
        if not torch.equal(self.route.s, proposal.s):
            raise ValueError('The proposed approach must use the currently published progress grid')
        now = middle.tick*.005
        guard = (middle.projection['progress'] + middle.follower['lookahead'] + .02*middle.v_user).clamp_max(self.route.s[-1])
        on_time = eligible & (ready<=deadline) & (now<=deadline) & (ready<=now+1e-8)
        accepted = on_time & (committed>=guard)
        ids = self.lanes[accepted]
        receipt = dict(tick=middle.tick,version=adapter.plan_version,
                       late=self.lanes[eligible & ~on_time].tolist(),
                       commitment_expired=self.lanes[on_time & ~accepted].tolist(),published=ids.tolist())
        if not len(ids):return receipt
        proposal_ids = proposal.route_ids
        active = copy(self.route)
        for key in ('xy','heading','curvature'):
            table = getattr(self.route,key).clone()
            table[ids] = getattr(proposal,key)[proposal_ids[ids]]
            setattr(active,key,table)
        # Other lanes (including vehicles that have already jumped) keep their full references intact.
        receipt.update(adapter.update_plan(active,torch.where(accepted,committed,self.route.s[-1]),now,expected_version))
        self.route = middle.route
        self.published_tick[ids] = middle.tick
        return receipt

    def at_handback(self, ids, position, progress):
        """Write actual left/straight/right references into private lane rows; active selection stays external."""
        if not len(ids):return
        route = self.route
        rows = route.route_ids[ids]
        if not torch.equal(rows,ids):
            raise ValueError('Only the currently published pre-jump approach may seed a new handback')
        sources = {k:getattr(route,k)[rows].detach().cpu().numpy() for k in ('xy','heading','curvature')}
        s = route.s.detach().cpu().numpy().astype(np.float64)
        x = position[:,0].detach().cpu().numpy().astype(np.float64)
        progress = progress.detach().cpu().numpy().astype(np.float64)
        joins = np.minimum(len(s)-1,np.maximum([np.searchsorted(xy[:,0].astype(np.float64),xx+.05)
                                                 for xy,xx in zip(sources['xy'],x)],np.searchsorted(s,progress)+1))
        # This is the original geometry builder. Its input is the actual (FP32) published grid,
        # lifted to FP64 for its interpolation and rounded back to the controller's native dtype.
        out = {k:np.repeat(a[:,None].astype(np.float64),3,axis=1) for k,a in sources.items()}
        for i,j in enumerate(joins):
            ref = {'s':s,**{k:a[i] for k,a in out.items()}}
            for side,target_y in enumerate((.36,0.,-.36)):
                departure_route(ref,side,int(j),target_y,1.6,15.,self.goal_x)
        for key,data in out.items():
            table=getattr(route,key)
            table[self.branch_rows[ids]] = torch.as_tensor(data,dtype=table.dtype,device=table.device)
        self.handoff_join[ids] = torch.as_tensor(joins,device=ids.device)

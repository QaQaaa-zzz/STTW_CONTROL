"""Run the registered supervised comparison following physical prefix export."""
from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess
import sys
import pandas as pd

model=Path(__file__).resolve().parent
base=model.parent
work=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
declaration=json.loads((model/'fit_preregistration.json').read_text())
config=declaration['shared_neural']
result=model/'formal_fit'
result.mkdir(exist_ok=True)
tbdir=result/'tensorboard'
tbdir.mkdir(exist_ok=True)
def note(phase,message):
    subprocess.run(['/usr/bin/python3',str(work/'learning/scripts/notify_chapter3_job.py'),
        '--title','第三章跳跃结果模型','--message',message,'--receipt',str(result/(phase+'_notice.json'))],check=False)
def record(phase,**fields):
    (result/'stage.json').write_text(json.dumps({'stage':phase,'utc':datetime.now(timezone.utc).isoformat(),**fields},indent=2)+'\n')
if '--summarize-existing' not in sys.argv[1:]:
    subprocess.run(['systemd-run','--user','--unit=sttw-ch3-outcome-tensorboard','--description=Chapter 3 jump outcome supervised metrics',
        str(Path(sys.executable).with_name('tensorboard')),'--logdir',str(tbdir),'--host','127.0.0.1','--port','6016'],check=True)
    record('started',seeds=config['seeds'])
    note('start','已取得 GPU。起跳结果模型仅使用六张训练图，两张开发图单独评分。训练曲线 http://127.0.0.1:6016')
    for seed in config['seeds']:
        record('fitting',seed=seed)
        out=result/f'seed_{seed}'
        cmd=[sys.executable,str(model/'fit_outcome.py'),'--data',str(base/'export'),
             '--split',str(base/'export/formal_train_dev.csv'),'--out',str(out),'--seed',str(seed),
             '--steps',str(config['updates']),'--batch-size',str(config['batch_size']),
             '--learning-rate',str(config['learning_rate']),'--device','cuda','--tensorboard-root',str(tbdir)]
        proc=subprocess.run(cmd)
        if proc.returncode:
            record('failed',seed=seed,returncode=proc.returncode)
            note('error',f'监督训练在种子 {seed} 退出，退出码 {proc.returncode}。运行记录 {result}')
            sys.exit(proc.returncode)
for name in ['development_by_map','development_by_root','development_by_combined','development_reliability']:
    tables=[pd.read_csv(result/f'seed_{seed}'/(name+'.csv')) for seed in config['seeds']]
    pd.concat(tables,ignore_index=True).to_csv(result/(name+'.csv'),index=False)
record('paired_development_calibration',seeds=config['seeds'])
proc=subprocess.run([sys.executable,str(model/'paired_development_calibration.py'),str(result)])
if proc.returncode:
    record('failed',phase_name='paired_development_calibration',returncode=proc.returncode)
    note('error','全部拟合已完成，开发图复锁概率配对分析失败。'+str(result))
    sys.exit(proc.returncode)
record('complete',seeds=config['seeds'],optimisation_steps=2*len(config['seeds'])*config['updates'])
note('complete','预登记的6次监督拟合已完成，按新开发图列出复锁率、位置和姿态误差。'+str(result/'development_by_map.csv'))

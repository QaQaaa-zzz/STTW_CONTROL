"""Matched fixed-map root bootstrap for the registered DEV verified-relock comparison."""
from itertools import combinations
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd

METHODS = ('mixture3', 'five_separate_roots', 'mean', 'empirical_action')
MAPS = ('dev_00', 'dev_01')
SEEDS = (61123, 61124, 61125)
METRICS = ('brier', 'ece_10_equal_width')
NBOOT, BOOT_SEED = 10000, 971123
KEY = ['layout', 'root', 'row']


def root_totals(wide):
    """Per root: count, sum of squared errors, ten signed bin residual totals per method."""
    groups = []
    for _, g in wide.groupby(level='root', sort=True):
        p = g[list(METHODS)].to_numpy()
        residual = p - g['relocked'].to_numpy()[:, None]
        bins = np.minimum((p * 10).astype(int), 9)
        binsums = np.stack([np.bincount(bins[:, j], weights=residual[:, j], minlength=10)
                            for j in range(len(METHODS))])
        groups.append(np.column_stack((np.full(len(METHODS), len(g)), (residual**2).sum(0), binsums)))
    return np.stack(groups)


def metric_values(totals):
    return np.stack((totals[..., 1], np.abs(totals[..., 2:]).sum(-1)), axis=-1) / totals[..., :1]


def compare(predictions, seed, expected=None, repetitions=NBOOT):
    if set(predictions.seed) != {seed} or set(predictions.model) != set(METHODS):
        raise ValueError('Unexpected model/seed identities')
    if predictions.duplicated(KEY + ['model']).any() or not predictions.relocked.isin([0, 1]).all():
        raise ValueError('Duplicated matched row or undefined verified relock')
    # A float32 sum of positive empirical support weights can reach the adjacent float
    # above one. Preserve the archived raw residual (and the frozen final-bin rule) so
    # each paired point estimate reconciles to the original end-of-fit report.
    one_up=float(np.nextafter(np.float32(1),np.float32(2)))
    empirical=predictions.model.isin(('five_separate_roots','empirical_action'))
    valid=predictions.probability.between(0,1) | (empirical & predictions.probability.eq(one_up))
    if not valid.all() or predictions.groupby(KEY).relocked.nunique().max() != 1:
        raise ValueError('Probability outside [0,1] or inconsistent matched target')
    wide = predictions.pivot(index=KEY, columns='model', values='probability').sort_index()
    if wide.isna().any().any() or set(wide.index.get_level_values('layout')) != set(MAPS):
        raise ValueError('A paired prediction or registered map is missing')
    wide['relocked'] = predictions.drop_duplicates(KEY).set_index(KEY).relocked.astype(int)
    if expected is not None and not wide.relocked.equals(expected):
        raise ValueError('Development predictions differ from the frozen physical-prefix identities or targets')
    rng = np.random.default_rng(BOOT_SEED)
    draws, roots, denominators = {}, {}, {}
    for name in MAPS:
        frame = wide.loc[[name]]
        by_root = root_totals(frame)
        nroots = len(by_root)
        weights = rng.multinomial(nroots, np.full(nroots, 1/nroots), size=repetitions)
        # Draw zero is the original point estimate. All methods in every replicate share these draws.
        draws[name] = np.tensordot(np.vstack((np.ones(nroots), weights)), by_root, axes=1)
        roots[name], denominators[name] = nroots, len(frame)
    both = 'two_fixed_maps_pooled'
    draws[both] = draws[MAPS[0]] + draws[MAPS[1]]
    roots[both] = sum(roots.values())
    denominators[both] = sum(denominators.values())
    rows = []
    for scope, totals in draws.items():
        values = metric_values(totals)
        for i, j in combinations(range(len(METHODS)), 2):
            delta = values[:, i] - values[:, j]
            interval = np.quantile(delta[1:], [.025, .975], axis=0)
            for k, metric in enumerate(METRICS):
                rows.append(dict(seed=seed, scope=scope, roots=roots[scope], prefixes=denominators[scope],
                                 model_a=METHODS[i],model_b=METHODS[j],metric=metric,
                                 comparison='primary' if seed==SEEDS[0] and scope==both and i==0 and j==1 and k==0 else 'descriptive',
                                 score_a=values[0,i,k],score_b=values[0,j,k],difference_a_minus_b=delta[0,k],
                                 bootstrap_p025=interval[0,k],bootstrap_p975=interval[1,k]))
    return pd.DataFrame(rows)


def summarize(folder):
    folder = folder.resolve()
    sources = []
    for name in MAPS:
        source = folder.parent.parent/'export/dev'/name
        ids = pd.read_csv(source/'prefix_index.csv',usecols=KEY)
        with np.load(source/'measured_targets.npz') as z:
            ids['relocked'] = z['verified_relock'].astype(int)
        if len(ids)!=576 or len(ids.groupby('root'))!=12 or not ids.groupby('root').size().eq(48).all():
            raise ValueError('Incomplete fixed-map prefix denominator')
        sources.append(ids)
    expected = pd.concat(sources).set_index(KEY).sort_index().relocked
    output = []
    reports = {};rounded=[]
    for seed in SEEDS:
        source = folder/f'seed_{seed}'/'development_predictions.csv.gz'
        preds = pd.read_csv(source,usecols=KEY+['seed','probability','relocked','model'],float_precision='round_trip')
        data = compare(preds,seed,expected)
        rounded.extend(preds.loc[preds.probability>1,KEY+['model','seed','probability','relocked']].to_dict('records'))
        # Reconcile the point estimates to the existing end-of-fit tables, once per method/scope.
        for table, keys in [('development_by_map',True),('development_by_combined',False)]:
            totals = pd.read_csv(folder/(table+'.csv'))
            for row in totals.loc[totals.seed==seed].itertuples():
                x = data[data.scope==(row.layout if keys else 'two_fixed_maps_pooled')]
                for title in METRICS:
                    vals = x[(x.model_a==row.model)&(x.metric==title)].score_a.tolist()
                    vals += x[(x.model_b==row.model)&(x.metric==title)].score_b.tolist()
                    np.testing.assert_allclose(vals, getattr(row,title),atol=1e-12,rtol=1e-11)
        output.append(data)
        reports[seed] = str(source)
    result = pd.concat(output,ignore_index=True)
    result[result.seed==SEEDS[0]].to_csv(folder/'development_paired_primary_seed.csv',index=False)
    result[result.seed!=SEEDS[0]].to_csv(folder/'development_paired_stability_seeds.csv',index=False)
    info = dict(role='Two fixed DEV maps only. No map resampling, calibration data, TEST or model selection.',
                primary='seed 61123; pooled fixed-map Brier difference mixture3 minus five_separate_roots. Negative favors mixture3.',
                remaining='Unadjusted descriptive 95% percentile intervals; no simultaneous familywise claim and no pooling across training seeds.',
                paired_unit='12 independently drawn roots with replacement inside each fixed map. Keep all 16 actions and 3 forces for every drawn root. Same paired draws across all four predictors and neural seeds.',
                pooled='Sum signed calibration-bin residuals across both sampled strata before absolute value; pool all 1152 physical prefixes.',
                ece='10 fixed equally spaced bins, left closed, with probability 1 in bin 9. Recompute each bootstrap replicate.',
                map_count=2,roots_per_map=12,prefixes_per_map=576,bootstrap_repetitions=NBOOT,bootstrap_seed=BOOT_SEED,
                sources=reports,empirical_roundoff=rounded,roundoff_convention='One adjacent float32 above one is accepted for normalized empirical weight sums only. As in the frozen end-of-fit reports, raw arithmetic is retained and bin 9 includes the endpoint.',primary_rows=36,stability_rows=72,point_estimates_match_registered_summary=True)
    (folder/'development_paired_receipt.json').write_text(json.dumps(info,indent=2)+'\n')


def fixture():
    # Within one bin, opposite-sign errors across roots cancel on the original sample.
    # Their resampled absolute sum must change, including when the same root is drawn twice.
    source=[]
    for name in MAPS:
        for j,y in enumerate([0,1]):
            for method in METHODS:
                source.append(dict(layout=name,root=j,row=j,model=method,seed=SEEDS[0],probability=.5,relocked=y))
    df=pd.DataFrame(source)
    zero=compare(df,SEEDS[0],repetitions=128)
    assert (zero[['difference_a_minus_b','bootstrap_p025','bootstrap_p975']]==0).all().all()
    df.loc[(df.root==1)&(df.model=='five_separate_roots'),'probability']=1.
    check=compare(df,SEEDS[0],repetitions=512)
    rows=check[(check.scope==MAPS[0])&(check.model_a==METHODS[0])&(check.model_b==METHODS[1])]
    np.testing.assert_allclose(rows.difference_a_minus_b,[.125,-.25])
    assert np.isclose(rows.iloc[1].bootstrap_p025,-.25) and np.isclose(rows.iloc[1].bootstrap_p975,.5)
    one_up=float(np.nextafter(np.float32(1),np.float32(2)))
    endpoint=df.copy();mask=(endpoint.root==1)&(endpoint.model=='five_separate_roots')
    endpoint.loc[mask,'probability']=one_up
    checked=compare(endpoint,SEEDS[0],repetitions=32)
    item=checked[(checked.scope==MAPS[0])&(checked.model_a=='mixture3')&(checked.model_b=='five_separate_roots')].set_index('metric')
    np.testing.assert_allclose(item.loc['brier','score_b'],(.25+(one_up-1.)**2)/2.,rtol=0,atol=1e-15)
    np.testing.assert_allclose(item.loc['ece_10_equal_width','score_b'],(.5+one_up-1.)/2.,rtol=0,atol=1e-15)
    for model,number in [('mean',one_up),('five_separate_roots',1.+2*(one_up-1.))]:
        invalid=df.copy();invalid.loc[(invalid.root==1)&(invalid.model==model),'probability']=number
        try:compare(invalid,SEEDS[0],repetitions=32)
        except ValueError:pass
        else:raise AssertionError('Invalid probability accepted')
    return dict(role='synthetic numerical check only',adjacent_empirical_float32_endpoint_reconciled=True,neural_and_larger_overshoots_rejected=True,equal_predictors_all_differences_and_bounds_zero=True,
                recomputed_ece_with_repeated_roots=[-.25,.5],formal_predictions_read=0)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('fit_directory',nargs='?',type=Path)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    if args.check: print(json.dumps(fixture(),indent=2))
    else: summarize(args.fit_directory)

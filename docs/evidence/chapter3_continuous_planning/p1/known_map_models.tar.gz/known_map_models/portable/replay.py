"""Replay fixed-model DEVELOPMENT predictions and every entry decision. CPU only."""
import argparse,hashlib,json,sys,tempfile
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from branch import BranchGeometry
P=Path(__file__).resolve().parents[1]
ROOT=P/'actions/amortized_exit'
sys.path[:0]=[str(P/'model'),str(ROOT)]
from exit_value import ExitValue
from jump_outcome import Dataset,DIM,JumpOutcome,MODE_NAMES,decision_inputs,decode_target
import paired_development_calibration as paired
CFG=json.loads((P/'model/downstream_preregistration.json').read_text())
SEED=61123
DRAWS=CFG['sampled_conditional_states']
DRAW_SEED=CFG['draw_seed']
# Original predicted_states' draw RNG is module-global SEED; its wrapper keeps the two
# original modules' different global SEED values (draws vs checkpoint) intact below.
G=['map_id','root','gate_x','side']
KEYS=['bank_row','action_slot','force_y_N']
OBSERVED=['t0_qpos_native','t0_qvel_native','t0_velocity_state9','alpha','approach_profile','step_geometry','approach_corridor_height_m','approach_corridor_support']
def local(f):
    p=Path(f)
    if p.name=='config.json':return P/'batches'/p.parent.name/'config.json'
    return p
def read(f):return json.loads(local(f).read_text())
def digest(f):return hashlib.sha256(local(f).read_bytes()).hexdigest()
class SelectedRows:
    def __init__(self,data,ids):self.data=data;self.ids=ids
    def __getitem__(self,key):
        row=np.searchsorted(self.ids,key)
        assert np.array_equal(self.ids[row],key)
        return self.data[row]
class KnownMap:
    def __init__(self,folder):
        world=read(folder/'world.json')
        self.walls=np.array(read(folder/'compiled_walls.json')['walls'])
        np.testing.assert_allclose(self.walls,world['terrain']['forbidden_rectangles'],atol=1e-9)
        self.goal_x=world['goal']['x_min_m'];self.platform_z=world['terrain']['far_bank_height_m']
        with np.load(folder/'terrain.npz') as g:
            self.height=g['height'];self.support=g['support'];self.bounds=g['bounds'];self.spacing=float(g['spacing'])
class FrozenExits(BranchGeometry):
    shared=None
    def __init__(self,unused,device):
        self.bank,self.approach=FrozenExits.shared
        self.bank_len=len(self.bank['s'])

def random_draws():
    rng=np.random.default_rng(SEED)
    u=(np.arange(DRAWS)+rng.random(DRAWS))/DRAWS
    return torch.tensor(rng.permutation(u),dtype=torch.float32),torch.tensor(rng.normal(size=(DRAWS,DIM)),dtype=torch.float32)

@torch.inference_mode()
def predicted_states(data,models,train,families=None):
    rows=[];opportunities={}
    common_u,common_noise=random_draws()
    if families is None:families=list(models)+[(name,'shared') for name in FAMILIES]
    for method,seed in families:
        if method in MODE_NAMES:
            net=models[method,seed]
            device=net.x_center.device
            logit,logw,center,scale=net(data.x.to(device))
            u=common_u.to(device).expand(len(data.x),-1)
            z=common_noise.to(device).expand(len(data.x),-1,-1)
            probs=logit.sigmoid().cpu()
            if method=='mean': latent=center[:,0,None,:]
            else:
                mode=torch.searchsorted(logw.exp().cumsum(-1).contiguous(),u.contiguous()).clamp_max(2)
                n=torch.arange(len(data.x),device=device)[:,None];latent=center[n,mode]+scale[n,mode]*z
            states={k:v.cpu() for k,v in decode_target(data.q0[:,None,:].to(device),latent*net.y_scale+net.y_center).items()}
        else:
            support=empirical_particles(train,data,None if method==FAMILIES[0] else 5)
            probs=torch.tensor([min(1.,max(0.,s[0])) for s in support])
        for n,r in enumerate(data.index.itertuples()):
            tag=dict(map_id=r.map_id,root=int(r.root),action_slot=int(r.action_slot),geometry=int(r.geometry),
                     alpha=float(r.alpha),section=r.section,section_x=float(r.section_x),target_side=int(r.target_side),method=method,seed=seed)
            key=(n,method,seed)
            chunk=[]
            if method in MODE_NAMES:
                fields={k:v[n] for k,v in states.items()}
            else:
                _,s,w=support[n]
                if len(s):
                    pick=torch.searchsorted(w.cumsum(0).contiguous(),common_u).clamp_max(len(w)-1)
                    fields=decode_target(data.q0[n:n+1],s[pick])
                else:fields=None
            if fields is not None:
                for i in range(len(fields['query_s'])):
                    p=dict(tag,particle=i,query_s=float(fields['query_s'][i]),q=fields['query_qpos_native'][i].numpy(),
                           v=fields['query_velocity_state9'][i].numpy(),prev=fields['previous_velocity_state9'][i].numpy())
                    chunk.append(p)
            rows.extend(chunk);opportunities[key]=(tag,float(probs[n]),chunk)
    return rows,opportunities

def config_rows(batch):
    if digest(batch['config'])!=batch['config_sha256']:raise ValueError('Frozen input config SHA mismatch')
    cfg=read(batch['config']);rr=cfg['ground_handoff']['handoff_variants']
    planned=pd.DataFrame([dict(**rr[v],lane=i) for i,(g,m,v) in enumerate(cfg['evaluation_lanes']) if g==rr[v]['geometry'] and m=='h75'])
    assert len(planned)==1152 and set(planned.data_split)=={batch['role']} and set(planned.map_id)=={batch['name']}
    left=planned[planned.arm=='left'].sort_values(KEYS).reset_index(drop=True)
    right=planned[planned.arm=='right'].sort_values(KEYS).reset_index(drop=True)
    assert len(left)==len(right)==576 and not left.duplicated(KEYS).any()
    eq=KEYS+['geometry','approach_alpha','section_x','side','bin','root_slot','map_slot','data_split','requested_speed_m_s']
    assert left[eq].equals(right[eq]) and (left.lane+1).equals(right.lane)
    assert np.all(left.planned_departure==0) and np.all(right.planned_departure==2)
    assert set(left.bank_row)==set(batch['bank_rows']) and left.groupby(['bank_row','action_slot']).force_y_N.apply(lambda a:set(a)=={-5,0,5}).all()
    assert left.groupby('bank_row').action_slot.nunique().eq(16).all()
    return cfg,left,right

def load_models(smoke):
    if smoke:
        file=P/'actions/continuous_examples/departure_plan/legacy_smoke_mixture3.pt'
        cp=torch.load(file,map_location='cpu',weights_only=True)
        nets={}
        for mode in MODE_NAMES:
            net=JumpOutcome(cp['width_in'],mode);net.load_state_dict(cp['state']);nets[(mode,str(SEED))]=net.eval()
        return nets,{'smoke_only_reuse_one_old_mixture_checkpoint_in_both_forward_modes':digest(file)}
    fit=P/'model/formal_fit'
    status=json.loads((fit/'stage.json').read_text());assert status['stage']=='complete' and SEED==CFG['seed_priority']
    seed_dir=fit/f'seed_{SEED}';spec=json.loads((P/'model/fit_preregistration.json').read_text())['shared_neural']
    assert spec['updates']==540 and spec['batch_size']==128 and status['seeds']==spec['seeds']
    assert status['optimisation_steps']==2*len(status['seeds'])*spec['updates']
    nets={};hashes={}
    for mode in MODE_NAMES:
        file=seed_dir/(mode+'.pt');cp=torch.load(file,map_location='cpu',weights_only=True)
        assert cp['mode']==mode
        net=JumpOutcome(cp['input_width'],mode,cp['width']);net.load_state_dict(cp['state'])
        nets[(mode,str(SEED))]=net.eval();hashes[mode]=digest(file)
    return nets,hashes

def predictions(folder,nets,root_subset):
    # Source row order is exactly the original exporter's frozen config sort; avoid opening
    # even the columns of an outcome-bearing CSV until after candidate selection.
    batch=next(b for b in json.loads((P/'collection_contract.json').read_text())['batches'] if b['name']==folder.name)
    _,left,_=config_rows(batch)
    cols=['map_id','bank_row','action_slot','geometry','approach_alpha','bin','section_x','side']
    meta=left.iloc[::3][cols].rename(columns={'bank_row':'root','approach_alpha':'alpha','bin':'section','side':'target_side'}).reset_index(drop=True)
    assert (left[cols].to_numpy()==np.repeat(left.iloc[::3][cols].to_numpy(),3,axis=0)).all()
    assert np.all(left.force_y_N.to_numpy().reshape(-1,3)==[-5.,0.,5.])
    with np.load(folder/'observed_inputs.npz',allow_pickle=False) as archive:
        obs={}
        for key in OBSERVED:
            a=archive[key];triplets=a.reshape(len(meta),3,*a.shape[1:])
            assert np.array_equal(triplets,np.broadcast_to(triplets[:,:1],triplets.shape))
            obs[key]=triplets[:,0]
    np.testing.assert_allclose(meta.alpha,obs['alpha'],rtol=0,atol=1e-7)
    x,q,reset,act=decision_inputs(obs)
    data=Dataset(x,q,reset,act,torch.zeros(len(q),dtype=torch.bool),torch.full((len(q),DIM),torch.nan),meta)
    if root_subset is not None:data=data.subset(np.flatnonzero(data.index.root.isin(root_subset)))
    # No outcome table is opened on this path. decision_rows checks identical allowed inputs for all 3 push copies.
    assert all(g.sort_values('action_slot').action_slot.tolist()==list(range(16)) for _,g in data.index.groupby('root'))
    engine=FrozenExits(P/'batches'/folder.name/'physical',device='cpu')
    world=KnownMap(P/'maps'/folder.name);model=ExitValue(ROOT/'train_model.npz')
    parts,items=predicted_states(data,nets,None,list(nets))
    score_rows=[]
    for lo in range(0,len(parts),128):
        ps=parts[lo:lo+128];q,v,prev,t=[np.asarray([p[k] for p in ps]) for k in ('q','v','prev','query_s')]
        branch=np.stack([engine.branch_ids(p['geometry'],p['q']) for p in ps])
        meta=pd.DataFrame([{k:p[k] for k in ('root','action_slot','geometry','alpha','method','particle')} for p in ps])
        for side,col in [(1,0),(-1,2)]:
            refs=[engine.bank[k][branch[:,col]] for k in ('xy','heading','curvature')]
            for gx in (12.7,15.):
                prob=model.score(world,q,v,prev,t,gx,side,side,*refs)
                score_rows.append(meta.assign(gate_x=gx,side=side,post_success=prob))
    values=pd.concat(score_rows).groupby(['root','action_slot','geometry','alpha','method','gate_x','side'],sort=True).post_success.agg(['size','mean']).reset_index()
    pr=pd.DataFrame([dict(root=tag['root'],action_slot=tag['action_slot'],method=tag['method'],p_relock=p) for tag,p,particles in items.values()])
    scores=values.merge(pr,on=['root','action_slot','method'],validate='many_to_one').rename(columns={'size':'particles','mean':'conditional_exit_probability'})
    scores['score']=scores.p_relock*scores.conditional_exit_probability;scores['map_id']=folder.name
    assert scores.particles[scores.method.eq('mean')].eq(1).all() and scores.particles[scores.method.eq('mixture3')].eq(16).all()
    return scores

def selection(s):
    choices={}
    for method in ('mean','mixture3'):
        ordered=s[s.method==method].sort_values('action_slot').set_index('action_slot')
        for size,label in ((5,'old5'),(16,'all16')):
            z=ordered.iloc[:size].score
            slot=int(z.idxmax());choices[method+'_'+label]=(slot,slot,int((z==z.max()).sum()))
    side=int(s.side.iloc[0]);fixed=4 if side==1 else 0;choices['old_train_rule']=(fixed,fixed,1)
    return choices

def hindsight(physical):
    options=physical.groupby('action_slot')[['lower','upper']].sum().sort_index();choices={}
    for size in (5,16):
        h=options.iloc[:size];low=int(h.lower.idxmax());high=int(h.upper.idxmax())
        choices['oracle_'+('old5' if size==5 else 'all16')]=(low,high,int((h.lower==h.lower.max()).sum()))
    return choices

def oracle_push_bounds(labels,size):
    # Exact marginal outcome of a hindsight winner for each push. Force that outcome
    # at one slot, give that slot the other upper outcomes, and rival slots their lower
    # outcomes. The lower-index tie convention must still let the forced slot win.
    L=labels.lower.unstack().sort_index().iloc[:size].to_numpy()
    U=labels.upper.unstack().sort_index().iloc[:size].to_numpy()
    totals=L.sum(1);high=U.sum(1)
    out=[]
    for j in range(3):
        possible=[]
        for a in range(size):
            for bit in range(L[a,j],U[a,j]+1):
                best=high[a]-U[a,j]+bit
                if (totals[:a]<best).all() and (totals[a+1:]<=best).all():possible.append(bit)
        out.append((min(possible),max(possible)))
    return out

def evaluate(scores,truth,out,preselected):
    complete=truth.groupby(['map_id','root']).known.all()
    incomplete=complete[~complete].index.tolist()
    groups=[];conditions=[];paired=[];fixed=[]
    by_truth=truth.groupby(G)
    for k,s in scores.groupby(G):
        meta=dict(zip(G,k));physical=by_truth.get_group(k);observed=bool(complete.loc[k[:2]])
        primary=preselected[k]
        choices={**primary,**hindsight(physical)}
        labels=physical.set_index(['action_slot','force']).sort_index()
        for method,(lo,hi,ties) in choices.items():
            a,b=labels.loc[lo],labels.loc[hi]
            group=dict(**meta,method=method,lower_choice=lo,upper_choice=hi,ties_at_lower_choice=ties,
                lower=int(a.lower.sum()),upper=int(b.upper.sum()),all_actions_observed_for_root=observed)
            groups.append(group)
            oracle=method.startswith('oracle')
            bounds=oracle_push_bounds(labels,5 if method=='oracle_old5' else 16) if oracle and not observed else None
            for j,force in enumerate((-5,0,5)):
                marginal=bounds[j] if bounds is not None else (int(a.loc[force,'lower']),int(b.loc[force,'upper']))
                conditions.append(dict(**meta,method=method,force_N=force,lower_choice=lo,upper_choice=hi,
                        lower=int(marginal[0]),upper=int(marginal[1]),lower_total_witness_case=int(a.loc[force,'lower']),
                        upper_total_witness_case=int(b.loc[force,'upper']),same_choice=lo==hi,
                        all_actions_observed_for_root=observed))
        for model,base in [('mean_old5','old_train_rule'),('mean_all16','old_train_rule'),
                           ('mixture3_old5','old_train_rule'),('mixture3_all16','old_train_rule'),
                           ('mean_all16','mean_old5'),('mixture3_all16','mixture3_old5'),
                           ('mixture3_old5','mean_old5'),('mixture3_all16','mean_all16')]:
            m,b=[choices[n][0] for n in (model,base)]
            for force in (-5,0,5):
                x,y=labels.loc[(m,force)],labels.loc[(b,force)]
                # Correlated missing labels cancel if the methods actually chose the same physical trial.
                lo,hi=(0,0) if m==b else (int(x.lower-y.upper),int(x.upper-y.lower))
                paired.append(dict(**meta,method=model,baseline=base,force_N=force,choice=m,base_choice=b,net_lower=lo,net_upper=hi,
                     exact_rescue=lo==hi==1,exact_loss=lo==hi==-1,exact_net=lo==hi,all_actions_observed_for_root=observed))
        # Geometry-only subset: same already active alpha, comparing only physically sampled options.
        for (method,alpha),h in s.groupby(['method','alpha']):
            if len(h)<2:continue
            h=h.sort_values('action_slot').set_index('action_slot')
            slot=int(h.score.idxmax());a=labels.loc[slot]
            fixed.append(dict(**meta,method=method,alpha=alpha,measured_slots=','.join(map(str,h.index)),selected=slot,
                lower=int(a.lower.sum()),upper=int(a.upper.sum()),all_actions_observed_for_root=observed))
    groups=pd.DataFrame(groups);conds=pd.DataFrame(conditions);pairs=pd.DataFrame(paired);fixed=pd.DataFrame(fixed)
    groups.to_csv(out/'groups.csv',index=False);conds.to_csv(out/'conditions.csv.gz',index=False)
    pairs.to_csv(out/'paired_conditions.csv.gz',index=False);fixed.to_csv(out/'fixed_alpha_measured_subsets.csv',index=False)
    result=[];diff=[]
    for panel in ('all_tasks_with_bounds','complete_roots'):
        def panelrows(df):return df if panel=='all_tasks_with_bounds' else df[df.all_actions_observed_for_root]
        for dims in (['map_id','gate_x','side'],['map_id','side'],['map_id'],['side'],[]):
            for methods,source,store in [(['method'],panelrows(groups),result),(['method','baseline'],panelrows(pairs),diff)]:
                for key,h in source.groupby(dims+methods):
                    if not isinstance(key,tuple):key=(key,)
                    rec=dict(panel=panel,**dict(zip(dims+methods,key)))
                    rec.update(roots=h.groupby(['map_id','root']).ngroups,shared_entry_decisions=h.groupby(G).ngroups)
                    if store is result:
                        rec.update(task_executions=3*len(h),lower=int(h.lower.sum()),upper=int(h.upper.sum()))
                    else:rec.update(task_executions=len(h),net_lower=int(h.net_lower.sum()),net_upper=int(h.net_upper.sum()),
                               certain_rescues=int(h.exact_rescue.sum()),certain_losses=int(h.exact_loss.sum()),undetermined_net=int((~h.exact_net).sum()))
                    store.append(rec)
    pd.DataFrame(result).to_csv(out/'by_map_and_side.csv',index=False)
    pd.DataFrame(diff).to_csv(out/'paired_by_map_and_side.csv',index=False)
    return dict(roots=len(complete),complete_roots=int(complete.sum()),incomplete_roots=[list(r) for r in incomplete],
                all_tasks=groups.groupby(G).ngroups*3)

# Each function copied from a different module retains its own original draw seed.
from types import FunctionType
random_draws=FunctionType(random_draws.__code__,{**globals(),'SEED':DRAW_SEED})

def compare_frame(new,old,keys):
    right=pd.read_csv(old,float_precision='round_trip')
    left=new.sort_values(keys).reset_index(drop=True)
    right=right.sort_values(keys).reset_index(drop=True)
    pd.testing.assert_frame_equal(left[right.columns],right,check_dtype=False,atol=1e-10,rtol=1e-10)
def setup_routes():
    with np.load(P/'portable/predicted_exit_geometry.npz') as z:
        ids=z['row_ids'];bank={'s':z['s'],**{k:SelectedRows(z[k],ids) for k in ('xy','heading','curvature')}}
    with np.load(P/'actions/approaches.npz') as z:approach=z['xy']
    FrozenExits.shared=bank,approach

def main():
    torch.set_num_threads(1);setup_routes()
    native=ROOT/'development_entry';fit=P/'model/formal_fit'
    dev=Dataset.join([Dataset.load(P/'export/dev'/m) for m in ('dev_00','dev_01')])
    train=Dataset.join([Dataset.load(P/'export/train'/f'train_{i:02d}') for i in range(6)])
    from jump_outcome import empirical_particles
    support={}
    for name,k in [('empirical_action',None),('five_separate_roots',5)]:
        support[name]=[v[0] for v in empirical_particles(train,dev,k)]
    prob_errors={}
    with torch.inference_mode():
        for seed in (61123,61124,61125):
            folder=fit/f'seed_{seed}';preds=pd.read_csv(folder/'development_predictions.csv.gz',float_precision='round_trip')
            assert len(preds)==4608 and preds.groupby('model').size().eq(1152).all()
            for mode in (*MODE_NAMES,*support):
                h=preds[preds.model==mode].reset_index(drop=True);assert np.array_equal(h[['layout','root','row']].values,dev.index[['layout','root','row']].values)
                assert np.array_equal(h.relocked,dev.success.numpy())
                if mode in MODE_NAMES:
                    cp=torch.load(folder/(mode+'.pt'),map_location='cpu',weights_only=True)
                    net=JumpOutcome(cp['input_width'],mode,cp['width']).eval();net.load_state_dict(cp['state'])
                    got=net(dev.x)[0].sigmoid().numpy()
                else:got=support[mode]
                error=float(np.max(np.abs(np.asarray(got)-h.probability.to_numpy())))
                assert error<5e-6,(seed,mode,error)
                prob_errors[f'{seed}/{mode}']=error
    nets,_=load_models(False)
    # Use the config and t0 only for ranking; open physical cases after every choice has been made.
    score=pd.concat([predictions(P/'export/dev'/m,nets,None) for m in ('dev_00','dev_01')],ignore_index=True)
    assert len(score)==3072
    keys=G+['method','action_slot'];compare_frame(score,native/'time_zero_scores.csv.gz',keys)
    raw=pd.read_csv(native/'time_zero_scores.csv.gz',float_precision='round_trip');diff=float(np.max(abs(raw.sort_values(keys).score.values-score.sort_values(keys).score.values)))
    chosen={k:selection(rows) for k,rows in score.groupby(G)}
    choices=pd.DataFrame([dict(**dict(zip(G,k)),method=name,selected=a,ties=t) for k,v in chosen.items() for name,(a,_,t) in v.items()]);compare_frame(choices,native/'time_zero_choices.csv',G+['method'])
    truth=pd.read_csv(native/'physical_conditions.csv.gz',float_precision='round_trip')
    with tempfile.TemporaryDirectory() as temp:
        out=Path(temp);summary=evaluate(score,truth,out,chosen)
        for name in ('groups.csv','conditions.csv.gz','paired_conditions.csv.gz','fixed_alpha_measured_subsets.csv','by_map_and_side.csv','paired_by_map_and_side.csv'):
            a,b=[pd.read_csv(d/name,float_precision='round_trip') for d in (out,native)];pd.testing.assert_frame_equal(a,b,check_dtype=False,rtol=1e-10,atol=1e-10)
    assert summary==read(native/'receipt.json')['outputs']
    assert paired.fixture()['adjacent_empirical_float32_endpoint_reconciled']
    # Original paired code writes to its given fit folder. Stage only its small inputs inside a temporary tree.
    import shutil
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp);tf=root/'model/formal_fit';tf.mkdir(parents=True)
        (root/'export').symlink_to(P/'export',target_is_directory=True)
        for seed in (61123,61124,61125):(tf/f'seed_{seed}').symlink_to(fit/f'seed_{seed}',target_is_directory=True)
        for f in fit.glob('development_by_*.csv'):shutil.copyfile(f,tf/f.name)
        paired.summarize(tf)
        for n in ('development_paired_primary_seed.csv','development_paired_stability_seeds.csv'):
            assert (tf/n).read_bytes()==(fit/n).read_bytes()
    print(json.dumps(dict(roots=summary['roots'],complete_roots=summary['complete_roots'],physical_options=len(truth),scored_separate_forecasts=len(score),
        decisions=len(chosen),method_choices=len(choices),compared_executions=summary['all_tasks'],probability_max_cpu_difference=prob_errors,
        time_zero_scores_max_abs_diff=diff,paired_tables_reproduced_byte_for_byte=True),indent=2))
if __name__=='__main__':main()

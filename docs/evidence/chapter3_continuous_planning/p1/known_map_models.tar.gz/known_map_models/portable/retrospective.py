"""Replay the measured-future diagnosis against its archived rows. It reads actual handback states."""
import sys,tempfile,shutil,types,contextlib,io
from pathlib import Path
import numpy as np,pandas as pd
import replay as r
from branch import BranchGeometry
folder=r.ROOT/'dev_true_handoff'
def main():
    # The official calculation reads physical config absolute paths. Map only the known route and map assets locally.
    with np.load(r.P/'portable/predicted_exit_geometry.npz') as first,np.load(r.P/'portable/measured_extra_geometry.npz') as extra:
        ids=np.r_[first['row_ids'],extra['row_ids']];ix=np.argsort(ids);bank={'s':first['s']}
        for key in ('xy','heading','curvature'):
            bank[key]=r.SelectedRows(np.concatenate([first[key],extra[key]])[ix],ids[ix])
    source=(folder/'diagnose.py').read_text().replace('from frozen_exit_value import FrozenExits, mapped_arrays','').replace('from exit_value import ExitValue, KnownMap','').replace("np.load(cfg['approach_file'])","np.load(P/'actions/approaches.npz')")
    env=dict(__file__=str(folder/'diagnose.py'),__name__='retrospective_archive',FrozenExits=BranchGeometry,mapped_arrays=lambda _:bank,KnownMap=r.KnownMap,ExitValue=r.ExitValue)
    with tempfile.TemporaryDirectory() as tmp:
        dest=Path(tmp);shutil.copyfile(folder/'protocol.json',dest/'protocol.json')
        exec(compile(source,str(folder/'diagnose.py'),'exec'),env)
        env['OUT']=dest
        with contextlib.redirect_stdout(io.StringIO()):env['main']()
        shutil.copyfile(folder/'intermediate_protocol.json',dest/'intermediate_protocol.json')
        intermediate={'__file__':str(folder/'intermediate.py'),'__name__':'archive_intermediate'}
        exec(compile((folder/'intermediate.py').read_text(),str(folder/'intermediate.py'),'exec'),intermediate)
        intermediate['OUT']=dest
        with contextlib.redirect_stdout(io.StringIO()):intermediate['main']()
        files=list(dest.glob('*.csv'))+list(dest.glob('*.csv.gz'))
        for file in files:
            a,b=[pd.read_csv(k,float_precision='round_trip') for k in (file,folder/file.name)]
            pd.testing.assert_frame_equal(a,b,check_dtype=False,atol=1e-12,rtol=1e-12)
        print('Measured-future diagnosis matched',len(files),'result tables.')
if __name__=='__main__':main()

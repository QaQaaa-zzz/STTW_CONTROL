import numpy as np
class BranchGeometry:
    def branch_ids(self,geometry,position,progress=None):
        """Include x+5 cm commitment; future state uses projection onto the known approach."""
        approach=self.approach[geometry]
        edge=np.searchsorted(approach[:,0],position[0]+.05)
        if progress is None:
            delta=np.diff(approach,axis=0)
            w=np.clip(((position[:2]-approach[:-1])*delta).sum(1)/(delta**2).sum(1),0,1)
            best=np.argmin(((approach[:-1]+w[:,None]*delta-position[:2])**2).sum(1))
            progress=(1-w[best])*self.bank['s'][best]+w[best]*self.bank['s'][best+1]
        join=min(self.bank_len-1,max(int(edge),int(np.searchsorted(self.bank['s'],progress))+1))
        return len(self.approach)+(geometry*3+np.arange(3))*self.bank_len+join

# 第三章已知地图的起跳预测与出发选路

本包冻结 2026-11-23 的 P1 结果。六张 TRAIN 地图有 3,456 个物理前缀，两张 DEV 地图有 1,152 个。每图 12 个起点，每起点 16 个动作，每动作有 −5、0、+5 N 三种隐藏侧推。对每个起点和门先选一次入口，三种推力共享同一选择。近、远门位于 x=12.7 和 15.0 米。地图、根和仿真通道存在重复测量。两张开发图的分数和区间描述这两张固定图。

## 查看

- 实际轨迹从 `external/xy.html` 打开。它链接原始外盘的全部 96 张图。`external/xy_files.csv` 给每图绝对路径。起点 1325、1328 的近左门 PNG 已随包附在 `actions/amortized_exit/development_entry/xy/`。`figures.csv` 列出全部 96 个根与门组合，`sources.csv.gz` 将 552 个共享曲线显示项映射回实际轨迹和参考资料。
- `maps/training_development_geometry.csv` 含各图的 16 cm 高台、墙盒、粗糙地形参数与随机种子。六张训练图与两张开发图的 `world.json`、栅格和 XML 均已保留。开发图还附从实际 MuJoCo MJB 提取并对照 world.json 检查的墙盒坐标。
- `model/formal_fit` 含 61123、61124、61125 三个种子的均值及三成分模型权重、逐行预测、优化记录和原开发统计。主种子为 61123，每种模型 22,456 个参数，每次 540 次优化。`paired_roundoff_interruption` 是原配对统计遇到经验概率浮点末位越界时留下的原始日志和阶段记录。修复后的判据和合成回归测试在 `model/paired_development_calibration.py`。
- `actions/amortized_exit/development_entry/` 下，`time_zero_scores.csv.gz` 为打开物理结果前生成的 3,072 条分数。`time_zero_choices.csv` 给每个起点和门的五种部署规则选择。两种事后上限出现在 `groups.csv`。`conditions.csv.gz`、`paired_conditions.csv.gz`、`physical_conditions.csv.gz` 和 `mixture_vs_old_cases.csv.gz` 可追到每个门向和物理条件。冻结的模型、选择协议和数据身份见同目录上级的 `development_entry_protocol.json`、`development_entry_registration.json` 与本目录 `receipt.json`。
- 288 个计分条件来自 24 根 × 四门 × 三种推力。旧规则完成 175，均值旧5/全16分别 162/158，三成分旧5/全16分别 154/139。事后在旧5/全16里选一个共享入口的完成界分别为 194 和 [220,222]。8 条虚拟门条件缺少实测后段，由源程序保留 0/1 界。每个实际物理条件只按规定门侧的已执行固定后缀计分。该结果是对有限动作候选的离线任务回评。连续规划器的实时发布、独立盲测和实车结果属于另行验证的命题。

## 在归档目录内复算

下面两条命令在解压后的 `known_map_models/` 内执行。环境版本在 `provenance.json`。第一条校验所有内容，第二条只用 CPU，从八项原始 t0 观测和权重开始预测，用归档中的分支参考和门侧评分，再读后段物理成绩重算完整结果表。离线回放无需连接原机目录。

```sh
sha256sum -c MANIFEST.sha256
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES='' python portable/replay.py
```

程序分别复算三个种子的两神经概率和两个经验方法概率，验证 3×4×1152 条结果；用开发两图的共同随机数为主种子生成均值及 16 个联合状态样本，重算全部 3,072 个入口分数和 480 个方法选择，再按实测逐条件表核对配对、未知后缀边界及六张汇总表；最后用原程序的 10,000 次图内根聚类重采样逐字节核对两张配对区间表。`portable/verification.json` 为实跑记录。原始工作站、软件版本、程序出处、配置和检查点身份均可追溯。

`portable/replay.py` 保留了原始预测、选路和计分函数，`portable/branch.py` 保留原有的分支行号选择函数。读入适配将原始绝对配置路径对到包内的同一文件；从冻结 MJB 已核对的墙盒和同一栅格恢复同样的地图量；仅装入这次两张固定图上预测状态实际使用的 576 行几何。其 x/y、切向、曲率、弧长均从原 50,414 行路线库逐位取出。`shared/route_bank_receipt.json` 记载原库 SHA-256 和生成方式。此紧凑子集用于复算包内所有任务，对其他候选或地图另需相应的路线。原始开发代码、数据导出和重评分代码保留在其原始相对位置，项目实现摘录在 `worktree_source/`。本包不包含完整物理仿真环境。

若需另行复拟合，在取得项目共享 GPU 锁后可使用以下注册的单种子入口；另外两个种子替换为 61124、61125。输出目录选归档外的位置。论文结果对应包内已冻结的 CUDA 权重。

```sh
PYTHONPATH="$PWD/worktree_source/learning/src" python model/fit_outcome.py --data export --split export/formal_train_dev.csv --out /tmp/ch3_p1_seed_61123 --seed 61123 --steps 540 --batch-size 128 --learning-rate .001 --device cuda
```

## 已知实际落地的追加诊断

`actions/amortized_exit/dev_true_handoff/` 保存观测到正式入口成绩后的诊断协议、实现、候选分数与配对病例。诊断使用每个动作三次真实未来的复锁情况和落地状态，再决定入口；只用于定位误差。额外的中间步骤用各候选实际三次复锁比例替换预测的复锁概率，同时沿用预测的落地状态价值。三种输入的完成次数依次为 139、157、204/288。替换顺序影响归因。所有样本的门侧与物理计分与主结果相同。CPU 上执行 `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python portable/retrospective.py` 可用真实目标和原始评分函数复算其数值。包内额外保留来自实测落地、预测回放部分未使用的 86 个原出口参考行。

## 原始数据位置

`external/trajectories.csv.gz` 列出这八张图 9,216 个唯一物理通道的原始轨迹绝对路径、地图、起点、动作、隐藏侧推和出口。原始十图全采集 11,520 通道。封包时逐项检查 9,216 个轨迹路径均可访问。每张纳入地图的 `export/<role>/<map>/suffix_index.csv` 进一步列出查询记录的原文件及行号、实际控制、后缀分支和轨迹。随包附窄表、真实复锁目标及 20 ms 前速度历史，两个外部保留阶段的观测和结果均排除。图可以在外盘挂载后查看；返回到逐毫秒仿真和重新绘制全部 96 张图需要这些原始轨迹。

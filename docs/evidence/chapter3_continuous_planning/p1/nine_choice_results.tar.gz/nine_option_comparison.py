"""Freeze prospective nine-entry choices and score separately against archived fixed-side exits."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import torch

import augmentation_fit as fit

R=fit.R;P=fit.P
NEW=P/'continuous_interpolation'
OLD=P/'actions/amortized_exit/development_entry'
sys.path[:0]=[str(P/'model'),str(P/'actions/amortized_exit'),
              '/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src']
from run_downstream_dev import decision_rows,predicted_states,FAMILIES
from jump_outcome import Dataset,JumpOutcome,MODE_NAMES
from frozen_exit_value import FrozenExits,mapped_arrays
from exit_value import KnownMap,ExitValue

KEY=['map_id','root','gate_x','side']
SID=['map_id','root','action_slot','method','seed','gate_x','side']
GATES=[(12.7,1),(12.7,-1),(15.,1),(15.,-1)]

def predictions(arm,seed):
    trainfolder=P/'export' if arm=='original' else fit.MERGED
    root=fit.MODEL/'formal_fit' if arm=='original' else R/'augmented_fit'
    train=Dataset.join([Dataset.load(trainfolder/'train'/m) for m in fit.PLAN['maps_train']])
    assert len(train.x)==(3456 if arm=='original' else 5184) and train.index.root.nunique()==72
    nets={}
    for method in MODE_NAMES:
        ckpt=torch.load(root/f'seed_{seed}'/(method+'.pt'),map_location='cpu',weights_only=True)
        model=JumpOutcome(ckpt['input_width'],method,ckpt['width'])
        model.load_state_dict(ckpt['state']);nets[method,str(seed)]=model.eval()
    methods=list(nets)+[(m,'shared') for m in FAMILIES]
    est=ExitValue(P/'actions/amortized_exit/train_model.npz')
    tables=[]
    for family,location in [('old',P),('new',NEW)]:
        for name in ('dev_00','dev_01'):
            ds,_=decision_rows(location/'export/dev'/name,False)
            cfg=json.loads(((P/'batches' if family=='old' else NEW)/name/'physical/resolved_config.json').read_text())
            assert cfg['platform_online']['latency_ticks']=={'start':3,'departure':3}
            world=KnownMap(P/'maps'/name)
            engine=FrozenExits.__new__(FrozenExits)
            with np.load(cfg['paired_departures']['approach_file']) as f:engine.approach=f['xy']
            engine.bank=mapped_arrays(cfg['paired_departures']['route_bank']);engine.bank_len=len(engine.bank['s'])
            # Keep the archived neural forward-batch size. Only the relevant old slots need an exit score.
            particles,opts=predicted_states(ds,nets,train,methods)
            if family=='old':particles=[p for p in particles if p['action_slot'] in (0,1,4)]
            columns=['map_id','root','action_slot','method','seed']
            records=[]
            for i in range(0,len(particles),96):
                part=particles[i:i+96]
                ids=np.stack([engine.branch_ids(p['geometry'],p['q']) for p in part])
                q,v,prev,t=[np.stack([r[k] for r in part]) for k in ['q','v','prev','query_s']]
                meta=pd.DataFrame([{k:p[k] for k in columns} for p in part])
                for gx,side in GATES:
                    rows=ids[:,0 if side==1 else 2]
                    refs=[engine.bank[k][rows] for k in ('xy','heading','curvature')]
                    records.append(meta.assign(gate_x=gx,side=side,exit_probability=est.score(world,q,v,prev,t,gx,side,side,*refs)))
            cond=pd.concat(records).groupby(SID,as_index=False).exit_probability.mean()
            base=pd.DataFrame([dict(**{k:tag[k] for k in columns},gate_x=gx,side=side,p_relock=p,alpha=tag['alpha'])
                for tag,p,_ in opts.values() if family=='new' or tag['action_slot'] in (0,1,4) for gx,side in GATES])
            table=base.merge(cond,on=SID,how='left',validate='one_to_one');assert table.loc[table.exit_probability.isna(),'p_relock'].lt(1e-12).all()
            table['score']=table.p_relock*table.exit_probability.fillna(0.);table['family']=family;tables.append(table)
    return pd.concat(tables,ignore_index=True)

def freeze(arm,seed,dest):
    ids=json.loads((R/'augmentation_identity.json').read_text());assert fit.registered()==ids
    scores=predictions(arm,seed)
    parity={}
    if arm=='original' and seed==61123:
        files={'old':OLD/'time_zero_scores.csv.gz','new':NEW/'pre_action_scores.csv.gz'}
        assert fit.digest(files['new'])==json.loads((NEW/'prediction_receipt.json').read_text())['hashes'][files['new'].name]
        oldrec=json.loads((OLD/'receipt.json').read_text())
        assert oldrec['seed']==seed and oldrec['exit_model_sha256']==ids['actions/amortized_exit/train_model.npz']
        for m in MODE_NAMES:assert oldrec['model_hashes'][m]==ids[f'model/formal_fit/seed_{seed}/{m}.pt']
        for family,path in files.items():
            cache=pd.read_csv(path,dtype={'seed':str},float_precision='round_trip')
            if family=='old':cache=cache[cache.action_slot.isin([0,1,4])].assign(seed=str(seed)).rename(columns={'conditional_exit_probability':'exit_probability'})
            ours=scores[scores.family.eq(family)&scores.method.isin(cache.method.unique())]
            rows=ours.merge(cache[SID+['score','exit_probability','p_relock']],on=SID,validate='one_to_one',suffixes=('','_archived'))
            assert len(rows)==len(ours)==len(cache)
            # Both runs must describe the same estimator and numerical rankings. For original use the saved doubles.
            maxerr={}
            for k in ['score','exit_probability','p_relock']:
                np.testing.assert_allclose(rows[k],rows[k+'_archived'],rtol=1e-5,atol=1e-6,equal_nan=True)
                maxerr[k]=float((rows[k]-rows[k+'_archived']).abs().max())
            parity[family]=dict(rows=len(rows),max_abs_difference=maxerr,source=str(path),sha256=fit.digest(path))
            idx=scores.reset_index().merge(cache[SID+['score','p_relock','exit_probability']],on=SID,suffixes=('','_cache'))
            idx=idx[idx.family.eq(family)].set_index('index')
            for k in ['score','p_relock','exit_probability']:scores.loc[idx.index,k]=idx[k+'_cache']
    scores.to_csv(dest/'pre_action_scores.csv.gz',index=False)
    groups=KEY+['method','seed']
    frozen=[]
    for menu in ['registered_alpha','alpha0']:
        fixed=scores[scores.family.eq('old') & scores.action_slot.eq(np.where(scores.side.eq(1),4 if menu=='registered_alpha' else 1,0))]
        pool=pd.concat([fixed.assign(incumbent=True),scores[scores.family.eq('new')].assign(incumbent=False)])
        assert pool.groupby(groups).size().eq(9).all()
        if menu=='alpha0':assert pool.alpha.eq(0).all()
        winner=pool.sort_values(['score','incumbent','action_slot'],ascending=[False,False,True],kind='stable').groupby(groups,as_index=False).head(1)
        winner=winner.merge(fixed[groups+['action_slot','alpha','score']].rename(columns={'action_slot':'fixed_slot','alpha':'fixed_alpha','score':'fixed_score'}),on=groups,validate='one_to_one')
        frozen.append(winner.assign(menu=menu))
    choices=pd.concat(frozen,ignore_index=True);assert len(choices)==768
    choices.to_csv(dest/'pre_action_choices.csv',index=False)
    weight_parent=fit.MODEL/'formal_fit' if arm=='original' else R/'augmented_fit'
    note=dict(stage='choices_frozen',arm=arm,seed=seed,candidate_rows=len(scores),root_gate_method_choices=len(choices),
        weights={m:fit.digest(weight_parent/f'seed_{seed}'/(m+'.pt')) for m in MODE_NAMES},
        scorer_sha256=ids['actions/amortized_exit/train_model.npz'],parity=parity,choices_sha256=fit.digest(dest/'pre_action_choices.csv'),
        scoring='Pre-action fields and map only, frozen gate-side exit success times relock probability. Mean 1, mixture and empirical 16 conditional draws, common seed 732611. No physical outcome data on freeze path.')
    (dest/'choice_receipt.json').write_text(json.dumps(note,indent=2)+'\n')

def old_margin(rows):
    pre=P/'actions/continuous_examples/continuous_entry_event_exit';xy=pre/'screen_capacity/xy'
    cache=pd.read_csv(xy/'margin_paths.csv')[['source','actual_min_clearance_m']].rename(columns={'source':'path'})
    missing=rows[(rows.lower==1)&~rows.path.isin(cache.path)]
    if not missing.empty:
        import importlib.util,mujoco
        helper=pre/'reference_controls/check.py'
        sp=importlib.util.spec_from_file_location('native_margin',helper);old=importlib.util.module_from_spec(sp);sp.loader.exec_module(old)
        out=[]
        for name,g in missing.groupby('map_id'):
            folder=P/'batches'/name/'physical';q=old.FrozenExits(folder,device='cpu',load_route_bank=False).query
            m=mujoco.MjModel.from_binary_path(str(folder/'terrain.mjb'))
            bodies=[m.geom(j).name or f'geom_{j}' for j in range(m.ngeom) if m.geom_bodyid[j]>0 and (m.geom_contype[j] or m.geom_conaffinity[j])]
            walls=[m.geom(j).name for j in range(m.ngeom) if m.geom(j).name.startswith('planning_obstacle_')]
            meta=pd.read_csv(P/'export/dev'/name/'suffix_index.csv').set_index('trajectory')
            for path in g.path.unique():
                r=meta.loc[path]
                with np.load(path) as raw,np.load(r.query_file) as obs:
                    assert np.array_equal(raw['qpos'][int(r.query_tick)],obs['qpos'][int(r.query_file_row)])
                    out.append(dict(path=path,actual_min_clearance_m=old.actual_clearance(raw,int(r.query_tick),q,bodies,walls)['actual_min_clearance_m']))
        cache=pd.concat([cache,pd.DataFrame(out)],ignore_index=True)
    return cache

def compare_training_arms(original, augmented):
    keys=['menu','method','seed',*KEY,'force']
    match=augmented.merge(original,on=keys,suffixes=('_aug','_orig'),validate='one_to_one')
    assert len(match)==len(original)==len(augmented)
    same=(match.family_aug==match.family_orig)&(match.action_slot_aug==match.action_slot_orig)
    match['same_entry']=same
    records=[]
    scopes=[('gate','lower','upper'),('margin','margin_lower','margin_upper'),
            ('matched_gate','strict_lower','strict_upper'),('matched_margin','matched_margin_lower','matched_margin_upper')]
    for target,lo,hi in scopes:
        match[target+'_delta_lo']=(match[lo+'_aug']-match[hi+'_orig']).mask(same,0)
        match[target+'_delta_hi']=(match[hi+'_aug']-match[lo+'_orig']).mask(same,0)
        for (menu,method,seed),v in match.groupby(['menu','method','seed']):
            for (m,side),g in [(('both',0),v),*[(('both',s),f) for s,f in v.groupby('side')],
                               *[((mp,0),f) for mp,f in v.groupby('map_id')],*v.groupby(['map_id','side'])]:
                lower,upper=g[target+'_delta_lo'],g[target+'_delta_hi']
                records.append(dict(menu=menu,method=method,seed=seed,map_id=m,side=side,target=target,n=len(g),
                    same_entry=int(g.same_entry.sum()),original_lo=int(g[lo+'_orig'].sum()),original_hi=int(g[hi+'_orig'].sum()),
                    augmented_lo=int(g[lo+'_aug'].sum()),augmented_hi=int(g[hi+'_aug'].sum()),
                    rescued_lo=int(lower.eq(1).sum()),rescued_hi=int(upper.eq(1).sum()),
                    lost_lo=int(upper.eq(-1).sum()),lost_hi=int(lower.eq(-1).sum()),
                    net_lo=int(lower.sum()),net_hi=int(upper.sum())))
    fields=keys+['family_orig','action_slot_orig','family_aug','action_slot_aug','same_entry']
    fields.extend([t+suffix for t,_,_ in scopes for suffix in ('_delta_lo','_delta_hi')])
    return match[fields],pd.DataFrame(records)

def score(arm,seed,dest):
    receipt=json.loads((dest/'choice_receipt.json').read_text());assert receipt['choices_sha256']==fit.digest(dest/'pre_action_choices.csv')
    choices=pd.read_csv(dest/'pre_action_choices.csv',dtype={'seed':str})
    old=pd.read_csv(OLD/'physical_conditions.csv.gz').rename(columns={'source_trajectory':'path'});old=old[old.action_slot.isin([0,1,4])]
    old=old.merge(old_margin(old),on='path',how='left',validate='many_to_one')
    assert old.loc[old.lower.eq(1),'actual_min_clearance_m'].notna().all()
    old['margin_lower']=(old.lower.eq(1)&old.actual_min_clearance_m.gt(.05330585315823555)).astype(int)
    old['margin_upper']=old.margin_lower.where(old.lower.eq(old.upper),1)
    new=pd.read_csv(NEW/'margin_gate_cases.csv.gz');cols=KEY+['action_slot','force','lower','upper','margin_lower','margin_upper','path','actual_min_clearance_m']
    truth=pd.concat([old[cols].assign(family='old'),new[cols].assign(family='new')])
    # Use original registered strict pair flags (uncertified physical prefixes keep interval bounds).
    from score_rank_audit import strict_outcomes
    arms=pd.concat([pd.read_csv(P/'export/dev'/m/'suffix_index.csv') for m in ('dev_00','dev_01')])
    certified_old=strict_outcomes(old,arms)
    cert=certified_old[cols[:6]+['strict_lower','strict_upper']].assign(family='old')
    cert=pd.concat([cert,new[cols[:6]+['strict_lower','strict_upper']].assign(family='new')])
    truth=truth.merge(cert,on=['family',*KEY,'action_slot','force'],validate='one_to_one')
    truth['matched_margin_lower']=truth.margin_lower.where(truth.strict_lower.eq(truth.strict_upper),0)
    truth['matched_margin_upper']=truth.margin_upper.where(truth.strict_lower.eq(truth.strict_upper),1)
    joined=[];oracles=[];ids=KEY+['force'];groups=['menu','method','seed']
    for menu,chosen in choices.groupby('menu'):
        fx=old[old.action_slot.eq(np.where(old.side.eq(1),4 if menu=='registered_alpha' else 1,0))][KEY+['action_slot']].drop_duplicates().assign(family='old')
        eligible=pd.concat([fx,new[KEY+['action_slot']].drop_duplicates().assign(family='new')])
        pool=eligible.merge(truth,on=KEY+['action_slot','family'],validate='one_to_many')
        assert len(pool)==2592
        for s,lo,hi in [('gate','lower','upper'),('margin','margin_lower','margin_upper'),('matched_gate','strict_lower','strict_upper'),('matched_margin','matched_margin_lower','matched_margin_upper')]:
            agg=pool.groupby(KEY+['family','action_slot'])[[lo,hi]].sum().groupby(KEY).max().reset_index()
            oracles.append(agg.rename(columns={lo:'oracle_lo',hi:'oracle_hi'}).assign(menu=menu,target=s))
        a=chosen.merge(truth,on=KEY+['family','action_slot'],validate='many_to_many')
        b=fx.merge(truth,on=KEY+['family','action_slot'],validate='one_to_many')
        b=b.drop(columns=['family','action_slot'])
        x=a.merge(b,on=ids,suffixes=('','_fixed'),validate='many_to_one')
        assert x.groupby(['method','seed']).size().eq(288).all()
        joined.append(x)
    x=pd.concat(joined);oracle=pd.concat(oracles)
    x.to_csv(dest/'physical_pairs.csv.gz',index=False);oracle.to_csv(dest/'hindsight_by_root_gate.csv',index=False)
    totals=[]
    for (menu,method,sd),g in x.groupby(groups):
        for target,lo,hi in [('gate','lower','upper'),('margin','margin_lower','margin_upper'),('matched_gate','strict_lower','strict_upper'),('matched_margin','matched_margin_lower','matched_margin_upper')]:
            options=truth[truth.family.eq('new')|truth.action_slot.eq(np.where(truth.side.eq(1),4 if menu=='registered_alpha' else 1,0))]
            options=options.groupby(KEY+['family','action_slot'])[[lo,hi]].sum().reset_index()
            selected=g.groupby(KEY+['family','action_slot'])[[lo,hi]].sum().reset_index()
            vs=options.merge(selected,on=KEY,validate='many_to_one',suffixes=('','_sel'))
            others=vs[(vs.family!=vs.family_sel)|(vs.action_slot!=vs.action_slot_sel)]
            regret=others.assign(gap_lo=(others[lo]-others[hi+'_sel']).clip(lower=0),gap_hi=(others[hi]-others[lo+'_sel']).clip(lower=0)).groupby(KEY)[['gap_lo','gap_hi']].max().reset_index()
            for dim,f in [(('both',0),g),*[((m,0),j) for m,j in g.groupby('map_id')],*[(('both',int(side)),j) for side,j in g.groupby('side')],*g.groupby(['map_id','side'])]:
                m,side=dim;same=f.incumbent
                low=(f[lo]-f[hi+'_fixed']).mask(same,0);high=(f[hi]-f[lo+'_fixed']).mask(same,0)
                wanted=f[KEY].drop_duplicates().merge(oracle.query('menu==@menu and target==@target'),on=KEY,validate='one_to_one')
                wanted=wanted.merge(regret,on=KEY,validate='one_to_one')
                totals.append(dict(menu=menu,method=method,seed=sd,target=target,map_id=m,side=side,n=len(f),switched=int((~same).sum()),
                    fixed_lo=int(f[lo+'_fixed'].sum()),fixed_hi=int(f[hi+'_fixed'].sum()),selected_lo=int(f[lo].sum()),selected_hi=int(f[hi].sum()),
                    rescued_lo=int((low==1).sum()),rescued_hi=int((high==1).sum()),lost_lo=int((high==-1).sum()),lost_hi=int((low==-1).sum()),
                    net_lo=int(low.sum()),net_hi=int(high.sum()),oracle_lo=int(wanted.oracle_lo.sum()),oracle_hi=int(wanted.oracle_hi.sum()),
                    gap_lo=int(wanted.gap_lo.sum()),gap_hi=int(wanted.gap_hi.sum())))
    final=pd.DataFrame(totals);final.to_csv(dest/'task_summary.csv',index=False)
    if arm=='augmented':
        original=pd.read_csv(R/'nine_option'/f'original_{seed}'/'physical_pairs.csv.gz',dtype={'seed':str})
        matched,summary=compare_training_arms(original,x)
        matched.to_csv(dest/'training_arm_pairs.csv.gz',index=False)
        summary.to_csv(dest/'training_arm_summary.csv',index=False)
    print(final.query("map_id=='both' and side==0 and target in ['gate','margin']")[['menu','method','target','n','fixed_lo','selected_lo','selected_hi','rescued_lo','lost_lo','gap_lo','gap_hi']].to_string(index=False))

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('stage',choices=['freeze','score']);cli.add_argument('--arm',choices=['original','augmented'],default='original')
    cli.add_argument('--seed',type=int,choices=[61123,61124,61125],default=61123);args=cli.parse_args();torch.set_num_threads(1)
    sys.path.append(str(NEW))
    dst=R/'nine_option'/f'{args.arm}_{args.seed}'
    if args.stage=='freeze':
        dst.mkdir(exist_ok=True,parents=True);freeze(args.arm,args.seed,dst)
    else:score(args.arm,args.seed,dst)

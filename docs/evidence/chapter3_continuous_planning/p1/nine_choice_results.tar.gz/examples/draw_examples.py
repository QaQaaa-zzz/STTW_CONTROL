"""Rebuild both DEV nine-option figures from the accompanying CSV, JSON, and NPZ."""
import argparse
import json
from pathlib import Path
from subprocess import check_output

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties, fontManager
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
EXAMPLES = [('rescued', 'dev_01', 1342, 15., 1), ('lost', 'dev_00', 1325, 12.7, -1)]
COLORS = {'fixed':'#156089', 'chosen':'#b84620'}

def ref_piece(ref, start, end):
    x = ref[:, 0]
    lo, hi = max(start, x[0]), min(end, x[-1])
    if hi <= lo:
        return ref[:0]
    y = np.interp([lo, hi], x, ref[:,1])
    return np.vstack(([lo, y[0]], ref[(x > lo) & (x < hi)], [hi,y[1]]))

def export(p):
    # Plot only rows selected in the frozen primary analysis; full-frame actual XY is retained.
    pairs = pd.read_csv(HERE.parent/'physical_pairs.csv.gz').query("menu=='registered_alpha' and method=='mixture3'")
    scores = pd.read_csv(HERE.parent/'pre_action_scores.csv.gz').query("method=='mixture3'")
    maps, tracks, rows = {}, {}, []
    with np.load(p/'shared/neutral.npz') as z:
        neutral = z['xy'][0]
    for name, m, root, gate, side in EXAMPLES:
        scene = json.loads((p/'maps'/m/'world.json').read_text())
        maps[m] = dict(walls=scene['terrain']['forbidden_rectangles'],step=scene['terrain']['front_x_m'],goal=scene['goal'])
        case = pairs.query('map_id==@m and root==@root and gate_x==@gate and side==@side')
        assert len(case) == 3 and case.family.eq('new').all()
        for role, suffix, sources, family in [('fixed','_fixed',p,'old'), ('chosen','',p/'continuous_interpolation','new')]:
            index = pd.read_csv(sources/'export/dev'/m/'suffix_index.csv').set_index('trajectory')
            assert index.index.is_unique
            for row in case.itertuples():
                path = getattr(row,'path'+suffix)
                lane = index.loc[path]
                slot = int(row.fixed_slot if role=='fixed' else row.action_slot)
                pred = scores.query('map_id==@m and root==@root and gate_x==@gate and side==@side and action_slot==@slot and family==@family').iloc[0]
                assert int(lane.root)==root and int(lane.action_slot)==slot and lane.arm==('left' if side==1 else 'right')
                assert np.isclose(pred.score, getattr(row, 'fixed_score' if role=='fixed' else 'score'))
                key = f'{name}_{role}_{row.force:+}'
                with np.load(path) as z:
                    xy=z['qpos'][:,:2]
                    t=z['trace'][:,0]
                    assert np.array_equal(xy,z['trace'][:,1:3],equal_nan=True)
                    valid=np.flatnonzero(np.isfinite(xy).all(1))
                    last=xy[valid[-1]]
                    assigned=int(lane.assigned_tick) if lane.physical_target_effective else -1
                    issue_x=xy[3,0]
                    switch_x=xy[assigned,0] if assigned>=0 else np.nanmax(xy[:,0])
                    refs=[ref_piece(neutral,xy[0,0],issue_x),ref_piece(z['reference_xy'],issue_x,switch_x)]
                    if assigned>=0:
                        refs.append(ref_piece(z['published_reference_xy'],switch_x,scene['goal']['x_max_m']))
                    tracks[key+'_ref']=np.concatenate([np.vstack([r,[np.nan,np.nan]]) for r in refs if len(r)])
                    tracks[key+'_xy']=xy
                    # Frozen event definition: first forward crossing at/after native handoff.
                    h=lane.native_handoff_s if np.isfinite(lane.native_handoff_s) else np.inf
                    crossings=np.flatnonzero((xy[:-1,0]<gate)&(xy[1:,0]>=gate)&(t[1:]>=h))
                    crossing=np.nan
                    if len(crossings):
                        i=crossings[0]
                        w=(gate-xy[i,0])/(xy[i+1,0]-xy[i,0])
                        crossing=xy[i,1]+w*(xy[i+1,1]-xy[i,1])
                    outcome=int(getattr(row,'lower'+suffix))
                    assert outcome==int(getattr(row,'upper'+suffix))
                    assert bool(outcome)==bool(lane.verified_relock and .06<=side*crossing<=3.9 and lane.physical_goal and not lane.physical_wall)
                    cleared=int(getattr(row,'margin_lower'+suffix))
                    distance=getattr(row,'actual_min_clearance_m'+suffix)
                    assert cleared==int(outcome and distance>.05330585315823555)
                    rows.append(dict(example=name,map_id=m,root=root,gate_x=gate,side=side,force=row.force,role=role,
                        family=family,slot=slot,alpha=pred.alpha,p_relock=pred.p_relock,conditional_exit_probability=pred.exit_probability,
                        score=pred.score,gate_success=outcome,margin_success=cleared,min_clearance_m=distance,
                        endpoint_x_m=last[0],endpoint_y_m=last[1],last_xy_s=t[valid[-1]],duration_s=t[-1],gate_cross_y_m=crossing,
                        termination=lane.termination,relocked=lane.verified_relock,assigned_tick=assigned,key=key,trajectory=path))
    pd.DataFrame(rows).to_csv(HERE/'examples.csv',index=False)
    (HERE/'map.json').write_text(json.dumps(maps,indent=2)+'\n')
    np.savez_compressed(HERE/'tracks.npz',**tracks)

def draw():
    data=pd.read_csv(HERE/'examples.csv')
    maps=json.loads((HERE/'map.json').read_text())
    with np.load(HERE/'tracks.npz') as z:
        tracks={k:z[k] for k in z}
    font=check_output(['fc-match','-f','%{file}','Noto Sans CJK SC'],text=True)
    fontManager.addfont(font)
    plt.rcParams.update({'font.family':FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':10.5})
    for name,m,root,gate,side in EXAMPLES:
        frame=data[data.example.eq(name)]
        scene=maps[m];goal=scene['goal']
        fig,axes=plt.subplots(3,1,figsize=(12.2,6.4),sharex=True,sharey=True)
        fig.subplots_adjust(left=.064,right=.985,top=.79,bottom=.13,hspace=.72)
        title='一次换路救回过门' if name=='rescued' else '一次换路使三种推力全部失败'
        fig.suptitle(f'{title}　｜　{m}，起点 {root}，'+('远左门' if side==1 else '近右门')+f' x = {gate:g} m',fontsize=17,y=.99)
        handles=[]
        for role,label in [('fixed','原固定'),('chosen','模型选择')]:
            r=frame[frame.role.eq(role)].iloc[0]
            handles.append(Line2D([],[],color=COLORS[role],lw=2.4,marker='o' if role=='fixed' else 'D',ms=5,
                label=f'{label} {r.family}{r.slot}（α={r.alpha:g}），事前分数 {r.score:.4f}'))
        handles.extend([Line2D([],[],color='#383f45',lw=1.25,ls=(0,(3,2)),label='控制器参考线'),
                        Line2D([],[],color='#315a41',lw=2.2,label='指定门口')])
        fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.93),ncol=4,frameon=False,fontsize=9.5)
        seen_x=[];seen_y=[]
        for ax,(force,rr) in zip(axes,frame.groupby('force')):
            ax.axvline(scene['step'],color='#777c82',lw=1.1,ls=':',zorder=1)
            ax.plot([gate,gate],[side*.06,side*3.9],color='#315a41',lw=2,zorder=1)
            for x0,x1,y0,y1 in scene['walls']:
                ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc='#7e6657',ec='#594b43',lw=.5))
            ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],fc='#e5eedf',zorder=0))
            status=[]
            for role in ('fixed','chosen'):
                r=rr[rr.role.eq(role)].iloc[0];xy=tracks[r.key+'_xy'];ref=tracks[r.key+'_ref']
                c=COLORS[role]
                ax.plot(*xy.T,c=c,lw=2.15 if role=='fixed' else 1.55,zorder=4 if role=='chosen' else 3)
                ax.plot(*ref.T,c=c,lw=1.15,ls=(0,(3,2)),alpha=.92,zorder=5)
                ax.plot(r.endpoint_x_m,r.endpoint_y_m,marker='o' if role=='fixed' else 'D',ms=6.5,color=c,mec='white',mew=.7,zorder=7)
                seen_x.append(xy[:,0]);seen_y.extend([xy[:,1],ref[:,1]])
                end={'tracking_domain_exit':'越出跟踪范围','timeout':'超时','goal':'到达终点','forbidden_obstacle_contact':'碰墙'}[r.termination]
                lab='原固定' if role=='fixed' else '所选'
                if r.gate_success:
                    safe='达标' if r.margin_success else '未达标'
                    status.append(f'{lab} 完成，净空 {r.min_clearance_m*100:.2f} cm（{safe}）')
                else:
                    status.append(f'{lab} 未完成（{end}）')
            ax.set_title(f'横推 {force:+d} N　　'+ '　　 '.join(status),loc='left',fontsize=10.3)
            ax.set_ylabel('y（m）');ax.grid(alpha=.18,linewidth=.5);ax.set_aspect('equal',adjustable='box')
            ax.spines[['top','right']].set_visible(False)
        xx=np.concatenate(seen_x);yy=np.concatenate(seen_y)
        axes[-1].set(xlabel='世界 x（m）',xlim=(1.,max(goal['x_max_m'],np.nanmax(xx))+.4),
            ylim=(min(-.95,np.nanmin(yy)-.1),max(.95,np.nanmax(yy)+.1)))
        fig.text(.5,.029,'实线为车体实走轨迹，圆／菱形标记最后实测位置。灰色点线为台阶，棕块为墙，浅绿为终点区。净空要求 > 5.33 cm。',ha='center',fontsize=9.1)
        fig.savefig(HERE/(name+'.png'),dpi=145)
        plt.close(fig)

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--export',type=Path,help='optional: regenerate CSV/NPZ/JSON from a P1 experiment root; normal redraw uses only sibling files')
    a=cli.parse_args()
    if a.export:export(a.export.resolve())
    draw()

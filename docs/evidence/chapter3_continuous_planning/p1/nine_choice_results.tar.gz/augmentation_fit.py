"""Add the newly collected TRAIN prefixes to the original, fixed-budget P1 fitter."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
import pandas as pd

R=Path(__file__).resolve().parent
P=R.parent
MODEL=P/'model'
PLAN=json.loads((MODEL/'fit_preregistration.json').read_text())
MERGED=R/'augmented_export'

def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def registered():
    index={}
    for name in ('jump_outcome.py','fit_outcome.py','fit_preregistration.json','run_downstream_dev.py','development_metrics.py','downstream_preregistration.json'):
        index['model/'+name]=digest(MODEL/name)
    for seed in PLAN['shared_neural']['seeds']:
        for method in ('mean','mixture3'):
            path=MODEL/'formal_fit'/f'seed_{seed}'/(method+'.pt')
            index[str(path.relative_to(P))]=digest(path)
    for path in (P/'actions/amortized_exit/train_model.npz',P/'actions/amortized_exit/exit_value.py',P/'continuous_interpolation/approaches.npz',R/'approaches.npz'):
        index[str(path.relative_to(P))]=digest(path)
    return index

def prefix(folder,role,name,slots):
    frame=pd.read_csv(folder/'prefix_index.csv')
    assert frame.role.eq(role).all() and frame.map_id.eq(name).all() and frame.layout.eq(name).all()
    assert frame.arm.eq('left').all() and len(frame)==12*slots*3 and frame.root.nunique()==12
    assert np.array_equal(frame.row,np.arange(len(frame)))
    assert not frame.duplicated(['root','action_slot','hidden_force_N_grouping_only']).any()
    assert frame.groupby(['root','action_slot']).hidden_force_N_grouping_only.agg(lambda g:set(g)=={-5,0,5}).all()
    assert set(frame.action_slot)==set(range(slots))
    return frame

def merge_train():
    done=json.loads((R/'result.json').read_text())
    assert done['stage']=='complete' and done['role']=='TRAIN' and (done['physical_lanes'],done['prefixes'])==(3456,1728)
    assert registered()==json.loads((R/'augmentation_identity.json').read_text())
    all_roots=set();dev_roots=set()
    for name in PLAN['maps_dev']:
        dst=MERGED/'dev'/name;src=P/'export/dev'/name
        dev_roots.update(prefix(src,'dev',name,16).root)
        dst.parent.mkdir(parents=True,exist_ok=True)
        if not dst.exists():dst.symlink_to(src,target_is_directory=True)
        assert dst.resolve()==src.resolve()
    for name in PLAN['maps_train']:
        old=P/'export/train'/name;extra=R/'export/train'/name;dst=MERGED/'train'/name
        a=prefix(old,'train',name,16);b=prefix(extra,'train',name,8)
        roots=set(a.root);assert roots==set(b.root) and not (all_roots&roots) and not (dev_roots&roots)
        all_roots.update(roots);assert b.alpha.eq(0.).all()
        with np.load(old/'observed_inputs.npz') as first,np.load(extra/'observed_inputs.npz') as second:
            assert np.allclose(first['alpha'],a.alpha) and np.allclose(second['alpha'],b.alpha)
            for k in ['t0_qpos_native','t0_qvel_native']:
                for root in roots:
                    reset=first[k][a[a.root.eq(root)].row.iloc[0]]
                    assert np.all(first[k][a.root.eq(root).to_numpy()]==reset) and np.all(second[k][b.root.eq(root).to_numpy()]==reset)
        dst.mkdir(parents=True,exist_ok=True)
        a=a.assign(source_panel='original_train',source_row=a.row,source_slot=a.action_slot,source_geometry=a.geometry)
        b=b.assign(source_panel='continuous_train',source_row=b.row,source_slot=b.action_slot,source_geometry=b.geometry,
                   action_slot=b.action_slot+16,geometry=b.geometry+14)
        index=pd.concat([a,b],ignore_index=True);index['row']=np.arange(len(index));index.to_csv(dst/'prefix_index.csv',index=False)
        for name_z in ['observed_inputs.npz','measured_targets.npz']:
            with np.load(old/name_z) as first,np.load(extra/name_z) as second:
                assert set(first.files)==set(second.files)
                merged={}
                for key in first.files:
                    x,y=first[key],second[key]
                    assert x.shape[0]==len(a) and y.shape[0]==len(b) and x.shape[1:]==y.shape[1:] and x.dtype==y.dtype
                    merged[key]=np.concatenate([x,y])
            np.savez_compressed(dst/name_z,**merged)
    assert (len(all_roots),len(dev_roots))==(72,24)
    receipt=dict(train_roots=72,dev_roots=24,old_prefixes=3456,new_prefixes=1728,merged_prefixes=5184,
                 split=str(P/'export/formal_train_dev.csv'),members='All same-map old rows then all additional rows in each of six maps; data-source ids are metadata only.')
    (MERGED/'merge_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')

def fit():
    assert json.loads((MERGED/'merge_receipt.json').read_text())['merged_prefixes']==5184
    assert registered()==json.loads((R/'augmentation_identity.json').read_text())
    for seed in PLAN['shared_neural']['seeds']:
        flags=PLAN['shared_neural'];out=R/'augmented_fit'
        command=[sys.executable,str(MODEL/'fit_outcome.py'),'--data',str(MERGED),'--split',str(P/'export/formal_train_dev.csv'),
            '--out',str(out/f'seed_{seed}'),'--steps',str(flags['updates']),'--batch-size',str(flags['batch_size']),
            '--seed',str(seed),'--learning-rate',str(flags['learning_rate']),'--device','cuda','--tensorboard-root',str(out/'tensorboard')]
        subprocess.run(command,check=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('stage',choices=['identity','merge','fit']);a=ap.parse_args()
    if a.stage=='identity':print(json.dumps(registered(),indent=2))
    elif a.stage=='merge':merge_train()
    else:fit()

"""Merge six completed TRAIN exports, fit the six augmented models, and compare the nine-entry menus."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from urllib.error import URLError
from urllib.request import urlopen

import pandas as pd

import augmentation_fit as fit

R=fit.R
WORK=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
OUT=R/'augmented_fit'
TB=OUT/'tensorboard'
SEEDS=fit.PLAN['shared_neural']['seeds']
CPU=dict(os.environ,CUDA_VISIBLE_DEVICES='',JAX_PLATFORMS='cpu',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONUNBUFFERED='1')
BOARD_UNIT='sttw-ch3-continuous-train-augmentation-tensorboard'

def record(stage,**facts):
    entry=dict(stage=stage,utc=datetime.now(timezone.utc).isoformat(),**facts)
    (OUT/'pipeline_status.json').write_text(json.dumps(entry,indent=2)+'\n')
    print(json.dumps(entry,ensure_ascii=False),flush=True)

def bark(stage,message):
    subprocess.run(['/usr/bin/python3',str(WORK/'learning/scripts/notify_chapter3_job.py'),'--title','第三章：新增训练入口与九选一',
           '--message',message,'--receipt',str(OUT/(stage+'_bark.json'))],check=False)

def check_collection():
    total=0
    for m in fit.PLAN['maps_train']:
        g=pd.read_csv(R/'export/train'/m/'suffix_index.csv')
        assert g.map_id.eq(m).all() and g.alpha.eq(0).all() and g.root.nunique()==12
        assert len(g)==576 and g.lane.nunique()==g.trajectory.nunique()==576
        assert g.groupby(['root','action_slot','hidden_force_N_grouping_only']).arm.agg(set).apply(lambda pair:pair=={'left','right'}).all()
        assert all(Path(f).is_file() for f in g.trajectory)
        total+=len(g)
    assert total==3456

def start_board():
    TB.mkdir(parents=True,exist_ok=True)
    with socket.socket() as sock:
        try:sock.bind(('127.0.0.1',6027))
        except OSError:sock.bind(('127.0.0.1',0))
        port=sock.getsockname()[1]
    url=f'http://127.0.0.1:{port}'
    subprocess.run(['systemd-run','--user','--collect','--unit='+BOARD_UNIT,'--setenv=CUDA_VISIBLE_DEVICES=',
        str(Path(sys.executable).with_name('tensorboard')),'--logdir',str(TB),'--host','127.0.0.1','--port',str(port),'--reload_interval','2'],check=True)
    (OUT/'tensorboard.json').write_text(json.dumps(dict(url=url,unit=BOARD_UNIT,logdir=str(TB)),indent=2)+'\n')
    for _ in range(30):
        try:
            with urlopen(url+'/data/logdir',timeout=2) as answer:
                if Path(json.load(answer)['logdir']).resolve()==TB.resolve():return url
        except URLError:pass
        time.sleep(1)
    raise RuntimeError(f'TensorBoard did not serve the registered log directory: {url}')

def gpu_fit():
    url=start_board()
    record('fitting',seeds=SEEDS,tensorboard=url)
    bark('training_start',f'已取得共享 GPU，六张 TRAIN 图合并后共 5,184 个前缀。开始六次监督拟合。{url}')
    subprocess.run([sys.executable,'-B',str(R/'augmentation_fit.py'),'fit'],check=True)

def check_fit():
    modes=('mean','mixture3')
    for seed in SEEDS:
        folder=OUT/f'seed_{seed}'
        summary=json.loads((folder/'summary.json').read_text())
        assert (summary['device'],summary['steps'],summary['batch_size'],summary['seed'])==('cuda',540,128,seed)
        df=pd.read_csv(folder/'optimization.csv')
        for mode in modes:
            assert (folder/(mode+'.pt')).is_file()
            assert df[df['mode'].eq(mode)].step.tolist()==list(range(1,541))

def check_board_scalars(url):
    for _ in range(10):
        with urlopen(url+'/data/plugin/scalars/tags',timeout=4) as response:tags=json.load(response)
        if all('train/loss' in tags.get(f'seed_{s}/{m}',{}) for s in SEEDS for m in ('mean','mixture3')):return
        time.sleep(1)
    raise RuntimeError('Six completed training loss series are missing from TensorBoard')

def run():
    OUT.mkdir(exist_ok=True)
    try:
        record('checking_physical_collection')
        subprocess.run([sys.executable,'-B',str(R/'augmentation_fit.py'),'merge'],env=CPU,check=True)
        check_collection()
        record('queued_for_fitting',physical_lanes=3456,merged_prefixes=5184)
        gpu=dict(CPU,CUDA_VISIBLE_DEVICES=os.environ.get('CUDA_VISIBLE_DEVICES') or '0')
        subprocess.run([str(WORK/'learning/scripts/gpu_queue.sh'),sys.executable,'-B',str(Path(__file__).resolve()),'--gpu-phase'],env=gpu,check=True)
        # The queue released the shared GPU before scoring.
        check_fit()
        url=json.loads((OUT/'tensorboard.json').read_text())['url']
        record('training_complete',fits=6,updates=3240,tensorboard=url)
        bark('training_complete',f'六个模型、3,240 次更新已完成，GPU 已释放。开始 CPU 九选一开发评分。{url}')
        check_board_scalars(url)
        script=[sys.executable,'-B',str(R/'nine_option_comparison.py')]
        for stage in ('freeze','score'):
            for seed in SEEDS:
                for arm in ('original','augmented'):
                    dest=R/'nine_option'/f'{arm}_{seed}'
                    if arm=='original' and seed==61123:
                        # These choices and results preceded the augmented fit; preserve the original files.
                        rec=json.loads((dest/'choice_receipt.json').read_text())
                        assert rec['choices_sha256']==fit.digest(dest/'pre_action_choices.csv') and (dest/'task_summary.csv').is_file()
                        continue
                    record(stage,arm=arm,seed=seed)
                    subprocess.run(script+[stage,'--arm',arm,'--seed',str(seed)],env=CPU,check=True)
        summary=pd.concat([pd.read_csv(R/'nine_option'/f'augmented_{s}'/'training_arm_summary.csv',dtype={'seed':str}) for s in SEEDS],ignore_index=True)
        # Empirical methods share one support set and one set of conditional draws per training arm.
        key=['menu','method','seed','target','map_id','side']
        summary=summary.drop_duplicates()
        assert not summary.duplicated(key).any() and len(summary)==576
        summary.to_csv(OUT/'nine_option_training_comparison.csv',index=False)
        record('complete',physical_lanes=3456,merged_prefixes=5184,fits=6,updates=3240,seeds=SEEDS,tensorboard=url,
              scores=str(OUT/'nine_option_training_comparison.csv'))
        bark('scoring_complete','三种种子的原训练与扩充训练九选一评分完成；均值、三成分及两种共享经验对照已按门与净空配对。')
    except Exception as error:
        prior=json.loads((OUT/'pipeline_status.json').read_text())
        record('failed',prior=prior,error=str(error))
        bark('error',f'阶段 {prior["stage"]} 失败。{error}。查看 {OUT}/pipeline_status.json 和服务日志。')
        raise

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--gpu-phase',action='store_true',help=argparse.SUPPRESS)
    if cli.parse_args().gpu_phase:gpu_fit()
    else:run()

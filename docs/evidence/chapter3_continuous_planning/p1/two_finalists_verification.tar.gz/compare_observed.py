"""Score the prospective decisions against both measured alternatives on the same three pushes."""
from pathlib import Path
import json
import pandas as pd

folder=Path(__file__).resolve().parent
options=pd.read_csv(folder/'shortlist_before_ground.csv')
decisions=pd.read_csv(folder/'verified_choices.csv')
truth=pd.read_csv(folder.parents[2]/'amortized_exit/development_entry/physical_conditions.csv.gz')
key=['map_id','root','gate_x','side']
base=options[options.incumbent].rename(columns={'action_slot':'original'})[key+['original']]
decisions=base.merge(decisions[key+['selected']],on=key,validate='one_to_one')
assert len(decisions)==96
selected=decisions.merge(truth,left_on=key+['selected'],right_on=key+['action_slot'],validate='one_to_many')
original=truth.rename(columns={'action_slot':'original','lower':'base_lo','upper':'base_hi','physical_wall':'base_wall'})
cases=selected.merge(original[key+['original','force','base_lo','base_hi']],on=key+['original','force'],validate='one_to_one')
assert len(cases)==288
same=cases.selected.eq(cases.original)
cases['net_lo']=(cases.lower-cases.base_hi).mask(same,0)
cases['net_hi']=(cases.upper-cases.base_lo).mask(same,0)
cases['rescued']=cases.net_lo.eq(1);cases['lost']=cases.net_hi.eq(-1)
cases.to_csv(folder/'verified_physical_pairs.csv.gz',index=False)
def summary(d):
    return dict(tasks=len(d),changed=int(d.selected.ne(d.original).sum()),baseline_lo=int(d.base_lo.sum()),
        baseline_hi=int(d.base_hi.sum()),selected_lo=int(d.lower.sum()),selected_hi=int(d.upper.sum()),
        rescued=int(d.rescued.sum()),lost=int(d.lost.sum()),net_lo=int(d.net_lo.sum()),net_hi=int(d.net_hi.sum()))
receipt=dict(overall=summary(cases),by_map_gate_side=[dict(map_id=m,side=int(s),**summary(d)) for (m,s),d in cases.groupby(['map_id','side'])])
(folder/'verified_physical_summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt['overall'])

"""Verify one physically successful near-left re-score and a negative on the same TRAIN start."""
import hashlib
import json
import mujoco
from pathlib import Path
import sys
from types import SimpleNamespace
import numpy as np
import pandas as pd
import torch
R=Path(__file__).resolve().parent
P=R.parents[3]
sys.path[:0]=[str(P/'model'),'/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src']
from frozen_exit_value import FrozenExits,mapped_arrays
import sttw_control.chapter3_continuous_exit as native
from sttw_control.platform_online import velocity_state

def tensor(x):
    return torch.tensor(np.array(x),dtype=torch.float32)

def actual_clearance(raw, first_tick, query, body_names, wall_names):
    times=raw['trace'][first_tick:,0].astype(float)
    qpos=tensor(raw['qpos'][first_tick:])
    assert np.allclose(np.diff(times),.005,rtol=0,atol=1e-6)
    assert np.array_equal(qpos[:,:2].numpy(),raw['trace'][first_tick:,1:3])
    pose=qpos.index_select(1,query.pose_order)
    lo,hi=query.envelope(pose)
    gap=torch.maximum(lo[:,:,None]-(query.center+query.half),
                      (query.center-query.half)-hi[:,:,None]).amax(-1)
    at,body,wall=np.unravel_index(int(gap.argmin()),tuple(gap.shape))
    minimum=float(gap[at,body,wall])
    # Also check sampling only every fourth recorded pose, aligned to the first
    # query just like the frozen 20 ms evaluator.
    stride4=gap[::4].amin((1,2))
    return dict(actual_min_clearance_m=minimum, actual_min_clearance_tick=int(first_tick+at),
                actual_min_clearance_time_s=float(times[at]),actual_min_clearance_after_query_s=float(times[at]-times[0]),
                actual_closest_body_geom=body_names[body],actual_closest_wall=wall_names[wall],
                actual_clearance_gt_zero=minimum>0,actual_clearance_gt_frozen_margin=minimum>query.margin,
                actual_clearance_minus_margin_m=minimum-query.margin,actual_pose_samples=len(times),
                actual_pose_step_s=.005, actual_margin_m=query.margin,
                actual_min_clearance_20ms_m=float(stride4.min()),actual_min_clearance_20ms_time_s=float(times[4*int(stride4.argmin())]))

@torch.inference_mode()
def main():
    torch.set_num_threads(1)
    f=P/'batches/train_00/physical';a=pd.read_csv(P/'export/train/train_00/suffix_index.csv')
    sel=a[a.root.eq(1250)&a.alpha.eq(0)&a.hidden_force_N_grouping_only.eq(0)&a.geometry.isin([0,1])&a.arm.eq('left')].sort_values('geometry')
    assert len(sel)==2
    cfg=json.loads((f/'resolved_config.json').read_text())
    bank=mapped_arrays(cfg['paired_departures']['route_bank'])
    s=tensor(bank['s']);frozen=FrozenExits(f,device='cpu',load_route_bank=False).query
    physics=mujoco.MjModel.from_binary_path(str(f/'terrain.mjb'))
    body_names=[physics.geom(j).name or f'geom_{j}' for j in range(physics.ngeom)
                if physics.geom_bodyid[j]>0 and (physics.geom_contype[j] or physics.geom_conaffinity[j])]
    wall_names=[physics.geom(j).name for j in range(physics.ngeom) if physics.geom(j).name.startswith('planning_obstacle_')]
    solver=native.ContinuousExitPlanner(frozen,SimpleNamespace(s=s),mode='smooth_event',horizon_steps=255,robots_per_chunk=1,fused=False)
    spec=json.loads((P.parent/'chapter3_smooth_exit_dev_20261124/protocol.json').read_text())
    sha=hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest()
    assert sha==spec['source_files'][native.__file__]
    out=[]
    for case in sel.itertuples():
        assert case.verified_relock and case.observed_query and case.physical_target_effective and case.declared_direction==case.online_selected_direction==0
        assert case.suffix_pair_status=='matched_observed_handoff' and case.section_x==12.7
        with np.load(case.query_file) as z,np.load(case.trajectory) as raw:
            i=int(case.query_file_row);t=int(z['tick']);earlier=int(z['previous_tick'])
            assert int(z['lanes'][i])==case.lane and t-earlier==4
            q,v,p,pv=[tensor(z[n][i:i+1]) for n in ['qpos','qvel','previous_qpos','previous_qvel']]
            assert all(np.array_equal(z[n][i],raw[k][j]) for n,k,j in [('qpos','qpos',t),('qvel','qvel',t),('previous_qpos','qpos',earlier),('previous_qvel','qvel',earlier)])
            twist,prev=tensor(z['velocity'][i:i+1]),tensor(z['previous_velocity'][i:i+1])
            assert torch.allclose(velocity_state(q,v),twist,rtol=0,atol=1e-6) and torch.allclose(velocity_state(p,pv),prev,rtol=0,atol=1e-6)
            branches=z['branch_ids'][i];idx=int(branches[0]);assert idx==case.committed_route_bank_row and np.array_equal(bank['xy'][idx],raw['published_reference_xy'])
            rem=float(z['remaining_s']);assert np.isclose(rem,10.-t*.005);sp=tensor(z['body_speed'][i:i+1]);req=tensor(z['requested_speed'][i:i+1])
            tr=raw['trace'];assert tr[:t+1,1].max()<12.7<cfg['ground_handoff']['goal']['x_min_m']
            actual=actual_clearance(raw,t,frozen,body_names,wall_names)
            assert bool(raw['world_flags'][:,2].any())==case.physical_wall
            crossings=np.flatnonzero((tr[:-1,1]<12.7)&(tr[1:,1]>=12.7)&(tr[1:,0]>=case.native_handoff_s))
            gy=None;gt=None
            if len(crossings):
                j=crossings[0];ratio=(12.7-tr[j,1])/(tr[j+1,1]-tr[j,1]);gy=float(tr[j,2]+ratio*(tr[j+1,2]-tr[j,2]));gt=float(tr[j,0]+ratio*(tr[j+1,0]-tr[j,0]))
                assert np.isclose(gy,case.crossing_y_m,atol=1e-6)
        ref=SimpleNamespace(s=s,**{k:tensor(bank[k][branches]) for k in ['xy','heading','curvature']})
        refs=[getattr(ref,k)[:1] for k in ('xy','heading','curvature')]
        section=tensor([12.7]);left=tensor([1.]);old=torch.zeros(1,dtype=torch.long)
        criteria={}
        def capture(frame,event,arg):
            if event!='return':return
            y=frame.f_locals
            if frame.f_code==native._score.__code__:
                criteria.update(gate=bool(y['gate'][0]),crossed=bool(y['crosses'].any()),cross_y=float(y['at'][0]),clear=bool(y['safe'][0]),domain=bool(y['within'][0]),goal_hold=bool(y['held'].any()))
            elif frame.f_code==native.ContinuousExitPlanner._smooth_score.__code__:
                criteria.update(curvature=bool(y['geometry'][0]),peak=float(y['peak'][0]))
        sys.setprofile(capture)
        try:
            score,admit,clearance,window=solver._smooth_score(q,twist,prev,*refs,section,left,tensor([rem]),old,tensor([0.]))
        finally:sys.setprofile(None)
        # The frozen historical shadow ran the opposite gate for geometry 1. Run both its
        # original sign and the benchmark sign at its archived remaining horizon.
        legacy={}
        branch=torch.arange(3).view(1,3)
        for key,side in [('registered',case.target_side),('near_left',1)]:
            choice,any_admit,selected,details=frozen.choose(q,sp,req,ref,branch,section,tensor([side]),old,rem,twist,prev,return_reasons=True)
            legacy[key]=dict(choice=int(choice),any_admitted=bool(any_admit),left_admitted=bool(selected),
                     **{k:x.item() for k,x in details.items()})
        assert (legacy['registered']['choice'],legacy['registered']['any_admitted'],legacy['registered']['left_admitted'])==(case.shadow_choice,case.shadow_any_admitted,case.shadow_incumbent_admitted)
        if not criteria['crossed']:criteria['cross_y']=None
        out.append(dict(root=1250,map='train_00',geometry=int(case.geometry),alpha=0,force_N=0,physical_lane=int(case.lane),declared_direction='left',
            archived_gate_side=int(case.target_side),rescored_gate_side=1,trajectory=case.trajectory,snapshot=case.query_file,route_id=idx,
            first_query_tick=t,previous_tick=earlier,assigned_tick=int(case.assigned_tick),remaining_s=rem,
            physical_verified=bool(case.verified_relock),physical_cross_y_m=gy,crossing_s=gt,physical_goal=bool(case.physical_goal),
            wall=bool(case.physical_wall),physical_termination=case.termination,physical_duration_s=case.duration_s,
            **actual,
            original_assigned_task_done=bool(case.physical_task_done),near_left_physically_done=bool(case.verified_relock and gy is not None and .06<=gy<=3.9 and case.physical_goal and not case.physical_wall),
            smooth_near_left_admitted=bool(admit),smooth_score=float(score),smooth_body_clearance_m=float(clearance),smooth_forecast_window_s=float(window),
            **{'smooth_'+k:v for k,v in criteria.items()},**{'old_rule_'+tag+'_'+k:v for tag,d in legacy.items() for k,v in d.items()}))
    d=pd.DataFrame(out);d.to_csv(R/'reference_cases.csv',index=False)
    receipt=dict(method='Two archived TRAIN fixed-left-exit lanes. Actual execution independently re-scored at near left; row 6 was originally registered at near right. No physics, control rollout, optimization or parameter updates.',scorer_sha=sha,required_clearance_m=frozen.margin,
            old_rule='Original PlatformDepartureQuery.choose at the archived remaining horizon, with original observed current and past twists and fixed-left incumbent. Registered-sign shadow flags and choices checked against saved GPU receiver.',
            smooth_rule='Native CPU float32 smooth_event._smooth_score, 255 steps x 20 ms and actual remaining time, original wheel/vehicle envelope and actual release reference. Gate status and pre-query goal hold zero because vehicle never reached the gate before the query.',
            actual_clearance_rule='Use every stored real 5 ms qpos (first query through true goal or failure frame, inclusive), native joint pose order, frozen MJB obstacle boxes and the same float32 BodyEnvelope for all body and pendulum collision geoms. Per box pair take max over XYZ of max(body_low - wall_high, wall_low - body_high), then min over body, wall, and time. Positive separates the axis-aligned boxes; threshold is strictly greater than margin. This is a sampled box clearance, not exact shape distance nor an intersample guarantee. Also report the 20 ms grid aligned to query tick. No dynamics performed.',
            results=[{k:v for k,v in row.items() if k.startswith('actual_') or k in ['geometry','route_id','physical_lane','archived_gate_side','near_left_physically_done','smooth_near_left_admitted','old_rule_near_left_left_admitted','smooth_gate','smooth_clear','smooth_domain','smooth_goal_hold','smooth_curvature','smooth_peak','smooth_body_clearance_m','physical_cross_y_m']} for row in out])
    (R/'receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n');print(json.dumps(receipt['results'],indent=2))
if __name__=='__main__':main()

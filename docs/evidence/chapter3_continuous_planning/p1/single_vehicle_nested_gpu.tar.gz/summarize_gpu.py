"""Summarize the twelve actual single-vehicle latency receipts; each repeat has the same TRAIN input."""
import json
from pathlib import Path
import pandas as pd

root=Path(__file__).resolve().parent
rows=[]
for method in ('mean','mixture3'):
    for repeat in range(6):
        d=json.loads((root/f'gpu_{method}_{repeat}.json').read_text())
        particles=d['particle_log']; curves=d['candidate_log']
        assert len(curves)==17 and len(particles)==d['particles_evaluated']
        rows.append(dict(model=method,repeat=repeat,temperature=d['temperature'],root=d['root'],
            gate_x=d['gate_x_m'],side=d['gate_side'],curves=len(curves),states=len(particles),
            searched=sum(v['performed_search'] for v in particles),
            gate_ahead=sum(v['gate_ahead'] for v in particles),state_admissions=sum(v['admitted'] for v in particles),
            highest_entry_score=max(v['score'] for v in curves),decision=d['publish_decision'],
            selected=d['selected'],publishable_candidate=d['publishable_candidate'],deadline_met=d['deadline_met'],
            replacement_prepared=d['replacement_prepared'],
            **{k+'_ms':1000*d[k+'_s'] for k in ('total','selection','geometry','jump_and_input','ground')}))
rows=pd.DataFrame(rows)
rows.to_csv(root/'gpu_timing_cases.csv',index=False)
warm=rows[rows['repeat']>0]
summary=warm.groupby('model').agg(requests=('repeat','size'),deadline_met=('deadline_met','sum'),
    warm_min_ms=('total_ms','min'),warm_median_ms=('total_ms','median'),warm_max_ms=('total_ms','max'),
    ground_median_ms=('ground_ms','median'),jump_and_input_median_ms=('jump_and_input_ms','median'),
    geometry_median_ms=('geometry_ms','median'))
summary['fraction_time_ground']=warm.groupby('model').ground_ms.sum()/warm.groupby('model').total_ms.sum()
summary.to_csv(root/'gpu_timing_summary.csv')
print(summary.to_string())

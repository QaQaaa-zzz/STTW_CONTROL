"""Hindsight capacity of frozen shortlists, sharing the final approach across all three pushes."""
from pathlib import Path
from itertools import combinations
import numpy as np
import pandas as pd

root=Path(__file__).resolve().parent
source=root.parents[2]/'amortized_exit/development_entry'
key=['map_id','root','gate_x','side']
scores=pd.read_csv(source/'time_zero_scores.csv.gz',float_precision='round_trip')
truth=pd.read_csv(source/'physical_conditions.csv.gz')
choices=pd.read_csv(source/'time_zero_choices.csv')
summary=pd.read_csv(source/'groups.csv')
incumbent=choices[choices.method.eq('old_train_rule')].set_index(key).selected
observed=truth.groupby(key+['action_slot'])[['lower','upper']].sum()
records=[]

def add(condition,method,rule,length,lo,hi):
    records.append(dict(zip(key,condition),model=method,rule=rule,budget=length,lower=lo,upper=hi))

for condition,g in scores.groupby(key):
    option=observed.loc[condition].sort_index()
    assert option.index.tolist()==list(range(16))
    y=option.to_numpy()
    base=int(incumbent.loc[condition])
    add(condition,'shared','TRAIN rule',1,*y[base])
    add(condition,'shared','all options',16,*y.max(0))
    for method,table in g.groupby('method'):
        ordered=table.sort_values(['score','action_slot'],ascending=[False,True]).action_slot.tolist()
        add(condition,method,'first',1,*y[ordered[0]])
        for b in [2,4]:
            add(condition,method,'ranked',b,*y[ordered[:b]].max(0))
            keep=[base]+[i for i in ordered if i!=base][:b-1]
            add(condition,method,'protected ranked',b,*y[keep].max(0))
    others=[i for i in range(16) if i!=base]
    for b in [2,4]:
        options=np.array([[base,*c] for c in combinations(others,b-1)])
        add(condition,'uniform','protected random expectation',b,*y[options].max(axis=1).mean(axis=0))
out=pd.DataFrame(records)
out.to_csv(root/'by_start_gate.csv',index=False)
for keys,oldname in [(('shared','all options'),'oracle_all16'),(('shared','TRAIN rule'),'old_train_rule'),(('mean','first'),'mean_all16'),(('mixture3','first'),'mixture3_all16')]:
    orig=summary[summary.method.eq(oldname)].set_index(key).sort_index()
    new=out[(out.model==keys[0]) & (out.rule==keys[1])].set_index(key).sort_index()
    np.testing.assert_array_equal(new[['lower','upper']],orig[['lower','upper']])
totals=out.groupby(['model','rule','budget'])[['lower','upper']].sum()
totals.to_csv(root/'totals.csv')
out.groupby(['map_id','side','model','rule','budget'])[['lower','upper']].sum().to_csv(root/'by_map_side.csv')
print(totals.to_string())

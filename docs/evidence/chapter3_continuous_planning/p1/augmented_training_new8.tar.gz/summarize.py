"""Postprocess frozen new-eight DEV scores; do not fit models, simulate, or open calibration/test."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import torch

OUT=Path(__file__).resolve().parent
T=OUT.parent
P=T.parent
N=P/'continuous_interpolation'
sys.path[:0]=[str(T),str(N),str(P/'model'),'/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src']
import nine_option_comparison as nine
import particle_spread as spread
from run_downstream_dev import predicted_states,decision_rows
from jump_outcome import JumpOutcome,Dataset
ids=['map_id','root','action_slot']
gate=['gate_x','side']
methods=['method','seed']
targets=[('gate','lower','upper'),('margin','margin_lower','margin_upper'),('strict_gate','strict_lower','strict_upper'),('strict_margin','matched_margin_lower','matched_margin_upper')]
torch.set_num_threads(1)
def load_json(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def mapped(frame):
    return pd.concat((frame.assign(cohort='all8'),frame.assign(cohort=frame.kind)),ignore_index=True)
def scales(frame):
    yield 'both',frame
    yield from frame.groupby('map_id')
def series(td,cols):
    return [dict(zip(cols,(k,) if not isinstance(k,tuple) else k),block=v) for k,v in td.groupby(cols,sort=True)]

def state_bands(arm,seed,plans,dest,*,use_archive=True):
    if use_archive and arm=='original' and seed==61123:
        known,bands=spread.forecasts()
        check=plans.merge(known,on=spread.ID,validate='one_to_one',suffixes=('','_archive'))
        assert np.allclose(check.p_relock,check.p_relock_archive,atol=1.e-6) and (check.kind==check.kind_archive).all()
        replay,rbands=state_bands(arm,seed,plans,dest,use_archive=False)
        merge=rbands.merge(bands,on=spread.ID+['quantity'],suffixes=('_rerun','_arch'),validate='one_to_one')
        assert len(merge)==len(bands)
        for k in ['particles','center','low_offset','high_offset','width90']:
            np.testing.assert_allclose(merge[k+'_rerun'],merge[k+'_arch'],rtol=1.e-6,atol=1.e-5)
        parity={k:float((merge[k+'_rerun']-merge[k+'_arch']).abs().max()) for k in ['center','low_offset','high_offset','width90']}
        (dest/'state_replay_parity.json').write_text(json.dumps(dict(bands=len(merge),largest_differences=parity),indent=2)+'\n')
        return known,bands
    support=P/'export' if arm=='original' else T/'augmented_export'
    train=Dataset.join([Dataset.load(support/'train'/m) for m in nine.fit.PLAN['maps_train']])
    assert len(train.x)==(3456 if arm=='original' else 5184)
    wc=P/'model/formal_fit' if arm=='original' else T/'augmented_fit'
    nets={}
    for m in ('mean','mixture3'):
        ck=torch.load(wc/f'seed_{seed}'/f'{m}.pt',weights_only=True,map_location='cpu')
        net=JumpOutcome(ck['input_width'],m,ck['width']);net.load_state_dict(ck['state'])
        nets[m,str(seed)]=net.eval()
    bands=[];mass=[]
    for mp in ('dev_00','dev_01'):
        ds,_=decision_rows(N/'export/dev'/mp,False)
        _,options=predicted_states(ds,nets,train,[*nets,('empirical_action','shared'),('five_separate_roots','shared')])
        for tag,pr,particles in options.values():
            base={k:tag[k] for k in spread.ID}
            mass.append({**base,'sample_count':len(particles),'recomputed_p':pr})
            if not particles:continue
            q=np.stack([a['q'] for a in particles]);v=np.stack([a['v'] for a in particles])
            t=np.rint(np.array([a['query_s'] for a in particles])/.005)*.005
            center,low,high=spread.intervals(spread.points(q,v,t))
            for j,quant in enumerate(spread.QUANTITIES):
                bands.append(dict(**base,quantity=quant,particles=len(particles),center=center[j],low_offset=low[j],high_offset=high[j],width90=high[j]-low[j]))
    plans=plans.merge(pd.DataFrame(mass),on=spread.ID,validate='one_to_one')
    np.testing.assert_allclose(plans.p_relock,plans.recomputed_p,atol=1e-6,rtol=1e-5)
    return plans.drop(columns='recomputed_p').rename(columns={'sample_count':'n_particles'}),pd.DataFrame(bands)

def run(arm,seed):
    source=T/'nine_option'/f'{arm}_{seed}'
    freeze=load_json(source/'choice_receipt.json')
    recorded=source/'pre_action_scores.csv.gz'
    if freeze.get('scores_sha256'):assert sha(recorded)==freeze['scores_sha256']
    d=pd.read_csv(recorded,dtype={'seed':str},float_precision='round_trip').query('family=="new"').copy()
    kind=pd.read_csv(N/'curves.csv').set_index('slot').kind
    d['kind']=d.action_slot.map(kind)
    assert len(d)==3072 and not d.duplicated(ids+gate+methods).any()
    dest=OUT/f'{arm}_{seed}';dest.mkdir(exist_ok=True)
    rank=mapped(d).sort_values(['score','root','action_slot'],ascending=[False,True,True],kind='stable')
    by=rank.groupby(['cohort','map_id',*gate,*methods],sort=False)
    rank['rank_for_25']=by.cumcount()+1;rank['admitted25']=rank.rank_for_25.le(np.where(rank.cohort.eq('all8'),24,12))
    rank['selected']=~rank.duplicated(['cohort',*ids[:2],*gate,*methods])
    assert rank.selected.sum()==1152 and rank.admitted25.sum()==1536
    rank.to_csv(dest/'pre_action_ranks.csv.gz',index=False)
    hist={}
    if arm=='original' and seed==61123:
        keys=['cohort',*ids,*gate,*methods]
        for name,file in [('selected','pre_action_choices.csv'),('admitted25','pre_action_admissions.csv.gz')]:
            saved=pd.read_csv(N/file,dtype={'seed':str})
            left=rank.loc[rank[name],keys].sort_values(keys).reset_index(drop=True)
            right=saved[keys].sort_values(keys).reset_index(drop=True)
            pd.testing.assert_frame_equal(left,right,check_dtype=False);hist[name+'_historical_exact']=len(right)
    # All selection and admission masks frozen before joining the actual pushes.
    tr=pd.read_csv(N/'margin_gate_cases.csv.gz')
    obs=spread.truths(N/'export/dev')
    tr=tr.merge(obs[ids+['hidden_force_N_grouping_only','verified']].rename(columns={'hidden_force_N_grouping_only':'force'}),on=ids+['force'],validate='many_to_one')
    joined=rank.merge(tr,on=ids+gate,validate='many_to_many')
    assert len(joined)==3*len(rank)
    joined.to_csv(dest/'physical_cases.csv.gz',index=False)
    phys=[];pick=[];cal=[];rel=[]
    for ident in series(joined,['cohort',*methods]):
        g=ident.pop('block')
        for m,v in scales(g):
            base=dict(**ident,map_id=m)
            for gx,side,block in [(0.,0,v),*[(float(gx),int(side),b) for (gx,side),b in v.groupby(gate)]]:
                key=dict(**base,gate_x=gx,side=side)
                for tag,lo,hi in targets:
                    sub=block[block.selected]
                    phys.append(dict(**key,target=tag,tasks=len(sub),lower=int(sub[lo].sum()),upper=int(sub[hi].sum())))
                    hit=block[block.admitted25];miss=block[~block.admitted25]
                    tp_lo,tp_hi=int(hit[lo].sum()),int(hit[hi].sum())
                    fn_lo,fn_hi=int(miss[lo].sum()),int(miss[hi].sum())
                    kh=hit[hit[lo]==hit[hi]];km=miss[miss[lo]==miss[hi]]
                    fp_lo,fp_hi=len(hit)-tp_hi,len(hit)-tp_lo
                    pick.append(dict(**key,target=tag,candidates_with_push=len(block),admitted_with_push=len(hit),true_positive_low=tp_lo,true_positive_high=tp_hi,
                        false_admission_count_low=fp_lo,false_admission_count_high=fp_hi,false_admission_rate_low=fp_lo/len(hit),false_admission_rate_high=fp_hi/len(hit),missed_success_low=fn_lo,missed_success_high=fn_hi,
                        recall_low=tp_lo/(tp_lo+fn_hi) if tp_lo+fn_hi else np.nan,recall_high=tp_hi/(tp_hi+fn_lo) if tp_hi+fn_lo else np.nan,
                        known_admitted=len(kh),known_rejected=len(km),known_false_admission_rate=(1-kh[lo]).mean(),known_recall=kh[lo].sum()/(kh[lo].sum()+km[lo].sum()) if kh[lo].sum()+km[lo].sum() else np.nan))
            # Collapse four gate rows before evaluating jump relock probabilities.
            unique=v.drop_duplicates(ids+['force'])
            for endpoint,table,prob,label in [('relock',unique,'p_relock','verified'),
                ('task',v[v.known],'score','lower'),('exit_given_relock',v[v.known&v.verified],'exit_probability','lower')]:
                t=table.dropna(subset=[prob]).copy()
                t['bin']=np.minimum(9,(10*t[prob]).astype(int))
                bins=t.groupby('bin').agg(n=(label,'size'),actual=(label,'mean'),predicted=(prob,'mean')).reset_index()
                for row in bins.itertuples():rel.append(dict(**base,endpoint=endpoint,bin=int(row.bin),n=int(row.n),actual=float(row.actual),prediction=float(row.predicted)))
                cal.append(dict(**base,endpoint=endpoint,eligible=len(table),n=len(t),brier=((t[prob]-t[label].astype(float))**2).mean(),p_mean=t[prob].mean(),rate=t[label].mean(),ece=(bins.n*(bins.actual-bins.predicted).abs()).sum()/len(t) if len(t) else np.nan))
    pd.DataFrame(phys).to_csv(dest/'physical_summary.csv',index=False);pd.DataFrame(pick).to_csv(dest/'screen25.csv',index=False)
    pd.DataFrame(cal).to_csv(dest/'calibration.csv',index=False);pd.DataFrame(rel).to_csv(dest/'reliability.csv',index=False)
    plans=d[spread.ID+['p_relock','kind']].drop_duplicates()
    plans,bands=state_bands(arm,seed,plans,dest)
    detail,summ=spread.score(plans,bands,obs)
    detail.to_csv(dest/'conditional_state_cases.csv.gz',index=False)
    scopes=[]; err=[]
    for entry in series(mapped(detail),['cohort',*methods]):
        g=entry.pop('block')
        for mp,v in scales(g):
            for scope,tag in [('method_available','scored'),('common_four','common')]:
                for quantity,b in v.groupby('quantity'):
                    use=b[b[tag]]
                    scopes.append(dict(**entry,map_id=mp,scope=scope,quantity=quantity,prefixes=len(b),observed_relocks=int(b.verified.sum()),observed_state=int(b.observed_state.sum()),n=len(use),distinct_roots=use.root.nunique(),
                        covered=int(use.covered90.eq(True).sum()),coverage90=use.covered90.eq(True).mean(),width90=use.width90.mean(),mae=use.abs_error.mean()))
                xy=v[v[tag]&v.quantity.isin(['landing_x_m','landing_y_m'])].pivot(index=ids+['hidden_force_N_grouping_only'],columns='quantity',values='signed_error')
                err.append(dict(**entry,map_id=mp,scope=scope,n=len(xy),xy_rmse_m=np.sqrt(xy.pow(2).sum(axis=1).mean())))
    pd.DataFrame(scopes).to_csv(dest/'state_coverage.csv',index=False);pd.DataFrame(err).to_csv(dest/'state_xy.csv',index=False)
    if arm=='original' and seed==61123:
        prior=pd.read_csv(N/'particle_spread_summary.csv',dtype={'seed':str})
        key=['map_id','kind',*methods,'quantity','scope']
        eq=summ.merge(prior,on=key,suffixes=('','_prior'),validate='one_to_one')
        assert len(eq)==192
        for col in ['scorable_prefixes','covered_count','coverage90','mean_width90','mae']:
            np.testing.assert_allclose(eq[col],eq[col+'_prior'],atol=1e-10,rtol=1e-8,equal_nan=True)
        hist['old_conditional_summary_rows_exact_or_numerically_equal']=len(eq)
        joint=pd.DataFrame(phys);record=pd.read_csv(N/'selected_summary.csv')
        test=joint[joint.target.eq('gate') & joint.side.ne(0) & joint.map_id.ne('both')].merge(record,on=['cohort','method','map_id',*gate],validate='one_to_one')
        assert len(test)==96 and test.lower.eq(test.success_lo).all() and test.upper.eq(test.success_hi).all()
        hist['physical_map_gate_rows_equal']=len(test)
    receipt=dict(arm=arm,fit_seed=seed,ready=True,physical=1152,actual_prefixes=576,scores_sha256=sha(recorded),ranks_sha256=sha(dest/'pre_action_ranks.csv.gz'),checks=hist)
    (dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(receipt,flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('arm',choices=['original','augmented']);parser.add_argument('seed',type=int)
    args=parser.parse_args();run(args.arm,args.seed)

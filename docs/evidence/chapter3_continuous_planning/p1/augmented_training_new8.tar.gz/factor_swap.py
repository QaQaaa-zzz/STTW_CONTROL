"""Post-hoc swaps of pre-action score components. Selection precedes the outcome join."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd

D=Path(__file__).resolve().parent
T=D.parent
K=['map_id','root','gate_x','side']
E=K+['family','action_slot']
methods=['mean','mixture3']
seeds=[61123,61124,61125]
arms=['original','augmented']

def collect():
    curves=pd.read_csv(T.parent/'continuous_interpolation/curves.csv').set_index('slot').kind
    blocks=[]; receipts=[]; fixed=[]
    for seed in seeds:
        for arm in arms:
            z=T/'nine_option'/f'{arm}_{seed}'
            s=pd.read_csv(z/'pre_action_scores.csv.gz',float_precision='round_trip').query('method in @methods').copy()
            s['kind']=s.action_slot.map(curves).where(s.family.eq('new'),'incumbent')
            blocks.append(s[E+['kind','method','p_relock','exit_probability']].assign(fit_seed=seed,arm=arm))
            chosen=pd.read_csv(z/'pre_action_choices.csv').query("method in @methods and menu=='registered_alpha'")
            receipts.append(chosen[E+['method']].assign(fit_seed=seed,arm=arm))
            if not fixed:
                physical=pd.read_csv(z/'physical_pairs.csv.gz').query("method=='mixture3' and menu=='registered_alpha'")
                fixed.append(physical[K+['fixed_slot','force','lower_fixed','upper_fixed']].rename(columns={'fixed_slot':'action_slot','lower_fixed':'lower','upper_fixed':'upper'}).assign(family='old'))
    physical=pd.read_csv(D/'original_61123/physical_cases.csv.gz').query("method=='mixture3' and cohort=='all8'")
    truth=pd.concat(fixed+[physical[E+['force','lower','upper']]])
    assert not truth.duplicated(E+['force']).any() and len(truth)==9*288
    truth.to_csv(D/'factor_input_truth.csv.gz',index=False)
    pd.concat(blocks).to_csv(D/'factor_input_scores.csv.gz',index=False)
    pd.concat(receipts).to_csv(D/'factor_registered_choices.csv.gz',index=False)

def calculate():
    z=pd.read_csv(D/'factor_input_scores.csv.gz',float_precision='round_trip')
    q=z[z.arm=='original'].merge(z[z.arm=='augmented'],on=E+['fit_seed','method','kind'],suffixes=('_o','_a'),validate='one_to_one')
    pools={'nine_registered':q[q.family.eq('new')|q.action_slot.eq(np.where(q.side.eq(1),4,0))],
           'all8':q[q.family.eq('new')],'center_edge':q[q.kind.eq('center_edge')],'same_edge':q[q.kind.eq('same_edge')]}
    keys=K+['fit_seed','method'];records=[]
    for pool,rows in pools.items():
        for jump,exit in [('o','o'),('a','o'),('o','a'),('a','a')]:
            score=rows['p_relock_'+jump]*rows['exit_probability_'+exit]
            assert score.notna().all()
            ranked=rows.assign(value=score,incumbent=rows.family.eq('old')).sort_values(['value','incumbent','action_slot'],ascending=[False,False,True],kind='stable')
            w=ranked.drop_duplicates(keys).copy();w['menu']=pool;w['jump']=jump;w['exit']=exit
            records.append(w[E+['kind','fit_seed','method','menu','jump','exit','value']])
    w=pd.concat(records,ignore_index=True)
    w.to_csv(D/'factor_pre_action_choices.csv.gz',index=False)
    choice=pd.read_csv(D/'factor_registered_choices.csv.gz')
    for typ,arm in zip(['o','a'],arms):
        xx=w.query("menu=='nine_registered' and jump==@typ and exit==@typ")
        yy=choice[choice.arm==arm]
        assert len(yy)==576 and len(xx.merge(yy,on=E+['fit_seed','method'],validate='one_to_one'))==len(xx)
    components=['fit_seed','method','menu','jump','exit']; by=['map_id','root','gate_x','side']
    phys=pd.read_csv(D/'factor_input_truth.csv.gz')
    x=w.merge(phys,on=E,validate='many_to_many')
    assert len(x)==len(w)*3
    s=x.groupby(components).agg(tasks=('lower','size'),lo=('lower','sum'),hi=('upper','sum'),center=('kind',lambda j:(j=='center_edge').sum()//3),same_edge=('kind',lambda j:(j=='same_edge').sum()//3),incumbent=('kind',lambda j:(j=='incumbent').sum()//3)).reset_index()
    s.to_csv(D/'factor_summary.csv',index=False)
    base=x.query("jump=='o' and exit=='o'");aug=x.query("jump=='a' and exit=='a'")
    y=base.merge(aug,on=['fit_seed','method','menu','force',*by],validate='one_to_one',suffixes=('_o','_a'))
    same=(y.family_o==y.family_a)&(y.action_slot_o==y.action_slot_a)
    y['d_lo']=(y.lower_a-y.upper_o).mask(same,0);y['d_hi']=(y.upper_a-y.lower_o).mask(same,0)
    g=y.groupby(['fit_seed','method','menu','kind_o','kind_a']).agg(choices=('force',lambda v:len(v)//3),tasks=('force','size'),old_lo=('lower_o','sum'),new_lo=('lower_a','sum'),rescued_lo=('d_lo',lambda d:int(d.eq(1).sum())),rescued_hi=('d_hi',lambda d:int(d.eq(1).sum())),lost_lo=('d_hi',lambda d:int(d.eq(-1).sum())),lost_hi=('d_lo',lambda d:int(d.eq(-1).sum())),net_lo=('d_lo','sum'),net_hi=('d_hi','sum')).reset_index()
    g.to_csv(D/'choice_family_transitions.csv',index=False)
if __name__=='__main__':
    if '--collect' in sys.argv:collect()
    calculate()

"""Verify new-eight DEV tables with pandas and numpy using only contents of this package."""
from pathlib import Path
import numpy as np
import pandas as pd
from factor_swap import calculate
D=Path(__file__).resolve().parent
K=['map_id','root','action_slot','force']
for arm in ('original','augmented'):
    for seed in (61123,61124,61125):
        m=D/f'{arm}_{seed}'
        physical=pd.read_csv(m/'physical_cases.csv.gz')
        state=pd.read_csv(m/'conditional_state_cases.csv.gz')
        s=pd.read_csv(m/'screen25.csv').query("map_id=='both' and side==0 and target=='gate'").set_index(['cohort','method'])
        ps=pd.read_csv(m/'physical_summary.csv').query("map_id=='both' and side==0 and target=='gate'").set_index(['cohort','method'])
        c=pd.read_csv(m/'calibration.csv').query("map_id=='both'").set_index(['cohort','method','endpoint'])
        xy=pd.read_csv(m/'state_xy.csv').query("map_id=='both' and scope=='method_available'").set_index(['cohort','method'])
        rr=pd.read_csv(m/'state_coverage.csv').query("map_id=='both' and scope=='method_available'").set_index(['cohort','method','quantity'])
        for (co,method),g in physical.groupby(['cohort','method']):
            top=g[g.admitted25]; picked=g[g.selected];whole=ps.loc[co,method]
            assert len(picked)==288 and (picked.lower.sum(),picked.upper.sum())==(whole.lower,whole.upper)
            v=s.loc[co,method]
            assert (len(top),len(top)-top.upper.sum(),len(top)-top.lower.sum())==(v.admitted_with_push,v.false_admission_count_low,v.false_admission_count_high)
            for label,df,prob,obs in [('relock',g.drop_duplicates(K),'p_relock','verified'),('task',g[g.known],'score','lower'),('exit_given_relock',g[g.known&g.verified],'exit_probability','lower')]:
                p=df.dropna(subset=[prob]);z=c.loc[co,method,label]
                assert (len(df),len(p))==(z.eligible,z.n)
                np.testing.assert_allclose([p[prob].mean(),p[obs].mean(),np.mean((p[prob]-p[obs].astype(float))**2)],[z.p_mean,z.rate,z.brier])
            a=state[(state.method==method)&(state.scored)&((co=='all8')|(state.kind==co))]
            z=xy.loc[co,method];coords=a[a.quantity.isin(['landing_x_m','landing_y_m'])].pivot(index=['map_id','root','action_slot','hidden_force_N_grouping_only'],columns='quantity',values='signed_error')
            assert len(coords)==z.n; np.testing.assert_allclose((coords.pow(2).sum(axis=1).mean())**.5,z.xy_rmse_m)
            for qty,b in a.groupby('quantity'):
                z=rr.loc[co,method,qty]; assert len(b)==z.n and b.covered90.eq(True).sum()==z.covered
                np.testing.assert_allclose([b.abs_error.mean(),b.width90.mean()],[z.mae,z.width90])
calculate()
print('PASS: 6 arm-seed tables, 72 method/cohort sets, gate totals, false admissions, 3 probability endpoints, 6-dimensional state errors and coverage, 4-way score swaps and registered choices.')

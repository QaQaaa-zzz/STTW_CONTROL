"""CPU-only follow-on. Optionally wake on the registered pipeline's process exit (no polling)."""
import argparse
import os
from pathlib import Path
import select
import json
import numpy as np
import pandas as pd
from summarize import OUT,T,N,run,load_json,targets,methods

seeds=(61123,61124,61125);taskkey=['cohort','map_id','root','gate_x','side','force']
def pair(a,b,typ,baseline):
    cols=taskkey+['action_slot','kind','verified']+list(dict.fromkeys(c for t,l,h in targets for c in (l,h)))
    j=a[cols].merge(b[cols],on=taskkey,suffixes=('_a','_b'),validate='one_to_one')
    assert len(j)==864
    same=j.action_slot_a.eq(j.action_slot_b)
    result=[];case=[]
    for tar,lo,hi in targets:
        jj=j[taskkey+['action_slot_a','action_slot_b']].copy()
        jj['delta_low']=(j[lo+'_a']-j[hi+'_b']).mask(same,0)
        jj['delta_high']=(j[hi+'_a']-j[lo+'_b']).mask(same,0)
        jj['same']=same;jj['a_lo']=j[lo+'_a'];jj['a_hi']=j[hi+'_a'];jj['b_lo']=j[lo+'_b'];jj['b_hi']=j[hi+'_b']
        jj['target']=tar;jj['comparison']=typ;jj['baseline']=baseline;case.append(jj)
        for cohort,g in jj.groupby('cohort'):
            blocks=[('both',0.,0,g),*[(m,0.,0,k) for m,k in g.groupby('map_id')],
                    *[(m,x,s,k) for (m,x,s),k in g.groupby(['map_id','gate_x','side'])],
                    *[('both',0.,s,k) for s,k in g.groupby('side')]]
            for m,x,s,k in blocks:
                result.append(dict(cohort=cohort,target=tar,comparison=typ,baseline=baseline,map_id=m,gate_x=x,side=s,n=len(k),same=int(k.same.sum()),
                    original_lower=int(k.b_lo.sum()),original_upper=int(k.b_hi.sum()),selected_lower=int(k.a_lo.sum()),selected_upper=int(k.a_hi.sum()),
                    rescues_lo=int(k.delta_low.eq(1).sum()),rescues_hi=int(k.delta_high.eq(1).sum()),losses_lo=int(k.delta_high.eq(-1).sum()),losses_hi=int(k.delta_low.eq(-1).sum()),
                    net_lo=int(k.delta_low.sum()),net_hi=int(k.delta_high.sum())))
    return pd.DataFrame(result),pd.concat(case)
def complete():
    stage=load_json(T/'augmented_fit/pipeline_status.json')
    if stage['stage']!='complete':
        print('Awaiting authorized fitted weights and six frozen score tables. Upstream stage:',stage['stage'],flush=True)
        return
    for seed in seeds:
        for arm in ('original','augmented'):
            d=OUT/f'{arm}_{seed}'
            if not (d/'receipt.json').exists():run(arm,seed)
    totals=[];cases=[];frequency=[]
    for seed in seeds:
        sel={}
        for arm in ('original','augmented'):
            d=OUT/f'{arm}_{seed}'
            s=pd.read_csv(d/'physical_cases.csv.gz',dtype={'seed':str}).query('selected')
            for method,g in s.groupby('method'):
                sel[arm,method]=g
                unique=g.drop_duplicates(taskkey[:-1]);assert len(unique)==288
                freq=unique.groupby(['cohort','kind','action_slot','map_id']).size().rename('root_gate_choices').reset_index()
                frequency.append(freq.assign(arm=arm,method=method,fit_seed=seed))
            for baseline in ('mean','empirical_action','five_separate_roots'):
                a,b=pair(sel[arm,'mixture3'],sel[arm,baseline],arm+'_mixture_vs_alternative',baseline)
                totals.append(a.assign(method='mixture3',fit_seed=seed));cases.append(b.assign(method='mixture3',fit_seed=seed))
        for method in ('mean','mixture3','empirical_action','five_separate_roots'):
            a,b=pair(sel['augmented',method],sel['original',method],'augmented_vs_original','same_method_original')
            totals.append(a.assign(method=method,fit_seed=seed));cases.append(b.assign(method=method,fit_seed=seed))
    pd.concat(totals,ignore_index=True).to_csv(OUT/'paired_summary.csv',index=False)
    pd.concat(cases,ignore_index=True).to_csv(OUT/'paired_cases.csv.gz',index=False)
    pd.concat(frequency,ignore_index=True).to_csv(OUT/'selection_frequency.csv',index=False)
    tables=['calibration','reliability','screen25','physical_summary','state_coverage','state_xy']
    for name in tables:
        dfs=[pd.read_csv(OUT/f'{arm}_{seed}'/f'{name}.csv',dtype={'seed':str}).assign(arm=arm,fit_seed=seed) for arm in ('original','augmented') for seed in seeds]
        pd.concat(dfs,ignore_index=True).to_csv(OUT/f'{name}.csv',index=False)
    (OUT/'completion.json').write_text(json.dumps({'status':'complete','seeds':seeds,'training_arms':['original','augmented'],'DEV_maps':2,'roots':24,'root_gate_choices_per_cohort_method':96,'physical_pushes_per_cohort_method':288,'shared_empirical':'The same deterministic empirical arm is reported under each fit_seed. Do not pool repeated empirical rows or seeds as independent roots.','parity':load_json(OUT/'original_61123/receipt.json')['checks']},indent=2)+'\n')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--after-pid',type=int);args=parser.parse_args()
    if args.after_pid and Path(f'/proc/{args.after_pid}').is_dir():
        fd=os.pidfd_open(args.after_pid)
        poll=select.poll();poll.register(fd,select.POLLIN);poll.poll();os.close(fd)
    complete()

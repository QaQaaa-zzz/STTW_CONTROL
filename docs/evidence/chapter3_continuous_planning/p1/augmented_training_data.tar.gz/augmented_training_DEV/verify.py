"""Check the actual training membership and recover the reported DEV decisions, totals and paired gains without a GPU."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
root=Path(__file__).resolve().parent
t=root/'continuous_train_support'
keys=['map_id','root','gate_x','side','method','seed']
totals=[]
olds=set();devs=set()
split=pd.read_csv(root/'export/formal_train_dev.csv');assert set(split.role)=={'train','dev'}
for row in split.itertuples():
    data=root/'export'/row.role/row.map_id
    index=pd.read_csv(data/'prefix_index.csv')
    (olds if row.role=='train' else devs).update(index.root)
    if row.role!='train':continue
    extra=t/'export/train'/row.map_id;merged=t/'augmented_export/train'/row.map_id
    idx=pd.read_csv(merged/'prefix_index.csv')
    assert len(idx)==864 and idx.root.nunique()==12 and len(index)==576
    assert len(pd.read_csv(extra/'prefix_index.csv'))==288
    for file in ('observed_inputs.npz','measured_targets.npz'):
        with np.load(data/file) as a,np.load(extra/file) as b,np.load(merged/file) as c:
            for key in a:
                first,second=a[key],b[key]
                assert len(first)==576 and len(second)==288
                np.testing.assert_equal(c[key],np.concatenate([first,second]))
assert len(olds)==72 and len(devs)==24 and not olds&devs
for seed in (61123,61124,61125):
    frames={}
    for arm in ('original','augmented'):
        dest=t/'nine_option'/f'{arm}_{seed}'
        fit=(root/'model/formal_fit' if arm=='original' else t/'augmented_fit')/f'seed_{seed}'
        rec=json.loads((dest/'choice_receipt.json').read_text())
        opt=pd.read_csv(fit/'optimization.csv')
        for method in ('mean','mixture3'):
            assert opt[opt['mode'].eq(method)].step.tolist()==list(range(1,541))
            assert hashlib.sha256((fit/(method+'.pt')).read_bytes()).hexdigest()==rec['weights'][method]
        assert hashlib.sha256((dest/'pre_action_choices.csv').read_bytes()).hexdigest()==rec['choices_sha256']
        allscores=pd.read_csv(dest/'pre_action_scores.csv.gz',dtype={'seed':str},float_precision='round_trip')
        saved=pd.read_csv(dest/'pre_action_choices.csv',dtype={'seed':str})
        pairs=pd.read_csv(dest/'physical_pairs.csv.gz',dtype={'seed':str})
        for menu,lslot in [('registered_alpha',4),('alpha0',1)]:
            pool=allscores[allscores.family.eq('new')|allscores.action_slot.eq(np.where(allscores.side.eq(1),lslot,0))].copy()
            pool['incumbent']=pool.family.eq('old');assert pool.groupby(keys).size().eq(9).all()
            sel=pool.sort_values(['score','incumbent','action_slot'],ascending=[False,False,True],kind='stable').drop_duplicates(keys)
            mk=keys+['family','action_slot']
            the_saved=saved[saved.menu.eq(menu)]
            assert len(sel.merge(the_saved,on=mk,validate='one_to_one'))==len(the_saved)==384
            actual=pairs[pairs.menu.eq(menu)]
            assert len(actual.merge(sel[mk],on=mk,validate='many_to_one'))==len(actual)==1152
        frames[arm]=pairs
        a=pairs.query('method=="mixture3" and menu=="registered_alpha"')
        totals.append((arm,seed,len(a),int(a.lower_fixed.sum()),int(a.margin_lower_fixed.sum()),int(a.lower.sum()),int(a.margin_lower.sum())))
    both=frames['augmented'].merge(frames['original'],on=['menu',*keys,'force'],suffixes=('_a','_o'),validate='one_to_one')
    summary=pd.read_csv(t/'nine_option'/f'augmented_{seed}'/'training_arm_summary.csv',dtype={'seed':str})
    for target,l,h in [('gate','lower','upper'),('margin','margin_lower','margin_upper'),('matched_gate','strict_lower','strict_upper'),('matched_margin','matched_margin_lower','matched_margin_upper')]:
        eq=(both.family_a==both.family_o)&(both.action_slot_a==both.action_slot_o)
        both['dlo']=(both[l+'_a']-both[h+'_o']).mask(eq,0);both['dhi']=(both[h+'_a']-both[l+'_o']).mask(eq,0)
        for q in summary[summary.target.eq(target)].itertuples():
            v=both[both.menu.eq(q.menu)&both.method.eq(q.method)&both.seed.eq(q.seed)]
            if q.map_id!='both':v=v[v.map_id.eq(q.map_id)]
            if q.side:v=v[v.side.eq(q.side)]
            assert (len(v),v.dlo.sum(),v.dhi.sum(),v.dlo.eq(1).sum(),v.dhi.eq(-1).sum())==(q.n,q.net_lo,q.net_hi,q.rescued_lo,q.lost_lo)
assert totals[:2]==[('original',61123,288,175,123,138,95),('augmented',61123,288,175,123,96,71)]
print('3,456 original + 1,728 new physical prefixes = 5,184; 72 TRAIN roots and 24 disjoint DEV roots.')
print('arm seed trials fixed_gate fixed_margin selected_gate selected_margin')
for values in totals:print(*values)

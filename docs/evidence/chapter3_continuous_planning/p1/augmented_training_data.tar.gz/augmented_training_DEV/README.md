# 第三章增补训练与原固定加八候选的九选一比较

两张已打开 DEV 地图、24 个起点、96 个指令、288 个任务结果。训练数据来自六张 TRAIN 图、72 个根。每根的多个候选与三种隐藏推力共享初态。

解压后在本目录使用以下 CPU 命令。数值核对需要 Python、NumPy 和 pandas，从权重重放另需 CPU PyTorch 和 SciPy。

```bash
python -B verify.py
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python -B portable/replay_weights.py
python -B continuous_train_support/augmented_fit/factor_analysis/compare.py
```

第一条从两部分的原始特征／实测标签逐数组重建合并数据，核实每个模型权重与540条更新记录，从分数再现每根门三推共用的选项和全部配对收益。第二条从全部12个权重及两份经验训练支持集出发，对每臂三个种子的候选和实际选择独立重放。使用原预测函数、出口评估器与网络权重，归档的参考行取自真实使用的两套冻结大表。在本机重放训练条件相同的 6×4,224 行，复锁分、条件出口分与总分和存档精确一致。每份冻结选择采用该种子的平均、三成分、全部训练起点经验和五近邻经验。两种经验支持不随神经种子改变。第三条重建事后评分因子互换表，在同目录更新派生结果。

原训练的输入、末次权重、优化表、TensorBoard事件位于 `export/train` 和 `model/formal_fit`；新增 TRAIN 的实测输入、合并后5,184个前缀、增强权重及事件位于 `continuous_train_support/export/train`、`continuous_train_support/augmented_export/train` 与 `continuous_train_support/augmented_fit`。原生拟合入口使用的旧16开发导出是 `export/dev`；新增八条 DEV 入口的事前观测和酌情使用的实测标签在 `continuous_interpolation/export/dev`。原调度在 `augmented_export/dev/{dev_00,dev_01}` 建立指向两张原 DEV 导出的目录链接；此包用相对路径指回所附数据。训练/开发地图划分在 `export/formal_train_dev.csv`。

`continuous_train_support/nine_option` 保存两臂六组全部事前分数、选择与身份回执、固定对照、每推力实走标签与事后界限。主种子固定、原训练、扩充训练的原门/严格净空分别为175/123、138/95、96/71。物理测量口径为实走整车和摆体的冻结包络，在真实首查到终点的每个5 ms姿态，要求离墙大于5.330585 cm。`continuous_train_support/augmented_fit/factor_analysis` 附候选与选择、逐任务因子交换、四组合汇总、失败阶段和解释。`RESULTS.md` 保留关联图、补充面板及阶段决定；其图包链接指向仓库同名兄弟文件。

`portable/external_sources.json` 给出已归档原P1实验、地形与模型、旧／新几何设计及采集程序的仓库路径和 SHA-256。历史逐车 NPZ 的物理源路径保留在原数据及逐项表中。归档包含实算所用的参考姿态/曲率行和地图特征，可离线重放本次实际候选。开启新的物理仿真仍使用原工程资产与运行合同。

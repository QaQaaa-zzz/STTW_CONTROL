"""Offline factorial replay of the two published factors and measured failure stages."""
from pathlib import Path
import numpy as np
import pandas as pd

out = Path(__file__).resolve().parent
t = out.parents[1]
p = t.parent
group = ['map_id', 'root', 'gate_x', 'side']
entry = group + ['family', 'action_slot']
arms = ('original', 'augmented')

def freeze_factor_choices(seed):
    estimates = []
    for arm in arms:
        scores = pd.read_csv(t/'nine_option'/f'{arm}_{seed}'/'pre_action_scores.csv.gz', float_precision='round_trip')
        scores = scores[scores.method.eq('mixture3')]
        scores = scores[scores.family.eq('new') | scores.action_slot.eq(np.where(scores.side.eq(1),4,0))]
        estimates.append(scores[entry + ['p_relock','exit_probability']])
    all_scores = estimates[0].merge(estimates[1], on=entry, suffixes=('_original','_augmented'),validate='one_to_one')
    all_scores['incumbent'] = all_scores.family.eq('old')
    assert len(all_scores) == 96*9
    chosen = []
    for landing in arms:
        for exit_arm in arms:
            score = all_scores['p_relock_'+landing]*all_scores['exit_probability_'+exit_arm].fillna(0)
            ordered = all_scores.assign(score=score).sort_values(['score','incumbent','action_slot'],ascending=[False,False,True],kind='stable')
            selected = ordered.groupby(group,sort=False).head(1).copy()
            if landing == exit_arm:
                original = pd.read_csv(t/'nine_option'/f'{landing}_{seed}'/'pre_action_choices.csv')
                original = original[(original.method=='mixture3') & (original.menu=='registered_alpha')]
                assert len(selected.merge(original[entry],on=entry,validate='one_to_one')) == 96
            chosen.append(selected.assign(relock_source=landing,conditional_source=exit_arm,seed=seed))
    return pd.concat(chosen,ignore_index=True)

selected = pd.concat([freeze_factor_choices(seed) for seed in [61123,61124,61125]],ignore_index=True)
selected.to_csv(out/'pre_action_choices.csv.gz',index=False)

fixed = pd.read_csv(t/'nine_option/augmented_61123/physical_pairs.csv.gz')
fixed = fixed[(fixed.method=='mixture3') & (fixed.menu=='registered_alpha')]
truth_cols = ['lower','upper','margin_lower','margin_upper','path']
fixed = fixed[group+['force','fixed_slot']+[col+'_fixed' for col in truth_cols]].rename(
    columns={**{col+'_fixed':col for col in truth_cols},'fixed_slot':'action_slot'}).assign(family='old')
fresh = pd.read_csv(p/'continuous_interpolation/margin_gate_cases.csv.gz').assign(family='new')
truth = pd.concat([fixed,fresh[entry+['force']+truth_cols]],ignore_index=True)
states = pd.concat([pd.read_csv(loc/'export/dev'/mp/'suffix_index.csv') for loc in [p,p/'continuous_interpolation'] for mp in ['dev_00','dev_01']])
truth = truth.merge(states[['trajectory','verified_relock','termination','physical_goal']],left_on='path',right_on='trajectory',validate='many_to_one').drop(columns='trajectory')
truth.to_csv(out/'candidate_outcomes.csv.gz',index=False)
counts = selected.merge(truth,on=entry,validate='many_to_many')
k = ['seed','relock_source','conditional_source']
assert counts.groupby(k).size().eq(288).all()
counts.to_csv(out/'factor_replay_cases.csv.gz',index=False)
total = counts.groupby(k)[truth_cols[:4]].sum().reset_index()
total.to_csv(out/'factor_summary.csv',index=False)
print(total.to_string(index=False))

baseline = [counts.query("seed==61123 and relock_source=='original' and conditional_source=='original'").assign(control='old training'),
            truth[truth.family=='old'].assign(control='fixed')]
new = counts.query("seed==61123 and relock_source=='augmented' and conditional_source=='augmented'")
paired = new.merge(pd.concat(baseline)[group+['force','control','lower','upper','family','action_slot']],on=group+['force'],suffixes=('','_before'))
assert paired.lower.eq(paired.upper).all() and paired.lower_before.eq(paired.upper_before).all()
paired['change'] = paired.lower-paired.lower_before
paired['failure_stage'] = np.select([~paired.verified_relock,paired.physical_goal & paired.lower.eq(0)],
                                    ['before handoff','reached goal on wrong side'], default=paired.termination)
paired.to_csv(out/'paired_outcomes.csv.gz',index=False)
clinical = paired[paired.change.eq(-1)].groupby(['control','failure_stage']).size().rename('losses')
clinical.to_csv(out/'failure_stages.csv')
print(clinical.to_string())

"""Evaluate all archived checkpoints using the native decoder, exact frozen geometry rows and learned exit scorer."""
from pathlib import Path
from types import SimpleNamespace
import argparse
import sys
import numpy as np
import pandas as pd
import torch
here=Path(__file__).resolve().parent
p=here.parent;t=p/'continuous_train_support'
sys.path[:0]=[str(p/'model'),str(p/'actions/amortized_exit')]
from native_functions import decision_rows,predicted_states,FAMILIES,branch_ids
from jump_outcome import Dataset,JumpOutcome,MODE_NAMES
from exit_value import ExitValue

def run(arm):
    fit=p/'model/formal_fit' if arm=='original' else t/'augmented_fit'
    support=p/'export/train' if arm=='original' else t/'augmented_export/train'
    tr=Dataset.join([Dataset.load(support/f'train_{i:02}') for i in range(6)])
    nets={}
    for seed in (61123,61124,61125):
        for method in MODE_NAMES:
            cp=torch.load(fit/f'seed_{seed}'/(method+'.pt'),map_location='cpu',weights_only=True)
            net=JumpOutcome(cp['input_width'],method,cp['width']);net.load_state_dict(cp['state'])
            nets[method,str(seed)]=net.eval()
    estimator=ExitValue(p/'actions/amortized_exit/train_model.npz')
    keys=['map_id','root','action_slot','method','seed']; by=keys+['gate_x','side'];all_scores=[]
    for family,location in [('old',p),('new',p/'continuous_interpolation')]:
        with np.load(here/(family+'_used_route_rows.npz')) as z:sub={k:z[k] for k in z}
        with np.load((p/'actions' if family=='old' else location)/'approaches.npz') as z:
            engine=SimpleNamespace(approach=z['xy'],bank={'s':sub['s']},bank_len=len(sub['s']))
        for name in ('dev_00','dev_01'):
            ds,_=decision_rows(location/'export/dev'/name,False)
            with np.load(here/(name+'_map.npz')) as z:world=SimpleNamespace(**{k:z[k].item() if z[k].ndim==0 else z[k] for k in z})
            parts,items=predicted_states(ds,nets,tr,[*nets,*[(m,'shared') for m in FAMILIES]])
            if family=='old':parts=[v for v in parts if v['action_slot'] in (0,1,4)]
            scores=[]
            for k in range(0,len(parts),96):
                block=parts[k:k+96]
                bids=np.stack([branch_ids(engine,v['geometry'],v['q']) for v in block])[:,[0,2]]
                idx=np.searchsorted(sub['row_ids'],bids)
                assert (sub['row_ids'][idx]==bids).all()
                tags=pd.DataFrame([{c:v[c] for c in keys} for v in block])
                q,v,prev,clk=[np.stack([b[c] for b in block]) for c in ('q','v','prev','query_s')]
                for gate,side in [(12.7,1),(12.7,-1),(15.,1),(15.,-1)]:
                    ix=idx[:,0 if side==1 else 1]
                    refs=[sub[c][ix] for c in ('xy','heading','curvature')]
                    scores.append(tags.assign(gate_x=gate,side=side,exit_probability=estimator.score(world,q,v,prev,clk,gate,side,side,*refs)))
            mean=pd.concat(scores).groupby(by,as_index=False).exit_probability.mean()
            opt=pd.DataFrame([{**{c:tag[c] for c in keys},'gate_x':gate,'side':side,'p_relock':prob} for tag,prob,_ in items.values()
                              if family!='old' or tag['action_slot'] in (0,1,4) for gate,side in [(12.7,1),(12.7,-1),(15.,1),(15.,-1)]])
            mid=opt.merge(mean,on=by,how='left',validate='one_to_one');mid['family']=family
            mid['score']=mid.p_relock*mid.exit_probability.fillna(0);all_scores.append(mid)
    got=pd.concat(all_scores)
    for seed in (61123,61124,61125):
        cache=pd.read_csv(t/'nine_option'/f'{arm}_{seed}'/'pre_action_scores.csv.gz',dtype={'seed':str},float_precision='round_trip')
        reduced=got[got.seed.isin([str(seed),'shared'])]
        matches=cache.merge(reduced,on=['family',*by],suffixes=('_saved','_new'),validate='one_to_one')
        assert len(matches)==len(cache)==len(reduced)==4224
        delta={}
        for k in ('p_relock','exit_probability','score'):
            a,b=matches[k+'_saved'],matches[k+'_new']
            np.testing.assert_allclose(a,b,rtol=1.e-5,atol=1.e-6,equal_nan=True)
            delta[k]=float((a-b).abs().max())
        saved=pd.read_csv(t/'nine_option'/f'{arm}_{seed}'/'pre_action_choices.csv',dtype={'seed':str})
        groups=['map_id','root','gate_x','side','method','seed']
        for menu,slot in [('registered_alpha',4),('alpha0',1)]:
            pool=reduced[reduced.family.eq('new')|reduced.action_slot.eq(np.where(reduced.side.eq(1),slot,0))].copy()
            pool['incumbent']=pool.family.eq('old')
            best=pool.sort_values(['score','incumbent','action_slot'],ascending=[False,False,True],kind='stable').drop_duplicates(groups)
            before=saved[saved.menu.eq(menu)]
            assert len(best.merge(before,on=groups+['family','action_slot'],validate='one_to_one'))==len(before)==384
        print(arm,seed,len(matches),'choices_match=768',delta,flush=True)

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('--arm',choices=['both','original','augmented'],default='both')
    arm=cli.parse_args().arm;torch.set_num_threads(1)
    for name in (('original','augmented') if arm=='both' else (arm,)):run(name)

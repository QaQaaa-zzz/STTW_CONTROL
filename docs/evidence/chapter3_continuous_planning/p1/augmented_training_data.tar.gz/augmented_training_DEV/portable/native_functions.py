# Exported function bodies from the bundled model/run_downstream_dev.py and model/frozen_exit_value.py.
import numpy as np
import pandas as pd
import torch
from jump_outcome import Dataset, DIM, decode_target, decision_inputs, empirical_particles
KEY=['map_id','root','action_slot']
DRAWS=16
SEED=732611
MODE_NAMES=('mean','mixture3')
FAMILIES=('empirical_action','five_separate_roots')
def decision_rows(folder,check):
    cols=['row','map_id','root','action_slot','geometry','alpha','hidden_force_N_grouping_only']
    idx=pd.read_csv(folder/'prefix_index.csv',usecols=cols)
    # The scheduled gate is read without opening any query, outcome or physical trajectories.
    gates=pd.read_csv(folder/'suffix_index.csv',usecols=['row','arm','target_side','section','section_x'])
    idx=idx.merge(gates[gates.arm.eq('left')].drop(columns='arm'),on='row',validate='one_to_one').sort_values('row')
    assert np.array_equal(idx.row,np.arange(len(idx))) and set(idx.map_id)=={folder.name}
    if check:
        root=idx.root.iloc[0];idx=idx[idx.root.eq(root)&idx.action_slot.isin([0,1])]
    parts=[]; reps=[]
    with np.load(folder/'observed_inputs.npz',allow_pickle=False) as z:
        arrays={k:z[k] for k in z.files}
    for _,g in idx.groupby(['root','action_slot'],sort=True):
        rr=g.row.to_numpy()
        assert set(g.hidden_force_N_grouping_only)=={-5,0,5} and len(g)==3 and g[KEY+['target_side','section','section_x','geometry','alpha']].nunique().eq(1).all()
        assert all(np.array_equal(v[rr],np.broadcast_to(v[rr[0]],v[rr].shape)) for v in arrays.values())
        parts.append(int(rr[0]));reps.append(g.iloc[0])
    meta=pd.DataFrame(reps).drop(columns=['hidden_force_N_grouping_only']).reset_index(drop=True)
    observed={k:v[parts] for k,v in arrays.items()}
    x,q,reset,a=decision_inputs(observed)
    # No new-map measured target is opened on the prospective score path.
    ds=Dataset(x,q,reset,a,torch.zeros(len(q),dtype=torch.bool),torch.full((len(q),DIM),torch.nan),meta)
    return ds,idx


def random_draws():
    rng=np.random.default_rng(SEED)
    u=(np.arange(DRAWS)+rng.random(DRAWS))/DRAWS
    return torch.tensor(rng.permutation(u),dtype=torch.float32),torch.tensor(rng.normal(size=(DRAWS,DIM)),dtype=torch.float32)


@torch.inference_mode()
def predicted_states(data,models,train,families=None):
    rows=[];opportunities={}
    common_u,common_noise=random_draws()
    if families is None:families=list(models)+[(name,'shared') for name in FAMILIES]
    for method,seed in families:
        if method in MODE_NAMES:
            net=models[method,seed]
            device=net.x_center.device
            logit,logw,center,scale=net(data.x.to(device))
            u=common_u.to(device).expand(len(data.x),-1)
            z=common_noise.to(device).expand(len(data.x),-1,-1)
            probs=logit.sigmoid().cpu()
            if method=='mean': latent=center[:,0,None,:]
            else:
                mode=torch.searchsorted(logw.exp().cumsum(-1).contiguous(),u.contiguous()).clamp_max(2)
                n=torch.arange(len(data.x),device=device)[:,None];latent=center[n,mode]+scale[n,mode]*z
            states={k:v.cpu() for k,v in decode_target(data.q0[:,None,:].to(device),latent*net.y_scale+net.y_center).items()}
        else:
            support=empirical_particles(train,data,None if method==FAMILIES[0] else 5)
            probs=torch.tensor([min(1.,max(0.,s[0])) for s in support])
        for n,r in enumerate(data.index.itertuples()):
            tag=dict(map_id=r.map_id,root=int(r.root),action_slot=int(r.action_slot),geometry=int(r.geometry),
                     alpha=float(r.alpha),section=r.section,section_x=float(r.section_x),target_side=int(r.target_side),method=method,seed=seed)
            key=(n,method,seed)
            chunk=[]
            if method in MODE_NAMES:
                fields={k:v[n] for k,v in states.items()}
            else:
                _,s,w=support[n]
                if len(s):
                    pick=torch.searchsorted(w.cumsum(0).contiguous(),common_u).clamp_max(len(w)-1)
                    fields=decode_target(data.q0[n:n+1],s[pick])
                else:fields=None
            if fields is not None:
                for i in range(len(fields['query_s'])):
                    p=dict(tag,particle=i,query_s=float(fields['query_s'][i]),q=fields['query_qpos_native'][i].numpy(),
                           v=fields['query_velocity_state9'][i].numpy(),prev=fields['previous_velocity_state9'][i].numpy())
                    chunk.append(p)
            rows.extend(chunk);opportunities[key]=(tag,float(probs[n]),chunk)
    return rows,opportunities


def branch_ids(self,geometry,position,progress=None):
    """Include x+5 cm commitment; future state uses projection onto the known approach."""
    approach=self.approach[geometry]
    edge=np.searchsorted(approach[:,0],position[0]+.05)
    if progress is None:
        delta=np.diff(approach,axis=0)
        w=np.clip(((position[:2]-approach[:-1])*delta).sum(1)/(delta**2).sum(1),0,1)
        best=np.argmin(((approach[:-1]+w[:,None]*delta-position[:2])**2).sum(1))
        progress=(1-w[best])*self.bank['s'][best]+w[best]*self.bank['s'][best+1]
    join=min(self.bank_len-1,max(int(edge),int(np.searchsorted(self.bank['s'],progress))+1))
    return len(self.approach)+(geometry*3+np.arange(3))*self.bank_len+join

"""Four options with an exact cutoff tie and one uncertified failed prefix."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

from score_rank_audit import rank_candidates, strict_outcomes, score_sweep

rows = []
arms = []
scores = []
for slot, score in enumerate([.8, .8, .5, .1]):
    key = dict(map_id='fixture', gate_x=12.7, side=1, root=10+slot, action_slot=slot)
    scores.append(dict(**key, score=score, method='mean', seed='fixture', kind='fixture4'))
    for f, outcome in zip((-5,0,5), [(0,1,1),(1,1,0),(0,0,0),(1,0,0)][slot]):
        rows.append(dict(**key,force=f,lower=outcome,upper=outcome))
        certificate='matched_observed_handoff' if outcome else 'matched_observed_prequery_endpoint'
        if slot==0 and f==-5:
            certificate='unmatched_prequery_endpoint'
        arms.append(dict(map_id='fixture',root=10+slot,action_slot=slot,arm='left',
                         hidden_force_N_grouping_only=f,suffix_pair_status=certificate))
ranks=rank_candidates(pd.DataFrame(scores))
truth=strict_outcomes(pd.DataFrame(rows),pd.DataFrame(arms))
result=score_sweep(ranks,truth)
r=result[(result.cohort=='all8')&(result['rank']==1)].iloc[0]
assert r.cut_splits_ties and r.cutoff_ties==2 and r.root==10
assert (r.hits_lo,r.hits_hi,r.strict_hits_lo,r.strict_hits_hi)==(2,2,2,3)
np.testing.assert_allclose([r.strict_false_admission_lo,r.strict_false_admission_hi,r.strict_recall_lo,r.strict_recall_hi],
                           [0.,1/3,2/5,3/6])
full=result[(result.cohort=='all8')&(result['rank']==4)].iloc[0]
assert full.strict_recall_lo==1 and full.strict_recall_hi==1
folder=Path(__file__).resolve().parent
old=folder.parent/'export/dev'
prior={}
for map_id in ('dev_00','dev_01'):
    df=pd.read_csv(old/map_id/'suffix_index.csv')
    prior[map_id]=df.suffix_pair_status.value_counts().to_dict()
assert sum(sum(counts.values()) for counts in prior.values())==2304
print(json.dumps(dict(hand_calculated_fixture='passed',previous_P1_DEV_arm_certificate_counts=prior),indent=2))

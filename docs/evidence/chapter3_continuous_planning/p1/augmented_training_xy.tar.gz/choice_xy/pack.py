"""Package all 96 directly viewable previews and exact portable inputs; PNG originals can be redrawn."""
from io import BytesIO
from pathlib import Path
import tarfile
from PIL import Image

base=Path(__file__).resolve().parent
with tarfile.open(base/'primary_nine_xy.tar.gz','w:gz') as tar:
    for name in ('index.csv','maps.json','case_legs.csv.gz','tracks.npz','draw_xy.py','pack.py','loss.png','rescue.png'):
        tar.add(base/name,'choice_xy/'+name)
    index=(base/'index.html').read_text()
    for png in sorted(base.glob('dev*.png')):
        target=png.with_suffix('.webp').name
        buf=BytesIO()
        with Image.open(png) as im:im.save(buf,'WEBP',lossless=True,method=3)
        b=buf.getvalue(); member=tarfile.TarInfo('choice_xy/'+target);member.size=len(b)
        tar.addfile(member,BytesIO(b));index=index.replace(png.name,target)
    page=index.encode();member=tarfile.TarInfo('choice_xy/index.html');member.size=len(page)
    tar.addfile(member,BytesIO(page))

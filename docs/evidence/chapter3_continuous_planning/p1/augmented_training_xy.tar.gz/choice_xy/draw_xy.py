"""Export primary DEV comparison coordinates and redraw panels independently of the physical archives."""
import argparse
import hashlib
import json
from pathlib import Path
from subprocess import check_output

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties,fontManager
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
KEY=['map_id','root','gate_x','side']
STYLE={'fixed':('#626871','o','固定'),'original':('#17679a','s','原训练'),'augmented':('#c24720','D','扩充训练')}
TERM={'goal':'抵达终点','tracking_domain_exit':'越出跟踪范围','forbidden_obstacle_contact':'碰墙','physical_failure':'物理失败','timeout':'超时'}
def clip(ref,x0,x1):
    x=ref[:,0];a=max(x0,x[0]);b=min(x1,x[-1])
    if a>=b:return ref[:0]
    ys=np.interp([a,b],x,ref[:,1])
    return np.vstack(([a,ys[0]],ref[(x>a)&(x<b)],[b,ys[1]]))

def export(root,old16,dest):
    source=root/'supplement_old16' if old16 else root/'nine_option'
    old='original' if old16 else 'original_61123'
    aug='augmented' if old16 else 'augmented_61123'
    menu='old16' if old16 else 'registered_alpha'
    run=root.parent
    allrows=[];arrays={};memo={}; maps={}
    def intern(a):
        a=np.ascontiguousarray(a)
        key='a'+hashlib.sha256(a.dtype.str.encode()+str(a.shape).encode()+a.tobytes()).hexdigest()[:20]
        arrays[key]=a
        return key
    with np.load(run/'shared/neutral.npz') as z:neutral=z['xy'][0]
    indices={}
    for folder,role in [(old,'fixed'),(old,'original'),(aug,'augmented')]:
        table=pd.read_csv(source/folder/'physical_pairs.csv.gz').query('menu==@menu and method=="mixture3" and seed=="61123"')
        if old16:table=table.query('root==1336 and gate_x==15 and side==1')
        for r in table.itertuples():
            fixed=role=='fixed';suffix='_fixed' if fixed else ''
            family='old' if fixed else r.family;slot=r.fixed_slot if fixed else r.action_slot
            alpha=(1. if r.side==1 else 0.) if fixed else r.alpha
            path=getattr(r,'path'+suffix)
            m=r.map_id
            if m not in maps:
                world=json.loads((run/'maps'/m/'world.json').read_text())
                maps[m]=dict(step=world['terrain']['front_x_m'],walls=world['terrain']['forbidden_rectangles'],goal=world['goal'])
            if (m,family) not in indices:
                parent=run if family=='old' else run/'continuous_interpolation'
                indices[m,family]=pd.read_csv(parent/'export/dev'/m/'suffix_index.csv').set_index('trajectory')
            idx=indices[m,family].loc[path]
            assert idx.root==r.root and idx.action_slot==slot and np.isclose(alpha,idx.alpha) and idx.arm==('left' if r.side==1 else 'right')
            if path not in memo:
                with np.load(path) as z:
                    xy=z['qpos'][:,:2]; assert np.array_equal(xy,z['trace'][:,1:3],equal_nan=True)
                    t=z['trace'][:,0];last=np.flatnonzero(np.isfinite(xy).all(axis=1))[-1]
                    assigned=int(idx.assigned_tick) if idx.physical_target_effective else -1
                    x0=xy[3,0];x1=xy[assigned,0] if assigned>=0 else np.nanmax(xy[:,0])
                    refs=[clip(neutral,xy[0,0],x0),clip(z['reference_xy'],x0,x1)]
                    if assigned>=0:refs.append(clip(z['published_reference_xy'],x1,maps[m]['goal']['x_max_m']))
                    ref=np.concatenate([np.vstack([a,[np.nan,np.nan]]) for a in refs if len(a)])
                    memo[path]=dict(xy=intern(xy),reference=intern(ref),assigned_tick=assigned,last_time_s=t[last],physical_end_s=t[-1],
                                    endx=xy[last,0],endy=xy[last,1],term=idx.termination,source=path)
            row={k:getattr(r,k) for k in KEY}
            allrows.append(dict(**row,role=role,family=family,slot=slot,alpha=alpha,force=r.force,score=r.fixed_score if fixed else r.score,
                     gate_lo=getattr(r,'lower'+suffix),gate_hi=getattr(r,'upper'+suffix),margin_lo=getattr(r,'margin_lower'+suffix),
                     margin_hi=getattr(r,'margin_upper'+suffix),clearance_m=getattr(r,'actual_min_clearance_m'+suffix),**memo[path]))
    dest.mkdir(exist_ok=True,parents=True)
    frame=pd.DataFrame(allrows)
    assert len(frame)==(9 if old16 else 864) and not frame.duplicated(KEY+['role','force']).any()
    frame.to_csv(dest/'case_legs.csv.gz',index=False)
    np.savez_compressed(dest/'tracks.npz',**arrays)
    (dest/'maps.json').write_text(json.dumps(dict(maps=maps,old16=old16,unique_paths=len(memo),case_legs=len(frame)),indent=2)+'\n')

def draw(dest):
    frame=pd.read_csv(dest/'case_legs.csv.gz')
    cfg=json.loads((dest/'maps.json').read_text())
    with np.load(dest/'tracks.npz') as z:arrays={k:z[k] for k in z}
    font=check_output(['fc-match','-f','%{file}','Noto Sans CJK SC'],text=True)
    fontManager.addfont(font)
    plt.rcParams.update({'font.family':FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':10})
    index=[]
    for key,group in frame.groupby(KEY):
        m,root,gx,side=key;scene=cfg['maps'][m];goal=scene['goal']
        fig,axes=plt.subplots(3,1,figsize=(13,7.2),sharex=True,sharey=True)
        fig.subplots_adjust(left=.065,right=.98,top=.805,bottom=.13,hspace=.66)
        picks=group.drop_duplicates('role').set_index('role')
        # Identical physical choices use one line and one label shared by all matching rules.
        routes={}
        for role in STYLE:
            r=picks.loc[role];routes.setdefault((r.family,r.slot),[]).append(role)
        title=('旧16条入口' if cfg['old16'] else '固定入口和八条新入口')+'　｜　'+m+f'　起点 {root}　'+('近' if gx<14 else '远')+('左门' if side==1 else '右门')+f'　x={gx:g} m'
        fig.suptitle(title,y=.99,fontsize=16)
        handles=[];styles=[]
        for route,roles in routes.items():
            role=roles[-1] if 'fixed' not in roles else ('original' if 'original' in roles and 'augmented' not in roles else 'fixed')
            color,marker,_=STYLE[role];label='、'.join(STYLE[i][2] for i in roles);r=picks.loc[roles[0]]
            handles.append(Line2D([],[],c=color,marker=marker,lw=2,label=label+f'：'+('旧' if route[0]=='old' else '新')+f'槽{route[1]}，α={r.alpha:.3g}'))
            styles.append((label,roles,color,marker))
        handles+=[Line2D([],[],c='#4e5358',lw=1.1,ls='--',label='实际下发的参考线')]
        fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.945),frameon=False,ncol=4)
        xx=[];yy=[]
        for ax,(force,g) in zip(axes,group.groupby('force')):
            ax.axvline(scene['step'],ls=':',lw=1.2,c='#7e8387')
            ax.plot([gx,gx],[side*.06,side*3.9],c='#3d704e',lw=2,zorder=1)
            for x0,x1,y0,y1 in scene['walls']:
                ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc='#806758',ec='#594b43',lw=.4))
            ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],fc='#e4eedf',zorder=0))
            labels=[]
            for name,roles,color,marker in styles:
                leg=g[g.role.isin(roles)];assert leg.source.nunique()==1
                r=leg.iloc[0];xy=arrays[r.xy];ref=arrays[r.reference]
                ax.plot(*xy.T,lw=1.8,c=color,zorder=3);ax.plot(*ref.T,lw=1.1,c=color,ls=(0,(3,2)),zorder=4)
                ax.plot(r.endx,r.endy,marker=marker,c=color,ms=6.6,mec='white',mew=.6,zorder=5)
                xx.append(xy[:,0]);yy.extend([xy[:,1],ref[:,1]])
                if r.gate_lo!=r.gate_hi:status='结果未定'
                elif r.gate_lo:
                    status=f'完成，净空{r.clearance_m*100:.1f} cm'+(' ✓' if r.margin_lo==1 else ' ×')
                else:status='未完成 · '+TERM.get(r.term,str(r.term))
                labels.append(name+' '+status)
            ax.set_title(f'横推 {force:+d} N　　 '+'　　 '.join(labels),loc='left',fontsize=10)
            ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.22,lw=.45);ax.set_ylabel('y（m）')
            ax.spines[['top','right']].set_visible(False)
        x=np.concatenate(xx);y=np.concatenate(yy)
        axes[-1].set(xlabel='世界 x（m）',xlim=(min(1.,np.nanmin(x)-.15),max(goal['x_max_m'],np.nanmax(x))+.35),
                     ylim=(min(-.95,np.nanmin(y)-.14),max(.95,np.nanmax(y)+.14)))
        fig.text(.5,.032,'实线是实际车体轨迹，末端符号是最后实测位置。竖点线为台阶，绿线为门，棕块为墙，浅绿色为终点区。净空达标须大于 5.33 cm。',ha='center',fontsize=9)
        filename=f"{m}_{root}_{gx:g}_{'left' if side==1 else 'right'}.png"
        fig.savefig(dest/filename,dpi=110)
        plt.close(fig)
        rows={role:group[group.role.eq(role)] for role in STYLE}
        result=dict(zip(KEY,key),file=filename)
        for role,g in rows.items():
            result[role+'_slot']=f"{g.family.iloc[0]}{g.slot.iloc[0]}"
            result[role+'_gate']=int(g.gate_lo.sum());result[role+'_margin']=int(g.margin_lo.sum())
        index.append(result)
    df=pd.DataFrame(index);df.to_csv(dest/'index.csv',index=False)
    body=['<!doctype html><html lang="zh"><meta charset="utf-8"><title>三种选路的实走对照</title><style>body{font:16px sans-serif;max-width:70rem;margin:2rem auto}td,th{padding:.4rem .9rem;text-align:left}tr:nth-child(even){background:#f1f4f6}</style><h1>同一起点、同一道门的三种选路</h1><p>每幅图叠加固定规则、原训练模型和扩充训练模型的真实轨迹，三行分别为 −5、0、+5 N 横推。</p>']
    if not cfg['old16']:
        import shutil
        for short,(m,root,gx,side),label in [('loss',('dev_01',1336,15.,1),'损失'),('rescue',('dev_00',1325,12.7,-1),'获救')]:
            r=df[(df.map_id==m)&(df.root==root)&(df.gate_x==gx)&(df.side==side)].iloc[0]
            shutil.copyfile(dest/r.file,dest/(short+'.png'))
            body.append(f'<p><a href="{short}.png">{label}例：{m}，起点 {root}</a>　原训练→扩充训练，原门 {r.original_gate}→{r.augmented_gate}，净空 {r.original_margin}→{r.augmented_margin}。</p>')
    body.append('<table><tr><th>地图</th><th>起点</th><th>门口</th><th>原固定、原训练、扩充训练的槽号</th><th>原门（各/3）</th><th>净空（各/3）</th></tr>')
    for r in df.itertuples():
        body.append(f'<tr><td>{r.map_id}</td><td>{r.root}</td><td><a href="{r.file}">{r.gate_x:g} m '+('左' if r.side==1 else '右')+f'</a></td><td>{r.fixed_slot} / {r.original_slot} / {r.augmented_slot}</td><td>{r.fixed_gate}/{r.original_gate}/{r.augmented_gate}</td><td>{r.fixed_margin}/{r.original_margin}/{r.augmented_margin}</td></tr>')
    (dest/'index.html').write_text(''.join(body)+'</table></html>')

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--dest',type=Path,default=HERE)
    cli.add_argument('--export',type=Path,help='optional path to continuous_train_support, for refreshing portable coordinates')
    cli.add_argument('--old16',action='store_true',help='export the prespecified old16 example instead')
    a=cli.parse_args()
    if a.export:export(a.export.resolve(),a.old16,a.dest)
    draw(a.dest)

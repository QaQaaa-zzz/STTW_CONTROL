# TRAIN 门侧配对与 1300 号实走图

解压后执行 `python reproduce.py`。需要 Python、NumPy、Pandas 和 Matplotlib。脚本用 inputs 目录的三份门结果表和八条参考的几何参数，重算 576 组配对的结果与未知分支上下界，并逐项核对已保存的表和收据。从 12 条实际轨迹、当时生效的参考曲线及原地图重画 root1300_gate_reversal.png。图只显示世界 x≥8.5 m；数字文件保存完整已执行的 XY、时间与真实终点。root1300_sources.csv 内末列是原实跑文件的位置，供追溯来源，独立复算不读取该路径。verify_and_draw.py 是从原始实验文件产生坐标与图的脚本。

"""Two fixed approaches compared under left and right gate instructions, measured TRAIN only."""
from pathlib import Path
from itertools import product
from collections import defaultdict
import hashlib
import json
import struct
import zipfile
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

O=Path(__file__).resolve().parent
T=O/'inputs'
SRC=[T/f'pair_{i}_gate_cases.csv.gz' for i in range(3)]
cases=pd.concat([pd.read_csv(p) for p in SRC],ignore_index=True)
geo=pd.read_csv(T/'curves.csv')[['slot','side','edge_magnitude_m','shape']].rename(columns={'slot':'action_slot','side':'edge_side'})
cases=cases.merge(geo,on='action_slot',validate='many_to_one')
key=['map_id','root','edge_side','edge_magnitude_m','gate_x']
assert len(cases)==6912 and len(cases[key].drop_duplicates())==576
records=[]
for ident,g in cases.groupby(key,sort=True):
    assert len(g)==12
    row=dict(zip(key,ident));spans=[]
    for name,gate,shape in [('left_outward',1,'outward'),('left_turnback',1,'turnback'),('right_outward',-1,'outward'),('right_turnback',-1,'turnback')]:
        block=g[(g.side==gate)&g['shape'].eq(shape)].sort_values('force')
        assert block.force.tolist()==[-5,0,5] and block.action_slot.nunique()==1
        c=block[['lower','upper']].sum().astype(int)
        spans.append(range(c.lower,c.upper+1))
        row[name+'_lo']=c.lower;row[name+'_hi']=c.upper;row[name+'_slot']=block.action_slot.iloc[0]
    outcomes=[]
    for lo,lt,ro,rt in product(*spans):
        common=max(lo+ro,lt+rt);adapt=max(lo,lt)+max(ro,rt)
        side=1 if lo>lt and ro<rt else (-1 if lo<lt and ro>rt else 0)
        gap=adapt-common
        assert (gap>0)==bool(side)
        outcomes.append((gap,side,common,adapt))
    arr=np.asarray(outcomes)
    definite=len(set(arr[:,1]))==1 and arr[0,1]!=0
    row.update(oracle_gap_lo=int(arr[:,0].min()),oracle_gap_hi=int(arr[:,0].max()),common_fixed_lo=int(arr[:,2].min()),common_fixed_hi=int(arr[:,2].max()),gate_specific_lo=int(arr[:,3].min()),gate_specific_hi=int(arr[:,3].max()),
               definite_reversal=bool(definite),possible_reversal=bool(arr[:,0].max()>0),
               direction='left_outward_right_turnback' if definite and arr[0,1]==1 else ('left_turnback_right_outward' if definite else 'unresolved' if arr[:,0].max()>0 else 'none'))
    records.append(row)
pairs=pd.DataFrame(records)
pd.testing.assert_frame_equal(pairs,pd.read_csv(O/'paired_gate_preference.csv'),check_dtype=False)
f=pairs[pairs.definite_reversal]
report=dict(total=len(pairs),maps=pairs.map_id.nunique(),roots=pairs.root.nunique(),gate_observations=len(cases),unknown_gate_observations=int((~cases.known).sum()),definite=len(f),affected_roots=len(f[['map_id','root']].drop_duplicates()),affected_maps=f.map_id.nunique(),directions=f.direction.value_counts().to_dict(),definite_gain_sizes=f.oracle_gap_lo.value_counts().to_dict(),possible_extra=int((pairs.possible_reversal&~pairs.definite_reversal).sum()),zero=int((~pairs.possible_reversal).sum()),whole_panel_opportunities=6*len(pairs),gap=[int(pairs.oracle_gap_lo.sum()),int(pairs.oracle_gap_hi.sum())],by_gate=[])
for gate,g in pairs.groupby('gate_x'):
    report['by_gate'].append(dict(gate_x=gate,pairs=len(g),full_decisions=len(g)*6,lo=int(g.oracle_gap_lo.sum()),hi=int(g.oracle_gap_hi.sum()),definite=int(g.definite_reversal.sum())))
report['inputs']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC}
assert (report['definite'],report['affected_roots'],report['affected_maps'],report['gap'])==(73,42,6,[79,80])
assert sorted(report['directions'].values())==[8,65]
assert json.loads(json.dumps(report))==json.loads((O/'receipt.json').read_text())
print(json.dumps(report),flush=True)

world=json.loads((T/'train_04_world.json').read_text())
rows=pd.read_csv(O/'root1300_sources.csv')
by={}
with np.load(O/'root1300_coordinates.npz') as archive:
    for r in rows.itertuples():
        xy=archive[r.key+'_xy']; tim=archive[r.key+'_seconds']
        assert len(tim)==len(xy) and np.allclose(xy[-1],[r.terminal_x_m,r.terminal_y_m])
        hits=np.flatnonzero((xy[:-1,0]<r.gate_x_m)&(xy[1:,0]>=r.gate_x_m)&(np.arange(1,len(xy))>=r.handback_tick)) if r.handback_tick>=0 else []
        gy=np.interp(r.gate_x_m,xy[hits[0]:hits[0]+2,0],xy[hits[0]:hits[0]+2,1]) if len(hits) else np.nan
        ok=bool(r.handback_tick>=0 and np.isfinite(gy) and .06<=(1 if r.gate=='left' else -1)*gy<=3.9 and r.terminal=='goal')
        assert np.isclose(gy,r.gate_y_m,equal_nan=True) and ok==r.success
        segs=[archive[r.key+'_ref'+str(i)] for i in range(r.reference_pieces)]
        by[r.gate,r.force_N,r.slot]=dict(xy=xy,segs=segs,gy=gy,ok=ok,term=r.terminal)
color={0:'#006B8D',2:'#B35320'}
fig=plt.figure(figsize=(12.4,7.55),dpi=170)
fig.text(.076,.953,'The better approach changes with the requested gate',fontsize=19,weight='semibold',color='#233842')
fig.text(.076,.905,'TRAIN map 04, start 1300  ·  Both approaches target y = +0.04 m at the step edge, α = 0  ·  Each chosen entry faces all three pushes',fontsize=10,color='#415660')
handles=[Line2D([],[],lw=2.7,color=color[0],label='Outward (entry 0)'),Line2D([],[],lw=2.7,color=color[2],label='Turnback (entry 2)'),Line2D([],[],color='#38444a',lw=1.6,label='Actual path'),Line2D([],[],color='#38444a',ls=':',lw=1.8,label='Active reference'),Line2D([],[],color='#38444a',mfc='white',marker='o',ls='',label='Complete'),Line2D([],[],color='#38444a',marker='x',ls='',label='Failure')]
fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.068,.886),ncol=6,frameon=False,fontsize=9.5,columnspacing=1.4)
for side,left in [('left',.075),('right',.565)]:
    fig.text(left,.804,('Left gate   ·   outward 3/3, turnback 0/3' if side=='left' else 'Right gate   ·   outward 0/3, turnback 2/3'),fontsize=12.2,weight='semibold',color='#233842')
    for i,f in enumerate([-5,0,5]):
        mid=.696-.215*i
        ax=fig.add_axes([left,mid-.067,.402,.143]);ax.set_aspect('equal',adjustable='box');ax.set_xlim(8.5,18.65);ax.set_ylim(-.84,.66)
        if side=='left':fig.text(.013,mid+0.005,f'{f:+d} N' if f else '0 N',weight='semibold',fontsize=11,color='#273c46')
        goal=world['goal'];ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],fc='#DCEFE4',ec='#A0C4B1',lw=.7))
        gx=world['terrain']['front_x_m']; ax.axvline(gx,color='#879294',ls='--',lw=1)
        for x0,x1,y0,y1 in world['terrain']['forbidden_rectangles']:ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc='#494341',ec='#272829',lw=.65,zorder=4))
        pole=.06 if side=='left' else -.06
        ax.vlines(15,pole,3.9*np.sign(pole),color='#80558A',lw=2.3,zorder=1);ax.scatter(15,pole,s=13,color='#80558A',zorder=4)
        for slot in (0,2):
            v=by[side,f,slot];xy=v['xy'];col=color[slot]
            for seg in v['segs']:ax.plot(*seg.T,color=col,ls=':',lw=1.5,zorder=2)
            ax.plot(*xy.T,color=col,lw=1.65,zorder=3)
            if np.isfinite(v['gy']):ax.scatter(15,v['gy'],marker='s',s=18,edgecolors='white',lw=.5,c=col,zorder=6)
            ax.plot(*xy[-1],ls='',marker='o' if v['ok'] else 'x',color=col,ms=6,mfc='white',mew=1.6,zorder=6)
            msg=(f'Gate y = {v["gy"]:+.3f} m, goal' if v['ok'] else
                 {'physical_failure':'Jump failed before handback','tracking_domain_exit':'Left tracking range','forbidden_obstacle_contact':'Hit obstacle'}[v['term']])
            fig.text(left,mid-.078-(.031 if slot==2 else 0),('Outward   ' if slot==0 else 'Turnback   ')+msg,va='center',fontsize=8.5,color=col)
        ax.set_xticks([9,10.3,12,13,15,17,18.5]);ax.set_yticks([-.5,0,.5]);ax.tick_params(labelsize=7.7,pad=2,length=2)
        if side=='right':ax.set_ylabel('y (m)',fontsize=8.2,labelpad=1)
        for sp in ('top','right'):ax.spines[sp].set_visible(False)
        for sp in ('left','bottom'):ax.spines[sp].set_color('#a8b1b2')
fig.text(.075,.107,'World x (m) and y (m), equal scale. The view begins at x = 8.5 m and includes the actual end of every run.',fontsize=9.2,color='#415660')
fig.text(.075,.063,'Dashed vertical line: step edge. Purple line: permitted side of the gate at x = 15 m. Black rectangle: obstacle. Green: goal area.',fontsize=9.2,color='#415660')
fig.savefig(O/'root1300_gate_reversal.png',dpi=180)

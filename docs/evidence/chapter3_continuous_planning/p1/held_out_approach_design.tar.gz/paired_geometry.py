"""Four same-edge interpolations and four center-edge transfer probes on the P1 arc grid."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from scipy.interpolate import CubicHermiteSpline

R = Path(__file__).resolve().parent
P = R.parent
sys.path.insert(0, str(P/'actions'))
from continuous_approach import Boundary, generate_reference

FIELDS = ('xy', 'heading', 'curvature')
FRONT, TRIGGER, COMMITTED = 10.3, 9.2, 8.0


def same_edge(neutral, train, donors, anchor):
    s = neutral['s']
    join = s.searchsorted(COMMITTED)
    start = neutral['xy'][0, join, 0]
    # Donor interpolation and arc regridding follow the P1 geometry builder in world x.
    # The initial blend preserves the published straight. The terminal blend recovers
    # the same trained edge and post-edge path on each side.
    mesh = np.linspace(start, start + (s[-1]-s[join]) + .15,
                       int(np.ceil(((s[-1]-s[join])+.15) / .0025)) + 1)
    def smoothstep(x, lo, hi):
        u = np.clip((x-lo)/(hi-lo),0.,1.)
        return u**3*(10.-15.*u+6.*u**2)

    def values(i):
        x,y = train['xy'][i].T
        return CubicHermiteSpline(x,y,np.tan(train['heading'][i]))(mesh.clip(x[0], x[-1]))

    y = .5*(values(donors[0]) + values(donors[1]))*smoothstep(mesh,start,4.5)
    tail_weight = smoothstep(mesh,10.14,10.28)
    y = (1-tail_weight)*y + tail_weight*values(anchor)
    arc = s[join] + np.r_[0.,np.cumsum(np.hypot(np.diff(mesh),np.diff(y)))]
    after = np.arange(join+1,len(s))
    x = np.interp(s[after],arc,mesh)
    path = {k:v.copy() for k,v in neutral.items()}
    path['xy'][0,after] = np.stack((x,np.interp(x,mesh,y)),axis=1)
    all_x, all_y = path['xy'][0].T
    h = np.arctan2(np.gradient(all_y), np.gradient(all_x))
    path['heading'][0,after] = h[after]
    path['curvature'][0,after] = np.gradient(h,s)[after]
    # Continue with the heading and curvature of the actual training reference
    # after its rejoin, expressed on the new sample positions.
    tail = np.flatnonzero(all_x>=10.28)
    for key in ('heading','curvature'):
        path[key][0,tail] = np.interp(all_x[tail],train['xy'][anchor,:,0],train[key][anchor])
    return path


def closest_training(xy, bank):
    # Piecewise-linear sampled paths: the largest absolute difference is attained at a knot.
    grid = np.unique(np.r_[3.,10.3,xy[:,0],bank[:,:,0].ravel()])
    grid = grid[(grid>=3.)&(grid<=10.3)]
    y = np.interp(grid,*xy.T)
    distances = np.array([np.abs(y-np.interp(grid,*other.T)).max() for other in bank])
    return int(distances.argmin()),float(distances.min())


def build():
    with np.load(P/'shared/neutral.npz') as z:
        neutral = {k:(z[k] if k=='s' else z[k][:1]) for k in ('s', *FIELDS)}
    with np.load(P/'actions/approaches.npz') as z:
        train = {k:z[k] for k in ('s', *FIELDS)}
    s = neutral['s']
    join = int(s.searchsorted(COMMITTED))
    items = []
    for a,b in ((3,5),(7,9)):
        for sign in (1,-1):
            donors=(a,b) if sign==1 else (a+1,b+1)
            anchor=1 if sign==1 else 2
            original_x,original_y=train['xy'][anchor].T
            one=same_edge(neutral,train,donors,anchor)
            details=dict(donor_a=donors[0],donor_b=donors[1],donor_b_weight=.5,
                         interp_full_from_x_m=4.5,interp_full_to_x_m=10.14,rejoined_anchor_x_m=10.28,
                         edge_anchor_geometry=anchor,
                         intended_edge_y_m=np.interp(FRONT,original_x,original_y),
                         intended_edge_heading_rad=np.interp(FRONT,original_x,train['heading'][anchor]))
            items.append(('same_edge',sign,one,details))
    for y,angle in ((.085,2.7),(.205,6.2)):
        for sign in (1,-1):
            one,_=generate_reference(neutral,COMMITTED,FRONT,FRONT-TRIGGER,
                                     Boundary(sign*y,sign*np.deg2rad(angle),0.),0.,0.)
            items.append(('center_edge',sign,one,dict(intended_target_y_m=sign*y,
                          intended_target_heading_deg=sign*angle,intended_edge_y_m=0.,intended_edge_heading_rad=0.)))
    output, meta=[],[]
    for kind,sign,one,details in items:
        x,y = one['xy'][0].T
        h,k = one['heading'][0],one['curvature'][0]
        nearest,distance=closest_training(one['xy'][0],train['xy'])
        aft=(x>=TRIGGER)&(x<=FRONT)
        pre=(x>=1.)&(x<=TRIGGER)
        assert (np.diff(x)>0.).all() and distance>1e-5
        for key in FIELDS:np.testing.assert_array_equal(one[key][:,:join+1],neutral[key][:,:join+1])
        edge_y,edge_h=np.interp(FRONT,x,y),np.interp(FRONT,x,h)
        assert abs(edge_y-details['intended_edge_y_m'])<1e-4
        assert abs(edge_h-details['intended_edge_heading_rad'])<np.deg2rad(.05)
        row=dict(slot=len(output),kind=kind,side=sign,join_index=join,commit_requested_s_m=COMMITTED,
                 commit_copied_through_s_m=s[join],join_x_m=x[join],target_x_m=TRIGGER,
                 target_s_m=np.interp(TRIGGER,x,s),target_y_m=np.interp(TRIGGER,x,y),
                 target_heading_rad=np.interp(TRIGGER,x,h),target_heading_deg=np.rad2deg(np.interp(TRIGGER,x,h)),
                 target_curvature_m_inv=np.interp(TRIGGER,x,k),edge_x_m=FRONT,edge_s_m=np.interp(FRONT,x,s),
                 edge_y_m=edge_y,edge_heading_rad=edge_h,edge_heading_deg=np.rad2deg(edge_h),
                 nearest_training_geometry=nearest,distance_to_nearest_training_geometry_m=distance,
                 approach_peak_curvature=np.abs(k[pre]).max(),edge_peak_curvature=np.abs(k[aft]).max(),**details)
        meta.append(row);output.append(one)
    curves=dict(s=s,**{k:np.concatenate([one[k] for one in output]) for k in FIELDS})
    np.savez_compressed(R/'approaches.npz',**curves)
    np.savez_compressed(R/'neutral.npz',s=s,**{k:np.repeat(neutral[k],8,axis=0) for k in FIELDS})
    pd.DataFrame(meta).to_csv(R/'curves.csv',index=False)
    return curves,output,meta


if __name__=='__main__':
    _,_,meta=build()
    print(pd.DataFrame(meta)[['slot','kind','target_y_m','target_heading_deg','edge_y_m',
        'edge_heading_deg','nearest_training_geometry','distance_to_nearest_training_geometry_m',
        'approach_peak_curvature','edge_peak_curvature']].to_string(index=False))

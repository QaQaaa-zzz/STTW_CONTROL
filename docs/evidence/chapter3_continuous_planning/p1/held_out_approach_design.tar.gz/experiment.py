"""Eight previously unused continuous approaches, two known maps and paired fixed exits."""
import argparse
import fcntl
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

import numpy as np
import pandas as pd

R = Path(__file__).resolve().parent
P = R.parent
W = Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
SRC = R/'registered_source'
sys.path[:0] = [str(SRC),str(P/'actions'),str(P/'model'),str(P/'actions/amortized_exit'),
                str(W/'learning/cli'),str(W/'learning/src'),'/home/qy/DVGC/JIT/src']
MAPS = ('dev_00','dev_01')
GATES = [(12.7,1),(12.7,-1),(15.,1),(15.,-1)]
AMPS = [(.035,1.5),(.085,2.7),(.145,4.1),(.205,6.2)]
FIELDS = ('xy','heading','curvature')
def load(path):return json.loads(path.read_text())
def save(path,data):path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
    return h.hexdigest()

def sources():
    """Retain P1's original observer, verification and labels, with this experiment's row counts."""
    SRC.mkdir(exist_ok=True)
    files=[(P/'collect.py','observer.py',[('OUT=Path(__file__).resolve().parent','OUT=Path(__file__).resolve().parents[1]'),
        ('len(cfg[\'evaluation_lanes\'])!=1152',"len(cfg['evaluation_lanes'])!=b['lanes']"),
        ('2000*1152*','2000*b[\'lanes\']*'),("        tick=state['tick']","        tick=state['tick']\n        if tick in (0,1,32,128,512,1024,1536,1999):milestone(tick,state)")]),
        (P/'audit_pairs.py','audit_arms.py',[('OUT=Path(__file__).resolve().parent','OUT=Path(__file__).resolve().parents[1]'),('len(rows)!=1152',"len(rows)!=b['lanes']"),('(1152,4)',"(b['lanes'],4)")]),
        (P/'export/export_prefixes.py','extract.py',[('len(planned)==1152',"len(planned)==batch['lanes']"),('len(right)==576',"len(right)==batch['distinct_prefixes']"),('.eq(16)','.eq(8)'),("len(status['results'])==1152","len(status['results'])==batch['lanes']")])]
    manifest={}
    for path,name,edits in files:
        text=path.read_text()
        if name=='observer.py':text=text[:text.index('def main():')]
        for old,new in edits:
            assert text.count(old)==1,(name,old)
            text=text.replace(old,new,1)
        compile(text,name,'exec')
        (SRC/name).write_text(text)
        manifest[name]=dict(source=str(path),source_sha256=sha(path),sha256=sha(SRC/name))
    save(SRC/'provenance.json',manifest)

def geometry():
    from paired_geometry import build
    from run_platform_task_oracle import departure_route
    curves,outputs,meta=build()
    s=curves['s']
    bank=R/'departures.npz'
    # Store uncompressed .npy members: the same file is memory mapped during prospective scoring.
    arr={k:np.lib.format.open_memmap(R/(k+'.npy'),mode='w+',shape=(8*(1+3*len(s)),*curves[k].shape[1:]),dtype=np.float32) for k in FIELDS}
    for k in FIELDS:arr[k][:8]=curves[k]
    for i,single in enumerate(outputs):
        for d,y in enumerate((.36,0.,-.36)):
            for j in range(len(s)):
                one={'s':s,**{k:single[k].copy() for k in FIELDS}}
                departure_route(one,0,j,y,1.6,15.,16.5)
                idx=8+(3*i+d)*len(s)+j
                for k in FIELDS:arr[k][idx]=one[k][0]
    np.save(R/'s.npy',s)
    with zipfile.ZipFile(R/'departures.pending','w',compression=zipfile.ZIP_STORED,allowZip64=True) as out:
        for k in ('s',*FIELDS):
            if k in arr:arr[k].flush()
            out.write(R/(k+'.npy'),k+'.npy')
    (R/'departures.pending').replace(bank)
    del arr
    for k in ('s',*FIELDS):(R/(k+'.npy')).unlink()

def prepare():
    sources()
    geometry()
    old=load(P/'collection_contract.json')
    batches=[]
    for donor in old['batches']:
        if donor['name'] not in MAPS: continue
        name=donor['name'];cfg=load(Path(donor['config'])); folder=R/name;folder.mkdir(exist_ok=True)
        vs=[]
        for v in cfg['ground_handoff']['handoff_variants']:
            slot=v['action_slot']
            if slot>=8:continue
            vs.append(dict(v,geometry=slot,approach_alpha=0.,alpha_numerator_24=0))
        assert len(vs)==576
        cfg['ground_handoff'].update(handoff_variants=vs,reference_path=str(R/'neutral.npz'))
        cfg['evaluation_lanes']=[[v['geometry'],'h75',i] for i,v in enumerate(vs)]
        cfg['ccd_capacity']=len(vs)*8
        cfg['paired_departures']=dict(approach_file=str(R/'approaches.npz'),route_bank=str(R/'departures.npz'),
                                     direction_ids=[v['planned_departure'] for v in vs])
        save(folder/'config.json',cfg)
        batches.append(dict(donor,lanes=len(vs),distinct_prefixes=len(vs)//2,config=str(folder/'config.json'),
            config_sha256=sha(folder/'config.json'),physical=str(folder/'physical'),source_config=donor['config'],source_sha256=donor['config_sha256']))
    save(R/'collection_contract.json',dict(batches=batches,budget='2 DEV maps × 12 independent roots/map × 8 generated paths × 3 hidden pushes × 2 physically fixed exits = 1152 lanes; 2 overlapping workers of 576, 10s at 1ms physics/5ms control. No training.',
        shared_geometry=['4 same_edge held-out shapes, made from same-sided parents with matched step edge; 4 center_edge paths with novel central step-edge placement. Original eight central-edge proposal did not isolate changed shape from changed edge. Replaced before any physical rollout. Exact geometry and parent TRAIN alpha ranges in curves.csv.','All routes share the existing neutral centerline through grid s=8 m (world x=3 m); planned geometry releases at tick 3. Alpha=0 from first command.'],
        empirical='Reuse registered P1 empirical_particles: numeric path+alpha RMS distance to closest three candidate actions per training root, inverse squared weights and nearest-only below 0.025. Compare all 72 roots and five nearest reset roots. No use of test action identifiers.',
        inputs='Prospective scores from initial bank after original x translation, registered map, numeric path and alpha. Keep same candidate for three pushes and both physical arms. No physically realized terminal or push features used.',
        primary='Primary seed 61123. Mean, mixture, empirical_action, five_separate_roots. Same fast frozen explicit gate-side exit scorer for each. Report Brier and continuous state errors on actual relocked queries; rank each map/root/gate on score=p_relock*E[exit success | relock]. For each map/gate, rank the 12×8 candidates, admit top 24; lowest root/slot breaks ties. Compare false positive and feasible recall on matching observed side with missing bounds. All 96 root/gate choices must face all three pushes. Fixed gates 12.7/15m, left/right.',
        split='Same two DEV maps, same 24 DEV roots. Only paths and their geometry outcomes held out. No model update, no CAL or TEST. Explicit two-exit trials, no continuous online search claim.',
        stop='Single panel only. Record failed relock/unknown suffix and physical terminals. Geometry/clock drift or failure to establish concurrent physics ends analysis; no automatic replacement or resampling.'))
    ready=load(P/'collection_ready.json')
    save(R/'collection_ready.json',dict(maps={m:ready['maps'][m] for m in MAPS},geometry_sha256=sha(R/'approaches.npz'),bank_sha256=sha(R/'departures.npz')))
    predict()

def predict():
    import torch
    import extract
    from run_downstream_dev import load_support,predicted_states
    from jump_outcome import Dataset,DIM,decision_inputs
    from frozen_exit_value import FrozenExits,mapped_arrays
    from exit_value import KnownMap,ExitValue
    torch.set_num_threads(1)
    train,models=load_support(False)
    methods=[('mean','61123'),('mixture3','61123'),('empirical_action','shared'),('five_separate_roots','shared')]
    estimator=ExitValue(P/'actions/amortized_exit/train_model.npz')
    curves=dict(np.load(R/'approaches.npz'))
    engine=FrozenExits.__new__(FrozenExits)
    engine.approach=curves['xy'];engine.bank=mapped_arrays(R/'departures.npz');engine.bank_len=len(curves['s'])
    bank=dict(np.load(P/'initial_bank.npz'))
    scores=[];states=[]
    kinds=pd.read_csv(R/'curves.csv').set_index('slot').kind
    for b in load(R/'collection_contract.json')['batches']:
        cfg,left,right=extract.config_rows(b);idx=left.iloc[::3].reset_index(drop=True)
        assert (left[['bank_row','action_slot']].to_numpy()==np.repeat(idx[['bank_row','action_slot']],3,axis=0)).all()
        ids=idx.bank_row.to_numpy();q=bank['qpos'][ids].copy();q[:,0]+=cfg['ground_handoff']['start_x_m']-2.5
        obs=extract.decision_inputs(q,bank['qvel'][ids],idx.geometry.to_numpy(),idx.approach_alpha,curves,
            dict(np.load(b['raster'])),load(Path(b['world'])))
        x,q0,reset,act=decision_inputs(obs)
        meta=idx[['map_id','bank_row','action_slot','geometry','approach_alpha','bin','section_x','side']].rename(columns={
            'bank_row':'root','approach_alpha':'alpha','bin':'section','side':'target_side'})
        ds=Dataset(x,q0,reset,act,torch.zeros(len(idx),dtype=torch.bool),torch.full((len(idx),DIM),torch.nan),meta)
        particles,options=predicted_states(ds,models,train,methods)
        world=KnownMap(P/'maps'/b['name'])
        parts=[]
        for start in range(0,len(particles),96):
            g=particles[start:start+96];q,v,prev,t=[np.array([a[key] for a in g]) for key in ('q','v','prev','query_s')]
            rows=np.stack([engine.branch_ids(a['geometry'],a['q']) for a in g]);ids=[{key:a[key] for key in ('map_id','root','action_slot','method','seed','particle')} for a in g]
            for gx,side in GATES:
                branch=rows[:,0 if side==1 else 2];refs=[engine.bank[k][branch] for k in FIELDS]
                out=estimator.score(world,q,v,prev,t,gx,side,side,*refs)
                parts.append(pd.DataFrame(ids).assign(gate_x=gx,side=side,exit_probability=out))
            for r,qq,vv,tt in zip(ids,q,v,t):states.append(dict(**r,q=qq.tolist(),velocity=vv.tolist(),query_s=tt))
        key=['map_id','root','action_slot','method','seed']
        cond=pd.concat(parts).groupby(key+['gate_x','side'],as_index=False).exit_probability.mean()
        base=pd.DataFrame([dict(**{k:tag[k] for k in key},p_relock=pr,gate_x=gx,side=side)
            for tag,pr,pts in options.values() for gx,side in GATES])
        out=base.merge(cond,how='left',on=key+['gate_x','side'],validate='one_to_one')
        assert (out.loc[out.exit_probability.isna(),'p_relock']==0).all()
        out['score']=out.p_relock*out.exit_probability.fillna(0.);out['kind']=out.action_slot.map(kinds)
        scores.append(out)
    data=pd.concat(scores,ignore_index=True);data.to_csv(R/'pre_action_scores.csv.gz',index=False)
    with (R/'pre_action_states.jsonl').open('w') as stream:
        for row in states:stream.write(json.dumps(row)+'\n')
    choices=[];admits=[]
    for cohort in ('same_edge','center_edge','all8'):
        d=data if cohort=='all8' else data[data.kind==cohort]
        ordered=d.sort_values(['score','root','action_slot'],ascending=[False,True,True],kind='stable')
        group=['map_id','gate_x','side','method','seed']
        choices.append(ordered.groupby(group+['root'],sort=False).head(1).assign(cohort=cohort))
        admitted=ordered.groupby(group,sort=False).head(24 if cohort=='all8' else 12)
        admits.append(admitted.assign(cohort=cohort))
    pd.concat(choices).to_csv(R/'pre_action_choices.csv',index=False)
    pd.concat(admits).to_csv(R/'pre_action_admissions.csv.gz',index=False)
    save(R/'prediction_receipt.json',dict(scores=len(data),decisions=sum(map(len,choices)),source_observations=extract.OBSERVED,
        closed_loop_physics_started=False,post_control_data_read='Only TRAIN support; no new-geometry physical outcomes exist at submission.',
        hashes={f:sha(R/f) for f in ['collection_contract.json','approaches.npz','curves.csv','pre_action_scores.csv.gz',
            'pre_action_states.jsonl','pre_action_choices.csv','pre_action_admissions.csv.gz']}))

def worker(batch,barrier):
    import observer
    def milestone(tick,state):
        import torch
        torch.cuda.synchronize()
        times=torch.from_dlpack(state['data'].time)[state['alive']]
        entry=dict(tick=tick,worlds=len(state['alive']),alive=len(times),arrived=time.monotonic(),pid=os.getpid(),
                   live_time_min=float(times.min()) if len(times) else None,live_time_max=float(times.max()) if len(times) else None)
        barrier.wait()
        entry['released']=time.monotonic()
        with (R/batch['name']/'milestones.jsonl').open('a') as f:f.write(json.dumps(entry)+'\n')
    observer.milestone=milestone
    observer.observed_run(batch)

def run():
    from multiprocessing.connection import wait
    import observer
    b=load(R/'collection_contract.json')['batches'];rec=load(R/'prediction_receipt.json')
    for name,h in rec['hashes'].items():assert sha(R/name)==h
    if any(Path(v['physical']).exists() for v in b):raise RuntimeError('Existing physical batch detected')
    os.environ.update(XLA_PYTHON_CLIENT_PREALLOCATE='false',OMP_NUM_THREADS='1')
    ctx=mp.get_context('spawn');barrier=ctx.Barrier(2)
    with (W.parents[2]/'research-hub/.gpu-job.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        def notify(stage,text):
            subprocess.run(['/usr/bin/python3',str(W/'learning/scripts/notify_chapter3_job.py'),'--title','第三章库外入口 '+stage,'--message',text,'--receipt',str(R/(stage+'_bark.json'))])
        notify('start','24个开发起点，八条新入口，三推、左右两出口。两张图各576车同步。')
        jobs=[ctx.Process(target=worker,args=(item,barrier)) for item in b]
        for job in jobs:job.start()
        pending={job.sentinel:job for job in jobs}
        while pending:
            for fd in wait(list(pending)):
                job=pending.pop(fd);job.join()
                if job.exitcode:barrier.abort()
        if any(job.exitcode for job in jobs):
            notify('error',f'两个物理进程退出码 {[j.exitcode for j in jobs]}');raise RuntimeError('Incomplete physics')
        stamps=[[json.loads(line) for line in (R/v['name']/'milestones.jsonl').read_text().splitlines()] for v in b]
        paired=list(zip(*stamps,strict=True))
        assert [r[0]['tick'] for r in paired]==[0,1,32,128,512,1024,1536,1999]
        overlap=[dict(from_tick=prev[0]['tick'],to_tick=now[0]['tick'],overlap_s=min(t['arrived'] for t in now)-max(t['released'] for t in prev),alive=sum(t['alive'] for t in now)) for prev,now in zip(paired,paired[1:])]
        assert any(t['alive']==1152 and t['overlap_s']>0 for t in overlap)
        save(R/'parallelism.json',dict(total=1152,worker_worlds=[576,576],intervals=overlap))
    analyze()
    notify('complete','1152条物理轨迹已完成，实际选择、预测误差、误放率已输出。')
    subprocess.run(['systemctl','--user','start','--no-block','sttw-ch3-rolling-goal-check.service'])

def analyze():
    import torch,audit_arms,extract
    from run_playground_task_reversal import crossings_by_section
    from sttw_control.playground_prediction import euler
    audit_arms.OUT=R;extract.OUT=R/'export'
    key=['map_id','root','action_slot']
    scores=pd.read_csv(R/'pre_action_scores.csv.gz');choices=pd.read_csv(R/'pre_action_choices.csv');admits=pd.read_csv(R/'pre_action_admissions.csv.gz')
    frozen=pd.read_json(R/'pre_action_states.jsonl',lines=True,dtype={'seed':str});statepred=[]
    for keys,g in frozen.groupby(key+['method']):
        p=np.array(g.q.tolist());v=np.array(g.velocity.tolist());pose=euler(torch.tensor(p[:,3:7])).numpy()
        statepred.append(dict(zip(key+['method'],keys),x=p[:,0].mean(),y=p[:,1].mean(),roll=np.arctan2(np.sin(pose[:,0]).mean(),np.cos(pose[:,0]).mean()),yaw=np.arctan2(np.sin(pose[:,2]).mean(),np.cos(pose[:,2]).mean()),body_vx=v[:,0].mean(),t=g.query_s.mean()))
    statepred=pd.DataFrame(statepred);outs=[];metrics=[]
    for b in load(R/'collection_contract.json')['batches']:
        folder=R/'export/dev'/b['name'];audit_arms.audit(b['name']);extract.export_map(b)
        mat=dict(np.load(folder/'measured_targets.npz'));ix=pd.read_csv(folder/'prefix_index.csv')
        with np.load(folder/'observed_inputs.npz') as z:
            bank=dict(np.load(P/'initial_bank.npz'));q=bank['qpos'][ix.root].copy();q[:,0]+=load(Path(b['config']))['ground_handoff']['start_x_m']-2.5
            np.testing.assert_array_equal(z['t0_qpos_native'],q);np.testing.assert_array_equal(z['t0_qvel_native'],bank['qvel'][ix.root])
        m=ix[key+['row','hidden_force_N_grouping_only']].copy();m['verified']=mat['verified_relock'];mask=mat['regression_valid']
        q=mat['query_qpos_native'];a=euler(torch.tensor(q[:,3:7])).numpy()
        for k,col in [('x',q[:,0]),('y',q[:,1]),('roll',a[:,0]),('yaw',a[:,2]),('body_vx',mat['query_velocity_state9'][:,0]),('t',mat['query_s'])]:m[k+'_obs']=np.where(mask,col,np.nan)
        m=m.merge(scores.drop_duplicates(key+['method'])[key+['method','kind','p_relock']],on=key).merge(statepred,on=key+['method'],how='left')
        m['brier']=(m.p_relock-m.verified.astype(float))**2;m['xy_sq']=(m.x-m.x_obs)**2+(m.y-m.y_obs)**2
        for k in ['roll','yaw']:m[k+'_abs_deg']=np.rad2deg(abs(np.angle(np.exp(1j*(m[k]-m[k+'_obs'])))))
        for k in ['body_vx','t']:m[k+'_abs']=(m[k]-m[k+'_obs']).abs()
        metrics.append(m)
        s=pd.read_csv(folder/'suffix_index.csv')
        for lane in s.itertuples():
            with np.load(lane.trajectory) as z:cross=list(crossings_by_section(z['trace'],lane.native_handoff_s if pd.notna(lane.native_handoff_s) else np.inf,[12.7,13.6,15.]))
            for j,gx in [(0,12.7),(2,15.)]:
                side=1 if lane.arm=='left' else -1;y=cross[j][-1]
                executed=lane.suffix_pair_status=='matched_observed_handoff' and lane.observed_query and lane.physical_target_effective and lane.online_selected_direction==lane.declared_direction
                known=not lane.verified_relock or executed;success=bool(lane.verified_relock and y is not None and .06<=side*y<=3.9 and lane.physical_goal and not lane.physical_wall)
                outs.append(dict(map_id=lane.map_id,root=lane.root,action_slot=lane.action_slot,gate_x=gx,side=side,force=lane.hidden_force_N_grouping_only,known=known,lower=int(known and success),upper=int(success or not known),terminal=lane.termination,path=lane.trajectory))
    metric=pd.concat(metrics);metric.to_csv(R/'measured_jump_errors.csv.gz',index=False)
    summary=metric.groupby(['map_id','kind','method']).agg(prefixes=('row','size'),observed_relocks=('verified','sum'),states_scored=('xy_sq','count'),brier=('brier','mean'),xy_mse=('xy_sq','mean'),roll_abs_deg=('roll_abs_deg','mean'),yaw_abs_deg=('yaw_abs_deg','mean'),body_vx_abs=('body_vx_abs','mean'),time_abs_s=('t_abs','mean'));summary['xy_rmse_m']=np.sqrt(summary.xy_mse);summary.to_csv(R/'jump_summary.csv')
    truth=pd.DataFrame(outs);k=key+['gate_x','side'];truth.to_csv(R/'real_gate_cases.csv.gz',index=False)
    for name,frame in [('selected',choices),('admitted',admits)]:
        joined=frame.merge(truth,on=k,validate='many_to_many');assert len(joined)==3*len(frame)
        joined.to_csv(R/(name+'_cases.csv.gz'),index=False)
        totals=joined.groupby(['cohort','map_id','gate_x','side','method']).agg(tests=('force','size'),success_lo=('lower','sum'),success_hi=('upper','sum'))
        totals['fail_lo']=totals.tests-totals.success_hi;totals['fail_hi']=totals.tests-totals.success_lo
        if name=='admitted':
            totals['false_admission_rate_lo']=totals.fail_lo/totals.tests; totals['false_admission_rate_hi']=totals.fail_hi/totals.tests
            full=truth.merge(scores[k+['kind']].drop_duplicates(),on=k)
            for condition,rr in totals.iterrows():
                cohort,map_id,gx,side,method=condition;a=full[(full.map_id==map_id)&(full.gate_x==gx)&(full.side==side)]
                if cohort!='all8':a=a[a.kind==cohort]
                row=joined[(joined.cohort==cohort)&(joined.map_id==map_id)&(joined.gate_x==gx)&(joined.side==side)&(joined.method==method)]
                lo,hi=int(rr.success_lo),int(rr.success_hi);rej_lo=a.lower.sum()-lo;rej_hi=a.upper.sum()-hi
                totals.loc[condition,'recall_lo']=lo/(lo+rej_hi) if lo+rej_hi else np.nan
                totals.loc[condition,'recall_hi']=hi/(hi+rej_lo) if hi+rej_lo else np.nan
        totals.to_csv(R/(name+'_summary.csv'))
    from draw_choices import draw
    draw()
    save(R/'result.json',dict(stage='complete',registered_choices=len(choices),new_physical_lanes=1152,observed_prefixes=576,new_training_updates=0))

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('stage',choices=('prepare','run','analyze','predict'));a=ap.parse_args()
    if a.stage in ('prepare','predict'):os.environ['CUDA_VISIBLE_DEVICES']=''
    {'prepare':prepare,'run':run,'predict':predict,'analyze':analyze}[a.stage]()

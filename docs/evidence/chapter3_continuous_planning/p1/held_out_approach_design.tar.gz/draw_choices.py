"""Actual and active-reference XY for each registered selection, from physical trajectories."""
from functools import lru_cache
from html import escape
import json
import os
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

R = Path(__file__).resolve().parent
sys.path.insert(0, str(R.parent / "model"))
from frozen_exit_value import mapped_arrays

METHODS = {"mean": "Mean", "mixture3": "Mixture", "empirical_action": "Action", "five_separate_roots": "5 roots"}
COHORTS = {"all8": "All 8", "same_edge": "Same edge (4)", "center_edge": "Central edge (4)"}
COLORS = ["#0069a5", "#bf5200", "#00815d", "#9a467e", "#74549a", "#887000", "#ab353d", "#007484"]


@lru_cache(maxsize=256)
def straight_ids(query):
    with np.load(query) as archive:
        return archive["branch_ids"][:, 1].copy()


def read_case(row, neutral, bank, initial_tick):
    with np.load(row.trajectory) as z:
        names = z["columns"].tolist()
        trace = z["trace"]
        xy = z["qpos"][:, :2].copy()
        approach = z["reference_xy"]
        final = z["published_reference_xy"]
    time = trace[:, names.index("time")]
    if not np.isclose(time[-1], row.duration_s, atol=1.e-6):
        raise ValueError(f"Physical endpoint disagrees with trajectory: {row.trajectory}")
    knots = [(0, neutral), (initial_tick, approach)]
    if pd.notna(row.query_tick):
        straight = straight_ids(row.query_file)[int(row.query_file_row)]
        knots.append((int(row.query_tick), bank["xy"][straight]))
    if row.assigned_tick >= 0:
        knots.append((int(row.assigned_tick), final))
    ground = np.isin(trace[:, names.index("phase")], [0, 2])
    finite = np.isfinite(xy).all(axis=1)
    pieces = []
    for i, (tick, ref) in enumerate(knots):
        stop = min(len(xy), knots[i+1][0] if i+1 < len(knots) else len(xy))
        if tick >= stop:
            continue
        # Plot only reference portions active under ground control. Keep gaps for flight and missing data.
        mask = ground[tick:stop] & finite[tick:stop]
        bounds = np.flatnonzero(np.diff(np.r_[False, mask, False])).reshape(-1, 2) + tick
        for lo, hi in bounds:
            xlo, xhi = np.clip([xy[lo:hi, 0].min(), xy[lo:hi, 0].max()], ref[0,0], ref[-1,0])
            inside = ref[(ref[:,0]>xlo) & (ref[:,0]<xhi)]
            ends = np.interp([xlo,xhi], ref[:,0], ref[:,1])
            pieces.append(np.vstack([[xlo, ends[0]], inside, [xhi, ends[1]]]))
    last = np.flatnonzero(finite)
    hand = None if pd.isna(row.native_handoff_s) else int(round(row.native_handoff_s/.005))
    return dict(xy=xy, time=time, pieces=pieces, hand=hand, verified=bool(row.verified_relock),
                finite_end=bool(finite[-1]), last=xy[last[-1]] if len(last) else None, terminal=row.termination,
                duration=float(row.duration_s), wall=bool(row.physical_wall), goal=bool(row.physical_goal))


def outcome(case, gate, side, known, lower):
    if not known:
        result = "suffix unverified"
    elif lower:
        result = "complete"
    elif case["hand"] is None:
        result = "no handback"
    elif not case["verified"]:
        result = "jump unverified"
    else:
        xy = case["xy"]
        ok = (xy[:-1,0] < gate) & (gate <= xy[1:,0]) & (np.arange(1,len(xy)) >= case["hand"])
        hits = np.flatnonzero(ok)
        if len(hits):
            i = hits[0]
            frac = (gate-xy[i,0])/(xy[i+1,0]-xy[i,0])
            y = xy[i,1] + frac*(xy[i+1,1]-xy[i,1])
            result = "gate passed" if .06 <= y*side <= 3.9 else "wrong gate side"
        else:
            result = "no gate crossing"
    return result


def render(mapname, root, gate, side, frame, world, cases, target):
    selected = frame[["cohort","method","action_slot"]].drop_duplicates()
    slots = sorted(selected.action_slot.unique())
    fig = plt.figure(figsize=(13.2, 10.6))
    gs = fig.add_gridspec(3, 2, left=.062, right=.985, top=.71, bottom=.06,
                          width_ratios=[2.1,1], hspace=.38, wspace=.08)
    axes = []
    mapping = []
    for slot in slots:
        names = []
        for cohort in COHORTS:
            group = selected[(selected.action_slot==slot) & (selected.cohort==cohort)]
            names.append(", ".join(METHODS[m] for m in METHODS if m in set(group.method)) or "—")
        mapping.append((slot,names))
    gate_label = ("left" if side==1 else "right") + f" gate at x = {gate:g} m"
    fig.suptitle(f"{mapname}    ·    start {root}    ·    {gate_label}", x=.062, ha="left", y=.975,
                 fontsize=16, weight="bold")
    legend = [Line2D([],[],c="#30343a",label="Actual",lw=1.8),
              Line2D([],[],c="#30343a",ls=(0,(2,2)),label="Active ground reference"),
              Line2D([],[],c="#30343a",marker="D",mfc="white",ls="",label="Physical handback"),
              Line2D([],[],c="#30343a",marker="o",ls="",label="Complete"),
              Line2D([],[],c="#30343a",marker="x",ls="",label="Other endpoint")]
    fig.legend(handles=legend,loc="upper left",bbox_to_anchor=(.055,.933),ncol=5,frameon=False,fontsize=9)
    matrix = fig.add_axes((.065,.745,.885,.145))
    matrix.axis("off")
    table = matrix.table(cellText=[[f"C{slot}",*labels] for slot,labels in mapping],
                         colLabels=["Curve",*COHORTS.values()],cellLoc="left",colLoc="left",
                         colWidths=[.09,.31,.30,.30],bbox=[0,0,1,1])
    table.auto_set_font_size(False)
    table.set_fontsize(8.3)
    for (row_id,col), cell in table.get_celld().items():
        cell.set_edgecolor("#dadcdf")
        cell.set_linewidth(.45)
        if row_id==0:
            cell.set_facecolor("#edf0ef")
        elif col==0:
            cell.get_text().set_color(COLORS[mapping[row_id-1][0]])
            cell.get_text().set_weight("bold")
    for row, (force, group) in enumerate(frame.groupby("force",sort=True)):
        ax = fig.add_subplot(gs[row,0],sharex=axes[0] if axes else None,sharey=axes[0] if axes else None)
        notes = fig.add_subplot(gs[row,1])
        notes.axis("off")
        axes.append(ax)
        terrain = world["terrain"]
        for x0,x1,y0,y1 in terrain["forbidden_rectangles"]:
            ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc="#988477",ec="none",alpha=.38))
        g = world["goal"]
        ax.add_patch(Rectangle((g["x_min_m"],-g["abs_y_max_m"]),g["x_max_m"]-g["x_min_m"],
                               2*g["abs_y_max_m"],fc="#d6e5ca",ec="none"))
        ax.plot([gate,gate],[side*.06,side*3.9],c="#6c576d",lw=2)
        ax.axvline(terrain["front_x_m"],c="#555555",ls=":",lw=.9)
        selected_cases = group[["action_slot","path","known","lower"]].drop_duplicates().sort_values("action_slot")
        if len(selected_cases)!=len(slots):
            raise ValueError("A selected action has different observed physical branches")
        for ordinal, r in enumerate(selected_cases.itertuples()):
            slot = r.action_slot
            case = cases[r.path]
            color = COLORS[slot]
            for part in case["pieces"]:
                ax.plot(*part.T,c=color,ls=(0,(2,2)),lw=1.8,alpha=.85)
            ax.plot(*case["xy"].T,c=color,lw=1.25)
            hand = case["hand"]
            if hand is not None and np.isfinite(case["xy"][hand]).all():
                ax.plot(*case["xy"][hand],marker="D",mfc="white",mec=color,ms=4)
            if case["last"] is not None:
                marker = "o" if r.known and r.lower else "x"
                ax.plot(*case["last"],marker=marker,c=color,ms=5)
            result = outcome(case,gate,side,r.known,r.lower)
            end = case["terminal"].replace("_", " ")
            detail = f"C{slot}  {result}  ·  {end}  ·  {case['duration']:.2f} s"
            if not case["finite_end"]:
                detail += " (last finite XY)"
            notes.text(.02,.87-ordinal*.105,detail,c=color,fontsize=8.8,va="top")
        ax.set_title(f"{force:+g} N",loc="left",fontsize=11,weight="bold",pad=3)
        ax.set_aspect("equal",adjustable="box")
        ax.set_ylabel("y (m)")
        ax.grid(alpha=.18)
        if row<2:
            ax.tick_params(labelbottom=False)
        else:
            ax.set_xlabel("x (m)")
    ax = axes[0]
    # Include every observed point, the entire prescribed gate and the goal corridor.
    xs = [world["goal"]["x_max_m"],gate]; ys = [-.15,.15,side*3.9]
    for path in frame.path.unique():
        xy = cases[path]["xy"];valid=xy[np.isfinite(xy).all(axis=1)]
        if len(valid):
            xs.extend([float(valid[:,0].min()),float(valid[:,0].max())]);ys.extend([float(valid[:,1].min()),float(valid[:,1].max())])
    for x0,x1,y0,y1 in world["terrain"]["forbidden_rectangles"]:
        xs.extend([x0,x1]);ys.extend([y0,y1])
    ax.set_xlim(min(xs)-.23,max(xs)+.23)
    ax.set_ylim(min(ys)-.15,max(ys)+.15)
    fig.savefig(target,dpi=130)
    plt.close(fig)
    # Keep the pre-action choices visible on the figure's own page; each physical curve has one row.
    return mapping


def draw(base=R):
    base=Path(base)
    out=base/"choice_xy"
    out.mkdir(exist_ok=True)
    choices=pd.read_csv(base/"selected_cases.csv.gz")
    registered=pd.read_csv(base/"pre_action_choices.csv")
    join=["map_id","root","gate_x","side","cohort","method","action_slot"]
    keys=["map_id","root","gate_x","side","cohort","method"]
    assert not registered.duplicated(keys).any() and set(registered.method)==set(METHODS)
    forces=choices.groupby(join)["force"].agg(lambda f: tuple(sorted(f)))
    expected=pd.MultiIndex.from_frame(registered[join])
    assert len(forces)==len(expected) and expected.isin(forces.index).all() and all(f==(-5,0,5) for f in forces)
    curves=pd.read_csv(base/"curves.csv");meta=curves.set_index("slot")
    raw=[];pages=[]
    for mapname, part in choices.groupby("map_id"):
        cfg=json.loads((base/mapname/"config.json").read_text())
        world=json.loads(Path(cfg["world_map"]).read_text())
        bank=mapped_arrays(cfg["paired_departures"]["route_bank"])
        with np.load(cfg["ground_handoff"]["reference_path"]) as archive:
            neutral=archive["xy"][0]
        suffix=pd.read_csv(base/"export/dev"/mapname/"suffix_index.csv")
        needed=set(part.path)
        cases={}
        for row in suffix.itertuples():
            case=read_case(row,neutral,bank,cfg["platform_online"]["latency_ticks"]["start"])
            pt=case["last"]
            raw.append(dict(map_id=mapname,root=row.root,action_slot=row.action_slot,kind=meta.loc[row.action_slot,"kind"],
                            force=row.hidden_force_N_grouping_only,arm=row.arm,lane=row.lane,verified_relock=case["verified"],
                            handback_s=row.native_handoff_s,terminal=case["terminal"],duration_s=case["duration"],
                            finite_terminal_xy=case["finite_end"],last_finite_x_m=None if pt is None else pt[0],
                            last_finite_y_m=None if pt is None else pt[1],trajectory=row.trajectory,pair_status=row.suffix_pair_status))
            if row.trajectory in needed:
                cases[row.trajectory]=case
        assert len(suffix)==576 and set(cases)==needed
        for (root,gate,side),frame in part.groupby(["root","gate_x","side"]):
            name=f"{mapname}_{root}_{gate:g}_{'left' if side==1 else 'right'}"
            mapping=render(mapname,root,gate,side,frame,world,cases,out/(name+".png"))
            html=['<meta charset="utf-8"><title>'+escape(name)+'</title>',
                  '<style>body{font:16px system-ui;max-width:1200px;margin:2em auto}table{border-collapse:collapse}th,td{padding:.4em .7em;border:1px solid #ccc;text-align:left}img{max-width:100%}</style>',
                  f'<h1>{escape(mapname)} · start {root} · {gate:g} m · {"left" if side==1 else "right"}</h1>',
                  '<table><caption>Registered methods selecting each curve, shared across three pushes</caption><tr><th>Curve</th><th>Shape</th>'+''.join(f'<th id="{cohort}">{text}</th>' for cohort,text in COHORTS.items())+'</tr>']
            for slot,labels in mapping:
                html.append(f'<tr><th>C{slot}</th><td>{escape(meta.loc[slot,"kind"])}</td>'+''.join(f'<td>{escape(v)}</td>' for v in labels)+'</tr>')
            html.extend(['</table>',f'<img src="{name}.png" alt="Physical and active ground reference paths for minus five, zero and plus five newtons, with observed endpoints.">',
                         '<p>Dotted vertical line marks the step edge. The gate is purple, walls are brown and the goal zone is green. A handback diamond marks the physical controller switch. A cross marks the end of an unsuccessful or unverified task.</p>',
                         '<table><caption>Raw trajectory by force and chosen curve</caption><tr><th>Push</th><th>Curve</th><th>Simulation terminal</th><th>Source</th></tr>'])
            for r in frame[["force","action_slot","terminal","path"]].drop_duplicates().sort_values(["force","action_slot"]).itertuples():
                link=escape(os.path.relpath(r.path,out),quote=True)
                html.append(f'<tr><td>{r.force:+g} N</td><td>C{r.action_slot}</td><td>{escape(r.terminal)}</td><td><a href="{link}">trajectory.npz</a></td></tr>')
            (out/(name+".html")).write_text(''.join(html)+'</table><p><a href="index.html">All starts</a></p>')
            for cohort in COHORTS:
                pages.append(dict(map_id=mapname,root=root,gate_x=gate,side=side,cohort=cohort,html=f"{name}.html#{cohort}",png=f"{name}.png"))
    ix=pd.DataFrame(pages)
    physical=pd.DataFrame(raw)
    assert len(ix)==288 and len(physical)==physical.trajectory.nunique()==1152
    ix.to_csv(out/"index.csv",index=False)
    physical.to_csv(out/"physical_cases.csv.gz",index=False)
    physical["side"]=physical.arm.map({"left":1,"right":-1})
    ids=["map_id","root","action_slot","force","side"]
    measured=physical[ids+["trajectory","verified_relock","duration_s","finite_terminal_xy","last_finite_x_m","last_finite_y_m"]]
    linked=choices.merge(measured,left_on=ids+["path"],right_on=ids+["trajectory"],validate="many_to_one")
    assert len(linked)==len(choices)
    linked.drop(columns="trajectory").to_csv(out/"selected_sources.csv.gz",index=False)
    links=['<meta charset="utf-8"><title>DEV physical entry choices</title><h1>Physical trajectories by map, start and gate</h1>',
           '<p><a href="physical_cases.csv.gz">All 1,152 trajectories and endpoints</a> · <a href="selected_sources.csv.gz">Selections for all force/method/cohort combinations</a></p>']
    for cohort,text in COHORTS.items():
        links.append(f'<h2>{text}</h2>')
        for m,group in ix[ix.cohort==cohort].groupby("map_id"):
            links.append(f'<h3>{m}</h3><ul>')
            for r in group.itertuples():
                links.append(f'<li><a href="{r.html}">Start {r.root} · {r.gate_x:g} m · {"left" if r.side==1 else "right"}</a></li>')
            links.append('</ul>')
    (out/"index.html").write_text(''.join(links))


if __name__=="__main__":
    draw()

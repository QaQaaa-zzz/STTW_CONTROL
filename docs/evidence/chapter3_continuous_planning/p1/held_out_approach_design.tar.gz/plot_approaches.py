"""Draw the eight prospective DEV reference curves in world coordinates."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
from matplotlib import font_manager
import matplotlib.pyplot as plt
import numpy as np

root = Path(__file__).resolve().parent
with np.load(root / 'approaches.npz') as source:
    curves = source['xy']
edge_x, offset_x = 10.3, 9.2
edge = np.array([np.interp(edge_x, path[:,0], path[:,1]) for path in curves])
center = np.abs(edge) < .01
assert curves.shape[0] == 8 and center.sum() == 4
font_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font_manager.fontManager.addfont(font_path)
plt.rcParams.update({'font.family': font_manager.FontProperties(fname=font_path).get_name(),
                     'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
fig = plt.figure(figsize=(10.6, 6.2), layout='constrained')
grid = fig.add_gridspec(2, 2, height_ratios=[1., 1.45])
overview = fig.add_subplot(grid[0, :])
panels = [fig.add_subplot(grid[1, i]) for i in range(2)]
colors = ['#995315','#006b9c']
styles = ['--','-']
for group, (is_center, detail) in enumerate(zip((False,True),panels)):
    rows = np.flatnonzero(center == is_center)
    for sign in (1,-1):
        values = {i:np.interp(offset_x,curves[i,:,0],curves[i,:,1]) for i in rows}
        pair = sorted((i for i in rows if sign*values[i]>0), key=lambda i:abs(values[i]))
        assert len(pair) == 2
        for rank, i in enumerate(pair):
            path = curves[i]
            for axis, factor in [(overview,1),(detail,100)]:
                axis.plot(path[:,0],factor*path[:,1],styles[rank],color=colors[group],lw=1.9,
                          label=(f'±{abs(values[i])*100:.1f} cm' if axis is detail and sign>0 else None))
                axis.scatter([offset_x],[factor*values[i]],s=12,color=colors[group],zorder=4)
    detail.set(xlim=(2.8,10.55),ylim=(-43,43),xticks=(3,5,7,9.2,10.3),
               xlabel='前进方向的位置 (m)',ylabel='横向位置 (cm)')
    detail.legend(loc='upper left',frameon=False,fontsize=9,title='圆点处的横移',title_fontsize=9)
for ax in [overview,*panels]:
    ax.axhline(0,lw=.6,c='#808080',zorder=0)
    ax.axvline(offset_x,lw=.8,c='#777777',ls=':',zorder=0)
    ax.axvline(edge_x,lw=1.1,c='#333333',ls='--')
    ax.grid(axis='y',lw=.4,c='#d2d2d2')
    ax.set_axisbelow(True)
overview.set(xlim=(2.3,10.7),ylim=(-.65,.65),yticks=[-.4,0,.4],
             xticks=[3,5,7,9.2,10.3],ylabel='横向位置 (m)',aspect='equal')
overview.set_title('全部 8 条参考路线 · 俯视，横纵坐标等比例',loc='left',fontsize=11)
overview.text(9.09,.49,'台阶前 1.1 m',ha='right',fontsize=9)
overview.text(10.27,.49,'台阶边缘',ha='right',fontsize=9)
panels[0].set_title('经过训练用的边缘位置 · 4 条',loc='left',fontsize=11,color=colors[0])
panels[1].set_title('经过台阶正中央 · 4 条',loc='left',fontsize=11,color=colors[1])
fig.suptitle('弯着接近同一座台阶',fontsize=16)
fig.savefig(root / 'approach_geometry.png', dpi=170, facecolor='white')

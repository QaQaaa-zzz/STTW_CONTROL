"""Export measured P1 jump outcomes. No physics or fitting runs here."""
import argparse
import csv
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import sys

import mujoco
import numpy as np
import pandas as pd
import torch

WORK=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path[:0]=[str(WORK/'learning/src'),str(WORK/'learning/cli'),'/home/qy/DVGC/JIT/src']
from analyze_chapter3_continuous_p0_branches import prefix_flight_force
from run_playground_task_reversal import crossings_by_section
from sttw_control.platform_online import velocity_state

P=Path(__file__).resolve().parents[1]
OUT=P/'export'
KEYS=['bank_row','action_slot','force_y_N']
OBSERVED=['t0_qpos_native','t0_qvel_native','t0_velocity_state9','alpha','approach_profile','step_geometry','approach_corridor_height_m','approach_corridor_support']
def read(p):return json.loads(Path(p).read_text())
def save(p,data):Path(p).write_text(json.dumps(data,indent=2)+'\n')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def decision_inputs(q,v,geometry,alpha,curves,raster,world):
    # Preserve the P0-B observed input contract including the 65-point x coordinate rounding.
    n=len(q);profiles=np.empty((n,65,4),np.float32);heights=np.empty((n,65,3),np.float32)
    support=np.empty_like(heights);step=np.empty((n,3),np.float32)
    terrain=world['terrain'];front=terrain['front_x_m'];xmin,_,ymin,_=raster['bounds'];spacing=float(raster['spacing'])
    for i,g in enumerate(geometry):
        xy=curves['xy'][g];xx=np.linspace(q[i,0],front,65)
        yy=np.interp(xx,xy[:,0],xy[:,1]);yaw=np.interp(xx,xy[:,0],curves['heading'][g])
        kappa=np.interp(xx,xy[:,0],curves['curvature'][g]);profiles[i]=np.column_stack((xx-q[i,0],yy-q[i,1],yaw,kappa))
        ci=np.rint((xx-xmin)/spacing).astype(int)[:,None];ri=np.rint((yy[:,None]+np.array([-.2,0.,.2])-ymin)/spacing).astype(int)
        if ci.min()<0 or ri.min()<0 or ci.max()>=raster['height'].shape[1] or ri.max()>=raster['height'].shape[0]:raise ValueError('Visible candidate corridor exceeds provided raster')
        heights[i]=raster['height'][ri,ci];support[i]=raster['support'][ri,ci]
        step[i]=[front-q[i,0],terrain['far_bank_height_m'],terrain['width_m']]
    return dict(t0_qpos_native=q,t0_qvel_native=v,t0_velocity_state9=velocity_state(torch.from_numpy(q),torch.from_numpy(v)).numpy(),alpha=np.asarray(alpha,np.float32),approach_profile=profiles,step_geometry=step,approach_corridor_height_m=heights,approach_corridor_support=support)

def config_rows(batch):
    if digest(batch['config'])!=batch['config_sha256']:raise ValueError('Frozen input config SHA mismatch')
    cfg=read(batch['config']);rr=cfg['ground_handoff']['handoff_variants']
    planned=pd.DataFrame([dict(**rr[v],lane=i) for i,(g,m,v) in enumerate(cfg['evaluation_lanes']) if g==rr[v]['geometry'] and m=='h75'])
    assert len(planned)==batch['lanes'] and set(planned.data_split)=={batch['role']} and set(planned.map_id)=={batch['name']}
    left=planned[planned.arm=='left'].sort_values(KEYS).reset_index(drop=True)
    right=planned[planned.arm=='right'].sort_values(KEYS).reset_index(drop=True)
    assert len(left)==len(right)==batch['distinct_prefixes'] and not left.duplicated(KEYS).any()
    eq=KEYS+['geometry','approach_alpha','section_x','side','bin','root_slot','map_slot','data_split','requested_speed_m_s']
    assert left[eq].equals(right[eq]) and (left.lane+1).equals(right.lane)
    assert np.all(left.planned_departure==0) and np.all(right.planned_departure==2)
    assert set(left.bank_row)==set(batch['bank_rows']) and left.groupby(['bank_row','action_slot']).force_y_N.apply(lambda a:set(a)=={-5,0,5}).all()
    assert left.groupby('bank_row').action_slot.nunique().eq(8).all()
    return cfg,left,right

def query_record(z,j,lane,q,v):
    t=int(z['tick']);p=int(z['previous_tick']);assert t==p+4 and int(z['lanes'][j])==lane
    for k,a in [('qpos',q[t]),('qvel',v[t]),('previous_qpos',q[p]),('previous_qvel',v[p])]:
        np.testing.assert_array_equal(z[k][j],a)
    # These are actually provided arguments to choose(). Compare their physical trace reconstruction.
    for name,qv,vv in [('velocity',q[t],v[t]),('previous_velocity',q[p],v[p])]:
        reconstructed=velocity_state(torch.from_numpy(qv[None]),torch.from_numpy(vv[None])).numpy()[0]
        np.testing.assert_allclose(z[name][j],reconstructed,atol=8e-6,rtol=8e-6)
    return {k:z[k][j] for k in ('qpos','qvel','previous_qpos','previous_qvel','velocity','previous_velocity')}

@lru_cache(maxsize=8)
def load_query(path):
    keep=('lanes','tick','previous_tick','qpos','qvel','previous_qpos','previous_qvel','velocity','previous_velocity','requested_speed','branch_ids','incumbent_direction','section_x','side','shadow_choice','shadow_any_admitted','shadow_incumbent_admitted')
    with np.load(path) as z:return {k:z[k] for k in keep}

def export_map(batch):
    cfg,left,right=config_rows(batch);name=batch['name'];folder=Path(batch['physical']);world=read(batch['world']);dest=OUT/batch['role']/name
    if not (folder/'p1_pair_summary.json').is_file():raise RuntimeError(f'{name}: awaiting completed physical branch and pair audit at {folder}')
    n=len(left);status=read(folder/'status.json');assert status['stage']=='complete' and len(status['results'])==batch['lanes']
    audit=read(folder/'p1_pair_summary.json');assert audit['stage']=='complete' and audit['distinct_prefixes']==n
    lane_index=pd.read_csv(folder/'p1_lanes.csv').set_index('lane',verify_integrity=True)
    pairs=pd.read_csv(folder/'p1_prefixes.csv').set_index('left_lane',verify_integrity=True)
    assert len(lane_index)==2*n and len(pairs)==n
    with np.load(cfg['paired_departures']['approach_file']) as z:curves=dict(z)
    with np.load(batch['raster']) as z:raster=dict(z)
    model=mujoco.MjModel.from_binary_path(batch['physical_model'])
    q0=np.empty((n,12),np.float32);v0=np.empty((n,11),np.float32);records=[];suffixes=[]
    label={k:np.full((n,d),np.nan,np.float32) for k,d in [('relock_qpos_native',12),('query_qpos_native',12),('query_qvel_native',11),('previous_qpos_native',12),('previous_qvel_native',11),('query_velocity_state9',9),('previous_velocity_state9',9)]}
    for k in ('relock_s','query_s','previous_s'):label[k]=np.full(n,np.nan)
    for k in ('verified_relock','observed_query'):label[k]=np.zeros(n,bool)
    for i,(a,b) in enumerate(zip(left.itertuples(),right.itertuples(),strict=True)):
        pair=pairs.loc[a.lane];assert int(pair.right_lane)==b.lane and int(pair.bank_row)==a.bank_row and int(pair.action_slot)==a.action_slot and int(pair.force_N)==a.force_y_N
        observed_cert=pair.status in ('matched_observed_handoff','matched_observed_prequery_endpoint')
        arm_rows=[]
        for e in (a,b):
            j=e.lane;ix=lane_index.loc[j];r=status['results'][j];rr=r['variant']
            trace_path=Path(ix.trajectory);assert trace_path==folder/r['case_dir']/'trajectory.npz'
            assert [rr[k] for k in KEYS+['geometry','approach_alpha','arm']]==[getattr(e,k) for k in KEYS+['geometry','approach_alpha','arm']]
            hand=r['handoff_s'];pulse=prefix_flight_force(r,trace_path,model,world['terrain']);verified=bool(pulse['verified'])
            with np.load(trace_path) as z:q=z['qpos'];v=z['qvel'];tr=z['trace']
            assert tr[0,0]==0 and q.shape==(len(tr),12) and v.shape==(len(tr),11)
            hit=next(x for x in crossings_by_section(tr,hand if hand is not None else np.inf,[12.7,13.6,15.]) if x[0]==e.bin)
            cy=hit[-1];gate=cy is not None and .06<=cy*e.side<=3.9
            wall=bool(r['forbidden_contact_steps']);done=bool(verified and gate and r['goal'] and not wall)
            hasq=pd.notna(ix.query_file);qt=round(hand/.005)+1 if hand is not None else None
            assert hasq==(qt is not None and qt<len(tr))
            shadow_ref=None;design_inc=int(e.planned_departure);sn=None
            if hasq:
                file=Path(ix.query_file);pos=int(ix.query_file_row);snap=load_query(file)
                assert int(snap['tick'])==qt and int(snap['incumbent_direction'][pos])==design_inc and np.isclose(snap['requested_speed'][pos],e.continuation_speed_m_s)
                assert float(snap['section_x'][pos])==np.float32(e.section_x) and int(snap['side'][pos])==e.side
                sn=query_record(snap,pos,j,q,v);shadow_ref=int(snap['branch_ids'][pos,design_inc])
            arm_rows.append(dict(row=i,map_id=name,root=e.bank_row,action_slot=e.action_slot,geometry=e.geometry,alpha=e.approach_alpha,hidden_force_N_grouping_only=e.force_y_N,arm=e.arm,lane=j,suffix_pair_status=pair.status,verified_relock=verified,observed_query=bool(hasq),native_handoff_s=hand,target_side=e.side,section=e.bin,section_x=e.section_x,crossing_s=hit[-2],crossing_y_m=cy,correct_gate=gate,physical_goal=r['goal'],physical_wall=wall,physical_task_done=done,termination=r['termination'],duration_s=r['duration_s'],declared_direction=design_inc,committed_route_bank_row=shadow_ref,query_tick=ix.query_tick,query_file=ix.query_file,query_file_row=ix.query_file_row,shadow_choice=ix.shadow_choice,shadow_any_admitted=ix.shadow_any_admitted,shadow_incumbent_admitted=ix.shadow_incumbent_admitted,due_tick=ix.physical_due_tick,assigned_tick=ix.physical_assigned_tick,online_selected_direction=ix.physical_selected_direction,physical_target_effective=ix.physical_target_effective,route_bank=cfg['paired_departures']['route_bank'],actual_targets_file=ix.actual_targets_file,trajectory=str(trace_path)))
            if e.arm=='left':
                q0[i]=q[0];v0[i]=v[0];label['verified_relock'][i]=verified;label['observed_query'][i]=hasq
                if verified:
                    label['relock_s'][i]=hand;label['relock_qpos_native'][i]=q[qt-1]
                if hasq:
                    label['query_s'][i]=qt*.005;label['previous_s'][i]=(qt-4)*.005
                    for src,dst in [('qpos','query_qpos_native'),('qvel','query_qvel_native'),('previous_qpos','previous_qpos_native'),('previous_qvel','previous_qvel_native'),('velocity','query_velocity_state9'),('previous_velocity','previous_velocity_state9')]:label[dst][i]=sn[src]
                prefix=dict(row=i,root=e.bank_row,layout=name,map_id=name,role=batch['role'],root_slot=e.root_slot,action_slot=e.action_slot,geometry=e.geometry,alpha=e.approach_alpha,hidden_force_N_grouping_only=e.force_y_N,lane=j,arm=e.arm,trajectory=str(trace_path),handback_snapshot=ix.query_file,query_tick_grouping_only=ix.query_tick,native_handoff_s=hand,verified_relock=verified,observed_query=hasq,pulse_flight_status=pulse['pulse_flight_status'],applied_force_ticks=r['applied_force_ticks'],actual_rb_entry_s=r['rb_entry_s'])
        if observed_cert:assert arm_rows[0]['verified_relock']==arm_rows[1]['verified_relock']
        suffixes.extend(arm_rows)
        records.append(dict(**prefix,right_lane=b.lane,cross_suffix_certified=observed_cert,suffix_pair_status=pair.status,raw_substep_loads_equal=bool(pair.raw_substep_loads_equal),pair_table=str(folder/'p1_prefixes.csv'),physical_status=str(folder/'status.json'),terrain_raster=batch['raster'],candidate_curve_bank=cfg['paired_departures']['approach_file']))
    index=pd.DataFrame(records);inputs=decision_inputs(q0,v0,left.geometry.to_numpy(),left.approach_alpha,curves,raster,world);assert list(inputs)==OBSERVED and all(np.isfinite(x).all() for x in inputs.values())
    for ids in index.groupby('root').indices.values():
        for x in (q0,v0):np.testing.assert_array_equal(x[ids],np.broadcast_to(x[ids[0]],x[ids].shape))
    for ids in index.groupby(['root','action_slot']).indices.values():
        assert len(ids)==3
        for x in inputs.values():np.testing.assert_array_equal(x[ids],np.broadcast_to(x[ids[0]],x[ids].shape))
    label['is_relocked']=label['verified_relock'];label['regression_valid']=label['verified_relock']&label['observed_query']
    for k,x in label.items():
        if x.dtype==np.bool_:continue
        eligible=label['verified_relock'] if k in ('relock_s','relock_qpos_native') else label['observed_query']
        assert np.isfinite(x[eligible]).all() and np.isnan(x[~eligible]).all()
    dest.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(dest/'observed_inputs.npz',**inputs);np.savez_compressed(dest/'measured_targets.npz',**label)
    index.to_csv(dest/'prefix_index.csv',index=False);pd.DataFrame(suffixes).to_csv(dest/'suffix_index.csv',index=False)
    save(dest/'export_receipt.json',dict(role=batch['role'],map_id=name,stage='complete',prefixes=n,physical_lanes=2*n,distinct_roots=index.root.nunique(),distinct_root_actions=len(index.groupby(['root','action_slot'])),verified_relock=int(label['verified_relock'].sum()),observed_query=int(label['observed_query'].sum()),regression_valid=int(label['regression_valid'].sum()),verified_without_query=int((label['verified_relock']&~label['observed_query']).sum()),query_without_verified=int((label['observed_query']&~label['verified_relock']).sum()),cross_suffix_certified=int(index.cross_suffix_certified.sum()),pair_audit=str(folder/'p1_pair_summary.json'),config_sha256=batch['config_sha256'],input_keys=OBSERVED,query_velocity='Exact velocity and previous_velocity arguments captured at first physical shadow query; compared to native reconstructed twists. Current/previous qpos and qvel matched bitwise to observed trajectory. Physical selected direction is independent of shadow choice.',target_masks='Verified requires original physical contact-free crossing and loaded far landing by native handback. Native handback alone is not the verified endpoint. Regression mask = verified_relock AND observed_query. Native handoff alone, branch IDs, force, outcome and time are never inputs.',source_export=str(Path(__file__).resolve()),benchmark_only=False))
    print(name,n,'verified',int(label['verified_relock'].sum()),'regression',int(label['regression_valid'].sum()),flush=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__);grp=parser.add_mutually_exclusive_group(required=True);grp.add_argument('--map');grp.add_argument('--all',action='store_true');grp.add_argument('--role',choices=('train','dev','calibration'));parser.add_argument('--validate-config',action='store_true')
    a=parser.parse_args(); c=read(P/'collection_contract.json')
    items=[b for b in c['batches'] if a.all or a.map==b['name'] or a.role==b['role']]
    if not items:parser.error('Unknown map')
    for b in items:
        if a.validate_config:config_rows(b);print(b['name'],b['role'],b['distinct_prefixes'],'config verified')
        else:export_map(b)
if __name__=='__main__':main()

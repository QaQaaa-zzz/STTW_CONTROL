"""Use the unchanged handoff evaluator; collect actual applied targets and shadow-query evidence."""
import argparse
import fcntl
from hashlib import file_digest
import json
from pathlib import Path
import subprocess
import sys
import time

import numpy as np

OUT=Path(__file__).resolve().parents[1]
WORK=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
LOCK=Path('/home/qy/STTW_CONTROL/research-hub/.gpu-job.lock')
sys.path.insert(0,str(WORK/'learning/cli'))
sys.path.insert(0,str(WORK/'learning/src'))
def read(p):return json.loads(p.read_text())
def write(p,payload):p.write_text(json.dumps(payload,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def digest(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
def notify(b,stage,message):
    subprocess.run(['/usr/bin/python3',str(WORK/'learning/scripts/notify_chapter3_job.py'),
                    '--title','第三章 P1 '+b['name']+' '+stage,'--message',message,'--receipt',
                    str(Path(b['config']).parent/('bark_'+stage+'.json'))],cwd=WORK)
def observed_run(b):
    import torch
    import jax
    import evaluate_playground_handoff as evaluator
    import sttw_control.playground_handoff_evaluation as handoff
    from sttw_control.playground_adapters import JumpAdapter
    from sttw_control.platform_online import PlatformDepartureQuery
    from sttw_control.chapter3_p0_physical import lane_tensors
    out=Path(b['physical'])
    events=[]
    tapes={}
    original_eval=handoff.evaluate_handoff
    original_select=JumpAdapter.select
    original_choose=PlatformDepartureQuery.choose
    def save_target(self,phase,ground_targets,rb_targets,joint_bias):
        value=original_select(self,phase,ground_targets,rb_targets,joint_bias)
        state=sys._getframe(1).f_locals
        tick=state['tick']
        if tick in (0,1,32,128,512,1024,1536,1999):milestone(tick,state)
        if not tapes:
            n=len(value)
            tapes['targets']=value.new_empty((2000,n,4))
            tapes['valid']=torch.empty((2000,n),device=value.device,dtype=torch.bool)
        tapes['targets'][tick].copy_(value.detach())
        tapes['valid'][tick].copy_(state['alive'])
        tapes['length']=tick+1
        return value
    def save_query(self,q,body_speed,request,route,branch_ids,section,side,old,seconds,velocity=None,previous=None,return_forecast=False,safety_only=False,return_reasons=False):
        state=sys._getframe(1).f_locals
        chosen=original_choose(self,q,body_speed,request,route,branch_ids,section,side,old,seconds,velocity,previous,return_forecast,safety_only,return_reasons)
        ids=state['ids'];tick=state['tick'];v=state['v'];n=len(v)
        pq,pv=state['velocity_history'][tick%4]
        item=dict(lanes=ids,qpos=q,qvel=v[ids],previous_qpos=pq[ids],previous_qvel=pv[ids],velocity=velocity,
            previous_velocity=previous,body_speed=body_speed,requested_speed=request,branch_ids=branch_ids,
            incumbent_direction=old,shadow_choice=chosen[0],shadow_any_admitted=chosen[1],shadow_incumbent_admitted=chosen[2],
            section_x=section,side=side,handoff_s=state['handoff_time'][ids],route_at_query=route.route_ids[ids],
            projection_progress=state['middle'].projection['progress'][ids])
        for name,obj in [('middle',state['middle']),('policy',state['middle'].policy),('controller',state['ctl'])]:
            item.update({k:value[ids] for k,value in lane_tensors(vars(obj),name,n).items()})
        for name in ('phase','target','lock','far_time','upper_ready_time','stable_time','recovering','pulse_start','pulse_ticks'):
            item['runtime_'+name]=state[name][ids]
        for name in ('qpos','qvel','act','ctrl','qacc_warmstart','qfrc_applied','eq_active','time'):
            item['physics_'+name]=torch.from_dlpack(getattr(state['data'],name))[ids]
        for name in ('history','obs','last','rb_events'):
            for j,leaf in enumerate(jax.tree.leaves(state[name])):
                item[f'{name}_{j}']=torch.from_dlpack(leaf)[ids]
        # Copy only event rows on device. No forecast or control is replaced, no host I/O before returning.
        saved={key:value.detach().clone() for key,value in item.items()}
        events.append((tick,float(seconds),saved))
        return chosen
    def checked_eval(model,mm,idx,cfg,bundle,hcfg,identity,controller,skills,args,brake_ids):
        receipt=read(OUT/'collection_ready.json')
        expected=receipt['maps'][b['name']]['mjb_sha256']
        if digest(out/'terrain.mjb')!=expected:
            raise ValueError('The freshly built evaluator model disagrees with the frozen map MJB')
        if model.opt.timestep!=.001 or len(cfg['evaluation_lanes'])!=b['lanes'] or cfg['collect_model_state']:
            raise ValueError('Frozen physical timestep, lane count or collection mode changed')
        return original_eval(model,mm,idx,cfg,bundle,hcfg,identity,controller,skills,args,brake_ids)
    JumpAdapter.select=save_target;PlatformDepartureQuery.choose=save_query;handoff.evaluate_handoff=checked_eval
    sys.argv=[str(Path(evaluator.__file__)),'--config',b['config'],'--output',b['physical'],'--skills','rb_run1',
              '--modes','h75','--routes','0','1','--physics-substeps','5','--seconds','10']
    evaluator.main()
    qdir=out/'p1_query';qdir.mkdir()
    seen=[]
    for tick,seconds,fields in events:
        host={k:v.cpu().numpy() for k,v in fields.items()}
        np.savez_compressed(qdir/f'tick_{tick:04d}.npz',tick=tick,previous_tick=tick-4,remaining_s=seconds,**host)
        seen.extend(host['lanes'].tolist())
    t=tapes['length']
    np.savez_compressed(out/'p1_applied_controls.npz',targets=tapes['targets'][:t].cpu().numpy(),
                         valid=tapes['valid'][:t].cpu().numpy(),dt_s=.005)
    if len(seen)!=len(set(seen)):raise ValueError('A physical lane issued multiple shadow queries')
    write(out/'p1_observer_receipt.json',dict(shadow_lanes=len(seen),event_batches=len(events),control_ticks=t,
        physical_lanes=b['lanes'],staged_gpu_targets_MiB=2000*b['lanes']*(4*4+1)/2**20,
        schema=str(OUT/'collection_contract.json'),instrumented_upstream='JumpAdapter.select, PlatformDepartureQuery.choose, evaluate_handoff',
        compiled_mjb_sha256=digest(out/'terrain.mjb'),observer_control_effect='Return original tensors without modification; shadow timing includes observer call overhead.'))

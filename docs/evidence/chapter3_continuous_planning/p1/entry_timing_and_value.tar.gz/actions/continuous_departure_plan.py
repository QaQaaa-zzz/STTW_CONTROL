"""One known-map, pre-takeoff planning decision on continuous entry curves and alpha."""
from pathlib import Path
import sys,time
import numpy as np
import torch
from continuous_approach import Boundary,generate_reference
from continuous_departures import score_approach_particles,score_continuous_handoffs
P=Path(__file__).resolve().parents[1];W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path[:0]=[str(P/'export'),str(P/'model'),str(W/'learning/src'),str(W/'learning/cli'),'/home/qy/DVGC/JIT/src']
from export_prefixes import decision_inputs as sample_corridor
from jump_outcome import decision_inputs,decode_target
from run_downstream_dev import random_draws,SEED as PARTICLE_SEED
from jump_outcome import DIM

@torch.inference_mode()
def plan(world,raster,ground,jump,qpos,qvel,published,published_alpha,committed_s,gate_x,gate_side,*,
         population=4,iterations=2,seed=923114,speed=2.,trigger_before_edge_m=1.1,episode_s=10.,
         continuous_alpha=False,publish_window_s=None,request_started=None,fixed_alpha=False,soft_exit_scores=None,
         conditional_particles=16,event_exit=None,follower_config=None):
    """Return the reference and alpha eligible for publication at the supplied deadline. No instance, map or catalog key is an input.

    ground is the frozen scorer for world/raster. committed_s is the actual publication
    commitment supplied by the controller. Particles use the registered common P1 quantiles
    and noise across *all* candidates. Timings include every candidate and conditional exit query.
    Fixed alpha is the value already applied at tick zero. Joint alpha/geometry search assumes
    alpha can be chosen before the first control interval, as in the frozen training set.
    soft_exit_scores optionally supplies two conditional completion probabilities per handback.
    """
    if gate_side not in (-1,1) or population<2 or iterations<1 or not 0<=published_alpha<=1:raise ValueError('Invalid gate, CEM budget or published alpha')
    if event_exit is not None and (soft_exit_scores is not None or follower_config is None):raise ValueError('An event exit requires follower settings and a single exit scorer')
    if fixed_alpha and continuous_alpha:raise ValueError('Choose fixed or continuous alpha')
    t0=time.perf_counter() if request_started is None else request_started
    route={k:np.asarray(v) for k,v in published.items()}
    inp={k:np.asarray(route[k]).reshape(-1,2) if k=='xy' else np.asarray(route[k]).reshape(-1) for k in ('xy','heading','curvature')}
    if route['xy'].ndim==3 and len(route['xy'])!=1:raise ValueError('Expected one currently published curve')
    canonical={'s':route['s'],**{k:v[None] for k,v in inp.items()}}
    edge=world['terrain']['front_x_m'];edge_y=float(np.interp(edge,inp['xy'][:,0],inp['xy'][:,1]));edge_h=float(np.interp(edge,inp['xy'][:,0],inp['heading']))
    candidates=[];records=[];steps=[];geom_s=forecast_s=ground_s=0.;device=jump.x_center.device
    if conditional_particles==16:
        u,z=random_draws()
    else:
        if conditional_particles<1:raise ValueError('Expected at least one conditional particle')
        draws=np.random.default_rng(PARTICLE_SEED)
        strata=(np.arange(conditional_particles)+draws.random(conditional_particles))/conditional_particles
        u=torch.tensor(draws.permutation(strata),dtype=torch.float32)
        z=torch.tensor(draws.normal(size=(conditional_particles,DIM)),dtype=torch.float32)
    u,z=u.to(device),z.to(device)
    rng=np.random.default_rng(seed)
    high=np.array([.225,np.deg2rad(8.),.08,1.]);low=-high.copy();low[3]=0.
    if fixed_alpha:low[3]=high[3]=published_alpha  # same geometry random draws as joint search
    alpha_levels=np.array([0.,.5,1.]);center=(low+high)/2.;spread=(high-low)/3.
    def evaluate(proposals, iteration):
        nonlocal forecast_s,ground_s
        start=time.perf_counter()
        curves,alphas,_=zip(*proposals)
        n=len(curves)
        bank={key:np.concatenate([curve[key] for curve in curves]) for key in ('xy','heading','curvature')}
        obs=sample_corridor(np.repeat(qpos[None],n,axis=0),np.repeat(qvel[None],n,axis=0),
                            range(n),alphas,bank,raster,world)
        x,anchors,_,_=decision_inputs(obs)
        logit,logw,mu,sigma=jump(x.to(device))
        if jump.mode=='mean':
            latent=mu[:,:1]
        else:
            quantiles=u.expand(n,-1).contiguous()
            modes=torch.searchsorted(logw.exp().cumsum(1).contiguous(),quantiles).clamp_max(mu.shape[1]-1)
            rows=torch.arange(n,device=device)[:,None]
            latent=mu[rows,modes]+sigma[rows,modes]*z
        batch_state=decode_target(anchors[:,None].to(device),latent*jump.y_scale+jump.y_center)
        npart=latent.shape[1]
        batch={k:batch_state[k].flatten(0,1) for k in ('query_s','query_qpos_native','query_velocity_state9','previous_velocity_state9')}
        probabilities=logit.sigmoid().view(-1).cpu().tolist()
        forecast_s+=time.perf_counter()-start;start=time.perf_counter()
        if event_exit is not None:
            event=score_continuous_handoffs(event_exit,follower_config,curves,batch['query_qpos_native'],
                         batch['query_velocity_state9'],batch['previous_velocity_state9'],batch['query_s'],
                         gate_x,gate_side,episode_s,speed)
            joins,admitted,retained,searched,gate_ahead=[a.cpu().numpy() for a in event]
            merged={k:batch[k].cpu().numpy() for k in ('query_s','query_qpos_native')}
        else:
            merged={k:v.cpu().numpy() for k,v in batch.items()}
            particle_curves=[curve for curve in curves for _ in range(npart)]
        ticks=np.rint(merged['query_s'].astype(float)/.005).astype(int)
        seconds=np.maximum(0.,episode_s-ticks*.005)
        if event_exit is None and soft_exit_scores is None:
            joins,selected,votes=score_approach_particles(ground,particle_curves,merged['query_qpos_native'],
                          merged['query_velocity_state9'],merged['previous_velocity_state9'],seconds,gate_x,gate_side,speed=speed)
        elif soft_exit_scores is not None:
            joins,branch_p=soft_exit_scores(particle_curves,merged['query_qpos_native'],merged['query_velocity_state9'],
                                            merged['previous_velocity_state9'],merged['query_s'],gate_x,gate_side)
        ground_s+=time.perf_counter()-start
        offset=0;scores=[]
        for (curve,alpha,parameters),probability in zip(proposals,probabilities):
            n=len(steps);stop=offset+npart
            if soft_exit_scores is None:
                count=int(admitted[offset:stop].sum() if event_exit is not None else votes[offset:stop].any(1).sum())
                score=probability*count/npart
                detail=dict(particles_with_exit=count)
            else:
                soft=float(branch_p[offset:stop].max(axis=1).mean())
                score=probability*soft
                detail=dict(particles_with_exit=None,mean_best_lr_conditional_probability=soft)
            scores.append(score)
            candidates.append(curve);steps.append(dict(candidate=n,iteration=iteration,published=(n==0),alpha=float(alpha),parameters=parameters,
                p_relock=probability,conditional_particles=npart,**detail,score=score))
            for particle,j in enumerate(range(offset,stop)):
                xy=merged['query_qpos_native'][j,:2]
                if event_exit is not None:
                    value=dict(admitted=bool(admitted[j]),incumbent_admitted=bool(retained[j]),performed_search=bool(searched[j]),gate_ahead=bool(gate_ahead[j]))
                elif soft_exit_scores is None:
                    value=dict(allow_left=bool(votes[j,0]),allow_straight=bool(votes[j,1]),allow_right=bool(votes[j,2]),selected_exit=int(selected[j]))
                else:
                    left,right=map(float,branch_p[j])
                    value=dict(p_left=left,p_right=right,model_preferred_side=1 if left>=right else -1,
                               allow_left=None,allow_straight=None,allow_right=None,selected_exit=None)
                forecast_steps=int(seconds[j]/.02) if event_exit is None else event_exit.horizon
                records.append(dict(candidate=n,particle=particle,query_tick=int(ticks[j]),exit_forecast_steps=forecast_steps,
                    join_index=int(joins[j]),predicted_x_m=float(xy[0]),predicted_y_m=float(xy[1]),**value))
            offset=stop
        return scores
    evaluate([(canonical,published_alpha,None)],-1)
    # The bounds are geometry/alpha search choices for this wiring check, never indexed by the map.
    blocked_before_innovation=(committed_s>route['s'][-1] or
        inp['xy'][min(len(route['s'])-1,np.searchsorted(route['s'],committed_s)),0]>=edge-trigger_before_edge_m)
    for i in range(iterations if not blocked_before_innovation else 0):
        draws=np.clip(rng.normal(center,spread,(population,4)),low,high);proposals=[]
        if not (fixed_alpha or continuous_alpha):
            draws[:,3]=alpha_levels[np.abs(draws[:,3,None]-alpha_levels).argmin(axis=1)]
        for a in draws:
            start=time.perf_counter();curve,_=generate_reference(canonical,committed_s,edge,trigger_before_edge_m,
                Boundary(edge_y+a[0],edge_h+a[1],a[2]),edge_y,edge_h)
            geom_s+=time.perf_counter()-start;proposals.append((curve,a[3],a.tolist()))
        scores=evaluate(proposals,i)
        if np.ptp(scores)>0:
            elite=draws[np.argsort(-np.asarray(scores),kind='stable')[:max(2,population//2)]]
            center=elite.mean(0);spread=np.maximum(elite.std(0),.07*(high-low))
    winner=int(np.argmax([r['score'] for r in steps]))   # preexisting route wins an exact tie
    if steps[winner]['score']<=0:winner=0;decision='all_vetoed_keep_published' if soft_exit_scores is None else 'zero_estimates_keep_published'
    elif not winner:decision='published_best_or_tied'
    else:decision='new_reference_selected'
    if blocked_before_innovation:decision='commitment_reaches_trigger_keep_published';winner=0
    # The proposal is never a transmitted command. A missed or unspecified deadline keeps the current reference.
    if device.type=='cuda':torch.cuda.synchronize(device)
    elapsed=time.perf_counter()-t0
    deadline_met=publish_window_s is not None and elapsed<=publish_window_s
    applied=winner if deadline_met else 0
    if not winner:publish_decision=decision
    elif publish_window_s is None:publish_decision='deadline_unspecified_keep_published'
    elif deadline_met:publish_decision='new_reference_eligible_for_publication'
    else:publish_decision='deadline_missed_keep_published'
    log=dict(decision=decision,selected=winner,alpha=steps[winner]['alpha'],candidate_count=len(steps),particles_evaluated=len(records),
             alpha_mode='fixed_from_tick_zero' if fixed_alpha else ('continuous' if continuous_alpha else 'three_levels'),conditional_samples_per_curve=(1 if jump.mode=='mean' else conditional_particles),ground_execution='round_batched' if soft_exit_scores is None else 'soft_two_fixed_exits',publish_window_s=publish_window_s,
             publish_decision=publish_decision,deadline_met=deadline_met,publishable_candidate=applied,publishable_alpha=steps[applied]['alpha'],
             gate_x_m=gate_x,gate_side=gate_side,committed_s_m=committed_s,threshold='positive estimated joint probability in this CPU wiring example',
             total_s=elapsed,geometry_s=geom_s,jump_and_input_s=forecast_s,ground_s=ground_s,
             candidate_log=steps,particle_log=records)
    if event_exit is not None:
        log['ground_execution']='smooth_event_full_dynamics'
        log['threshold']='Estimated probability of relock and a future gate crossing admitted by the deployed continuous exit model'
    if soft_exit_scores is not None:
        log['threshold']='No branch admission test; rank by relock probability times mean maximum of left/right conditional success probabilities'
    return (published if applied==0 else candidates[applied]),steps[applied]['alpha'],log,candidates

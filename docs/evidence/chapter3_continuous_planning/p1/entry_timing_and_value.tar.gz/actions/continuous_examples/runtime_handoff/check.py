"""Run from the repository root: python /path/to/runtime_handoff/check.py --worktree ."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import torch

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--worktree',type=Path,default=Path.cwd())
args=parser.parse_args();root=args.worktree.resolve();folder=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'learning/src'))
from sttw_control.continuous_handoff_routes import ContinuousHandoffRoutes
from sttw_control.playground_adapters import GroundAdapter
from sttw_control.torch_controller import TorchController
from sttw_control.torch_middle_control import TorchMiddleControl
from sttw_control.torch_path_policy import TorchPathPolicy
from sttw_control.torch_path_reference import TorchPathReference

torch.set_num_threads(1)
read=lambda name:json.loads((folder/name).read_text())
cfg=read('fixture.json');u=read('two_lane_options.json')['plan_updates'][0]
with np.load(folder/'fixture.npz') as z:d=dict(z)
with np.load(folder/u['reference_path']) as z:packet=dict(z)
# Load only the original numerical function from the oracle CLI, without importing any simulation libraries.
source=(root/'learning/cli/run_platform_task_oracle.py').read_text()
node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='departure_route')
assert hashlib.sha256(ast.get_source_segment(source,node).encode()).hexdigest()==cfg['numpy_reference_function_sha256']
ns={'np':np};exec(compile(ast.Module(body=[node],type_ignores=[]),'<original departure_route>','exec'),ns)
oracle=ns['departure_route']
route=TorchPathReference(d,cfg['h75'],route_ids=[0,0]);candidate=TorchPathReference(packet,cfg['h75'],route_ids=[0,0])
policy=TorchPathPolicy(folder/'actor.npz',cfg['actor_sha256'],cfg['h75'],2)
ctl=TorchController(cfg['controller'],2);middle=TorchMiddleControl(policy,route,cfg['frame_scales'],torch.zeros(2),torch.full((2,),2.))
repeat=lambda x:torch.as_tensor(x,dtype=torch.float32).expand(2,-1).clone()
def frame(i):
    q,v,yaw=d['qpos'][i],d['qvel'][i],d['yaw'][i]
    return (repeat([-d['roll'][i],-v[3],q[8],v[7],v[5],v[6],v[8]]),
            repeat([q[0],q[1],yaw]),torch.full((2,),float(v[0]*np.cos(yaw)+v[1]*np.sin(yaw))))
m,pose,speed=frame(0);near=(route.xy[route.route_ids]-pose[:,None,:2]).square().sum(-1).argmin(-1)
raw=torch.stack((speed,m[:,2]),1);middle.reset(m,pose,speed,raw,raw,m[:,[3,5]],ctl,initial_progress=route.s[near])
runtime=ContinuousHandoffRoutes(route,cfg['goal_x']);middle.route=runtime.route;adapter=GroundAdapter(middle,ctl)
for i in range(4):
    m,pose,speed=frame(i);governed=middle.before(pose)
    ctl.step(torch.stack((speed,m[:,2],m[:,3],m[:,0],m[:,1],governed[:,1]),1),torch.zeros(2,dtype=torch.bool))
    act=repeat(d['issued'][i,:2]);m,pose,speed=frame(i+1);middle.after(m,pose,speed,governed,act,act,ctl)
def snapshot():
    return [getattr(obj,k).clone() for obj,fields in [(middle,('frames','mask','nominal','rates','yaw_rate','v_user','alpha')),
        (policy,('filtered','offsets')),(ctl,('eso','filtered_roll_rate','disturbance'))] for k in fields]
before=snapshot();commit=torch.tensor(u['committed_until_m']);fields=('xy','heading','curvature')
result=runtime.publish(adapter,candidate,commit,torch.full((2,),u['ready_s']),torch.tensor(u['deadline_s']),torch.ones(2,dtype=torch.bool),0)
assert result['published']==[0] and result['late']==[1]
end=int(torch.searchsorted(route.s,commit[0]))
for k in fields:
    ref=getattr(runtime.route,k);assert torch.equal(ref[0],getattr(candidate,k)[0]) and torch.equal(ref[1],getattr(route,k)[0])
    assert torch.equal(ref[0,:end+1],ref[1,:end+1])
point=repeat(d['locked'][:2]);near=(runtime.route.xy[:2]-point[:,None]).square().sum(-1).argmin(-1)
progress=runtime.route.project(point,runtime.route.s[near],torch.zeros(2))['progress'];runtime.at_handback(torch.arange(2),point,progress)
s=route.s.double().numpy();max_error={}
for i in range(2):
    ref={k:getattr(runtime.route,k)[i].double().numpy() for k in fields}
    j=min(len(s)-1,max(np.searchsorted(ref['xy'][:,0],float(point[i,0])+.05),np.searchsorted(s,float(progress[i]))+1))
    assert j==runtime.handoff_join[i]
    expected={'s':s,**{k:np.repeat(a[None],3,axis=0) for k,a in ref.items()}}
    for b,target in enumerate((.36,0.,-.36)):oracle(expected,b,j,target,1.6,15.,cfg['goal_x'])
    for k in fields:
        actual=getattr(runtime.route,k)[runtime.branch_rows[i]].numpy();target=expected[k].astype(np.float32)
        np.testing.assert_array_equal(actual,target)
        np.testing.assert_array_equal(actual[:,:j+1],np.broadcast_to(ref[k][:j+1],actual[:,:j+1].shape))
        max_error[k]=max(max_error.get(k,0.),float(np.abs(actual-target).max()))
assert all(torch.equal(a,b) for a,b in zip(before,snapshot()))
print(json.dumps(dict(published=result['published'],retained=result['late'],joins=runtime.handoff_join.tolist(),
                      exact_three_per_lane=True,max_abs_error=max_error,control_state_preserved=True,physics_steps=0)))

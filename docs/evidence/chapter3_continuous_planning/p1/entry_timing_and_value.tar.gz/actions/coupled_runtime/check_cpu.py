"""Check the coupled runtime using observed train_00 departure and handback states."""
from pathlib import Path
import argparse
import json
import os
import sys
import tempfile

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--checkout', type=Path, required=True, help='STTW working copy with the coupled runtime patch')
parser.add_argument('--p1-run', type=Path, default=HERE.parents[1])
parser.add_argument('--reference-worktree', type=Path, default=None, help='Checkout containing the frozen bundle and CLI')
parser.add_argument('--output', type=Path, default=HERE)
args = parser.parse_args()
P = args.p1_run.resolve()
W = (args.reference_worktree or args.checkout).resolve()
os.environ['CUDA_VISIBLE_DEVICES'] = ''
sys.path[:0] = [str(args.checkout.resolve()/'learning/src'), str(W/'learning/cli'), str(P/'model'), '/home/qy/DVGC/JIT/src']
import numpy as np
import torch
from sttw_control.coupled_handoff_planner import CoupledHandoffPlanner
from sttw_control.chapter3_p0_physical import P0Branches
from sttw_control.continuous_handoff_routes import ContinuousHandoffRoutes
from sttw_control.platform_online import velocity_state
from sttw_control.playground_adapters import GroundAdapter
from sttw_control.playground_prediction import euler
from sttw_control.torch_middle_control import TorchMiddleControl
from sttw_control.torch_path_reference import TorchPathReference
from frozen_exit_value import FrozenExits


@torch.inference_mode()
def check():
    torch.set_num_threads(1)
    folder=P/'batches/train_00/physical'
    cfg=json.loads((folder/'resolved_config.json').read_text())
    rows=json.loads((folder/'status.json').read_text())['results']
    chosen=[rows[i] for i in (0,2,4)]
    q,v=[],[]
    for r in chosen:
        with np.load(folder/r['case_dir']/'trajectory.npz') as z:
            q.append(z['qpos'][0]);v.append(z['qvel'][0])
    q,v=[torch.from_numpy(np.stack(a)).float() for a in (q,v)]
    assert torch.equal(q[:1].expand_as(q),q) and torch.equal(v[:1].expand_as(v),v)
    hcfg=json.loads((W/cfg['ground_handoff']['bundle']/'config.json').read_text())
    hcfg['follower']['lookahead_scale']=1.
    with np.load(cfg['ground_handoff']['reference_path']) as z:
        route=TorchPathReference(dict(z),hcfg,'cpu',route_ids=[0]*3)
    world=cfg['world_map_spec']
    dynamic=ContinuousHandoffRoutes(route,world['goal']['x_min_m'])
    route=dynamic.route
    model=FrozenExits(folder,'cpu',load_route_bank=False).query
    case=chosen[0]['variant']
    gate_x=torch.tensor([case['section_x']]*3);sides=torch.tensor([case['side']]*3)
    middle=TorchMiddleControl.__new__(TorchMiddleControl);middle.route=route;middle.tick=0
    middle.alpha=torch.zeros(3);middle.v_user=torch.full((3,),2.)
    middle.lane_ticks=torch.zeros(3,dtype=torch.long)
    heading=euler(q[:,3:7])[:,2]
    speed=v[:,0]*heading.cos()+v[:,1]*heading.sin()
    pose=torch.cat((q[:,:2],heading[:,None]),1)
    nearest=(route.xy[route.route_ids]-q[:,None,:2]).square().sum(-1).argmin(-1)
    middle.projection=route.project(q[:,:2],route.s[nearest],torch.zeros_like(speed))
    middle.follower=route.pursuit(middle.projection['progress'],pose,speed,middle.v_user)
    scratch=tempfile.TemporaryDirectory();out=Path(scratch.name)
    contracts=[{'side':int(s),'section_x':float(x)} for x,s in zip(gate_x,sides)]
    roll=P0Branches(dict(group_size=1,planner_mode='smooth_event',schedule_ticks=20,deadline_ms=100,
                         candidates=64,robots_per_chunk=1),out,model,route,contracts,q,v,dynamic_routes=dynamic)
    opt=dict(p1_run=str(P),outcome_checkpoint=str(P/'model/formal_fit/seed_61123/mixture3.pt'),
             outcome_mode='mixture3',deadline_ms=100,population=2,iterations=1,conditional_particles=2,entry_particle_chunk=1)
    planner=CoupledHandoffPlanner(opt,world,cfg['platform_online']['relative'],dynamic,model,'cpu',out)
    planner.request(q,v,middle,gate_x,sides,[True]*3,torch.tensor([case['jump_start_x_m']]*3),
                    torch.tensor([case['lookahead_scale']]*3),middle.v_user,10.)
    logged=json.loads((out/'p2_initial_decisions.json').read_text())
    assert len(logged)==1 and logged[0]['lanes']==[0,1,2] and logged[0]['due_tick']%4==0
    assert np.array_equal(np.asarray(logged[0]['initial_qpos']),q[0].numpy())
    adapter=GroundAdapter(middle,None)
    if not logged[0]['queued']:
        assert planner.publish(4,adapter,torch.ones(3,dtype=torch.bool)) is None
    handtime=chosen[0]['handoff_s']
    tick=1+round(handtime/.005)
    truefile=folder/f'p1_query/tick_{tick:04d}.npz'
    with np.load(truefile) as z:
        ix=int(np.flatnonzero(z['lanes']==0)[0])
        obs={k:torch.tensor(z[k][ix:ix+1]) for k in ['qpos','qvel','previous_qpos','previous_qvel',
                  'middle_projection_progress','middle_follower_lookahead','previous_velocity']}
    ids=torch.tensor([0]);measured_q=q.clone();measured_v=v.clone()
    measured_q[0]=obs['qpos'][0];measured_v[0]=obs['qvel'][0]
    middle.projection['progress'][ids]=obs['middle_projection_progress']
    middle.follower['lookahead'][ids]=obs['middle_follower_lookahead']
    dynamic.at_handback(ids,measured_q[ids,:2],middle.projection['progress'][ids])
    route.route_ids[ids]=dynamic.branch_rows[ids,1]
    prev=torch.zeros(3,9);prev[ids]=velocity_state(obs['previous_qpos'],obs['previous_qvel'])
    assert torch.allclose(prev[ids],obs['previous_velocity'],atol=1e-6)
    locked=torch.tensor([True,False,False])
    env=dict(q=measured_q,v=measured_v,route=route,middle=middle,alive=locked,handoff_time=torch.tensor([handtime,-1.,-1.]),hold=torch.zeros(3))
    roll.step(tick,env,locked,prev)
    events=[json.loads(x) for x in (out/'p0_events.jsonl').read_text().splitlines()]
    assert [e['kind'] for e in events]==['dynamic_handback','query']
    assert roll.queries.tolist()==[1,0,0] and events[0]['previous_twist'][0]==prev[0].tolist()
    # Duplicate the same observed handback into two distinct unused lanes to exercise paired clock replay.
    # The distinct synthetic samples make a lane-offset timing error observable.
    pair=torch.tensor([1,2])
    measured_q[pair]=measured_q[:1].clone();measured_v[pair]=measured_v[:1].clone()
    prev[pair]=prev[:1].clone();middle.projection['progress'][pair]=obs['middle_projection_progress']
    middle.follower['lookahead'][pair]=obs['middle_follower_lookahead']
    dynamic.at_handback(pair,measured_q[pair,:2],middle.projection['progress'][pair])
    route.route_ids[pair]=dynamic.branch_rows[pair,1]
    assert torch.equal(route.xy[route.route_ids[1]],route.xy[route.route_ids[2]])
    roll.event_ms={'monitor':torch.tensor([7.,11.]),'search':torch.tensor([41.,83.])}
    both=torch.tensor([False,True,True])
    env.update(alive=both,handoff_time=torch.tensor([-1.,handtime,handtime]))
    roll.step(tick,env,both,prev);roll.finish()
    clock=[json.loads(x) for x in (out/'p0_events.jsonl').read_text().splitlines()][-1]
    assert clock['lanes']==[1,2] and clock['sample_index']==[0,0] and clock['ms']==[41.,41.] and clock['due'][0]==clock['due'][1]
    # Exercise an on-time new packet on the same reset data in a separate, labelled interface test.
    from continuous_approach import Boundary,generate_reference
    clean=ContinuousHandoffRoutes(TorchPathReference(dict(np.load(cfg['ground_handoff']['reference_path'])),hcfg,'cpu',route_ids=[0]*3),world['goal']['x_min_m'])
    planner.dynamic=clean;planner.pending={};middle.route=clean.route;middle.tick=0
    middle.projection=middle.route.project(q[:,:2],middle.route.s[nearest],torch.zeros_like(speed))
    middle.follower=middle.route.pursuit(middle.projection['progress'],pose,speed,middle.v_user)
    def predetermined(world,raster,ground,jump,native_q,native_v,published,alpha,committed,section,side,**kw):
        x=world['terrain']['front_x_m']
        xx,yy=published['xy'][0].T
        y0=np.interp(x,xx,yy);h0=np.interp(x,xx,published['heading'][0])
        curve,_=generate_reference(published,committed,x,kw['trigger_before_edge_m'],Boundary(y0+.12,h0,0.),y0,h0)
        return curve,alpha,dict(total_s=0.,publishable_candidate=1,publishable_alpha=alpha,
                               candidate_log=[{'alpha':alpha}],publish_decision='interface_fixture'),[]
    planner.plan=predetermined
    with tempfile.TemporaryDirectory() as temp:
        planner.output=Path(temp)
        planner.request(q,v,middle,gate_x,sides,[True]*3,torch.tensor([case['jump_start_x_m']]*3),
                        torch.tensor([case['lookahead_scale']]*3),middle.v_user,10.)
    release_tick,=planner.pending.keys()
    before=middle.route.xy[middle.route.route_ids].clone()
    active=torch.ones(3,dtype=torch.bool); adapter=GroundAdapter(middle,None)
    assert planner.publish(release_tick-1,adapter,active) is None
    middle.tick=release_tick
    pub=planner.publish(release_tick,adapter,active)
    after=middle.route.xy[middle.route.route_ids]
    assert pub['published']==[0,1,2] and adapter.plan_version==1 and not torch.equal(before,after)
    boundary=int(torch.searchsorted(middle.route.s,planner.committed[0]))
    assert torch.equal(before[:,:boundary+1],after[:,:boundary+1])
    receipt=dict(train_map='train_00',root=1250,fixture_disturbances_N=[r['variant']['force_y_N'] for r in chosen],
                 distinct_input_decisions=len(logged),entry_lanes=logged[0]['lanes'],cpu_entry_particle_chunk=planner.solver.chunk,physical_exit_chunk=roll.models.chunk,entry_candidates=logged[0]['candidate_count'],
                 entry_selected=logged[0]['selected'],entry_queued=logged[0]['queued'],entry_latency_s=logged[0]['measured_ready_s'],
                 archived_handback=str(truefile),query_tick=tick,prior_velocity_tick=tick-4,exit_search=events[1]['searched'],
                 exit_admitted=events[1]['admitted'],actual_exit_query_elapsed_ms=events[1]['offline_batch_wall_ms'],
                 paired_clock_replay=dict(lanes=clock['lanes'],same_actual_handback=True,sample_index=clock['sample_index'],
                     fixture_search_ms=clock['ms'],due_ticks=clock['due']),
                 injected_candidate_interface_check=dict(source='predetermined curve solely to exercise publication, no trained selection',
                     published_lanes=pub['published'],published_tick=release_tick,committed_prefix_preserved=True,
                     maximum_lateral_reference_change_m=float((before-after).abs()[:,:,1].max())),
                 decision_evidence='CPU on observed reset and handback snapshots; zero new physical transitions')
    args.output.mkdir(exist_ok=True,parents=True)
    (args.output/'check_cpu.json').write_text(json.dumps(receipt,indent=2)+'\n')
    (args.output/'observed_decision.json').write_text(json.dumps(logged,indent=2)+'\n')
    (args.output/'observed_handback.jsonl').write_text((out/'p0_events.jsonl').read_text())
    scratch.cleanup()
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':
    check()

"""Time one cold and five warm single-vehicle requests on the same observed TRAIN initial state."""
import argparse
import csv
import hashlib
import json
import time

import numpy as np
import torch
from check_continuous_departure_plan import HERE,W,read_request,preview_commitment,table,write
from continuous_departure_plan import plan
from frozen_exit_value import FrozenExits
from jump_outcome import JumpOutcome
from sttw_control.torch_path_reference import TorchPathReference


def use_fused_ground(ground):
    """Bind the two existing P0 kernels on this timing process's frozen model only."""
    from functools import partial
    from sttw_control.platform_query_kernels import fused_step, route_features

    model=ground.query.model
    if not ground.query.relative or model.model_kind!='residual' or model.alpha_conditioned or len(model.terrain.field)!=1:
        raise ValueError('P0 Triton ground kernels require a single-map platform-relative residual checkpoint')
    model.step=partial(fused_step,model)
    model.nominal.features=partial(route_features,model.nominal.follower)


def compare_fused(target, references):
    """Scientific comparison after all clocks have stopped. Keep every matched row, including differences."""
    import pandas as pd

    comparisons={}
    for baseline,reference in references.items():
        if not (reference/'receipt.json').is_file():
            comparisons[baseline]={'status':'reference timing receipt missing','directory':str(reference)}
            continue
        if json.loads((reference/'receipt.json').read_text())['sha256']!=json.loads((target/'receipt.json').read_text())['sha256']:
            raise ValueError('Reference timing used a different jump checkpoint')
        def matched(file,keys,columns):
            fields=keys+columns
            current=pd.read_csv(target/file,usecols=fields,keep_default_na=False,float_precision='round_trip')
            prior=pd.read_csv(reference/file,usecols=fields,keep_default_na=False,float_precision='round_trip')
            data=current.merge(prior,on=keys,how='outer',validate='one_to_one',indicator=True,suffixes=('_fused','_reference'))
            if not data['_merge'].eq('both').all():raise ValueError(f'Unpaired {file}: {reference}')
            return data.drop(columns='_merge')
        votes=['allow_left','allow_straight','allow_right']
        particles=matched('particles.csv',['request','candidate','particle'],votes+['selected_exit','join_index','query_tick','exit_forecast_steps','predicted_x_m','predicted_y_m'])
        candidates=matched('candidates.csv',['request','candidate'],['iteration','published','parameters','alpha','conditional_particles','particles_with_exit','p_relock','score'])
        requests=matched('requests.csv',['request'],['elapsed_s','decision_elapsed_s','ground_s','nominal_deadline_s','body_window_s','meets_publish_slack','meets_archived_body_window','proposal','proposal_alpha','proposal_score','eligible_reference','publish_result'])
        assert len(particles)==6*144 and len(candidates)==6*9 and len(requests)==6
        assert particles.groupby('request').size().eq(144).all() and candidates.groupby('request').size().eq(9).all()
        for field in votes+['selected_exit','join_index','query_tick','exit_forecast_steps']:
            particles[field+'_differs']=particles[field+'_fused']!=particles[field+'_reference']
        candidates['score_delta']=candidates.score_fused-candidates.score_reference
        candidates['candidate_parameters_differ']=(candidates.parameters_fused!=candidates.parameters_reference)|(candidates.alpha_fused!=candidates.alpha_reference)
        requests['proposal_differs']=requests.proposal_fused!=requests.proposal_reference
        requests['highest_score_delta']=requests.proposal_score_fused-requests.proposal_score_reference
        requests['elapsed_delta_s']=requests.elapsed_s_fused-requests.elapsed_s_reference
        requests['fused_slack_remaining_s']=requests.nominal_deadline_s_fused-requests.elapsed_s_fused
        requests['reference_slack_remaining_s']=requests.nominal_deadline_s_reference-requests.elapsed_s_reference
        counts=particles.groupby('request')[[v+'_differs' for v in votes]+['selected_exit_differs','exit_forecast_steps_differs','join_index_differs']].sum()
        requests=requests.merge(counts.assign(vote_differences_of_432=counts[[v+'_differs' for v in votes]].sum(axis=1)),on='request')
        requests=requests.merge(candidates.groupby('request').score_delta.apply(lambda x:float(x.abs().max())).rename('max_abs_candidate_score_delta'),on='request')
        for name,data in [('particles',particles),('candidates',candidates),('requests',requests)]:
            data.to_csv(target/f'vs_{baseline}_{name}.csv',index=False)
        comparisons[baseline]=dict(status='complete',reference=str(reference),requests=6,exit_votes_per_request=432,selected_exits_per_request=144,
            differing_exit_votes=int(requests.vote_differences_of_432.sum()),differing_selected_exits=int(particles.selected_exit_differs.sum()),
            differing_candidate_parameters=int(candidates.candidate_parameters_differ.sum()),differing_proposals=int(requests.proposal_differs.sum()),
            differing_particle_horizons=int(particles.exit_forecast_steps_differs.sum()),differing_query_ticks=int(particles.query_tick_differs.sum()),
            max_abs_candidate_score_delta=float(candidates.score_delta.abs().max()),
            fused_satisfying_publication_slack=int(requests.meets_publish_slack_fused.sum()),reference_satisfying_publication_slack=int(requests.meets_publish_slack_reference.sum()),
            fused_warm_median_s=float(requests.loc[requests.request>1,'elapsed_s_fused'].median()),reference_warm_median_s=float(requests.loc[requests.request>1,'elapsed_s_reference'].median()))
    write(target/'comparison.json',comparisons)
    return comparisons


def main(device,fused=False):
    if fused and device!='cuda':raise ValueError('--fused requires --device cuda')
    setup=time.perf_counter()
    torch.set_num_threads(1)
    old=HERE/'three_alpha_batched'
    checkpoint=HERE/'legacy_smoke_mixture3.pt'
    cp=torch.load(checkpoint,weights_only=True,map_location='cpu')
    model=JumpOutcome(cp['width_in'],'mixture3')
    model.load_state_dict(cp['state']);model.eval().to(device)
    folder,cfg,first,side,gate,world,raster,published,q,v=read_request()
    ground=FrozenExits(folder,device=device,load_route_bank=False)
    if fused:use_fused_ground(ground)
    hcfg=json.loads((W/cfg['ground_handoff']['bundle']/'config.json').read_text());hcfg['follower']['lookahead_scale']=1.
    route=TorchPathReference(published,hcfg)
    source=json.loads((old/'receipt.json').read_text());clock=json.loads((old/'timing_window.json').read_text())
    if device=='cuda':torch.cuda.synchronize()
    setup_s=time.perf_counter()-setup
    outputs=[];candidate_rows=[];particle_rows=[]
    with (old/'particles.csv').open() as f:cpuparticles=list(csv.DictReader(f))
    with (old/'candidates.csv').open() as f:cpuscores=np.array([float(z['score']) for z in csv.DictReader(f)])
    assert cpuscores.shape==(9,) and len(cpuparticles)==144 and len(q)==12 and first['root_slot']==first['action_slot']==0
    for trial in range(6):
        if device=='cuda':torch.cuda.synchronize()
        ready=time.perf_counter()
        near,req,look,commit,slack=preview_commitment(route,published,q,v)
        output,alpha,log,_=plan(world,raster,ground,model,q,v,published,float(first['approach_alpha']),commit,gate,side,
                                publish_window_s=slack,request_started=ready)
        if device=='cuda':torch.cuda.synchronize()
        elapsed=time.perf_counter()-ready
        # The caller is at the handoff to publication now; include return and final synchronization.
        pub=int(log['publishable_candidate'])
        if elapsed>slack and pub:
            pub=0;output=published;alpha=float(first['approach_alpha'])
        eligible=pub!=0
        if not pub:assert output is published and alpha==first['approach_alpha']
        rows=log['candidate_log'];particles=log['particle_log'];scores=np.array([z['score'] for z in rows])
        assert len(rows)==9 and len(particles)==144 and {z['alpha'] for z in rows}=={0.,.5,1.}
        votes=('allow_left','allow_straight','allow_right')
        vote_differences=sum(z[k]!=(o[k]=='True') for z,o in zip(particles,cpuparticles) for k in votes)
        selected_differences=sum(z['selected_exit']!=int(o['selected_exit']) for z,o in zip(particles,cpuparticles))
        join_differences=sum(z['join_index']!=int(o['join_index']) for z,o in zip(particles,cpuparticles))
        outputs.append(dict(request=trial+1,cache='cold_first_model_loaded' if trial==0 else 'warm',elapsed_s=elapsed,
            decision_elapsed_s=log['total_s'],geometry_s=log['geometry_s'],jump_and_input_s=log['jump_and_input_s'],ground_s=log['ground_s'],
            candidate_count=9,conditional_particles=144,nominal_deadline_s=slack,body_window_s=clock['archived_arrival_s'],
            meets_publish_slack=elapsed<=slack,meets_archived_body_window=elapsed<=clock['archived_arrival_s'],
            proposal=log['selected'],proposal_alpha=log['alpha'],proposal_score=float(scores[log['selected']]),
            eligible_reference=pub,eligible_alpha=alpha,
            publish_result='new_reference_eligible' if eligible else ('deadline_missed_keep_published' if elapsed>slack and log['selected'] else log['publish_decision']),
            same_proposal_as_cpu=log['selected']==source['selected'],max_abs_score_delta_vs_cpu=float(np.abs(scores-cpuscores).max()),
            differing_cpu_exit_votes_of_432=vote_differences,differing_cpu_selected_exits_of_144=selected_differences,differing_cpu_joins_of_144=join_differences))
        candidate_rows.extend(dict(request=trial+1,**z) for z in rows)
        particle_rows.extend(dict(request=trial+1,**z) for z in particles)
    target=HERE/('three_alpha_timing_'+device+('_fused' if fused else ''));target.mkdir(parents=True,exist_ok=True)
    table(target/'requests.csv',outputs);table(target/'candidates.csv',candidate_rows);table(target/'particles.csv',particle_rows)
    warm=np.array([r['elapsed_s'] for r in outputs[1:]])
    info=dict(stage='complete',role='One observed TRAIN initial state, root 1250, train_00, fixed near-left gate. Latency only.',
        device=device,device_name=torch.cuda.get_device_name(0) if device=='cuda' else 'CPU, one PyTorch thread',
        checkpoint=str(checkpoint),sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),same_checkpoint_as_cpu=True,
        setup_s=setup_s,start='Immutable map, observations and model resident. Request begins before host route projection and H75 preview. First request follows model load without a prior planning request.',
        stop='Post-return explicit device synchronization and caller deadline decision; inputs, CPU curve generation, device transfers, CEM scoring and decision included. File writing follows timing.',
        measured_requests=6,vehicles_per_request=1,conditional_particles_per_request=144,
        cold_s=outputs[0]['elapsed_s'],warm_s=warm.tolist(),warm_median_s=float(np.median(warm)),warm_max_s=float(warm.max()),
        request_specific_nominal_publication_window_s=outputs[0]['nominal_deadline_s'],observed_body_travel_window_s=clock['archived_arrival_s'],
        changes_meeting_deadline=sum(r['eligible_reference']!=0 for r in outputs),physical_rollouts=0,transmitted_commands=0,training_updates=0)
    assert info['sha256']==source['model_checkpoint_sha256']
    if fused:
        info.update(ground_implementation='Original P0 fused_step and route_features bound to the frozen ground model. Original particle states, generated exit curves, per-particle times and PlatformDepartureQuery.choose retained.',
            cuda_graph=False,graph_note='P0 CapturedDepartureQuery freezes the route object and a scalar horizon. Here each round generates explicit candidate routes and particles have different remaining times. Reuse the kernels in eager PyTorch without capturing a different workload.',
            kernels_source=str(W/'learning/src/sttw_control/platform_query_kernels.py'))
    write(target/'receipt.json',info)
    if fused:compare_fused(target,{name:HERE/('three_alpha_timing_'+name) for name in ('cpu','cuda')})
    print(json.dumps(info,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device',choices=('cpu','cuda'),required=True)
    parser.add_argument('--fused',action='store_true',help='Use existing P0 Triton ground kernels on CUDA; default runs the original timing path.')
    args=parser.parse_args()
    main(args.device,args.fused)

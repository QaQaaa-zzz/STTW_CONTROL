"""Prespecified two-map, time-zero P1 -> two fixed exit values -> one shared approach per gate."""
import argparse,hashlib,json,subprocess,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from exit_value import KnownMap,ExitValue

ROOT=Path(__file__).resolve().parent
P=ROOT.parents[1];W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path[:0]=[str(P/'model'),str(P/'export'),str(W/'learning/cli')]
from export_prefixes import config_rows,OBSERVED
from run_downstream_dev import predicted_states,CFG
from jump_outcome import Dataset,DIM,decision_inputs,JumpOutcome,MODE_NAMES
from frozen_exit_value import FrozenExits
from run_playground_task_reversal import crossings_by_section

SEED=61123
GATES=[(12.7,1),(12.7,-1),(15.,1),(15.,-1)]
G=['map_id','root','gate_x','side']
MODELS=['mean_old5','mean_all16','mixture3_old5','mixture3_all16','old_train_rule','oracle_old5','oracle_all16']
def write(file,x):file.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()


def load_models(smoke):
    if smoke:
        file=P/'actions/continuous_examples/departure_plan/legacy_smoke_mixture3.pt'
        cp=torch.load(file,map_location='cpu',weights_only=True)
        nets={}
        for mode in MODE_NAMES:
            net=JumpOutcome(cp['width_in'],mode);net.load_state_dict(cp['state']);nets[(mode,str(SEED))]=net.eval()
        return nets,{'smoke_only_reuse_one_old_mixture_checkpoint_in_both_forward_modes':digest(file)}
    fit=P/'model/formal_fit'
    status=json.loads((fit/'stage.json').read_text());assert status['stage']=='complete' and SEED==CFG['seed_priority']
    seed_dir=fit/f'seed_{SEED}';spec=json.loads((P/'model/fit_preregistration.json').read_text())['shared_neural']
    assert spec['updates']==540 and spec['batch_size']==128 and status['seeds']==spec['seeds']
    assert status['optimisation_steps']==2*len(status['seeds'])*spec['updates']
    nets={};hashes={}
    for mode in MODE_NAMES:
        file=seed_dir/(mode+'.pt');cp=torch.load(file,map_location='cpu',weights_only=True)
        assert cp['mode']==mode
        net=JumpOutcome(cp['input_width'],mode,cp['width']);net.load_state_dict(cp['state'])
        nets[(mode,str(SEED))]=net.eval();hashes[mode]=digest(file)
    return nets,hashes


def predictions(folder,nets,root_subset):
    # Source row order is exactly the original exporter's frozen config sort; avoid opening
    # even the columns of an outcome-bearing CSV until after candidate selection.
    batch=next(b for b in json.loads((P/'collection_contract.json').read_text())['batches'] if b['name']==folder.name)
    _,left,_=config_rows(batch)
    cols=['map_id','bank_row','action_slot','geometry','approach_alpha','bin','section_x','side']
    meta=left.iloc[::3][cols].rename(columns={'bank_row':'root','approach_alpha':'alpha','bin':'section','side':'target_side'}).reset_index(drop=True)
    assert (left[cols].to_numpy()==np.repeat(left.iloc[::3][cols].to_numpy(),3,axis=0)).all()
    assert np.all(left.force_y_N.to_numpy().reshape(-1,3)==[-5.,0.,5.])
    with np.load(folder/'observed_inputs.npz',allow_pickle=False) as archive:
        obs={}
        for key in OBSERVED:
            a=archive[key];triplets=a.reshape(len(meta),3,*a.shape[1:])
            assert np.array_equal(triplets,np.broadcast_to(triplets[:,:1],triplets.shape))
            obs[key]=triplets[:,0]
    np.testing.assert_allclose(meta.alpha,obs['alpha'],rtol=0,atol=1e-7)
    x,q,reset,act=decision_inputs(obs)
    data=Dataset(x,q,reset,act,torch.zeros(len(q),dtype=torch.bool),torch.full((len(q),DIM),torch.nan),meta)
    if root_subset is not None:data=data.subset(np.flatnonzero(data.index.root.isin(root_subset)))
    # No outcome table is opened on this path. decision_rows checks identical allowed inputs for all 3 push copies.
    assert all(g.sort_values('action_slot').action_slot.tolist()==list(range(16)) for _,g in data.index.groupby('root'))
    engine=FrozenExits(P/'batches'/folder.name/'physical',device='cpu')
    world=KnownMap(P/'maps'/folder.name);model=ExitValue(ROOT/'train_model.npz')
    parts,items=predicted_states(data,nets,None,list(nets))
    score_rows=[]
    for lo in range(0,len(parts),128):
        ps=parts[lo:lo+128];q,v,prev,t=[np.asarray([p[k] for p in ps]) for k in ('q','v','prev','query_s')]
        branch=np.stack([engine.branch_ids(p['geometry'],p['q']) for p in ps])
        meta=pd.DataFrame([{k:p[k] for k in ('root','action_slot','geometry','alpha','method','particle')} for p in ps])
        for side,col in [(1,0),(-1,2)]:
            refs=[engine.bank[k][branch[:,col]] for k in ('xy','heading','curvature')]
            for gx in (12.7,15.):
                prob=model.score(world,q,v,prev,t,gx,side,side,*refs)
                score_rows.append(meta.assign(gate_x=gx,side=side,post_success=prob))
    values=pd.concat(score_rows).groupby(['root','action_slot','geometry','alpha','method','gate_x','side'],sort=True).post_success.agg(['size','mean']).reset_index()
    pr=pd.DataFrame([dict(root=tag['root'],action_slot=tag['action_slot'],method=tag['method'],p_relock=p) for tag,p,particles in items.values()])
    scores=values.merge(pr,on=['root','action_slot','method'],validate='many_to_one').rename(columns={'size':'particles','mean':'conditional_exit_probability'})
    scores['score']=scores.p_relock*scores.conditional_exit_probability;scores['map_id']=folder.name
    assert scores.particles[scores.method.eq('mean')].eq(1).all() and scores.particles[scores.method.eq('mixture3')].eq(16).all()
    return scores


def measured(folder,roots):
    s=pd.read_csv(folder/'suffix_index.csv')
    s=s[s.root.isin(roots)]
    rows=[];assigned=0;unmatched=0
    for r in s.itertuples(index=False):
        # Each actually run arm is rescored at both registered sections and both gate signs.
        with np.load(r.trajectory) as z:
            c=list(crossings_by_section(z['trace'],r.native_handoff_s if pd.notna(r.native_handoff_s) else np.inf,[12.7,13.6,15.]))
        executed=r.suffix_pair_status=='matched_observed_handoff' and r.observed_query and r.physical_target_effective and r.online_selected_direction==r.declared_direction
        if r.observed_query:
            assert r.query_tick==round(r.native_handoff_s/.005)+1 and r.due_tick==r.query_tick+3
            if executed:assert r.assigned_tick==r.due_tick
        if r.verified_relock and not executed:unmatched+=1
        for section,gx,_,y in [c[0],c[2]]:
            for side in (1,-1):
                gate=y is not None and .06<=y*side<=3.9
                success=bool(r.verified_relock and gate and r.physical_goal and not r.physical_wall)
                if section==r.section and side==r.target_side:
                    assert gate==r.correct_gate and success==r.physical_task_done
                    assigned+=1
                if (r.arm=='left')!=(side==1):continue
                # Failure before verified relock is observed. An unexecuted post at a verified handback remains unknown.
                known=bool(not r.verified_relock or executed)
                rows.append(dict(map_id=folder.name,root=r.root,gate_x=gx,side=side,action_slot=r.action_slot,alpha=r.alpha,
                    force=int(r.hidden_force_N_grouping_only),known=known,lower=int(known and success),upper=int((not known) or success),
                    physical_arm=r.arm,lane=r.lane,relocked=bool(r.verified_relock),post_executed=bool(executed),source_trajectory=r.trajectory))
    assert assigned==len(s)
    data=pd.DataFrame(rows)
    assert data.groupby(G+['action_slot']).force.agg(lambda x:set(x)=={-5,0,5}).all()
    assert data.groupby(G).size().eq(48).all()
    return data,dict(map=folder.name,source_arms=len(s),rescored_assigned_gates_exact=assigned,
                     verified_unexecuted_or_unmatched_arms=unmatched,unknown_gate_matching_physical_rows=int((~data.known).sum()))


def selection(s):
    choices={}
    for method in ('mean','mixture3'):
        ordered=s[s.method==method].sort_values('action_slot').set_index('action_slot')
        for size,label in ((5,'old5'),(16,'all16')):
            z=ordered.iloc[:size].score
            slot=int(z.idxmax());choices[method+'_'+label]=(slot,slot,int((z==z.max()).sum()))
    side=int(s.side.iloc[0]);fixed=4 if side==1 else 0;choices['old_train_rule']=(fixed,fixed,1)
    return choices


def hindsight(physical):
    options=physical.groupby('action_slot')[['lower','upper']].sum().sort_index();choices={}
    for size in (5,16):
        h=options.iloc[:size];low=int(h.lower.idxmax());high=int(h.upper.idxmax())
        choices['oracle_'+('old5' if size==5 else 'all16')]=(low,high,int((h.lower==h.lower.max()).sum()))
    return choices


def oracle_push_bounds(labels,size):
    # Exact marginal outcome of a hindsight winner for each push. Force that outcome
    # at one slot, give that slot the other upper outcomes, and rival slots their lower
    # outcomes. The lower-index tie convention must still let the forced slot win.
    L=labels.lower.unstack().sort_index().iloc[:size].to_numpy()
    U=labels.upper.unstack().sort_index().iloc[:size].to_numpy()
    totals=L.sum(1);high=U.sum(1)
    out=[]
    for j in range(3):
        possible=[]
        for a in range(size):
            for bit in range(L[a,j],U[a,j]+1):
                best=high[a]-U[a,j]+bit
                if (totals[:a]<best).all() and (totals[a+1:]<=best).all():possible.append(bit)
        out.append((min(possible),max(possible)))
    return out


def evaluate(scores,truth,out,preselected):
    complete=truth.groupby(['map_id','root']).known.all()
    incomplete=complete[~complete].index.tolist()
    groups=[];conditions=[];paired=[];fixed=[]
    by_truth=truth.groupby(G)
    for k,s in scores.groupby(G):
        meta=dict(zip(G,k));physical=by_truth.get_group(k);observed=bool(complete.loc[k[:2]])
        primary=preselected[k]
        choices={**primary,**hindsight(physical)}
        labels=physical.set_index(['action_slot','force']).sort_index()
        for method,(lo,hi,ties) in choices.items():
            a,b=labels.loc[lo],labels.loc[hi]
            group=dict(**meta,method=method,lower_choice=lo,upper_choice=hi,ties_at_lower_choice=ties,
                lower=int(a.lower.sum()),upper=int(b.upper.sum()),all_actions_observed_for_root=observed)
            groups.append(group)
            oracle=method.startswith('oracle')
            bounds=oracle_push_bounds(labels,5 if method=='oracle_old5' else 16) if oracle and not observed else None
            for j,force in enumerate((-5,0,5)):
                marginal=bounds[j] if bounds is not None else (int(a.loc[force,'lower']),int(b.loc[force,'upper']))
                conditions.append(dict(**meta,method=method,force_N=force,lower_choice=lo,upper_choice=hi,
                        lower=int(marginal[0]),upper=int(marginal[1]),lower_total_witness_case=int(a.loc[force,'lower']),
                        upper_total_witness_case=int(b.loc[force,'upper']),same_choice=lo==hi,
                        all_actions_observed_for_root=observed))
        for model,base in [('mean_old5','old_train_rule'),('mean_all16','old_train_rule'),
                           ('mixture3_old5','old_train_rule'),('mixture3_all16','old_train_rule'),
                           ('mean_all16','mean_old5'),('mixture3_all16','mixture3_old5'),
                           ('mixture3_old5','mean_old5'),('mixture3_all16','mean_all16')]:
            m,b=[choices[n][0] for n in (model,base)]
            for force in (-5,0,5):
                x,y=labels.loc[(m,force)],labels.loc[(b,force)]
                # Correlated missing labels cancel if the methods actually chose the same physical trial.
                lo,hi=(0,0) if m==b else (int(x.lower-y.upper),int(x.upper-y.lower))
                paired.append(dict(**meta,method=model,baseline=base,force_N=force,choice=m,base_choice=b,net_lower=lo,net_upper=hi,
                     exact_rescue=lo==hi==1,exact_loss=lo==hi==-1,exact_net=lo==hi,all_actions_observed_for_root=observed))
        # Geometry-only subset: same already active alpha, comparing only physically sampled options.
        for (method,alpha),h in s.groupby(['method','alpha']):
            if len(h)<2:continue
            h=h.sort_values('action_slot').set_index('action_slot')
            slot=int(h.score.idxmax());a=labels.loc[slot]
            fixed.append(dict(**meta,method=method,alpha=alpha,measured_slots=','.join(map(str,h.index)),selected=slot,
                lower=int(a.lower.sum()),upper=int(a.upper.sum()),all_actions_observed_for_root=observed))
    groups=pd.DataFrame(groups);conds=pd.DataFrame(conditions);pairs=pd.DataFrame(paired);fixed=pd.DataFrame(fixed)
    groups.to_csv(out/'groups.csv',index=False);conds.to_csv(out/'conditions.csv.gz',index=False)
    pairs.to_csv(out/'paired_conditions.csv.gz',index=False);fixed.to_csv(out/'fixed_alpha_measured_subsets.csv',index=False)
    result=[];diff=[]
    for panel in ('all_tasks_with_bounds','complete_roots'):
        def panelrows(df):return df if panel=='all_tasks_with_bounds' else df[df.all_actions_observed_for_root]
        for dims in (['map_id','gate_x','side'],['map_id','side'],['map_id'],['side'],[]):
            for methods,source,store in [(['method'],panelrows(groups),result),(['method','baseline'],panelrows(pairs),diff)]:
                for key,h in source.groupby(dims+methods):
                    if not isinstance(key,tuple):key=(key,)
                    rec=dict(panel=panel,**dict(zip(dims+methods,key)))
                    rec.update(roots=h.groupby(['map_id','root']).ngroups,shared_entry_decisions=h.groupby(G).ngroups)
                    if store is result:
                        rec.update(task_executions=3*len(h),lower=int(h.lower.sum()),upper=int(h.upper.sum()))
                    else:rec.update(task_executions=len(h),net_lower=int(h.net_lower.sum()),net_upper=int(h.net_upper.sum()),
                               certain_rescues=int(h.exact_rescue.sum()),certain_losses=int(h.exact_loss.sum()),undetermined_net=int((~h.exact_net).sum()))
                    store.append(rec)
    pd.DataFrame(result).to_csv(out/'by_map_and_side.csv',index=False)
    pd.DataFrame(diff).to_csv(out/'paired_by_map_and_side.csv',index=False)
    return dict(roots=len(complete),complete_roots=int(complete.sum()),incomplete_roots=[list(r) for r in incomplete],
                all_tasks=groups.groupby(G).ngroups*3)


def main(smoke=False):
    torch.set_num_threads(1);begin=time.perf_counter()
    nets,hashes=load_models(smoke)
    names=['train_00','train_01'] if smoke else ['dev_00','dev_01']
    role='train' if smoke else 'dev'
    out=ROOT/('development_entry_train_smoke' if smoke else 'development_entry')
    out.mkdir(exist_ok=True)
    # The registered fit checks the two DEV exports before fitting. Also check their terminal receipts.
    for name in names:
        folder=P/'export'/role/name
        assert (folder/'export_receipt.json').is_file()
    specs=[]
    for name in names:
        root_subset={'train_00':[1250],'train_01':[1273]}[name] if smoke else None
        specs.append(predictions(P/'export'/role/name,nets,root_subset))
    pred=pd.concat(specs,ignore_index=True)
    # Commit all time-zero scores to disk before opening post-control trajectories or labels.
    pred.to_csv(out/'time_zero_scores.csv.gz',index=False)
    preselected={k:selection(s) for k,s in pred.groupby(G)}
    chosen=[dict(**dict(zip(G,k)),method=m,selected=a,ties=t) for k,v in preselected.items() for m,(a,_,t) in v.items()]
    pd.DataFrame(chosen).to_csv(out/'time_zero_choices.csv',index=False)
    provenance=[];truth=[]
    for name in names:
        rec=json.loads((P/'export'/role/name/'export_receipt.json').read_text())
        assert rec['stage']=='complete' and rec['role']==role and rec['map_id']==name
        current=pred[pred.map_id==name];t,receipts=measured(P/'export'/role/name,current.root.unique())
        provenance.append(receipts);truth.append(t)
    truth=pd.concat(truth,ignore_index=True)
    truth.to_csv(out/'physical_conditions.csv.gz',index=False)
    if smoke: # Independent pre-existing TRAIN trajectory gate re-scoring.
        for name in names:
            archived=pd.read_csv(P/'export/cross_fixed_exit_gates'/f'{name}_crossings.csv.gz')
            observed=truth[(truth.map_id==name)&truth.known]
            original=archived.rename(columns={'action':'action_slot','arm':'physical_arm'}).copy()
            original['gate_x']=original.section.map({'near':12.7,'far':15.})
            linked=observed.merge(original[['lane','physical_arm','gate_x','side','done']],on=['lane','physical_arm','gate_x','side'],validate='one_to_one')
            assert len(linked)==len(observed) and np.array_equal(linked.lower,linked.done)
    summary=evaluate(pred,truth,out,preselected)
    assert summary['all_tasks']==(24 if smoke else 288)
    write(out/'receipt.json',dict(stage='complete',role='CPU TRAIN wiring smoke only' if smoke else 'registered DEV time-zero finite entry comparison',
        elapsed_s=time.perf_counter()-begin,maps=names,seed=None if smoke else SEED,model_hashes=hashes,exit_model_sha256=digest(ROOT/'train_model.npz'),
        outputs=summary,observed=provenance,training_updates=0,physical_rollouts=0,source_gate_inputs='Known gate side and distance plus registered candidate geometry; P1 decision rows exclude force and all actual post-control states.',
        common_draw_seed=CFG['draw_seed'],conditional_particles=dict(mean=1,mixture3=16),default_rule='near/far left: old slot 4; near/far right: old slot 0.',
        missing='Unknown continuation is bounded 0..1. Verified jump failure remains zero in all methods. Complete-root subset requires every action, push and gate-side paired outcome known. Hindsight lower and upper each maximize over one shared slot; the maximizing slot may differ. Per-push hindsight marginals enumerate every possible winning outcome under deterministic lowest-slot ties. Use group bounds, not sums of marginal bounds, for totals.',
        alpha='Primary 16/5 ranking assumes the selected alpha starts with first actuator command. Fixed-alpha rows group only measured same-alpha slots; no post-launch change to alpha.',
        scope='Every map, root and gate selects a single scheduled entry for all three hidden pushes. Baseline and two models all execute the same gate-side rule.')
        )
    if not smoke:subprocess.run([sys.executable,str(ROOT/'plot_development_entries.py'),str(out.resolve())],check=True)
    print(json.dumps(summary))

if __name__=='__main__':
    ap=argparse.ArgumentParser();mode=ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--train-smoke',action='store_true');mode.add_argument('--registered',action='store_true')
    main(ap.parse_args().train_smoke)

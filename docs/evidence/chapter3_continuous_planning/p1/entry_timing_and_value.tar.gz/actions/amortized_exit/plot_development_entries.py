"""Render the observed physical paths selected by all five time-zero rules, for every root and gate."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

RUN = Path(__file__).resolve().parents[2]
METHOD = {'old_train_rule':'固定门侧规则', 'mean_old5':'均值·5', 'mean_all16':'均值·16',
          'mixture3_old5':'分布·5', 'mixture3_all16':'分布·16'}
COLORS = ['#185f88', '#b54226', '#287c5a', '#6b5698', '#82611e']


def draw(report):
    receipt = json.loads((report / 'receipt.json').read_text())
    role = 'train' if 'TRAIN wiring' in receipt['role'] else 'dev'
    choices = pd.read_csv(report/'conditions.csv.gz').query('method in @METHOD').copy()
    truth = pd.read_csv(report/'physical_conditions.csv.gz')
    keys = ['map_id','root','gate_x','side']
    chosen = choices.merge(truth, left_on=keys+['force_N','lower_choice'], right_on=keys+['force','action_slot'],
                           validate='many_to_one', suffixes=('_rule','_trace'))
    assert chosen.same_choice.all() and (chosen.lower_rule == chosen.lower_trace).all()
    dest = report / 'xy'; dest.mkdir(exist_ok=True)
    with np.load(RUN/'shared/neutral.npz') as z:
        neutral=z['xy'][0]
    files, source = [], []
    plt.rcParams.update({'font.family':'Noto Sans CJK JP','font.size':10,'axes.unicode_minus':False})
    for name, map_cases in chosen.groupby('map_id'):
        scene = json.loads((RUN/'maps'/name/'world.json').read_text())
        walls, goal = scene['terrain']['forbidden_rectangles'], scene['goal']
        lane_meta = pd.read_csv(RUN/'export'/role/name/'suffix_index.csv').set_index('lane')
        for (root,gate,side), group in map_cases.groupby(['root','gate_x','side']):
            fig, axes = plt.subplots(3,1,figsize=(11.5,6.8),sharex=True,sharey=True)
            fig.subplots_adjust(left=.085,right=.975,top=.83,bottom=.115,hspace=.52)
            slots = group.drop_duplicates('method').set_index('method').loc[list(METHOD)].lower_choice
            color = dict(zip(dict.fromkeys(slots),COLORS))
            order = list(color)
            alphas=group.drop_duplicates('action_slot').set_index('action_slot').alpha
            actual_y=[]
            handles = [Line2D([],[],color=color[k],lw=2,label=' / '.join(METHOD[m] for m in slots[slots==k].index)+f'（入口 {k}，α={alphas[k]:.3g}）') for k in order]
            natural = {'forbidden_obstacle_contact':'碰墙','tracking_domain_exit':'离开跟踪范围','goal':'到达终点但未完成门任务','timeout':'超时'}
            for ax,(force,frame) in zip(axes, group.groupby('force_N',sort=True)):
                ax.axvline(scene['terrain']['front_x_m'],ls=':',color='#5d686f',lw=.9)
                ax.plot([gate,gate],[side*.06,side*3.9],color='#7c569a',zorder=0,lw=2)
                for x0,x1,y0,y1 in walls:
                    ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc='#8c6a56',alpha=.5,zorder=0))
                ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],
                                       2*goal['abs_y_max_m'],fc='#dcebd5',zorder=0))
                outcomes=[]
                for slot in order:
                    matches=frame[frame.action_slot==slot]
                    row=matches.iloc[0]; lane=lane_meta.loc[row.lane]
                    with np.load(row.source_trajectory) as z:
                        xy=z['qpos'][:,:2];t=z['trace'][:,z['columns'].tolist().index('time')]
                        ref=z['reference_xy'];exit_ref=z['published_reference_xy']
                    finite=np.flatnonzero(np.isfinite(xy).all(axis=1))
                    xy=xy[:finite[-1]+1]
                    j=int(lane.assigned_tick) if lane.physical_target_effective else len(xy)-1
                    cut=xy[min(j,len(xy)-1),0]
                    switch_x=xy[min(3,len(xy)-1),0]
                    lead=neutral[(neutral[:,0]>=xy[0,0])&(neutral[:,0]<=switch_x)]
                    pre=ref[(ref[:,0]>=switch_x)&(ref[:,0]<=cut)]
                    post=exit_ref[(exit_ref[:,0]>=cut)&(exit_ref[:,0]<=max(xy[:,0].max(),goal['x_max_m']))] if lane.physical_target_effective else exit_ref[:0]
                    c=color[slot]
                    for piece in (lead,pre,post):ax.plot(*piece.T,ls=':',lw=1.1,color=c,alpha=.8)
                    ax.plot(*xy.T,lw=1.7,color=c);actual_y.append(xy[:,1])
                    status='结果未知' if not row.known else '完成' if row.lower_trace else natural.get(lane.termination,'物理失败')
                    symbol='s' if not row.known else 'o' if row.lower_trace else 'X'
                    ax.plot(*xy[-1],ls='',marker=symbol,ms=6.5,color=c,mec='white',mew=.6)
                    if len(finite)!=len(t):status+='（末帧位置缺失）'
                    outcomes.append(f'{slot} {status}')
                    source.append(dict(map_id=name,root=root,gate_x=gate,side=side,force_N=force,slot=slot,alpha=lane.alpha,
                                     methods='|'.join(matches.method),physical_lane=row.lane,last_xy_time_s=float(t[finite[-1]]),
                                     physical_end_s=float(t[-1]),termination=lane.termination,known=row.known,outcome=status,source=row.source_trajectory))
                ax.set_title(f'横推 {force:+d} N    '+ '　'.join(outcomes),loc='left',fontsize=10)
                ax.set_aspect('equal',adjustable='box'); ax.set_ylabel('y（m）');ax.grid(lw=.35,alpha=.35)
            # The wall can extend to the edge of the map. Keep the running corridor legible
            # and include all measured endpoints; the gate segment is clipped to this view.
            ys=np.concatenate(actual_y); ymin=min(-.85,float(ys.min())-.15);ymax=max(.85,float(ys.max())+.15)
            axes[-1].set_ylim(ymin,ymax);axes[-1].set_xlabel('前进方向 x（m）')
            fig.suptitle(f'{name}  ·  起点 {root}  ·  x = {gate:g} m '+('左门' if side==1 else '右门'),fontsize=16,y=.99)
            fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.945),ncol=min(len(handles),3),frameon=False,fontsize=9)
            fig.text(.5,.015,'实线为实走轨迹，点线为参考。竖线标台阶和指定门侧，绿色区域为终点。各行按原物理终点截断。',ha='center',fontsize=9)
            file=dest/f"{name}_root{root}_gate{gate:g}_{'L' if side==1 else 'R'}.png"
            fig.savefig(file,dpi=135);plt.close(fig)
            files.append(dict(map_id=name,root=root,gate_x=gate,side=side,file=file.name))
    index=pd.DataFrame(files)
    index.to_csv(dest/'figures.csv',index=False);pd.DataFrame(source).to_csv(dest/'sources.csv.gz',index=False)
    items=[f'<li><a href="{r.file}">起点 {r.root}，{r.gate_x:g} 米'+('左门' if r.side==1 else '右门')+'</a></li>' for r in index.itertuples()]
    (dest/'index.html').write_text('<!doctype html><html lang="zh"><meta charset="utf-8"><title>按出发观测选路的实际轨迹</title><h1>按出发观测选路的实际轨迹</h1><p>'+role.upper()+'。每张图含三种横推及五种方法，同一入口共用一次物理记录。</p><ul>'+''.join(items)+'</ul></html>')
    assert len(index)*3*len(METHOD)==len(chosen)
    return len(index)

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('report',type=Path)
    print(draw(cli.parse_args().report),'paired XY panels')

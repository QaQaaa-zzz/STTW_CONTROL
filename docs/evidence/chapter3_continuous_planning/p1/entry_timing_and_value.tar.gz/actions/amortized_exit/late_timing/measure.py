"""Six complete CPU requests with a 500 ms geometric reserve and a 400 ms release boundary."""
import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
import hashlib,json,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
import torch

OUT=Path(__file__).resolve().parent;VALUE=OUT.parent;P=VALUE.parents[1]
AUDIT=P/'export/exit_decision_time/approach_window/late_publication'
sys.path[:0]=[str(VALUE),str(AUDIT)]
from time_planner import SMOKE,W,read_request,plan,JumpOutcome,TorchPathReference,KnownMap,ExitValue,departure_options_lr_batch,table,write
from check import compare_reference_reads,native_publication,DUE
from sttw_control.chapter3_continuous_exit import committed_progress
from sttw_control.playground_prediction import euler

def main():
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    start=time.perf_counter()
    folder,cfg,first,side,gate,world,raster,neutral,q,v=read_request()
    assert (first['bank_row'],first['action_slot'],first['approach_alpha'],first['force_y_N'],side,gate)==(1250,0,0.,0,1,12.7)
    with np.load(cfg['paired_departures']['approach_file']) as a:incumbent={'s':a['s'],**{k:a[k][:1] for k in ('xy','heading','curvature')}}
    hcfg=json.loads((W/cfg['ground_handoff']['bundle']/'config.json').read_text());hcfg['follower']['lookahead_scale']=1.
    neutral_rt=TorchPathReference(neutral,hcfg);old_rt=TorchPathReference(incumbent,hcfg)
    jump_file=SMOKE/'legacy_smoke_mixture3.pt';cp=torch.load(jump_file,map_location='cpu',weights_only=True)
    jump=JumpOutcome(cp['width_in'],'mixture3');jump.load_state_dict(cp['state']);jump.eval()
    known=KnownMap(P/'maps/train_00');exit_file=VALUE/'train_model.npz';soft=ExitValue(exit_file)
    request=torch.tensor([float(first['approach_speed_m_s'])]);obs_q=torch.from_numpy(q[None]);obs_v=torch.from_numpy(v[None])
    def soft_score(curves,qpos,vel,prev,query_s,x,side):
        joined,refs=departure_options_lr_batch(curves,qpos[:,:2],goal_start_x_m=known.goal_x)
        args=[np.repeat(a,2,axis=0) for a in (qpos,vel,prev,query_s)]
        fields=[refs[k].reshape((-1,*refs[k].shape[2:])) for k in ('xy','heading','curvature')]
        scores=soft.score(known,*args,x,side,np.tile([1,-1],len(qpos)),*fields)
        return joined,scores.reshape(-1,2)
    setup_s=time.perf_counter()-start
    logs=[];saved=None
    for trial in range(6):
        ready=time.perf_counter()
        yaw=euler(obs_q[:,3:7])[:,2]
        start_pose=torch.column_stack((obs_q[:,:2],yaw));speed=obs_v[:,0]*yaw.cos()+obs_v[:,1]*yaw.sin()
        nearest=(neutral_rt.xy-start_pose[:,None,:2]).square().sum(-1).argmin(1)
        init=neutral_rt.project(start_pose[:,:2],neutral_rt.s[nearest],torch.zeros_like(speed))
        first_read=neutral_rt.pursuit(init['progress'],start_pose,speed,request)
        commit=committed_progress(init['progress'],first_read['lookahead'],request,.5)
        output,alpha,log,curves=plan(world,raster,None,jump,q,v,incumbent,float(first['approach_alpha']),float(commit),gate,side,
            fixed_alpha=True,soft_exit_scores=soft_score,publish_window_s=.4,request_started=ready)
        elapsed=time.perf_counter()-ready
        selected=log['selected'];by_time=selected if elapsed<=.4 else 0
        assert len(log['particle_log'])==144 and len(curves)==9 and all(r['alpha']==0 for r in log['candidate_log'])
        for i,item in enumerate(log['candidate_log']):
            states=log['particle_log'][i*16:(i+1)*16]
            np.testing.assert_allclose(item['p_relock']*np.mean([max(s['p_left'],s['p_right']) for s in states]),
                                      item['score'],atol=1e-12,rtol=0)
        if saved is None:
            saved=(curves,log);table(OUT/'candidates.csv',log['candidate_log']);table(OUT/'particles.csv',log['particle_log'])
            np.savez_compressed(OUT/'candidate_curves.npz',s=incumbent['s'],**{k:np.concatenate([c[k] for c in curves]) for k in ('xy','heading','curvature')})
        else:
            assert log['candidate_log']==saved[1]['candidate_log'] and log['particle_log']==saved[1]['particle_log']
        logs.append(dict(request=trial+1,cold=not trial,elapsed_s=elapsed,returned_in_400ms=elapsed<=.4,deadline_s=.4,
            geometry_s=log['geometry_s'],jump_and_input_s=log['jump_and_input_s'],explicit_exit_and_value_s=log['ground_s'],
            proposed=selected,old0_score=log['candidate_log'][0]['score'],proposed_score=log['candidate_log'][selected]['score'],
            proposed_alpha=alpha,time_eligible_route=by_time))
    # The recorded post-start states are opened only after every t0 decision and wall clock are fixed.
    df=pd.read_csv(AUDIT/'sources.csv');r=df[df.root==1250].iloc[0]
    with np.load(r.trajectory) as z:
        measured_q=z['qpos'][:DUE+1];measured_v=z['qvel'][:DUE+1];tr=z['trace'][:DUE+1];yy=tr[:,z['columns'].tolist().index('yaw')]
        np.testing.assert_array_equal(q,measured_q[0]);np.testing.assert_array_equal(v,measured_v[0])
    pose=torch.tensor(np.column_stack([measured_q[:,:2],yy]))[:,None,:];angle=pose[:,:,2]
    vel=torch.from_numpy(measured_v);body_speed=vel[:,0,None]*angle.cos()+vel[:,1,None]*angle.sin()
    # Same archived state and native reset as the 72-root audit. Leave the plant untouched.
    near=(neutral_rt.xy-pose[:1,0,None,:2]).square().sum(-1).argmin(1)
    audit_init=neutral_rt.project(pose[0,:,:2],neutral_rt.s[near],torch.zeros_like(request))
    audit_first=neutral_rt.pursuit(audit_init['progress'],pose[0],body_speed[0],request)
    assert torch.equal(init['progress'],audit_init['progress']) and torch.equal(first_read['lookahead'],audit_first['lookahead'])
    winning=saved[0][selected];raw=torch.stack((body_speed[0],torch.tensor([measured_q[0,8]])),1)
    proj,fol,required,consumed,computed,envelope=compare_reference_reads(pose,body_speed,request,raw,neutral_rt,old_rt,
        TorchPathReference(winning,hcfg),audit_init,audit_first)
    approved,reason,pub=native_publication(incumbent,winning,hcfg,request,proj['progress'],fol['lookahead'],commit)
    for row in logs:
        row.update(controller_accepts_candidate=approved,reads_bitwise_equal=consumed[0] is None,
                   route_at_400ms=row['time_eligible_route'] if approved and consumed[0] is None else 0,alpha_at_400ms=0.)
    table(OUT/'requests.csv',logs)
    for label,ref in [('scheduled_incumbent',incumbent),('highest_score',winning),('eligible_release',saved[0][logs[-1]['route_at_400ms']])]:
        np.savez_compressed(OUT/(label+'.npz'),**ref,alpha=0.)
    elapsed=[x['elapsed_s'] for x in logs]
    result=dict(stage='complete',map='train_00',root=1250,section_x_m=gate,side=side,alpha_at_t0=0.,alpha_at_release=0.,
        nominal_leadin='Identical neutral through ticks 0-2; the known running reference from 15 ms is actual old slot 0. Candidate 0 is this incumbent, not neutral.',
        input_source=str(P/'export/train/train_00/observed_inputs.npz'),timing_source='Only t0 vehicle state and known map enter the six requests. Timer includes native reset projection/preview, continuous generation, jump samples, both explicit exits, feature scoring and selection; excludes model setup and physical publication.',
        geometry_reserve_s=.5,release_boundary_s=.4,committed_progress_m=float(commit),required_at_release_m=float(required),
        margin_at_release_m=float(commit-required),initial_progress_m=float(init['progress']),initial_lookahead_m=float(first_read['lookahead']),
        jump_weights=str(jump_file),jump_sha256=hashlib.sha256(jump_file.read_bytes()).hexdigest(),exit_weights=str(exit_file),
        exit_sha256=hashlib.sha256(exit_file.read_bytes()).hexdigest(),setup_s=setup_s,threads=1,requests=len(logs),
        cold_s=elapsed[0],warm_s=elapsed[1:],warm_median_s=float(np.median(elapsed[1:])),candidate_count=9,conditional_particles=16,
        p_relock_times_mean_max_two_exits=True,selected=selected,incumbent_score=logs[0]['old0_score'],selected_score=logs[0]['proposed_score'],
        native_update_accepted=approved,native_receipt=pub,reason=reason,all_used_reference_outputs_bitwise_equal=consumed[0] is None,
        all_computed_reference_outputs_bitwise_equal=computed[0] is None,first_difference=consumed[0],source_archived_xy=str(r.trajectory),
        timely_candidates=sum(z['returned_in_400ms'] for z in logs),changes_eligible_at_400ms=sum(z['route_at_400ms']!=0 for z in logs),
        actually_transmitted_or_simulated_new_routes=0,training_updates=0,physical_steps=0,
        interpretation='One TRAIN input, old jump smoke and TRAIN exit value. Native publication call is replayed on the required real state fields. New vehicle motion after the geometric switch and gate success are unmeasured.')
    write(OUT/'receipt.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()

"""Retrospective approach ranking with perfect knowledge of three realized jump queries."""
import json
from pathlib import Path
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
P=OUT.parents[1]
def main():
    pred=pd.read_csv(OUT/'held_predictions.csv.gz');missing=pd.read_csv(OUT/'unexecuted.csv')
    excluded=missing[['map_id','root']].drop_duplicates()
    all_actions=[];all_groups=[];paired_push=[]
    for map_id in sorted(pred.map_id.unique()):
        prefixes=pd.read_csv(P/'export/train'/map_id/'prefix_index.csv')
        bad_roots=set(excluded.loc[excluded.map_id==map_id,'root'])
        prefixes=prefixes[~prefixes.root.isin(bad_roots)]
        # No unknown physical branch is converted to zero; dropped roots are absent from every method.
        assert prefixes.verified_relock.equals(prefixes.observed_query)
        known=pred[(pred.map_id==map_id)&(~pred.root.isin(bad_roots))]
        assert set(known.row)==set(prefixes.loc[prefixes.verified_relock,'row'])
        assert set(prefixes.groupby(['root','action_slot']).hidden_force_N_grouping_only.agg(tuple).map(frozenset))=={frozenset([-5,0,5])}
        c=prefixes[['row','root','action_slot','hidden_force_N_grouping_only','verified_relock']].copy()
        for gx in [12.7,15.]:
            for side in [1,-1]:
                gates=known[(known.gate_x==gx)&(known.side==side)]
                left=c.merge(gates[gates.arm=='left'][['row','p_exit','p_baseline','done']],on='row',how='left',validate='one_to_one')
                right=c.merge(gates[gates.arm=='right'][['row','p_exit','p_baseline','done']],on='row',how='left',validate='one_to_one')
                assert np.array_equal(left.done.notna(),c.verified_relock) and np.array_equal(right.done.notna(),c.verified_relock)
                left_p,left_base,left_y=left[['p_exit','p_baseline','done']].fillna(0.).to_numpy(float).T
                right_p,right_base,right_y=right[['p_exit','p_baseline','done']].fillna(0.).to_numpy(float).T
                toward_y=left_y if side==1 else right_y
                # Binary jump survival is known at each of the three futures; one shared approach must be selected.
                z=c.copy()
                z['logistic_score']=np.maximum(left_p,right_p)
                z['logistic_realized']=np.where(left_p>=right_p,left_y,right_y)
                z['freq_score']=np.maximum(left_base,right_base)
                z['freq_realized']=np.where(left_base>=right_base,left_y,right_y)
                z['toward_score']=left_p if side==1 else right_p
                z['toward_realized']=toward_y
                z['relock_score']=c.verified_relock.astype(float)
                z['relock_realized']=toward_y
                z['upper']=np.maximum(left_y,right_y)
                for root,sub in z.groupby('root'):
                    options=sub.groupby('action_slot').agg({k:'sum' for k in ['logistic_score','logistic_realized','freq_score','freq_realized',
                        'toward_score','toward_realized','relock_score','relock_realized','upper']}).sort_index()
                    assert options.index.tolist()==list(range(16)) and len(sub)==48
                    actions=options.copy()
                    for m in ('logistic','freq','relock','toward'):actions[m+'_score']/=3.
                    all_actions.append(actions.reset_index().assign(map_id=map_id,root=root,gate_x=gx,side=side))
                    out=dict(map_id=map_id,root=int(root),gate_x=gx,side=side,actions=16,pushes=3)
                    for method in ('logistic','freq','relock','toward'):
                        scores=options[method+'_score'].to_numpy()
                        a=int(np.argmax(scores));out[method+'_action']=a
                        out[method+'_mean_score']=float(scores[a]/3.)
                        tied=scores==scores.max()
                        out[method+'_ties']=int(tied.sum())
                        out[method+'_uniform_tied_expected']=float(options.loc[tied,method+'_realized'].mean())
                        out[method+'_completed']=int(options.loc[a,method+'_realized'])
                        out[method+'_if_always_toward']=int(options.loc[a,'toward_realized'])
                        out[method+'_if_oracle_exit']=int(options.loc[a,'upper'])
                    out['oracle_action']=int(options.upper.idxmax());out['oracle_ties']=int((options.upper==options.upper.max()).sum())
                    out['oracle_completed']=int(options.upper.max());out['oracle_toward_completed']=int(options.toward_realized.max())
                    gains=losses=0
                    for push in (-5,0,5):
                        arr=sub[sub.hidden_force_N_grouping_only==push].set_index('action_slot')
                        record={k:out[k] for k in ('map_id','root','gate_x','side')}
                        record['push_N_paired_only']=push
                        for method in ('logistic','freq','relock','toward'):
                            record[method+'_completed']=int(arr.loc[out[method+'_action'],method+'_realized'])
                        gains+=int(record['logistic_completed']>record['freq_completed'])
                        losses+=int(record['logistic_completed']<record['freq_completed'])
                        paired_push.append(record)
                    out['paired_push_rescued']=gains;out['paired_push_lost']=losses
                    all_groups.append(out)
    tasks=pd.DataFrame(all_groups);actions=pd.concat(all_actions)
    # Three registered old-library controls on the identical complete 68-root panel.
    old=actions[actions.action_slot<5]
    grouped=old.groupby(['map_id','root','gate_x','side'])
    benchmarks=[]
    for (held,gate,sgn),h in tasks.groupby(['map_id','gate_x','side']):
        train_old=old[(old.map_id!=held)&(old.gate_x==gate)&(old.side==sgn)]
        physical=train_old.groupby('action_slot').toward_realized.sum().sort_index()
        best_shared=int(physical.idxmax())
        for task in h.itertuples():
            g=grouped.get_group((held,task.root,gate,sgn)).set_index('action_slot').sort_index()
            old_value=int(g.logistic_score.idxmax());oracle_toward=int(g.toward_realized.idxmax())
            benchmarks.append(dict(map_id=held,root=task.root,gate_x=gate,side=sgn,
                old_train_gate_action=best_shared,old_train_gate_ties=int((physical==physical.max()).sum()),
                old_train_gate_completed=int(g.loc[best_shared,'toward_realized']),
                old_5_value_action=old_value,old_5_value_ties=int((g.logistic_score==g.logistic_score.max()).sum()),
                old_5_value_completed=int(g.loc[old_value,'logistic_realized']),
                old_5_hindsight_gate_action=oracle_toward,old_5_hindsight_gate_ties=int((g.toward_realized==g.toward_realized.max()).sum()),
                old_5_hindsight_gate_completed=int(g.loc[oracle_toward,'toward_realized'])))
    tasks=tasks.merge(pd.DataFrame(benchmarks),on=['map_id','root','gate_x','side'],validate='one_to_one')
    pd.DataFrame(paired_push).to_csv(OUT/'approach_paired_pushes.csv.gz',index=False)
    tasks.to_csv(OUT/'approach_groups.csv',index=False);actions.to_csv(OUT/'approach_scores.csv.gz',index=False)
    cols=['logistic_completed','freq_completed','relock_completed','toward_completed','logistic_if_always_toward',
          'logistic_if_oracle_exit','freq_if_oracle_exit','relock_if_oracle_exit','oracle_completed','oracle_toward_completed',
          'old_train_gate_completed','old_5_value_completed','old_5_hindsight_gate_completed']
    by=[]
    for label,groups in list(tasks.groupby('map_id'))+[('all',tasks)]:
        r=dict(map=label,roots=groups.root.nunique(),choices=len(groups),executions=3*len(groups))
        r.update({k:int(groups[k].sum()) for k in cols})
        r.update(logistic_uniform_tied_expected=groups.logistic_uniform_tied_expected.sum(),freq_uniform_tied_expected=groups.freq_uniform_tied_expected.sum(),
                 relock_uniform_tied_expected=groups.relock_uniform_tied_expected.sum(),freq_tasks_with_ties=int((groups.freq_ties>1).sum()),
                 paired_push_rescued=int(groups.paired_push_rescued.sum()),paired_push_lost=int(groups.paired_push_lost.sum()),
                 logistic_vs_freq_gain=int((groups.logistic_completed-groups.freq_completed).clip(lower=0).sum()),
                 logistic_vs_freq_loss=int((groups.freq_completed-groups.logistic_completed).clip(lower=0).sum()),
                 logistic_better_groups=int((groups.logistic_completed>groups.freq_completed).sum()),
                 logistic_worse_groups=int((groups.logistic_completed<groups.freq_completed).sum()),
                 logistic_equal_groups=int((groups.logistic_completed==groups.freq_completed).sum()),
                 same_logistic_freq_approach=int((groups.logistic_action==groups.freq_action).sum()),
                 freq_relock_same_action=int((groups.freq_action==groups.relock_action).sum()))
        by.append(r)
    summary=pd.DataFrame(by);summary.to_csv(OUT/'approach_by_map.csv',index=False)
    (OUT/'approach_analysis.json').write_text(json.dumps(dict(stage='Post hoc on stored held-TRAIN fold predictions only. No refits.',
        excluded_before_grouping=excluded.to_dict('records'),comparison='16 approaches per root/gate, equal weight over -5, 0, +5 N; one shared choice across all three. Drop each affected root and all four gates. No-force labels or IDs in the exit model.',
        perfect_information='Use the measured future handback probability 0 or 1 and, when verified, its true query pose, twists and time. This access is impossible before jumping. The result isolates ranking conditional on having these three measured futures.',
        logistic='maximize mean of max(left,right) predicted probabilities; physically score the predicted direction at that push.',
        freq='training-fold root-weighted frequency by gate sign/section and branch; maximize mean over actual jump survival, evaluate predicted branch.',
        relock='maximize fraction of physically verified jumps; always take exit matching gate sign.',
        toward='rank on actual survival times the logistic probability for the gate-matching exit, and always execute that exit.',
        logistic_if_always_toward='retain the full logistic selected approach, then fix execution to the gate-matching exit.',
        upper='best single shared approach, with an oracle selecting either of the two measured exits separately for each push. Same 16 choices, same three conditions and same 272 tasks.',
        old_train_gate='Per held TRAIN map and gate, choose one old slot (0..4) with highest actual gate-side completion among every complete root from the other five maps. Freeze that slot for all current roots. No future input at deployment.',
        old_5_value='Rank just the five old slots with the identical retrospective two-exit logistic score and execute its chosen exit for each realization.',
        old_5_hindsight_gate='Per held root and gate, hindsight-pick one old slot maximizing its three actual gate-matching branch labels and always take that side.',
        ties='Lowest action slot on an exact tie. Equal exit probability selects left. All per-method per-group tie counts plus the exact expected successes for uniform random selection among top ties are reported.',
        results=by),indent=2)+'\n')
    print(summary[['map','roots','choices','executions','logistic_completed','freq_completed','relock_completed','toward_completed','oracle_completed','logistic_vs_freq_gain','logistic_vs_freq_loss']].to_string(index=False))
if __name__=='__main__':main()

"""Time the shared feature+score API on 144 resident TRAIN queries with both explicit routes."""
import json,time
import numpy as np
import pandas as pd
from scipy.special import expit
from run import HERE,P,KnownMap,ExitValue,mapped_arrays

def main():
    data=pd.read_csv(HERE/'rows.csv.gz')
    same=data[(data.map_id=='train_00')&(data.gate_x==12.7)&(data.side==1)].iloc[:288]
    assert len(same.row.unique())==144 and same.exit_side.to_list()==[1,-1]*144
    row=same.row.to_numpy();branch=same.committed_route_bank_row.to_numpy(int)
    bank=mapped_arrays(P/'shared/departures.npz')
    with np.load(P/'export/train/train_00/measured_targets.npz') as f:
        states=[f[k][row] for k in ('query_qpos_native','query_velocity_state9','previous_velocity_state9','query_s')]
    known=KnownMap(P/'maps/train_00');model=ExitValue(HERE/'train_model.npz')
    args=(known,*states,12.7,1,same.exit_side.to_numpy(),*[bank[k][branch] for k in ('xy','heading','curvature')])
    ms=[]
    for _ in range(11):
        start=time.perf_counter();score=model.score(*args);ms.append(1000*(time.perf_counter()-start))
    with np.load(HERE/'train_features.npz') as f:stored=f['X'][same.index]
    expected=expit(((stored-model.center)/model.scale)@model.coef+model.intercept)
    np.testing.assert_allclose(score,expected,atol=1e-10,rtol=1e-10)
    result=dict(timing='144 observed TRAIN landings × 2 explicit left/right routes, near-left gate. CPU NumPy feature construction and logistic scoring, data/geometry/map/model resident. Excludes geometry generation and jump prediction, CEM and publication.',
                first_ms=ms[0],warm_ms=ms[1:],warm_median_ms=float(np.median(ms[1:])),comparison_max_error=float(np.max(abs(score-expected))),
                batch_branch_scores=len(score),source='First 144 eligible distinct TRAIN_00 matched queries in rows.csv.gz; physical branch rows are present at the handback query. This tests shape and time only.')
    (HERE/'cpu_batch.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()

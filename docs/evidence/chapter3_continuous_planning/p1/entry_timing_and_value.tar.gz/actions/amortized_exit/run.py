"""Index six TRAIN maps first, then perform the six prespecified held-map-out fits."""
import argparse,json,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from exit_value import KnownMap,features,ExitValue

HERE=Path(__file__).resolve().parent
P=HERE.parents[1]
sys.path.insert(0,str(P/'model'))
from frozen_exit_value import mapped_arrays
MAPS=[f'train_{i:02}' for i in range(6)]
def save(file,data):file.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')


def index():
    groups=[];matrices=[];sources=[];excluded=[]
    bank=mapped_arrays(P/'shared/departures.npz')
    for name in MAPS:
        f=P/'export/train'/name;folder=P/'maps'/name;world=KnownMap(folder)
        suffix=pd.read_csv(f/'suffix_index.csv')
        real=suffix[suffix.observed_query & suffix.verified_relock & suffix.suffix_pair_status.eq('matched_observed_handoff')].copy()
        both=real.groupby('row').physical_target_effective.agg(['size','all'])
        assert (both['size']==2).all()
        lost=both.index[~both['all']]
        excluded.extend(real[real.row.isin(lost)][['map_id','row','root','action_slot','hidden_force_N_grouping_only','arm','termination']].to_dict('records'))
        matched=real[~real.row.isin(lost)].copy()
        assert matched.online_selected_direction.eq(matched.declared_direction).all()
        prefix=pd.read_csv(f/'prefix_index.csv').set_index('row')
        labels=pd.read_csv(P/'export/cross_fixed_exit_gates'/f'{name}_crossings.csv.gz')
        ids=matched[['row','map_id','root','action_slot','hidden_force_N_grouping_only','arm','lane','committed_route_bank_row','query_file','query_file_row']]
        # Lane, map and arm identify the source; only the four offline gate outcomes enter as targets.
        data=ids.merge(labels[['lane','arm','root','action','force','section','side','done','assigned']],on=['lane','arm','root'],validate='one_to_many')
        assert np.array_equal(data.action,data.action_slot) and np.array_equal(data.force,data.hidden_force_N_grouping_only)
        assert len(data)==4*len(matched) and data.assigned.sum()==len(matched)
        data['strict_substep_match']=prefix.loc[data.row,'raw_substep_loads_equal'].to_numpy()
        data['gate_x']=data.section.map({'near':12.7,'far':15.});data['exit_side']=data.arm.map({'left':1,'right':-1})
        data=data.sort_values(['row','gate_x','side','exit_side'],ascending=[True,True,False,False]).reset_index(drop=True)
        assert data.groupby(['row','gate_x','side']).arm.count().eq(2).all()
        # Verify that the predecision index is the queried alternative, not a shadow or later free choice.
        for qp,arm in matched.groupby('query_file'):
            with np.load(qp) as stored:
                j=arm.query_file_row.to_numpy(int);e=arm.declared_direction.to_numpy(int)
                np.testing.assert_array_equal(arm.committed_route_bank_row.to_numpy(int),stored['branch_ids'][j,e])
        with np.load(f/'measured_targets.npz') as z:
            q=z['query_qpos_native'];v=z['query_velocity_state9'];old=z['previous_velocity_state9'];times=z['query_s']
        for off in range(0,len(data),192):
            block=data.iloc[off:off+192];b=block.committed_route_bank_row.to_numpy(int);r=block.row.to_numpy(int)
            X,columns=features(world,q[r],v[r],old[r],times[r],block.gate_x,block.side,block.exit_side,
                bank['xy'][b],bank['heading'][b],bank['curvature'][b])
            assert np.isfinite(X).all()
            matrices.append(X)
        groups.append(data)
        sources.append(dict(map=name,physical_prefixes=len(prefix),verified_queries=len(both),excluded_before_effect=len(lost),
            executed_pairs=len(matched)//2,distinct_roots=matched.root.nunique(),virtual_gate_choices=len(data)//2,branch_labels=len(data),
            strict_pairs=int(prefix.loc[matched.row.unique(),'raw_substep_loads_equal'].sum()),
            paired_table=str(f/'suffix_index.csv'),state_file=str(f/'measured_targets.npz'),physical_model=str(folder/'terrain.mjb'),
            label_source=str(P/'export/cross_fixed_exit_gates'/f'{name}_crossings.csv.gz')))
    meta=pd.concat(groups,ignore_index=True);X=np.concatenate(matrices)
    np.savez_compressed(HERE/'train_features.npz',X=X,feature_names=np.array(columns))
    meta.to_csv(HERE/'rows.csv.gz',index=False);pd.DataFrame(sources).to_csv(HERE/'sources.csv',index=False)
    pd.DataFrame(excluded).to_csv(HERE/'unexecuted.csv',index=False)
    save(HERE/'index.json',dict(maps=MAPS,branch_labels=len(meta),queries=len(meta)//8,physical_verified_queries=sum(a['verified_queries'] for a in sources),
        not_reached_physical_branch=sum(a['excluded_before_effect'] for a in sources),physical_sources=sources,feature_count=len(columns),
        feature_names=list(columns),excluded_as_features=['map','lane','root','row','force','action','arm ID','curve ID','shadow decision','future trajectory or contact','published direction/late data'],
        direction_is_supplied_candidate_action=True,matched_pair='Exactly matched measured query; both requested physical continuations applied before termination. Four goal re-scorings share each physical exit trajectory.'))
    print('Indexed',len(meta),'executed branch labels',len(columns),'features')


def weights(d):
    per_root=d.groupby(['map_id','root']).row.transform('size').to_numpy()
    w=1./per_root
    return w*(len(w)/w.sum())


def solve(x,y,w):
    mean=np.average(x,axis=0,weights=w);std=np.sqrt(np.average((x-mean)**2,axis=0,weights=w))
    # Constant columns get unit scale, matching StandardScaler.
    std[std<1e-12]=1.
    z=(x-mean)/std
    def loss(theta):
        logits=z@theta[:-1]+theta[-1];error=w*(expit(logits)-y)
        return (np.dot(w,np.logaddexp(0.,logits)-y*logits)+.5*np.dot(theta[:-1],theta[:-1]))/len(y),np.r_[z.T@error+theta[:-1],error.sum()]/len(y)
    t=time.perf_counter()
    opt=minimize(loss,np.zeros(z.shape[1]+1),jac=True,method='L-BFGS-B',options=dict(maxiter=200,ftol=1e-11,gtol=1e-5))
    return dict(center=mean,scale=std,coef=opt.x[:-1],intercept=opt.x[-1]),dict(iterations=opt.nit,converged=bool(opt.success),
        termination=str(opt.message),gradient_inf_norm=float(np.max(np.abs(opt.jac))),fit_seconds=time.perf_counter()-t)


def summarize(d):
    gkeys=['map_id','root','row','gate_x','side']
    a=d[d.exit_side==1].set_index(gkeys);b=d[d.exit_side==-1].set_index(gkeys).loc[a.index];both=a.copy()
    true_a=a.done.to_numpy(int);true_b=b.done.to_numpy(int)
    row_w=weights(d);pair_w=weights(a.reset_index())
    result=dict(roots=d.groupby(['map_id','root']).ngroups,landings=d.groupby(['map_id','row']).ngroups,
                virtual_choices=len(a),branch_labels=len(d),branch_success=int(d.done.sum()))
    for model,col in [('logistic','p_exit'),('frequency','p_baseline')]:
        score=d[col].to_numpy();choose=a[col].to_numpy()>=b[col].to_numpy()
        success=np.where(choose,true_a,true_b)
        both[model+'_success']=success
        both[model+'_choice']=np.where(choose,'left','right')
        result[model+'_brier_equal_root']=float(np.average((score-d.done)**2,weights=row_w))
        result[model+'_brier_raw']=float(np.mean((score-d.done)**2))
        result[model+'_completed']=int(success.sum());result[model+'_completion_equal_root']=float(np.average(success,weights=pair_w))
        result[model+'_ties_choose_left']=int((a[col].to_numpy()==b[col].to_numpy()).sum())
    oracle=np.maximum(true_a,true_b)
    result.update(oracle_completed=int(oracle.sum()),oracle_completion_equal_root=float(np.average(oracle,weights=pair_w)),
                  logistic_rescued=int(((both.logistic_success==1)&(both.frequency_success==0)).sum()),
                  logistic_lost=int(((both.logistic_success==0)&(both.frequency_success==1)).sum()))
    both['oracle']=oracle
    return result,both.reset_index()[gkeys+['logistic_choice','frequency_choice','logistic_success','frequency_success','oracle']]


def fit():
    meta=pd.read_csv(HERE/'rows.csv.gz')
    with np.load(HERE/'train_features.npz') as f:X=f['X'];columns=f['feature_names']
    y=meta.done.to_numpy(int);folds=[];details=[];pair_reports=[];estimates=[]
    for hold in MAPS+['all_train']:
        train=meta.map_id.ne(hold).to_numpy()
        t=meta[train].copy();w=weights(t)
        model,stats=solve(X[train],y[train],w)
        stats.update(held_out=hold,train_rows=len(t),train_roots=t.groupby(['map_id','root']).ngroups)
        details.append(stats)
        if hold=='all_train':
            np.savez_compressed(HERE/'train_model.npz',**model,feature_names=columns)
            continue
        h=meta[~train].copy();xh=X[~train]
        h['p_exit']=expit(((xh-model['center'])/model['scale'])@model['coef']+model['intercept'])
        t['weight']=w;t['weighted_success']=t.done*w
        keys=['section','side','exit_side'];g=t.groupby(keys)
        freq=(g.weighted_success.sum()/g.weight.sum()).rename('p_baseline').reset_index()
        h=h.merge(freq,on=keys,validate='many_to_one')
        assert not set(t.root)&set(h.root) and len(h)==sum(~train)
        folds.append(h);r,paired=summarize(h);pair_reports.append(paired);estimates.append(dict(map=hold,**r))
    held=pd.concat(folds,ignore_index=True);all_counts,choices=summarize(held)
    estimates.append(dict(map='all_held_train',**all_counts))
    strict=held[held.strict_substep_match]
    strict_counts,_=summarize(strict);estimates.append(dict(map='strict_substep_subset_same_predictions',**strict_counts))
    keep=['map_id','root','row','action_slot','hidden_force_N_grouping_only','gate_x','side','arm','done','p_exit','p_baseline','strict_substep_match']
    held[keep].to_csv(HERE/'held_predictions.csv.gz',index=False);choices.to_csv(HERE/'held_choices.csv.gz',index=False)
    pd.DataFrame(estimates).to_csv(HERE/'held_metrics.csv',index=False);pd.DataFrame(details).to_csv(HERE/'fits.csv',index=False)
    report=dict(heldout_maps=6,all_train_refit=1,model='Root-weighted standardized L2 logistic, C=1, unpenalized intercept, scipy L-BFGS 200 iterations maximum; fixed input features, no parameter search.',
        weighting='Equal total weight per represented training root, normalized to fold row count. Same root weights for scaling and baseline rates. Per-root Brier averages both exits/four gates across available matched landings. Raw counts separately pooled.',
        tie_policy='Exact probability ties choose left for both methods. Oracle chooses either actual measured route after seeing both labels.',
        interpretation='Conditional on reaching a verified, matched query and physically executing both fixed continuations. Four gate rescoring targets share each actual run. These are internal held-out TRAIN results on two exits.',
        all_held=all_counts,strict_identical_1ms_substep_contact_forces_subset=strict_counts)
    save(HERE/'result.json',report)
    print(pd.DataFrame(estimates)[['map','landings','virtual_choices','logistic_brier_equal_root','frequency_brier_equal_root','logistic_completed','frequency_completed','oracle_completed']].to_string(index=False))

if __name__=='__main__':
    args=argparse.ArgumentParser();args.add_argument('stage',choices=['index','fit']);a=args.parse_args()
    if a.stage=='index':index()
    else:fit()

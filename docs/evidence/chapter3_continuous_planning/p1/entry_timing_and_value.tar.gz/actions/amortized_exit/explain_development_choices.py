"""Compare each changed physical outcome to the old entry selected for the same task."""
from pathlib import Path
import pandas as pd

root = Path(__file__).resolve().parent
out = root / 'development_entry'
pair = pd.read_csv(out / 'paired_conditions.csv.gz')
pair = pair[(pair.method == 'mixture3_all16') & (pair.baseline == 'old_train_rule')].copy()
truth = pd.read_csv(out / 'physical_conditions.csv.gz').rename(columns={'force':'force_N'})
scores = pd.read_csv(out / 'time_zero_scores.csv.gz').query("method == 'mixture3'")
keys = ['map_id','root','gate_x','side']
item = keys + ['action_slot']
meta = pd.concat([pd.read_csv(root.parents[1]/'export/dev'/name/'suffix_index.csv',usecols=['lane','map_id','termination']) for name in pair.map_id.unique()])
truth = truth.merge(meta,on=['map_id','lane'],validate='many_to_one')
for name,slot in [('new','choice'),('old','base_choice')]:
    phy = truth[item+['force_N','relocked','post_executed','known','lower','termination','lane']]
    pred = scores[item+['p_relock','conditional_exit_probability','score']]
    data = phy.merge(pred,on=item,validate='many_to_one').rename(columns={'action_slot':slot})
    shared = keys + ['force_N',slot]
    data = data.rename(columns={c:name+'_'+c for c in data if c not in shared})
    pair = pair.merge(data,on=shared,validate='one_to_one')
pair.to_csv(out/'mixture_vs_old_cases.csv.gz',index=False)
for flag,prefix in [('exact_loss','new'),('exact_rescue','old')]:
    subset=pair[pair[flag]]
    print(flag,len(subset))
    print(subset.groupby([prefix+'_relocked',prefix+'_termination']).size().to_string())
print(pair.loc[(pair.root.isin([1325,1328])) & (pair.gate_x==12.7) & (pair.side==1),['root','choice','new_p_relock','new_conditional_exit_probability','new_score','base_choice','old_p_relock','old_conditional_exit_probability','old_score']].drop_duplicates().round(4).to_string(index=False))

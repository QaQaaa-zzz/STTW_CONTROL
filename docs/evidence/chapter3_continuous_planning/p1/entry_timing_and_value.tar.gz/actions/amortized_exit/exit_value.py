"""Conditional completion of a requested, explicit left or right exit, given a handback state."""
import json
from pathlib import Path

import numpy as np
from scipy.special import expit


class KnownMap:
    def __init__(self, folder):
        """Frozen decision-time map: physical wall boxes, registered goal and known height raster."""
        import mujoco
        folder=Path(folder)
        world=json.loads((folder/'world.json').read_text())
        model=mujoco.MjModel.from_binary_path(str(folder/'terrain.mjb'))
        boxes=[]
        for i in range(model.ngeom):
            if model.geom(i).name.startswith('planning_obstacle_'):
                x,y,z=model.geom_pos[i];a,b,c=model.geom_size[i]
                boxes.append([x-a,x+a,y-b,y+b])
                np.testing.assert_allclose([z-c,z+c],[world['terrain']['far_bank_height_m'],
                    world['terrain']['far_bank_height_m']+world['terrain']['obstacle_height_m']],atol=1e-9)
        self.walls=np.array(boxes)
        np.testing.assert_allclose(self.walls,world['terrain']['forbidden_rectangles'],atol=1e-9)
        self.goal_x=world['goal']['x_min_m'];self.platform_z=world['terrain']['far_bank_height_m']
        with np.load(folder/'terrain.npz') as grid:
            self.height=grid['height'];self.support=grid['support'];self.bounds=grid['bounds'];self.spacing=float(grid['spacing'])


def features(known,qpos,velocity9,previous9,query_s,gate_x,gate_side,exit_side,xy,heading,curvature):
    """One row per state/gate/explicit exit. Exit and gate side are +1 left, -1 right.

    query_s is seconds since departure. Both real handbacks and forecast particles pass the
    same native pose and two 9-channel body-velocity frames, 20 ms apart. References have
    shape (N, grid, 2) and (N, grid), increasing in world X on the supported courses.
    """
    q=np.asarray(qpos);v=np.asarray(velocity9);prev=np.asarray(previous9);n=len(q);q_x,q_y,q_z=q[:,:3].T
    time,gx,side,turn=[np.broadcast_to(x,(n,)) for x in (query_s,gate_x,gate_side,exit_side)]
    walls=known.walls
    grid=np.column_stack([q_x,q_x+.5,q_x+1,q_x+1.5,gx,np.full(n,known.goal_x),
                          *[np.full(n,x) for lo,hi,_,_ in walls for x in (lo,(lo+hi)/2,hi)]])
    # Interpolate read-only candidate references; no realized trajectory enters this module.
    idx=np.stack([np.searchsorted(points[:,0],at,side='right') for points,at in zip(xy,grid)])
    idx=np.clip(idx,1,xy.shape[1]-1);rows=np.arange(n)[:,None]
    x_low=xy[rows,idx-1,0];fraction=np.clip((grid-x_low)/(xy[rows,idx,0]-x_low),0.,1.)
    def sample(field):
        lo=field[rows,idx-1]
        return lo+fraction*(field[rows,idx]-lo)
    y=sample(xy[:,:,1]);h=sample(heading);k=sample(curvature)
    w,xx,yy,zz=q[:,3:7].T
    yaw=np.arctan2(2*(w*zz+xx*yy),1-2*(yy*yy+zz*zz))
    roll=np.arctan2(2*(w*xx+yy*zz),1-2*(xx*xx+yy*yy));pitch=np.arcsin(np.clip(2*(w*yy-zz*xx),-1,1))
    angle=np.arctan2(np.sin(h[:,0]-yaw),np.cos(h[:,0]-yaw))
    # Signed side of the virtual gate and directional compatibility with the handback.
    values={'remaining_s':10.-time,'gate_ahead_m':gx-q_x,'goal_ahead_m':known.goal_x-q_x,
            'state_y_m':q_y,'z_above_platform_m':q_z-known.platform_z,'roll_rad':roll,
            'pitch_rad':pitch,'yaw_sin':np.sin(yaw),'yaw_cos':np.cos(yaw),
            'steer_rad':q[:,8],'hip_rad':q[:,10],'knee_rad':q[:,11],
            'exit_side':turn,'gate_side':side,'gate_exit_sign':turn*side,
            'signed_state_gate_y_m':q_y*side,'signed_sin_yaw_exit':turn*np.sin(yaw),
            'signed_roll_exit_rad':turn*roll,'signed_steer_exit_rad':turn*q[:,8],
            'signed_yaw_rate_exit':turn*v[:,5],'roll_magnitude_rad':abs(roll),
            'path_y_error_m':q_y-y[:,0],'heading_error_rad':angle,'abs_heading_error_rad':abs(angle),
            'gate_reference_margin_m':side*y[:,4]-.06,'gate_current_heading_margin_m':
                side*(q_y+np.sin(yaw)*(gx-q_x))-.06}
    names=('vx','vy','vz','wx','wy','wz','steer_rate','front_wheel_rate','rear_wheel_rate')
    for i,name in enumerate(names):
        values['body_'+name]=v[:,i];values['change_20ms_'+name]=v[:,i]-prev[:,i]
    for j,location in enumerate(('now','ahead05','ahead10','ahead15','gate','goal')):
        values[location+'_target_dy_m']=y[:,j]-q_y
        values[location+'_heading_rad']=h[:,j];values[location+'_curvature_per_m']=k[:,j]
    # Closest reference-to-wall lateral clearance across both faces and the center.
    # The sign is negative inside the wall's lateral span, positive outside.
    wy=y[:,6:].reshape(n,len(walls),3)
    clearance=np.maximum(walls[None,:,2,None]-wy,wy-walls[None,:,3,None]).min(2)
    wall_idx=clearance.argmin(1);nearest=walls[wall_idx];i=np.arange(n)
    values.update(wall_min_path_clearance_m=clearance[i,wall_idx],
                  wall_ahead_m=nearest[:,0]-q_x,wall_gate_dx_m=nearest[:,0]-gx,
                  wall_y_from_state_m=(nearest[:,2]+nearest[:,3])/2-q_y,
                  wall_y_from_gate_side_m=(nearest[:,2]+nearest[:,3])/2*side,
                  wall_clearance_against_query_heading_m=np.maximum(nearest[:,2]-(q_y+np.sin(yaw)*(nearest[:,0]-q_x)),
                      q_y+np.sin(yaw)*(nearest[:,0]-q_x)-nearest[:,3]))
    # Sample absolute DEM and terrain support on the specified exit at five known locations.
    xi=np.clip(np.rint((grid[:,1:6]-known.bounds[0])/known.spacing).astype(int),0,known.height.shape[1]-1)
    yi=np.clip(np.rint((y[:,1:6]-known.bounds[2])/known.spacing).astype(int),0,known.height.shape[0]-1)
    elevation=known.height[yi,xi]-known.platform_z
    values.update(path_max_height_m=elevation.max(1),path_min_height_m=elevation.min(1),
                  path_height_at_gate_m=elevation[:,3],path_min_support=known.support[yi,xi].min(1))
    return np.column_stack(list(values.values())),tuple(values)


class ExitValue:
    def __init__(self,checkpoint):
        with np.load(checkpoint) as f:
            self.center=f['center'];self.scale=f['scale'];self.coef=f['coef'];self.intercept=f['intercept']
    def score(self,known,qpos,velocity9,previous9,query_s,gate_x,gate_side,exit_side,xy,heading,curvature):
        x,_=features(known,qpos,velocity9,previous9,query_s,gate_x,gate_side,exit_side,xy,heading,curvature)
        return expit(((x-self.center)/self.scale)@self.coef+self.intercept)

"""End-to-end fixed-alpha CEM timing with the two measured-direction value model, on one TRAIN query."""
import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name]='1'
import csv
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import torch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from check_continuous_departure_plan import HERE as SMOKE,P,W,read_request,preview_commitment,write,table
from continuous_departure_plan import plan
from continuous_departures import departure_options,departure_options_lr_batch
from exit_value import ExitValue,KnownMap
from jump_outcome import JumpOutcome
from sttw_control.torch_path_reference import TorchPathReference


def main():
    start=time.perf_counter()
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    folder,cfg,first,side,gate,world,raster,published,q,v=read_request()
    cp_file=SMOKE/'legacy_smoke_mixture3.pt';cp=torch.load(cp_file,map_location='cpu',weights_only=True)
    model=JumpOutcome(cp['width_in'],'mixture3');model.load_state_dict(cp['state']);model.eval()
    known=KnownMap(P/'maps/train_00');weights=HERE/'train_model.npz';value=ExitValue(weights)
    hcfg=json.loads((W/cfg['ground_handoff']['bundle']/'config.json').read_text());hcfg['follower']['lookahead_scale']=1.
    route=TorchPathReference(published,hcfg)
    body_window=json.loads((SMOKE/'three_alpha_batched/timing_window.json').read_text())['archived_arrival_s']
    requests=[];candidates=[];particles=[]
    setup_s=time.perf_counter()-start
    def soft_score(curves,qpos,vel,prev,query_s,gx,gside):
        start=time.perf_counter()
        joins,refs=departure_options_lr_batch(curves,qpos[:,:2],goal_start_x_m=known.goal_x)
        before_score=time.perf_counter()
        args=[np.repeat(a,2,axis=0) for a in (qpos,vel,prev,query_s)]
        exit_args=[refs[k].reshape((-1,*refs[k].shape[2:])) for k in ('xy','heading','curvature')]
        probs=value.score(known,*args,gx,gside,np.tile([1,-1],len(qpos)),*exit_args).reshape(-1,2)
        finish=time.perf_counter()
        slices.append(dict(n=len(qpos),explicit_geometry_s=before_score-start,features_and_value_s=finish-before_score))
        return joins,probs
    for trial in range(6):
        slices=[]
        ready=time.perf_counter()
        near,request,look,commit,slack=preview_commitment(route,published,q,v)
        output,alpha,log,all_curves=plan(world,raster,None,model,q,v,published,float(first['approach_alpha']),commit,gate,side,
                                          fixed_alpha=True,soft_exit_scores=soft_score,publish_window_s=slack,request_started=ready)
        elapsed=time.perf_counter()-ready
        proposed=log['selected'];pub=log['publishable_candidate']
        if elapsed>slack:output=published;alpha=float(first['approach_alpha']);pub=0
        plans=log['candidate_log'];samples=log['particle_log']
        assert all(a['alpha']==0. for a in plans) and len(plans)==9 and len(samples)==144 and sum(r['n'] for r in slices)==144
        assert sum(a['n'] for a in slices)==144 and len(slices)==3 and [a['n'] for a in slices]==[16,64,64]
        if not pub:assert output is published and alpha==0.
        for i,item in enumerate(plans):
            batch=samples[16*i:16*(i+1)]
            assert all(s['candidate']==i and s['allow_left'] is None and s['selected_exit'] is None for s in batch)
            calc=item['p_relock']*np.mean([max(s['p_left'],s['p_right']) for s in batch])
            np.testing.assert_allclose(calc,item['score'],rtol=0,atol=1e-12)
        requests.append(dict(request=trial+1,cache='cold_first_model_loaded' if trial==0 else 'warm',elapsed_s=elapsed,
            inner_decision_s=log['total_s'],approach_geometry_s=log['geometry_s'],jump_and_input_s=log['jump_and_input_s'],exit_total_s=log['ground_s'],
            explicit_lr_geometry_s=sum(r['explicit_geometry_s'] for r in slices),map_features_and_soft_value_s=sum(r['features_and_value_s'] for r in slices),
            request_specific_slack_s=slack,archived_body_window_s=body_window,meets_request_slack=elapsed<=slack,meets_archived_body_window=elapsed<=body_window,
            candidate_count=len(plans),conditional_particles=len(samples),conditional_branch_probabilities=2*len(samples),incumbent_score=plans[0]['score'],
            proposal=proposed,proposal_alpha=log['alpha'],proposal_score=plans[proposed]['score'],eligible_reference=pub,eligible_alpha=alpha,
            publish_decision='deadline_missed_keep_published' if proposed and elapsed>slack else log['publish_decision']))
        candidates.extend(dict(request=trial+1,**x) for x in plans);particles.extend(dict(request=trial+1,**x) for x in samples)
    # Non-timed full-batch audit. The original ground scorer generates a left/straight/right bank.
    # Each of our 288 arrays (in each geometry channel) must match the old left or right, including the join.
    pos=np.array([(z['predicted_x_m'],z['predicted_y_m']) for z in samples])
    refs=[all_curves[z['candidate']] for z in samples]
    joins,batch=departure_options_lr_batch(refs,pos,goal_start_x_m=known.goal_x)
    for i,(curve,x) in enumerate(zip(refs,pos)):
        j,original=departure_options(curve,x,goal_start_x_m=known.goal_x)
        assert j==joins[i]==samples[i]['join_index']
        for field in ('xy','heading','curvature'):np.testing.assert_array_equal(original[field][[0,2]],batch[field][i])
    target=HERE/'timing';target.mkdir(exist_ok=True)
    table(target/'requests.csv',requests);table(target/'candidates.csv',candidates);table(target/'particles.csv',particles)
    warm=np.array([r['elapsed_s'] for r in requests[1:]])
    receipt=dict(stage='complete',role='CPU engineering timing, single observed TRAIN start 1250, train_00 near-left gate. Known map and both models already resident.',
        section_x=gate,gate_side=side,alpha=float(first['approach_alpha']),alpha_mode='held at existing tick-zero value',seed=923114,
        jump_model=str(cp_file),jump_sha256=hashlib.sha256(cp_file.read_bytes()).hexdigest(),exit_model=str(weights),exit_sha256=hashlib.sha256(weights.read_bytes()).hexdigest(),
        exit_score='p_relock times conditional particle mean of maximum(left completion probability, right completion probability). One shared proposal across hidden pushes.',
        admission='No hard admission test or straight-exit prediction. CSV probabilities are model outputs. Branch admission and actual chosen-exit fields are empty.',
        online='Clock starts with measured initial CPU qpos/qvel and existing reference ready, before H75 projection and preview. Includes jump prediction, full explicit geometry synthesis, map/route feature extraction, fitted scores, CEM and eligible-reference decision. No timed output I/O.',
        threads=dict(torch=torch.get_num_threads(),torch_interop=torch.get_num_interop_threads(),blas=1),
        setup_s=setup_s,requests=6,candidates_per_request=9,particles_per_candidate=16,conditional_exit_probabilities_per_request=288,
        cold_s=requests[0]['elapsed_s'],warm_s=warm.tolist(),warm_median_s=float(np.median(warm)),warm_range_s=[float(warm.min()),float(warm.max())],
        independent_geometry_audit='Same last full CEM batch: 144/144 joins, 288/288 left or right curves (all XY, heading and curvature samples) exact versus original per-particle departure_options.',
        timely_vs_request_slack=sum(r['meets_request_slack'] for r in requests),timely_vs_archived_body_window=sum(r['meets_archived_body_window'] for r in requests),
        plans_eligible_for_new_publication=sum(r['eligible_reference']!=0 for r in requests),physical_rollouts=0,new_fit_updates=0,actual_vehicle_publications=0,
        scope='Original physical-TRAIN fitted exit value and legacy jump smoke. No held-out planning claim. Timings use one machine, one map, one root and six requests.')
    write(target/'receipt.json',receipt);print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()

"""Single-vehicle continuous entry / event-triggered exit timing on a known training map."""
import argparse
import json
import time
from pathlib import Path
import numpy as np
import torch
from check_continuous_departure_plan import P,W,read_request
from continuous_departure_plan import plan
from frozen_exit_value import FrozenExits
from jump_outcome import JumpOutcome
from sttw_control.chapter3_continuous_exit import ContinuousExitPlanner,committed_progress
from sttw_control.torch_path_reference import TorchPathReference
from sttw_control.playground_prediction import euler

def run(device,check):
    torch.set_num_threads(1)
    folder,cfg,first,side,gate,world,raster,_,q,v=read_request()
    with np.load(cfg['paired_departures']['approach_file']) as z:
        published={'s':z['s'],**{k:z[k][:1] for k in ('xy','heading','curvature')}}
    follower=json.loads((W/cfg['ground_handoff']['bundle']/'config.json').read_text())
    follower['follower']['lookahead_scale']=1.
    route=TorchPathReference(published,follower,device=device)
    ground=FrozenExits(folder,device,load_route_bank=False)
    solver=ContinuousExitPlanner(ground.query,route,mode='smooth_event',candidates=64,iterations=2,
                  robots_per_chunk=1 if check else 8,horizon_steps=255,fused=device=='cuda')
    output=P/'actions/continuous_examples'/'continuous_entry_event_exit'
    output.mkdir(parents=True,exist_ok=True)
    for mode in ('mean','mixture3'):
        file=P/'model/formal_fit/seed_61123'/(mode+'.pt')
        cp=torch.load(file,map_location=device,weights_only=True)
        jump=JumpOutcome(cp['input_width'],mode,width=cp['width']).to(device)
        jump.load_state_dict(cp['state']);jump.eval()
        for run_id in range(1 if check else 6):
            start=time.perf_counter()
            pose=torch.as_tensor(q,device=device,dtype=torch.float32)[None]
            yaw=euler(pose[:,3:7])[:,2]
            speed=v[0]*yaw.cos()+v[1]*yaw.sin()
            near=(route.xy[0]-pose[:,:2]).square().sum(1).argmin()
            progress=route.project(pose[:,:2],route.s[near].view(1),torch.zeros_like(speed))['progress']
            req=torch.full_like(speed,2.)
            preview=route.pursuit(progress,torch.cat([pose[:,:2],yaw[:,None]],1),speed,req)['lookahead']
            commit=float(committed_progress(progress,preview,req,.1)[0])
            _,alpha,log,curves=plan(world,raster,ground,jump,q,v,published,float(first['approach_alpha']),commit,gate,side,
                population=2 if check else 8,iterations=1 if check else 2,conditional_particles=2 if check else 8,
                fixed_alpha=True,event_exit=solver,follower_config=follower,publish_window_s=.1,request_started=start)
            log.update(model=file.name,seed=61123,device=device,root=1250,temperature='first_for_model' if run_id==0 else 'warm',
                stage='CPU full-horizon wiring only' if check else 'one-vehicle GPU latency only',rollouts=0,
                reference='old0, alpha held from the first control step',exit_candidate_count=64,exit_iterations=2,exit_horizon_steps=255,
                commitments='Projected forecast pose approximates controller progress; before-query crossings remain uncredited. Real handback uses measured progress.',
                gate_and_goal='Gate crossing ahead of predicted query, articulated clearance and stable finish required for solver admission.')
            name=('cpu' if check else 'gpu')+'_'+mode+'_'+str(run_id)
            (output/(name+'.json')).write_text(json.dumps(log,indent=2)+'\n')
            print(name,log['candidate_count'],log['particles_evaluated'],log['selected'],log['total_s'],flush=True)

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--cpu-check',action='store_true');args=a.parse_args()
    run('cpu' if args.cpu_check else 'cuda',args.cpu_check)

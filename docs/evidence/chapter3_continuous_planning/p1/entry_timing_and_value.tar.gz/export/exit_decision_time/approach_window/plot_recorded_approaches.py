"""Single-panel set from three recorded pre-takeoff tracks and the archived TRAIN clocks."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

OUT=Path(__file__).resolve().parent
P=OUT.parents[2]
FOLDER=P/'batches/train_00/physical'
COLORS=('#184e75','#b24924','#20816f')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.3,'axes.titlesize':11,'axes.labelsize':9.2,
                     'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#60717a',
                     'xtick.color':'#45555d','ytick.color':'#45555d','savefig.facecolor':'white'})

cfg=json.loads((FOLDER/'resolved_config.json').read_text())
idx=pd.read_csv(P/'export/train/train_00/prefix_index.csv')
case=idx.query("root==1250 and arm=='left' and alpha==0 and hidden_force_N_grouping_only==0 and action_slot in [0,1,2]").sort_values('action_slot')
assert list(case.action_slot)==[0,1,2] and list(case.geometry)==[0,1,2]
cfg_lanes=cfg['evaluation_lanes'];variants=cfg['ground_handoff']['handoff_variants']
lanes=case.lane.to_numpy();cut=float(case.actual_rb_entry_s.min())
commands=FOLDER/'p1_applied_controls.npz'
with np.load(commands) as z:
    dt=float(z['dt_s']);steps=int(round(cut/dt));applied=z['targets'][:steps,lanes];assert z['valid'][:steps,lanes].all()
pt=np.arange(steps+1)*dt
native_publish=cfg['platform_online']['latency_ticks']['start']*dt
track=[];state=[];pub=[];meta=[]
with np.load(cfg['paired_departures']['approach_file']) as z: bank=z['xy']
with np.load(cfg['ground_handoff']['reference_path']) as z:neutral=z['xy'][0]
for item in case.itertuples():
    v=variants[cfg_lanes[item.lane][2]]
    assert (v['root_variant'],v['action_slot'],v['approach_alpha'],v['force_y_N'],v['arm'])==(1250,item.action_slot,0.,0.,'left')
    with np.load(item.trajectory) as z:
        trace=z['trace'][:steps+1];q=z['qpos'][:steps+1];vel=z['qvel'][:steps+1]
        columns=z['columns'].tolist();ts=trace[:,columns.index('time')]
        assert np.allclose(ts,pt,atol=2e-7,rtol=0)
        track.append(q[:,:2]);state.append(np.column_stack((q,vel)))
        # The runner publishes neutral at reset, then a fixed geometry on control tick 3.
        # The saved final publication may include a landing suffix. Verify all displayed pre-jump samples against the configured approach.
        original=bank[item.geometry]
        xa,xb=q[0,0],q[-1,0]
        assert np.all(np.diff(original[:,0])>0)
        ext=(original[:,0]>=xa-.04)&(original[:,0]<=xb+.04)
        assert np.allclose(z['published_reference_xy'][ext],original[ext],atol=1e-6,rtol=0)
        xchange=float(q[round(native_publish/dt),0])
        xshow=np.r_[xa,original[(original[:,0]>xa)&(original[:,0]<xb),0],xb]
        near=xshow<=xchange
        yshow=np.where(near,np.interp(xshow,neutral[:,0],neutral[:,1]),np.interp(xshow,original[:,0],original[:,1]))
        pub.append(np.column_stack((xshow,yshow)))
    meta.append(dict(map='train_00',root=1250,physical_arm='left',hidden_force_n=0,slot=item.action_slot,geometry=item.geometry,
            lane=item.lane,alpha=0,gate_side=v['side'],gate_x_m=v['section_x'],trajectory=item.trajectory,shared_actual_four_targets=str(commands),
            target_fields='front steering position (rad); rear wheel speed (rad/s); hip position (rad); knee position (rad)',
            published_approach=cfg['paired_departures']['approach_file'],previous_neutral=cfg['ground_handoff']['reference_path'],
            native_first_publication_s=native_publish,native_rb_entry_s=item.actual_rb_entry_s,physical_cutoff_s=cut,terminal_x_at_cut_m=track[-1][-1,0],terminal_y_at_cut_m=track[-1][-1,1]))
commands_delta=applied-applied[:,:1]
pair_control=[];pair_state=[]
for i in [1,2]:
    tick=int(np.flatnonzero((commands_delta[:,i]!=0).any(1))[0])
    st=int(np.flatnonzero((state[i]!=state[0]).any(1))[0])
    pair_control.append(tick);pair_state.append(st)
    meta[i].update(first_four_channel_diff_vs_slot0_s=tick*dt,first_native_qpos_qvel_diff_vs_slot0_s=st*dt,
        steering_target_delta_at_first_rad=float(commands_delta[tick,i,0]),
        rear_target_delta_at_first_rad_s=float(commands_delta[tick,i,1]))
assert pair_control==[4,304] and pair_state==[5,305] and not commands_delta[:,:,2:].any()
root_windows=pd.read_csv(OUT/'by_root.csv')
timing_root=P/'actions/continuous_examples/departure_plan'
latency={name:pd.read_csv(timing_root/f'three_alpha_timing_{name}'/'requests.csv') for name in ['cpu','cuda']}
cpu,gpu=latency.values()
assert len(root_windows)==72 and all(len(v)==6 for v in latency.values())
for row in meta:
    row.update(panel_d_windows=str(OUT/'by_root.csv'),panel_d_preview_column='timed_first_preview_beyond_s',
               panel_d_definition='Observed physical H75 20 ms pursuit refresh, first look beyond last grid sample retained by the timed planner at departure.',
               panel_d_cpu_requests=str(timing_root/'three_alpha_timing_cpu/requests.csv'),
               panel_d_gpu_requests=str(timing_root/'three_alpha_timing_cuda/requests.csv'))
pd.DataFrame(meta).to_csv(OUT/'recorded_approaches_sources.csv',index=False)
old=pd.read_csv(OUT/'cpu_requests_against_72_windows.csv')
by_device=[]
for name,table in latency.items():
    rows=[]
    for r in table.itertuples():
        for col in old.clock.unique():
            windows=root_windows[col].dropna()
            rows.append(dict(request=r.request,cache=r.cache,elapsed_s=r.elapsed_s,clock=col,roots_total=len(root_windows),measured=len(windows),
                             elapsed_strictly_before=int(sum(r.elapsed_s<windows)),elapsed_at_or_after=int(sum(r.elapsed_s>=windows))))
    comparison=pd.DataFrame(rows)
    if name=='cpu':pd.testing.assert_frame_equal(comparison,old,check_exact=False)
    comparison.insert(0,'device',name)
    by_device.append(comparison)
pd.concat(by_device,ignore_index=True).to_csv(OUT/'device_requests_against_72_windows.csv',index=False)

fig=plt.figure(figsize=(11.4,7.9))
fig.subplots_adjust(left=.105,right=.968,bottom=.103,top=.846)
gs=fig.add_gridspec(3,2,height_ratios=(.9,1.,1.),width_ratios=(1.08,1),wspace=.32,hspace=.76)
xy=fig.add_subplot(gs[0,:]);front=fig.add_subplot(gs[1,0]);rear=fig.add_subplot(gs[2,0],sharex=front)
body=fig.add_subplot(gs[1,1]);clock=fig.add_subplot(gs[2,1])
fig.text(.105,.961,'When do different approach routes first change the commands?',fontsize=17.3,weight='bold',color='#183342')
fig.text(.105,.923,'Three recorded approaches from TRAIN start 1250   •   same initial vehicle state, α = 0, no push, fixed left exit',fontsize=10.7,color='#47616a')
xy.set_title('A   Measured vehicle position and published approach',loc='left',fontweight='bold',pad=7)
for i in range(3):
    x=track[i];r=pub[i]
    xy.plot(*r.T,color=COLORS[i],ls=(0,(4,2)),lw=1.3,alpha=.93)
    xy.plot(*x.T,color=COLORS[i],lw=1.9)
    xy.scatter(*x[-1],c=COLORS[i],marker='s',s=28,zorder=6,edgecolors='white',linewidths=.6)
xy.set_aspect('equal',adjustable='box');xy.set(xlim=(1.42,9.41),ylim=(-.38,.53),xlabel='World x (m)',ylabel='World y (m)',yticks=[-.25,0,.25])
# Each compared pair still shares the recorded state at its first different command.
for i,k in enumerate(pair_control):
    x,y=track[0][k]
    xy.plot(x,y,'o',color='white',markeredgecolor='#25323a',ms=5,zorder=8)
    xy.annotate(f'0 / {i+1}    x = {x:.2f} m',(x,y),xytext=(x+.25,.32+.055*i),fontsize=8,
                arrowprops={'arrowstyle':'-','color':'#55656a','lw':.7},ha='left',va='bottom')
xy.text(9.35,-.36,'■  Common cutoff: 3.600 s',fontsize=8,color='#37474c',ha='right',va='bottom')
handles=[Line2D([],[],color=c,lw=2.3,label=f'Slot {i}') for i,c in enumerate(COLORS)]
handles.extend([Line2D([],[],color='#46555e',lw=1.8,label='Measured XY'),Line2D([],[],color='#46555e',ls='--',lw=1.3,label='Published curve')])
fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.104,.906),fontsize=9,ncol=5,frameon=False,handlelength=2.1,columnspacing=1.65,borderaxespad=0)
front.set_title('B   Applied targets relative to slot 0',loc='left',fontweight='bold',pad=8)
body.set_title('C   Measured lateral position relative to slot 0',loc='left',fontweight='bold',pad=8)
for ax in (front,rear,body):
    ax.axhline(0,color=COLORS[0],lw=.85)
    for k in pair_control:ax.axvline(k*dt,color='#57666e',lw=.83,ls=(0,(2,2)),zorder=0)
    ax.set_xlim(-.08,3.65);ax.yaxis.set_major_locator(MaxNLocator(3, min_n_ticks=3));ax.grid(axis='y',alpha=.12)
for i in (1,2):
    for ax,j in [(front,0),(rear,1)]:ax.stairs(commands_delta[:,i,j],pt,baseline=None,color=COLORS[i],lw=1.25)
    body.plot(pt,track[i][:,1]-track[0][:,1],color=COLORS[i],lw=1.6)
front.set_ylabel('Steering position\ntarget difference (rad)');rear.set_ylabel('Rear-wheel speed\ntarget difference (rad/s)')
body.set_ylabel('World y difference (m)')
for ax in (rear,body):ax.set_xlabel('Time since departure (s)')
front.tick_params(labelbottom=False)
body.text(.03,.97,'First four-target differences\n0 / 1   0.020 s       0 / 2   1.520 s',transform=body.transAxes,va='top',fontsize=8.4,color='#293f4a')
rear.text(0.,1.035,'Hip and knee target differences are zero throughout.',ha='left',va='bottom',transform=rear.transAxes,fontsize=8.1,color='#3d5260',bbox={'facecolor':'white','edgecolor':'none','alpha':.84,'pad':1})
clock.set_title('D   Travel windows and measured computation',loc='left',fontweight='bold',pad=8)
clock.set(xlim=(-.08,1.94),ylim=(-.50,3.57),yticks=[0,1,2,3],yticklabels=['CPU (6)','GPU, eager (6)','Body arrival (72)','H75 preview (72)'],xlabel='Time since request (s)')
clock.tick_params(axis='y',length=0,labelsize=8.4);clock.spines['left'].set_visible(False);clock.grid(axis='x',alpha=.13)
bodyvals=np.sort(root_windows.timed_body_arrival_s.to_numpy())
clock.scatter(bodyvals,2+.105*np.sin(np.arange(len(bodyvals))*2.4),c='#2f6671',s=9,alpha=.74,linewidths=0,zorder=3)
for y0,runs,color in [(0,cpu,'#8b492c'),(1,gpu,'#865589')]:
    # Diamond = first request after model load. All five warm requests remain visible through a small deterministic y offset.
    for j,x in enumerate(runs.elapsed_s):
        clock.scatter(x,y0+[0,-.14,.08,0,.14,-.07][j],c=color,edgecolor='white',lw=.45,s=28 if j==0 else 21,
                      marker='D' if j==0 else 'o',alpha=.93,zorder=3)
xpv,counts=np.unique(root_windows.timed_first_preview_beyond_s.round(3),return_counts=True)
for x,k in zip(xpv,counts):
    clock.scatter(x,3-(.10 if x<.05 else -.10),c='#2f6671',s=k*.95,alpha=.9)
clock.text(.14,3,'40 or 60 ms · timed planner prefix',fontsize=8.15,color='#405861',va='center')
clock.text(.30,2.19,'0.659–0.787 s',fontsize=8.1,color='#405861')
clock.text(1.43,1.0,f'{gpu.elapsed_s.min():.3f}–{gpu.elapsed_s.max():.3f} s',fontsize=8,color='#794c80',va='center')
clock.text(.99,-.02,f'{cpu.elapsed_s.min():.3f}–{cpu.elapsed_s.max():.3f} s',fontsize=8,color='#73462e',va='center')
fig.text(.105,.032,'Preset route published at 15 ms. Four targets sampled every 5 ms. All tracks end at the first jump-skill entry. Each device: 1 cold ◆ and 5 warm ●.',fontsize=8.7,color='#334c58')
fig.savefig(OUT/'recorded_approaches.png',dpi=265,metadata={'Title':'Recorded approach trajectories and action timing from a matched initial state',
   'Description':'Three matched pre-jump robot trajectories and published routes, actual command differences, measured lateral positions, and archive timing windows. Full raw sources are indexed in recorded_approaches_sources.csv.'})
plt.close(fig)

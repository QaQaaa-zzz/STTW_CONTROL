"""Fixed-root measured approach windows on six TRAIN maps; no physics or fitting."""
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import torch

OUT=Path(__file__).resolve().parent
P=OUT.parents[2]
W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path[:0]=[str(P/'actions'),str(W/'learning/src')]
from check_continuous_departure_plan import preview_commitment
from sttw_control.chapter3_continuous_exit import committed_progress
from sttw_control.torch_path_reference import TorchPathReference


def crossing(t,x,target):
    right=np.flatnonzero(x>=target)
    if not len(right):return (np.nan,)*3
    j=int(right[0])
    if j==0:return float(t[0]),float(t[0]),float(t[0])
    return float(np.interp(target,x[j-1:j+1],t[j-1:j+1])),float(t[j-1]),float(t[j])


def first(mask,t):
    return float(t[np.flatnonzero(mask)[0]]) if np.any(mask) else np.nan


def measure():
    torch.set_num_threads(1)
    rows=[]
    timing=P/'actions/continuous_examples/departure_plan/three_alpha_timing_cpu/requests.csv'
    with np.load(P/'actions/approaches.npz') as z:
        approach={k:z[k] if k=='s' else z[k][:1] for k in ('s','xy','heading','curvature')}
    for map_slot in range(6):
        name=f'train_{map_slot:02}';physical=P/'batches'/name/'physical'
        config=json.loads((physical/'resolved_config.json').read_text());h=config['ground_handoff']
        c=json.loads((W/h['bundle']/'config.json').read_text());c['follower']['lookahead_scale']=1.
        assert c['timing']['path_follower_dt_s']==.02 and c['timing']['lower_dt_s']==.005
        with np.load(h['reference_path']) as z:
            neutral={k:z[k] if k=='s' else z[k][:1] for k in ('s','xy','heading','curvature')}
        plan_route=TorchPathReference(neutral,c)
        approach_route=TorchPathReference(approach,c)
        latency=config['platform_online']['latency_ticks']['start']
        ids=pd.read_csv(P/'export/train'/name/'prefix_index.csv').query("action_slot==0 and geometry==0 and alpha==0 and hidden_force_N_grouping_only==0 and arm=='left'").sort_values('root_slot')
        assert len(ids)==12 and ids.root.nunique()==12 and set(ids.root_slot)==set(range(12)) and latency==3
        for item in ids.itertuples():
            variant=h['handoff_variants'][config['evaluation_lanes'][item.lane][2]]
            assert (variant['bank_row'],variant['action_slot'],variant['geometry'],variant['arm'],variant['planned_departure'],variant['force_y_N'],variant['approach_alpha'])==(item.root,0,0,'left',0,0,0.)
            with np.load(item.trajectory) as z:
                q=z['qpos'];v=z['qvel'];trace=z['trace'];columns=z['columns'].tolist()
                t=trace[:,columns.index('time')];yaw=trace[:,columns.index('yaw')]
                assert np.allclose(t,np.arange(len(t))*.005,rtol=0,atol=1e-6)
                recorded_ref=z['published_reference_xy']
            near,request,initial_plan_look,plan_commit,slack=preview_commitment(plan_route,neutral,q[0],v[0])
            assert float(request)==variant['approach_speed_m_s']
            # H75 uses the horizontal heading projection of world velocity, from observe(data).
            pose=torch.from_numpy(np.column_stack((q[:,0],q[:,1],yaw)))
            ys=torch.from_numpy(yaw);vel=torch.from_numpy(v[:,:2])
            speed=vel[:,0]*ys.cos()+vel[:,1]*ys.sin()
            init=plan_route.project(pose[:1,:2],plan_route.s[near:near+1],torch.zeros(1))['progress']
            look=plan_route.pursuit(init,pose[:1],speed[:1],request)['lookahead']
            native_commit=float(committed_progress(init,look,request,.015));native_look=float(look)
            windows={'timed':plan_commit,'native':native_commit}
            stats={};physical_ends={}
            for label,s0 in windows.items():
                end=int(neutral['s'].searchsorted(s0));xend=float(neutral['xy'][0,end,0])
                # Every routed baseline is identical on, and one sample ahead of, the timing target.
                assert all(np.array_equal(approach[k][0,:end+2],neutral[k][0,:end+2]) for k in ('xy','heading','curvature'))
                assert np.allclose(recorded_ref[:end+2],neutral['xy'][0,:end+2],rtol=0,atol=1e-6)
                arrive,lo,hi=crossing(t,q[:,0],xend)
                stats.update({label+'_commit_arc_m':s0,label+'_end_arc_m':float(neutral['s'][end]),
                              label+'_end_x_m':xend,label+'_body_travel_m':xend-float(q[0,0]),
                              label+'_body_arrival_s':arrive,label+'_body_frame_before_s':lo,label+'_body_frame_after_s':hi})
                physical_ends[label]=float(neutral['s'][end])
            # Reset at t=0. After every recorded 5 ms post-state the active route is projected.
            # Original approach replaces neutral at tick 3, so its first post-step projection is at tick 4.
            progress=init;deadline=max(stats['timed_body_frame_after_s'],stats['native_body_frame_after_s'])
            n=min(len(t),int(np.ceil(deadline/.005))+3) if np.isfinite(deadline) else len(t)
            refreshed=[];previews=[];guards=[];reads=[]
            for k in range(n):
                if not k:route=plan_route
                else:
                    route=plan_route if k<=latency else approach_route
                    distance=torch.linalg.vector_norm(pose[k:k+1,:2]-pose[k-1:k,:2],dim=-1)
                    progress=route.project(pose[k:k+1,:2],progress,distance)['progress']
                if k%4==0:
                    cur_look=float(route.pursuit(progress,pose[k:k+1],speed[k:k+1],request)['lookahead'])
                    refreshed.append(float(t[k]));previews.append(float(progress)+cur_look)
                    guards.append(float(progress)+cur_look+float(request)*.02)
                    # before() calls observation() on the 50 Hz policy clock when the route is inspected.
                    reads.append(max(previews[-1],float(progress)+1.))
            refresh=np.asarray(refreshed);pv=np.asarray(previews);guard=np.asarray(guards)
            for label,s0 in windows.items():
                end=physical_ends[label]
                at=first(pv>end,refresh);bad=first(guard>s0,refresh)
                stats.update({label+'_first_preview_beyond_s':at,label+'_first_any_route_read_beyond_s':first(np.asarray(reads)>end,refresh),
                              label+'_first_guard_reject_at_boundary_s':bad,
                              label+'_last_prior_guard_valid_boundary_s':float(refresh[refresh<bad][-1]) if np.isfinite(bad) and np.any(refresh<bad) else np.nan})
            rows.append(dict(map=name,root=int(item.root),root_slot=int(item.root_slot),lane=int(item.lane),action_slot=0,
                geometry=0,alpha=0,physical_exit='left',force_n=0,assigned_gate_side=variant['side'],assigned_section_x_m=variant['section_x'],
                trajectory=str(item.trajectory),published_reference=str(h['reference_path']),original_approach=str(config['paired_departures']['approach_file']),
                start_x_m=float(q[0,0]),start_y_m=float(q[0,1]),timed_initial_progress_m=float(plan_route.s[near]),native_initial_progress_m=float(init),
                timed_initial_look_m=float(initial_plan_look),native_initial_look_m=native_look,measured_plan_slack_s=slack,
                physical_ticks_observed=len(t),prefix_identity_checked=True,**stats))
    data=pd.DataFrame(rows)
    assert len(data)==data.root.nunique()==72
    data.to_csv(OUT/'by_root.csv',index=False)
    summary=[]
    for scope,g in [('six_fixed_train_maps',data),*data.groupby('map')]:
        for col in ['timed_body_arrival_s','native_body_arrival_s','timed_first_preview_beyond_s','native_first_preview_beyond_s',
                    'timed_first_any_route_read_beyond_s','native_first_any_route_read_beyond_s','timed_first_guard_reject_at_boundary_s',
                    'native_first_guard_reject_at_boundary_s','timed_body_travel_m','native_body_travel_m']:
            x=g[col].dropna()
            summary.append(dict(scope=scope,measurement=col,denominator=len(g),observed=len(x),minimum=x.min(),median=x.median(),maximum=x.max()))
    pd.DataFrame(summary).to_csv(OUT/'by_map.csv',index=False)
    timings=pd.read_csv(timing);assert len(timings)==6
    comparisons=[]
    for r in timings.itertuples():
        for col in ['timed_body_arrival_s','native_body_arrival_s','timed_first_preview_beyond_s','native_first_preview_beyond_s','timed_first_guard_reject_at_boundary_s','native_first_guard_reject_at_boundary_s']:
            x=data[col];valid=x.notna()
            comparisons.append(dict(request=r.request,cache=r.cache,elapsed_s=r.elapsed_s,clock=col,roots_total=len(x),measured=int(valid.sum()),
                                    elapsed_strictly_before=int((r.elapsed_s<x[valid]).sum()),elapsed_at_or_after=int((r.elapsed_s>=x[valid]).sum())))
    pd.DataFrame(comparisons).to_csv(OUT/'cpu_requests_against_72_windows.csv',index=False)
    old_clock=json.loads((P/'actions/continuous_examples/departure_plan/three_alpha_batched/timing_window.json').read_text())
    np.testing.assert_allclose(data[data.root==1250].timed_body_arrival_s,old_clock['archived_arrival_s'],atol=1e-9)
    info=dict(stage='complete',root_count=len(data),maps=list(data['map'].unique()),physical_repeats=0,fits=0,measured_planning_requests=6,
      selection='One fixed archived physical lane per distinct TRAIN root. Shared actual entry action_slot=0, geometry=0, alpha=0, no external pulse, fixed physical left exit. Gates retain the preregistered near/far and side. No filtering by later outcomes.',
      body='First physical world-x crossing of the last copied grid sample, interpolated between 5 ms trace frames. The retained prefix is straight; fixed baseline and neutral arrays agree through the next sample. A planner could lose its opportunity earlier.',
      clocks='timed matches the existing CPU request helper (initial nearest reference sample and full rotated velocity); native matches the H75 physical runner reset (bounded segment projection and world horizontal velocity projected onto yaw). Both allocate 15ms at speed 2 m/s, with lookahead plus one 20ms update of forward motion reserved.',
      actual_preview='Replay the archived physical qpos, qvel, yaw and immutable route through TorchPathReference at real H75 20 ms pursuit refreshes, with 5 ms projection updates. First preview strictly beyond the copied end can interpolate changed geometry. Reconstructed read; no new candidate was physically applied. Also reports earliest among that preview and the policy curvature probe up to progress+1 m.',
      eligibility='At each real 20 ms update boundary, the frozen same-grid update guard requires commitment >= current progress + current lookahead + requested speed × .02. First violated boundary is not the same quantity as a physical command change or the last feasible planner launch.',
      measured_reference='Neutral until tick 3, then frozen approach geometry 0 with alpha 0. Projection after tick 3 changes route beginning with the t=20 ms frame. Saved full publication XY and in-memory reference prefix match numerically through each cutoff.',
      runtime='Compare the same six measured single-CPU-request latencies from root 1250 against 72 individual motion windows. Timings were not independently measured on the other 71 roots. No TEST, vehicle hardware, new physics or terrain generalization.',
      timing_source=str(timing),physics_tick_s=.005,reference_refresh_s=.02,source_runner=str(W/'learning/src/sttw_control/playground_handoff_evaluation.py'))
    (OUT/'receipt.json').write_text(json.dumps(info,indent=2)+'\n')
    print(pd.DataFrame(summary).query("scope=='six_fixed_train_maps'").to_string(index=False))

if __name__=='__main__':measure()

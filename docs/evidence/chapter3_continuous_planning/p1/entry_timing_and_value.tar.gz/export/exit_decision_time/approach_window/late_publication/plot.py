"""Plot the observed pre-release XY and the original controller's release margins."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).parent
d=pd.read_csv(p/'by_root_candidate.csv');prefix=d[(d.root==1250)&(d.reserve_s==.5)]
with np.load(p/'reference_and_physical_xy.npz') as z:
    q=z['physical_xy_until_release'][np.flatnonzero(z['source_root']==1250)[0]]
    inc=z['incumbent_xy'];refs=z['candidate_xy'][prefix.route_ref_array_index.to_numpy(int)]
fig,(ax,bx)=plt.subplots(2,1,figsize=(9.5,5.8),gridspec_kw={'height_ratios':[1,1.3]},layout='constrained')
ax.plot(*inc.T,'--',color='#54616a',lw=1.5,label='Previously scheduled, slot 0')
for ref,style,col,lab in zip(refs,['-','-.'],['#087d86','#b85921'],['+0.08 m candidate','−0.08 m candidate']):
    ax.plot(*ref.T,linestyle=style,color=col,lw=1.8,label=lab)
ax.plot(*q.T,color='#15191c',lw=3.5,label='Recorded vehicle, 0–400 ms');ax.plot(*q[-1],'o',color='black',markersize=4)
for x,lab in [(prefix.immutable_end_x_m.iloc[0],'End of copied path'),(9.2,'Target'),(10.3,'Step')]:
    ax.axvline(x,color='#8b969c',lw=.75,ls=':');ax.text(x,.44,lab,ha='center',va='bottom',fontsize=8)
ax.set(xlim=(1.25,10.7),ylim=(-.62,.62),xlabel='World x (m)',ylabel='World y (m)',aspect='equal')
ax.set_title('Recorded approach to release and two candidate references  ·  TRAIN start 1250',loc='left',weight='bold',fontsize=11)
ax.legend(loc='upper center',bbox_to_anchor=(.5,-.47),ncols=4,fontsize=8,frameon=False)
by=d[d.target_offset_m.eq(.08)].sort_values(['reserve_s','root'])
for budget,co,m in [(.4,'#b85921','x'),(.5,'#087d86','o')]:
    s=by[by.reserve_s==budget];bx.scatter(s.root,s.publication_remaining_commit_m*100,c=co,s=20,marker=m,label=f'{budget*1000:.0f} ms reserve · {int(s.accepted_400ms.sum())}/72 accepted')
bx.axhline(0,color='#222',lw=1)
for boundary in [1261.5,1273.5,1285.5,1297.5,1309.5]:bx.axvline(boundary,color='#b7c1c6',lw=.65,ls=':')
bx.set(xlabel='TRAIN start ID  ·  12 consecutive starts per map',ylabel='Remaining protected length (cm)',xlim=(1248.5,1322.5))
bx.legend(loc='lower right',fontsize=8,frameon=True);bx.set_title('Geometric release margin at 400 ms  ·  both candidate directions give the same result',loc='left',weight='bold',fontsize=11)
for a in (ax,bx):a.spines[['top','right']].set_visible(False);a.tick_params(labelsize=8.5)
fig.savefig(p/'observed_xy_and_release.png',dpi=180,metadata={'Title':'TRAIN approach XY and release margin','Description':'XY uses equal metric scales. Observed history stops at release; the two reference branches were not driven.'})

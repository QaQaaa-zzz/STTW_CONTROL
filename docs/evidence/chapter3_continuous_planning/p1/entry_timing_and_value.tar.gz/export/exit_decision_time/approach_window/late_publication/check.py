"""Replay H75 reference reads and the unmodified geometric publication predicate, using only real TRAIN states."""
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
import torch

OUT=Path(__file__).resolve().parent;P=OUT.parents[3]
W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path[:0]=[str(P/'actions'),str(W/'learning/src')]
from continuous_approach import generate_reference,Boundary
from sttw_control.chapter3_continuous_exit import committed_progress
from sttw_control.torch_path_reference import TorchPathReference
from sttw_control.torch_middle_control import TorchMiddleControl
from sttw_control.playground_adapters import GroundAdapter
F=('xy','heading','curvature')
N=72;DUE=80;EARLY=3
read=lambda f:json.loads(Path(f).read_text())
arr=lambda x:np.asarray(x)
def route_rows(one,number):
    return {'s':one['s'],**{k:np.repeat(one[k],number,axis=0) for k in F}}
def diffrows(x,y):
    if x.is_floating_point():x=x.contiguous().view(torch.int32);y=y.contiguous().view(torch.int32)
    return (x!=y).reshape(len(x),-1).any(1).numpy()


def compare_reference_reads(pose,speed,request,start_raw,neutral_rt,old_rt,proposal,init,first):
    n=len(request)
    projections=[init,init];followers=[first,first]
    nom=[neutral_rt.publish(start_raw,first['command'])[0] for _ in range(2)]
    first_consumed=[None]*n;first_computed=[None]*n
    envelope_end=torch.zeros(n)
    def compare(tag,a,b,tick,consumed=True):
        hits=diffrows(a,b)
        if hits.any():
            for j in np.where(hits)[0]:
                if first_computed[j] is None:first_computed[j]=(tick,tag)
                if consumed and first_consumed[j] is None:first_consumed[j]=(tick,tag)
        return hits
    for tick in range(DUE+1):
        # after(tick-1) runs before the route publication event at tick.
        if tick>0:
            rs=(neutral_rt,neutral_rt) if tick<=EARLY else (old_rt,proposal)
            moved=(pose[tick,:,:2]-pose[tick-1,:,:2]).norm(dim=1)
            projections=[r.project(pose[tick,:,:2],a['progress'],moved) for r,a in zip(rs,projections)]
            for k in projections[0]:compare('projection.'+k,projections[0][k],projections[1][k],tick)
            pt=[r.pursuit(a['progress'],pose[tick],speed[tick],request) for r,a in zip(rs,projections)]
            refresh=tick%4==0
            for k in pt[0]:compare('pursuit.'+k,pt[0][k],pt[1][k],tick,refresh)
            if refresh:
                followers=pt;envelope_end=torch.maximum(envelope_end,projections[0]['progress']+pt[0]['lookahead'])
            pub=[r.publish(n,f['command']) for r,n,f in zip(rs,nom,followers)]
            nom=[a[0] for a in pub]
            for j,k in enumerate(('nominal','nominal_rate')):compare(k,pub[0][j],pub[1][j],tick)
        if tick==DUE:break
        rs=(neutral_rt,neutral_rt) if tick<EARLY else (old_rt,proposal)
        # before() computes the observation at 200 Hz with lane clocks, retains network
        # outputs at 50 Hz, and checks numerical faults at every tick.
        for d in (0.,.5,1.):
            values=[r.at(a['progress']+d)[2] for r,a in zip(rs,projections)]
            compare('curvature.'+str(d),*values,tick,tick%4==0)
        envelope_end=torch.maximum(envelope_end,projections[0]['progress']+1.)
        # Runtime ground-side path/domain score reads the full-route nearest distance.
        nearest=[(r.xy-pose[tick,:,None,:2]).square().sum(-1).min(-1).values.sqrt() for r in rs]
        compare('monitor.nearest_distance',*nearest,tick)
    required=projections[0]['progress']+followers[0]['lookahead']+request*.02
    return projections[0],followers[0],required,first_consumed,first_computed,envelope_end


def native_publication(old, x, c, request, progress, look, committed):
    old1=TorchPathReference(old,c);new1=TorchPathReference(x,c)
    mid=TorchMiddleControl.__new__(TorchMiddleControl)
    mid.tick=DUE;mid.route=old1;mid.v_user=request;mid.alpha=torch.zeros(1)
    mid.projection={'progress':progress};mid.follower={'lookahead':look}
    adapter=GroundAdapter(mid,None);reason=''
    try:receipt=adapter.update_plan(new1,committed,.4,0)
    except ValueError as exc:reason=str(exc);receipt=None
    accepted=receipt is not None
    assert (adapter.plan_version==1 and mid.route is new1) if accepted else (adapter.plan_version==0 and mid.route is old1)
    assert mid.alpha.item()==0
    return accepted,reason,receipt


def main():
    torch.set_num_threads(1);source=[];poses=[];speeds=[];steers=[];physical_xy=[]
    prior=pd.read_csv(OUT.parent/'by_root.csv').sort_values(['map','root'])
    assert len(prior)==N and prior.root.nunique()==N
    for num in range(6):
        name=f'train_{num:02}';cfg=read(P/'batches'/name/'physical/resolved_config.json');hand=cfg['ground_handoff']
        assert cfg['platform_online']['latency_ticks']['start']==EARLY
        c=read(W/hand['bundle']/'config.json');c['follower']['lookahead_scale']=1.
        old_file=cfg['paired_departures']['approach_file'];neutral_file=hand['reference_path']
        with np.load(old_file) as z:old={'s':z['s'],**{k:z[k][:1] for k in F}}
        with np.load(neutral_file) as z:neutral={'s':z['s'],**{k:z[k][:1] for k in F}}
        front=cfg['world_map_spec']['terrain']['front_x_m'];target_x=hand['approach']['jump_start_x_m']
        assert np.isclose(front-target_x,1.1) and np.isclose(front,10.3)
        for r in prior[prior['map'].eq(name)].itertuples():
            v=hand['handoff_variants'][cfg['evaluation_lanes'][r.lane][2]]
            assert (v['arm'],v['bank_row'],v['geometry'],v['action_slot'],v['approach_alpha'],v['force_y_N'])==('left',r.root,0,0,0,0)
            with np.load(r.trajectory) as trace:
                q=trace['qpos'][:DUE+1];vel=trace['qvel'][:DUE+1];tr=trace['trace'][:DUE+1];cols=trace['columns'].tolist()
                np.testing.assert_array_equal(trace['reference_xy'],old['xy'][0])
                assert np.all(tr[:,cols.index('phase')]==0) and len(q)==DUE+1
                np.testing.assert_allclose(tr[:,0],np.arange(DUE+1)*.005,rtol=0,atol=2e-8)
            yaw=tr[:,cols.index('yaw')]
            p=torch.from_numpy(np.column_stack((q[:,0],q[:,1],yaw)))
            posvel=torch.from_numpy(vel[:,:2]);speed=posvel[:,0]*p[:,2].cos()+posvel[:,1]*p[:,2].sin()
            poses.append(p);speeds.append(speed);steers.append(q[0,8]);physical_xy.append(q[:,:2])
            source.append(dict(map=name,root=int(r.root),lane=int(r.lane),action_slot=0,alpha=0,hidden_force_N=0,arm='left',trajectory=r.trajectory))
    pose=torch.stack(poses,1);speed=torch.stack(speeds,1);request=torch.full((N,),2.);start_raw=torch.stack((speed[0],torch.tensor(steers)),1)
    neutral_rt=TorchPathReference(route_rows(neutral,N),c);old_rt=TorchPathReference(route_rows(old,N),c)
    initial_near=(neutral_rt.xy-pose[0,:,:2,None].transpose(1,2)).square().sum(-1).argmin(1)
    init=neutral_rt.project(pose[0,:,:2],neutral_rt.s[initial_near],torch.zeros(N))
    first=neutral_rt.pursuit(init['progress'],pose[0],speed[0],request)
    common_y=np.interp(target_x,old['xy'][0,:,0],old['xy'][0,:,1])
    common_h=np.interp(target_x,old['xy'][0,:,0],old['heading'][0]);common_k=np.interp(target_x,old['xy'][0,:,0],old['curvature'][0])
    edge_y=np.interp(front,old['xy'][0,:,0],old['xy'][0,:,1]);edge_h=np.interp(front,old['xy'][0,:,0],old['heading'][0])
    rows=[];refs=[]
    for budget in (.4,.5):
        reserved=committed_progress(init['progress'],first['lookahead'],request,budget)
        for lateral in (.08,-.08):
            curves=[];geoms=[]
            for commit in reserved:
                x,g=generate_reference(old,float(commit),front,1.1,Boundary(common_y+lateral,common_h,common_k),edge_y,edge_h)
                curves.append(x);geoms.append(g)
            proposal=TorchPathReference({'s':old['s'],**{k:np.concatenate([a[k] for a in curves]) for k in F}},c)
            # Both schedules initialize on the identical published neutral route. On interval
            # [0.015,0.020) the early route becomes candidate, the late route becomes incumbent 0.
            projection,follower,required,first_consumed,first_computed,envelope_end=compare_reference_reads(
                pose,speed,request,start_raw,neutral_rt,old_rt,proposal,init,first)
            for j,(info,g,x) in enumerate(zip(source,geoms,curves)):
                # Per-lane native call; one failing lane cannot invalidate a different lane's receipt.
                accepted,reason,_=native_publication(old,x,c,request[j:j+1],projection['progress'][j:j+1],
                      follower['lookahead'][j:j+1],reserved[j:j+1])
                z=first_consumed[j];any_read=first_computed[j];refs.append(x['xy'][0])
                rows.append(dict(**info,reserve_s=budget,release_s=.4,target_offset_m=lateral,common_target_y_m=common_y,target_y_m=g['target_y_m'],
                    target_heading_rad=g['target_heading_rad'],target_curvature_per_m=g['target_curvature_m_inv'],init_s_m=float(init['progress'][j]),
                    init_lookahead_m=float(first['lookahead'][j]),committed_s_m=float(reserved[j]),immutable_end_s_m=g['commit_copied_through_s_m'],
                    immutable_end_x_m=g['join_x_m'],mutable_to_trigger_x_m=g['target_x_m']-g['join_x_m'],
                    mutable_to_trigger_arc_m=g['target_s_m']-g['commit_copied_through_s_m'],x_at_release_m=float(pose[DUE,j,0]),
                    actual_progress_at_release=float(projection['progress'][j]),actual_lookahead_at_release=float(follower['lookahead'][j]),
                    required_prefix_at_release_m=float(required[j]),publication_remaining_commit_m=float(reserved[j]-required[j]),
                    max_consumed_sample_arc_m=float(envelope_end[j]),all_reference_computations_bitwise_equal=any_read is None,
                    all_used_reference_outputs_bitwise_equal=z is None,first_used_difference_tick=None if z is None else z[0],
                    first_used_difference_field='' if z is None else z[1],first_computed_difference_tick=None if any_read is None else any_read[0],
                    first_computed_difference_field='' if any_read is None else any_read[1],accepted_400ms=accepted,rejection_reason=reason,
                    both_equal_and_accepted=accepted and z is None,route_ref_array_index=len(refs)-1))
    df=pd.DataFrame(rows);assert len(df)==288
    df.to_csv(OUT/'by_root_candidate.csv',index=False);pd.DataFrame(source).to_csv(OUT/'sources.csv',index=False)
    np.savez_compressed(OUT/'reference_and_physical_xy.npz',s=old['s'],candidate_xy=np.stack(refs),source_root=[r['root'] for r in source],
        physical_xy_until_release=np.stack(physical_xy),incumbent_xy=old['xy'][0],neutral_xy=neutral['xy'][0])
    summary=[]
    for name,md in [('all_72',df),*df.groupby('map')]:
        for (b,side),d in md.groupby(['reserve_s','target_offset_m']):
            summary.append(dict(map=name,reserve_s=b,target_offset_m=side,roots=len(d),
                all_computed_identical=int(d.all_reference_computations_bitwise_equal.sum()),all_used_identical=int(d.all_used_reference_outputs_bitwise_equal.sum()),
                native_published=int(d.accepted_400ms.sum()),identical_and_published=int(d.both_equal_and_accepted.sum()),
                min_slack_m=d.publication_remaining_commit_m.min(),max_slack_m=d.publication_remaining_commit_m.max(),
                initial_mutable_x_min_m=d.mutable_to_trigger_x_m.min(),initial_mutable_x_max_m=d.mutable_to_trigger_x_m.max(),
                initial_mutable_arc_min_m=d.mutable_to_trigger_arc_m.min(),initial_mutable_arc_max_m=d.mutable_to_trigger_arc_m.max()))
    summaries=pd.DataFrame(summary);summaries.to_csv(OUT/'by_map.csv',index=False)
    receipt=dict(stage='complete',physical_steps=0,training_steps=0,device='CPU',physical_roots=72,early_vs_late_comparisons=288,
        controller='Frozen H75 TorchPathReference.project, pursuit, at, publish; actual TorchMiddleControl.update_plan through GroundAdapter.update_plan at tick 80, per lane on original state fields required by publication.',
        time_order='Neutral reset. At pre-control tick 3 early execution receives generated route; late execution receives old 0. Compare through tick 79 and post-step tick 80 projection/pursuit before publication, then apply native 400 ms release predicate.',
        projection_and_pursuit='Every 5 ms bounded projection on archived XY. Every 5 ms computed pursuit, every fourth tick retained. The focus is signed-zero-aware bit equality of FP32 reference outputs under archived physical poses; cached and discarded computed reads distinguished.',
        controller_reads='Projection and heading, interpolated curvature at progress/+.5/+1 m, pursuit preview in world and body, tracking command and domain/fault flags, lower-rate slew command, monitor nearest-path distance. Non-geometric state/ESO/actor not resimulated.',
        schedule='Fixed alpha zero for both schedules; candidate trigger x=9.2, old-slot-0 y at trigger +/-0.08m, same target heading/curvature and same step-edge pose.',
        implication='Equal initial complete state, disturbance, and consumed reference outputs imply equal state/control by deterministic one-step induction on each archived prefix; numerical mismatch ends the induction. Native publication acceptance and future physical completion are distinct.',
        limitations='No candidate is physically executed; no new jump or gate result and no new online request timing. Results on the 72 TRAIN prefixes only.',
        by_budget_direction=summaries[summaries['map']=='all_72'].to_dict('records'))
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(summaries[summaries['map']=='all_72'].to_string(index=False))
if __name__=='__main__':main()

"""Compare recorded pre-jump controls for equal-alpha approaches, on the six training maps."""
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd

root = Path(__file__).resolve().parents[1]
rows = []
for map_index in range(6):
    name = f'train_{map_index:02d}'
    suffixes = pd.read_csv(root / 'export/train' / name / 'suffix_index.csv')
    left = suffixes[(suffixes.arm == 'left') & (suffixes.hidden_force_N_grouping_only == 0)]
    with np.load(root / 'batches' / name / 'physical/p1_applied_controls.npz') as tape:
        controls, valid, dt = tape['targets'], tape['valid'], float(tape['dt_s'])
    for bank, group in left.groupby('root'):
        states = {}
        for item in group.itertuples():
            with np.load(item.trajectory) as trajectory:
                phase = trajectory['columns'].tolist().index('phase')
                trace = trajectory['trace']
                ground = np.flatnonzero(trace[:, phase] != 0)
                end = int(ground[0]) if len(ground) else len(trace)
                states[item.action_slot] = (trajectory['qpos'][:end], trajectory['qvel'][:end])
        for alpha, actions in group.groupby('alpha'):
            for a, b in combinations(actions.sort_values('action_slot').itertuples(), 2):
                qa, va = states[a.action_slot]
                qb, vb = states[b.action_slot]
                n = min(len(qa), len(qb), len(controls))
                assert valid[:n, [a.lane, b.lane]].all()
                assert np.array_equal(qa[0], qb[0]) and np.array_equal(va[0], vb[0])
                ticks = np.flatnonzero((controls[:n, a.lane] != controls[:n, b.lane]).any(axis=1))
                motion = np.flatnonzero((qa[:n] != qb[:n]).any(axis=1) | (va[:n] != vb[:n]).any(axis=1))
                rows.append(dict(map=name, root=bank, alpha=alpha, slot_a=a.action_slot, slot_b=b.action_slot,
                                 lane_a=a.lane, lane_b=b.lane, compared_ground_ticks=n, tick_s=dt,
                                 first_command_s=(ticks[0] * dt if len(ticks) else np.nan),
                                 first_state_s=(motion[0] * dt if len(motion) else np.nan),
                                 source_a=a.trajectory, source_b=b.trajectory))
out = pd.DataFrame(rows)
out.to_csv(root / 'export/exit_decision_time/same_alpha_geometry_controls.csv', index=False)
print(out.groupby(['slot_a','slot_b']).first_command_s.agg(['size','count','min','median','max']).to_string())

# Reuse the physical left/right runs scored at identical gates. Each action is shared across three pushes.
gate_dir = root / 'export/cross_fixed_exit_gates'
scores = pd.read_csv(gate_dir / 'all_actions.csv.gz').pivot(
    index=['map', 'root', 'section', 'side'], columns='action', values='toward')
scorecard = pd.DataFrame({
    'three_old_curves_alpha0': scores[[0, 1, 2]].max(axis=1),
    'old_curve_alpha_half': scores[3],
    'old_curve_alpha_one': scores[4],
    'old_slot0_only': scores[0],
    'old_slot2_only': scores[2],
    'either_late_separating_old_curve_alpha0': scores[[0, 2]].max(axis=1),
    'all_five_old': scores[list(range(5))].max(axis=1),
    'all_sixteen': scores.max(axis=1),
}).reset_index()
scorecard.to_csv(root / 'export/exit_decision_time/equal_alpha_gate_scores.csv', index=False)
print(scorecard.groupby('side').sum(numeric_only=True).drop(columns='root').to_string())

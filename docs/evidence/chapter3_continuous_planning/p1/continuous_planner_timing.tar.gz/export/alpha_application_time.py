"""At identical time zero and on the same curve, compare the executed alpha=0 and 1 prefixes."""
from pathlib import Path
import numpy as np
import pandas as pd

root=Path(__file__).resolve().parents[1]
rows=[]
for i in range(6):
    name=f'train_{i:02}'
    sf=pd.read_csv(root/'export/train'/name/'suffix_index.csv')
    s=sf[(sf.arm=='left') & (sf.hidden_force_N_grouping_only==0) & sf.action_slot.isin([1,4])]
    with np.load(root/'batches'/name/'physical/p1_applied_controls.npz') as z:
        control=z['targets'];valid=z['valid'];dt=float(z['dt_s'])
    for bank,g in s.groupby('root'):
        a,b=g.sort_values('alpha').itertuples(index=False)
        assert a.geometry==b.geometry and [a.alpha,b.alpha]==[0.,1.]
        with np.load(a.trajectory) as f:qa=f['qpos'];va=f['qvel']
        with np.load(b.trajectory) as f:qb=f['qpos'];vb=f['qvel']
        assert np.array_equal(qa[0],qb[0]) and np.array_equal(va[0],vb[0])
        count=min(len(qa),len(qb))
        moving=np.flatnonzero(valid[:,a.lane] & valid[:,b.lane] & (control[:,a.lane]!=control[:,b.lane]).any(axis=1))
        state=np.flatnonzero((qa[:count]!=qb[:count]).any(1)|(va[:count]!=vb[:count]).any(1))
        record=dict(map=name,root=bank,first_control_tick=int(moving[0]),first_control_s=moving[0]*dt,
                    first_state_s=state[0]*dt,left0_lane=a.lane,left1_lane=b.lane)
        for step in (3,20,100,320):
            record[f'planar_gap_at_{int(1000*dt*step)}ms_m']=np.linalg.norm(qa[step,:2]-qb[step,:2])
        rows.append(record)
table=pd.DataFrame(rows)
table.to_csv(root/'export/exit_decision_time/alpha_actuation.csv',index=False)
print(table.filter(regex='first_|gap_at_').describe().loc[['min','50%','max']].to_string())

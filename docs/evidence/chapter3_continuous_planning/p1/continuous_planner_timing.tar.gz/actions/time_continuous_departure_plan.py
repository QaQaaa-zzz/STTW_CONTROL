"""Time one cold and five warm single-vehicle requests on the same observed TRAIN initial state."""
import argparse
import csv
import hashlib
import json
import time

import numpy as np
import torch
from check_continuous_departure_plan import HERE,W,read_request,preview_commitment,table,write
from continuous_departure_plan import plan
from frozen_exit_value import FrozenExits
from jump_outcome import JumpOutcome
from sttw_control.torch_path_reference import TorchPathReference


def main(device):
    setup=time.perf_counter()
    torch.set_num_threads(1)
    old=HERE/'three_alpha_batched'
    checkpoint=HERE/'legacy_smoke_mixture3.pt'
    cp=torch.load(checkpoint,weights_only=True,map_location='cpu')
    model=JumpOutcome(cp['width_in'],'mixture3')
    model.load_state_dict(cp['state']);model.eval().to(device)
    folder,cfg,first,side,gate,world,raster,published,q,v=read_request()
    ground=FrozenExits(folder,device=device,load_route_bank=False)
    hcfg=json.loads((W/cfg['ground_handoff']['bundle']/'config.json').read_text());hcfg['follower']['lookahead_scale']=1.
    route=TorchPathReference(published,hcfg)
    source=json.loads((old/'receipt.json').read_text());clock=json.loads((old/'timing_window.json').read_text())
    if device=='cuda':torch.cuda.synchronize()
    setup_s=time.perf_counter()-setup
    outputs=[];candidate_rows=[];particle_rows=[]
    with (old/'particles.csv').open() as f:cpuparticles=list(csv.DictReader(f))
    with (old/'candidates.csv').open() as f:cpuscores=np.array([float(z['score']) for z in csv.DictReader(f)])
    assert cpuscores.shape==(9,) and len(cpuparticles)==144 and len(q)==12 and first['root_slot']==first['action_slot']==0
    for trial in range(6):
        if device=='cuda':torch.cuda.synchronize()
        ready=time.perf_counter()
        near,req,look,commit,slack=preview_commitment(route,published,q,v)
        output,alpha,log,_=plan(world,raster,ground,model,q,v,published,float(first['approach_alpha']),commit,gate,side,
                                publish_window_s=slack,request_started=ready)
        if device=='cuda':torch.cuda.synchronize()
        elapsed=time.perf_counter()-ready
        # The caller is at the handoff to publication now; include return and final synchronization.
        pub=int(log['publishable_candidate'])
        if elapsed>slack and pub:
            pub=0;output=published;alpha=float(first['approach_alpha'])
        eligible=pub!=0
        if not pub:assert output is published and alpha==first['approach_alpha']
        rows=log['candidate_log'];particles=log['particle_log'];scores=np.array([z['score'] for z in rows])
        assert len(rows)==9 and len(particles)==144 and {z['alpha'] for z in rows}=={0.,.5,1.}
        votes=('allow_left','allow_straight','allow_right')
        vote_differences=sum(z[k]!=(o[k]=='True') for z,o in zip(particles,cpuparticles) for k in votes)
        selected_differences=sum(z['selected_exit']!=int(o['selected_exit']) for z,o in zip(particles,cpuparticles))
        join_differences=sum(z['join_index']!=int(o['join_index']) for z,o in zip(particles,cpuparticles))
        outputs.append(dict(request=trial+1,cache='cold_first_model_loaded' if trial==0 else 'warm',elapsed_s=elapsed,
            decision_elapsed_s=log['total_s'],geometry_s=log['geometry_s'],jump_and_input_s=log['jump_and_input_s'],ground_s=log['ground_s'],
            candidate_count=9,conditional_particles=144,nominal_deadline_s=slack,body_window_s=clock['archived_arrival_s'],
            meets_publish_slack=elapsed<=slack,meets_archived_body_window=elapsed<=clock['archived_arrival_s'],
            proposal=log['selected'],proposal_alpha=log['alpha'],proposal_score=float(scores[log['selected']]),
            eligible_reference=pub,eligible_alpha=alpha,
            publish_result='new_reference_eligible' if eligible else ('deadline_missed_keep_published' if elapsed>slack and log['selected'] else log['publish_decision']),
            same_proposal_as_cpu=log['selected']==source['selected'],max_abs_score_delta_vs_cpu=float(np.abs(scores-cpuscores).max()),
            differing_cpu_exit_votes_of_432=vote_differences,differing_cpu_selected_exits_of_144=selected_differences,differing_cpu_joins_of_144=join_differences))
        candidate_rows.extend(dict(request=trial+1,**z) for z in rows)
        particle_rows.extend(dict(request=trial+1,**z) for z in particles)
    target=HERE/('three_alpha_timing_'+device);target.mkdir(parents=True,exist_ok=True)
    table(target/'requests.csv',outputs);table(target/'candidates.csv',candidate_rows);table(target/'particles.csv',particle_rows)
    warm=np.array([r['elapsed_s'] for r in outputs[1:]])
    info=dict(stage='complete',role='One observed TRAIN initial state, root 1250, train_00, fixed near-left gate. Latency only.',
        device=device,device_name=torch.cuda.get_device_name(0) if device=='cuda' else 'CPU, one PyTorch thread',
        checkpoint=str(checkpoint),sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),same_checkpoint_as_cpu=True,
        setup_s=setup_s,start='Immutable map, observations and model resident. Request begins before host route projection and H75 preview. First request follows model load without a prior planning request.',
        stop='Post-return explicit device synchronization and caller deadline decision; inputs, CPU curve generation, device transfers, CEM scoring and decision included. File writing follows timing.',
        measured_requests=6,vehicles_per_request=1,conditional_particles_per_request=144,
        cold_s=outputs[0]['elapsed_s'],warm_s=warm.tolist(),warm_median_s=float(np.median(warm)),warm_max_s=float(warm.max()),
        request_specific_nominal_publication_window_s=outputs[0]['nominal_deadline_s'],observed_body_travel_window_s=clock['archived_arrival_s'],
        changes_meeting_deadline=sum(r['eligible_reference']!=0 for r in outputs),physical_rollouts=0,transmitted_commands=0,training_updates=0)
    assert info['sha256']==source['model_checkpoint_sha256']
    write(target/'receipt.json',info);print(json.dumps(info,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device',choices=('cpu','cuda'),required=True)
    main(parser.parse_args().device)

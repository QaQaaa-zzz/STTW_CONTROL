"""One known-map, pre-takeoff planning decision on continuous entry curves and alpha."""
from pathlib import Path
import sys,time
import numpy as np
import torch
from continuous_approach import Boundary,generate_reference
from continuous_departures import score_approach_particles
P=Path(__file__).resolve().parents[1];W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path[:0]=[str(P/'export'),str(P/'model'),str(W/'learning/src'),str(W/'learning/cli'),'/home/qy/DVGC/JIT/src']
from export_prefixes import decision_inputs as sample_corridor
from jump_outcome import decision_inputs,decode_target
from run_downstream_dev import random_draws

@torch.inference_mode()
def plan(world,raster,ground,jump,qpos,qvel,published,published_alpha,committed_s,gate_x,gate_side,*,
         population=4,iterations=2,seed=923114,speed=2.,trigger_before_edge_m=1.1,episode_s=10.,
         continuous_alpha=False,publish_window_s=None,request_started=None):
    """Return the reference and alpha eligible for publication at the supplied deadline. No instance, map or catalog key is an input.

    ground is the frozen scorer for world/raster. committed_s is the actual publication
    commitment supplied by the controller. Particles use the registered common P1 quantiles
    and noise across *all* candidates. Timings include every candidate and conditional exit query.
    """
    if gate_side not in (-1,1) or population<2 or iterations<1 or not 0<=published_alpha<=1:raise ValueError('Invalid gate, CEM budget or published alpha')
    t0=time.perf_counter() if request_started is None else request_started
    route={k:np.asarray(v) for k,v in published.items()}
    inp={k:np.asarray(route[k]).reshape(-1,2) if k=='xy' else np.asarray(route[k]).reshape(-1) for k in ('xy','heading','curvature')}
    if route['xy'].ndim==3 and len(route['xy'])!=1:raise ValueError('Expected one currently published curve')
    canonical={'s':route['s'],**{k:v[None] for k,v in inp.items()}}
    edge=world['terrain']['front_x_m'];edge_y=float(np.interp(edge,inp['xy'][:,0],inp['xy'][:,1]));edge_h=float(np.interp(edge,inp['xy'][:,0],inp['heading']))
    candidates=[];records=[];steps=[];geom_s=forecast_s=ground_s=0.;device=jump.x_center.device
    u,z=random_draws();u=u.to(device);z=z.to(device)
    rng=np.random.default_rng(seed)
    high=np.array([.225,np.deg2rad(8.),.08,1.]);low=-high.copy();low[3]=0.
    alpha_levels=np.array([0.,.5,1.]);center=(low+high)/2.;spread=(high-low)/3.
    def evaluate(proposals, iteration):
        nonlocal forecast_s,ground_s
        states=[];probabilities=[];particle_curves=[]
        start=time.perf_counter()
        for curve,alpha,_ in proposals:
            obs=sample_corridor(qpos[None],qvel[None],[0],[alpha],curve,raster,world)
            x,anchor,_,_=decision_inputs(obs);logit,logw,mu,sigma=jump(x.to(device))
            if jump.mode=='mean':latent=mu[:,0:1]
            else:
                modes=torch.searchsorted(logw[0].exp().cumsum(0).contiguous(),u).clamp_max(mu.shape[1]-1)
                latent=mu[:,modes]+sigma[:,modes]*z[None]
            state={k:v[0].cpu().numpy() for k,v in decode_target(anchor[:,None].to(device),latent*jump.y_scale+jump.y_center).items()}
            states.append(state);probabilities.append(float(logit.sigmoid().item()))
            particle_curves.extend([curve]*len(state['query_s']))
        merged={key:np.concatenate([state[key] for state in states]) for key in
                ('query_s','query_qpos_native','query_velocity_state9','previous_velocity_state9')}
        ticks=np.array([round(float(t)/.005) for t in merged['query_s']])
        seconds=np.maximum(0.,episode_s-ticks*.005)
        forecast_s+=time.perf_counter()-start;start=time.perf_counter()
        joins,selected,votes=score_approach_particles(ground,particle_curves,merged['query_qpos_native'],
                      merged['query_velocity_state9'],merged['previous_velocity_state9'],seconds,gate_x,gate_side,speed=speed)
        ground_s+=time.perf_counter()-start
        offset=0;scores=[]
        for (curve,alpha,parameters),state,probability in zip(proposals,states,probabilities):
            n=len(steps);npart=len(state['query_s']);stop=offset+npart
            count=int(votes[offset:stop].any(1).sum())
            score=probability*count/npart;scores.append(score)
            candidates.append(curve);steps.append(dict(candidate=n,iteration=iteration,published=(n==0),alpha=float(alpha),parameters=parameters,
                p_relock=probability,conditional_particles=npart,particles_with_exit=count,score=score))
            for particle,j in enumerate(range(offset,stop)):
                xy=merged['query_qpos_native'][j,:2]
                records.append(dict(candidate=n,particle=particle,query_tick=int(ticks[j]),exit_forecast_steps=int(seconds[j]/.02),
                    join_index=int(joins[j]),predicted_x_m=float(xy[0]),predicted_y_m=float(xy[1]),allow_left=bool(votes[j,0]),
                    allow_straight=bool(votes[j,1]),allow_right=bool(votes[j,2]),selected_exit=int(selected[j])))
            offset=stop
        return scores
    evaluate([(canonical,published_alpha,None)],-1)
    # The bounds are geometry/alpha search choices for this wiring check, never indexed by the map.
    blocked_before_innovation=(committed_s>route['s'][-1] or
        inp['xy'][min(len(route['s'])-1,np.searchsorted(route['s'],committed_s)),0]>=edge-trigger_before_edge_m)
    for i in range(iterations if not blocked_before_innovation else 0):
        draws=np.clip(rng.normal(center,spread,(population,4)),low,high);proposals=[]
        if not continuous_alpha:
            draws[:,3]=alpha_levels[np.abs(draws[:,3,None]-alpha_levels).argmin(axis=1)]
        for a in draws:
            start=time.perf_counter();curve,_=generate_reference(canonical,committed_s,edge,trigger_before_edge_m,
                Boundary(edge_y+a[0],edge_h+a[1],a[2]),edge_y,edge_h)
            geom_s+=time.perf_counter()-start;proposals.append((curve,a[3],a.tolist()))
        scores=evaluate(proposals,i)
        if np.ptp(scores)>0:
            elite=draws[np.argsort(-np.asarray(scores),kind='stable')[:max(2,population//2)]]
            center=elite.mean(0);spread=np.maximum(elite.std(0),.07*(high-low))
    winner=int(np.argmax([r['score'] for r in steps]))   # preexisting route wins an exact tie
    if steps[winner]['score']<=0:winner=0;decision='all_vetoed_keep_published'
    elif not winner:decision='published_best_or_tied'
    else:decision='new_reference_selected'
    if blocked_before_innovation:decision='commitment_reaches_trigger_keep_published';winner=0
    # The proposal is never a transmitted command. A missed or unspecified deadline keeps the current reference.
    if device.type=='cuda':torch.cuda.synchronize(device)
    elapsed=time.perf_counter()-t0
    deadline_met=publish_window_s is not None and elapsed<=publish_window_s
    applied=winner if deadline_met else 0
    if not winner:publish_decision=decision
    elif publish_window_s is None:publish_decision='deadline_unspecified_keep_published'
    elif deadline_met:publish_decision='new_reference_eligible_for_publication'
    else:publish_decision='deadline_missed_keep_published'
    log=dict(decision=decision,selected=winner,alpha=steps[winner]['alpha'],candidate_count=len(steps),particles_evaluated=len(records),
             alpha_mode='continuous' if continuous_alpha else 'three_levels',ground_execution='round_batched',publish_window_s=publish_window_s,
             publish_decision=publish_decision,deadline_met=deadline_met,publishable_candidate=applied,publishable_alpha=steps[applied]['alpha'],
             gate_x_m=gate_x,gate_side=gate_side,committed_s_m=committed_s,threshold='positive estimated joint probability in this CPU wiring example',
             total_s=elapsed,geometry_s=geom_s,jump_and_input_s=forecast_s,ground_s=ground_s,
             candidate_log=steps,particle_log=records)
    return (published if applied==0 else candidates[applied]),steps[applied]['alpha'],log,candidates

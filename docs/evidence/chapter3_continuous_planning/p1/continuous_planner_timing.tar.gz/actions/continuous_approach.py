"""Generate a forward planar reference from boundary conditions for the current published path.

Inputs are one sampled, forward/world-x-monotone route (s, xy, heading, curvature), plus
a mandatory committed arc distance. Shape parameters are metres, radians and inverse
metres. The algorithm never loads a route library. The command-line adapter reads a
single-route NPZ and writes the standard route-bank NPZ with one row.
"""
import argparse
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from numpy.polynomial.polynomial import polyval,polyder

_GAUSS_X,_GAUSS_W=np.polynomial.legendre.leggauss(8)

@dataclass(frozen=True)
class Boundary:
    y: float
    heading: float
    curvature: float

class Quintic:
    def __init__(self,x0,start,x1,end):
        self.x0=x0; self.x1=x1; self.length=x1-x0
        d=self.length
        m0,m1=np.tan([start.heading,end.heading])
        b0=start.curvature*(1+m0*m0)**1.5
        b1=end.curvature*(1+m1*m1)**1.5
        c0=start.y; c1=d*m0; c2=.5*d*d*b0
        sy=end.y-c0-c1-c2;sm=d*m1-c1-2*c2;sb=d*d*b1-2*c2
        self.coef=np.array([c0,c1,c2,10*sy-4*sm+.5*sb,-15*sy+7*sm-sb,6*sy-3*sm+.5*sb])
        self.d1=polyder(self.coef)/d;self.d2=polyder(self.d1)/d
    def at(self,x):
        u=(np.asarray(x)-self.x0)/self.length
        m=polyval(u,self.d1)
        return polyval(u,self.coef),np.arctan(m),polyval(u,self.d2)/(1+m*m)**1.5
    def arc(self,a,b):
        a,b=np.broadcast_arrays(a,b);half=(b-a)*.5
        x=(a+half)[...,None]+half[...,None]*_GAUSS_X
        slope=polyval((x-self.x0)/self.length,self.d1)
        return half*(np.sqrt(1+slope*slope)@_GAUSS_W)
    def arc_table(self,step):
        grid=np.linspace(self.x0,self.x1,max(2,int(np.ceil(self.length/step))+1))
        return grid,np.r_[0.,np.cumsum(self.arc(grid[:-1],grid[1:]))]
    def x_at_arc(self,offset,table):
        x,s=table
        j=np.searchsorted(s,offset,side='right').clip(1,len(s)-1)-1
        v=x[j]+(offset-s[j])*(x[j+1]-x[j])/(s[j+1]-s[j])
        # Newton correction inside the interval using the same arc integrand.
        for _ in range(2):
            slope=polyval((v-self.x0)/self.length,self.d1)
            v=np.clip(v-(s[j]+self.arc(x[j],v)-offset)/np.sqrt(1+slope*slope),x[j],x[j+1])
        return v

def generate_reference(route,committed_s_m,front_x_m,target_before_edge_m,target,edge_y_m,edge_heading_rad):
    """Return an H75-compatible one-row route bank and the continuous curve's junction metadata.

    'target.y' and 'edge_y_m' are world lateral coordinates (or offsets with a
    coordinate system whose forward centreline is y=0). The caller supplies the live
    commitment distance and downstream straight line, common across candidates when
    comparisons require it. The actual adjustable start is the first published sample
    at/after that distance. Sample locations through that anchor are copied.
    """
    s=np.asarray(route['s']);xy=np.asarray(route['xy']);hd=np.asarray(route['heading']);curv=np.asarray(route['curvature'])
    if xy.ndim==3 and xy.shape[0]==1:xy,hd,curv=xy[0],hd[0],curv[0]
    if s.ndim!=1 or len(s)<3 or xy.shape!=(len(s),2) or hd.shape!=s.shape or curv.shape!=s.shape:
        raise ValueError('Expected a single already-published path with s[N], xy[N,2], heading[N] and curvature[N]')
    if not np.all(np.diff(s)>0) or not s[0]<=committed_s_m<s[-1]:
        raise ValueError('The mutable interval must start on a strictly increasing route arc grid')
    join=int(s.searchsorted(committed_s_m,side='left'))
    x0,y0=map(float,xy[join]);xt=front_x_m-target_before_edge_m
    # A nominally coincident FP32 anchor/target can differ in double precision.
    x_next=np.nextafter(xy[join,0],np.array(np.inf,dtype=xy.dtype))
    if not x_next<xt<front_x_m or np.any(np.diff(xy[:join+1,0])<=0):
        raise ValueError('The committed prefix must be x-forward and end strictly before the requested pre-step target')
    if not np.all(np.abs([hd[join],target.heading,edge_heading_rad])<np.pi/2):
        raise ValueError('Heading must lie strictly within the x-forward half-plane')
    start=Boundary(y0,float(hd[join]),float(curv[join]));edge=Boundary(edge_y_m,edge_heading_rad,0.)
    first=Quintic(x0,start,xt,target);second=Quintic(xt,target,front_x_m,edge)
    step=min(.01,float(np.min(np.diff(s)))/2)
    tables=(first.arc_table(step),second.arc_table(step))
    arc1=tables[0][1][-1];arc2=tables[1][1][-1]
    if s[-1]-s[join]<arc1+arc2:
        raise ValueError('The published route grid ends before the generated curve reaches the step edge')
    outxy,outhd,outk=xy.copy(),hd.copy(),curv.copy()
    ids=np.arange(join+1,len(s));ds=s[ids].astype(float)-float(s[join])
    for poly,table,lo,hi in [(first,tables[0],0.,arc1),(second,tables[1],arc1,arc1+arc2)]:
        sel=(ds>lo)&(ds<=hi); ii=ids[sel];x=poly.x_at_arc(ds[sel]-lo,table);y,h,k=poly.at(x)
        outxy[ii]=np.column_stack((x,y));outhd[ii]=h;outk[ii]=k
    tail=ds>arc1+arc2;ii=ids[tail];tail_s=ds[tail]-arc1-arc2
    outxy[ii]=np.column_stack((front_x_m+tail_s*np.cos(edge.heading),edge.y+tail_s*np.sin(edge.heading)))
    outhd[ii]=edge.heading;outk[ii]=0.
    return dict(s=s.copy(),xy=outxy[None],heading=outhd[None],curvature=outk[None]),dict(
        join_index=join,commit_requested_s_m=float(committed_s_m),commit_copied_through_s_m=float(s[join]),join_x_m=x0,
        target_x_m=float(xt),target_s_m=float(s[join]+arc1),edge_x_m=float(front_x_m),edge_s_m=float(s[join]+arc1+arc2),
        target_y_m=float(target.y),target_heading_rad=float(target.heading),target_curvature_m_inv=float(target.curvature),edge_y_m=float(edge.y),edge_heading_rad=float(edge.heading))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('published_one_route',type=Path);p.add_argument('output',type=Path)
    for name in ('committed-s-m','front-x-m','target-before-edge-m','target-y-m','target-heading-deg','target-curvature-m-inv','edge-y-m','edge-heading-deg'):
        p.add_argument('--'+name,type=float,required=True)
    a=p.parse_args();target=Boundary(a.target_y_m,np.deg2rad(a.target_heading_deg),a.target_curvature_m_inv)
    with np.load(a.published_one_route) as z:
        new,meta=generate_reference(z,a.committed_s_m,a.front_x_m,a.target_before_edge_m,target,a.edge_y_m,np.deg2rad(a.edge_heading_deg))
    np.savez_compressed(a.output,**new)
    print(meta)

"""Build raised-platform exit references directly from one supplied approach in world coordinates."""
from pathlib import Path
import sys
import numpy as np

CLI=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/cli')
if str(CLI) not in sys.path:sys.path.insert(0,str(CLI))
from run_platform_task_oracle import departure_route

def departure_options(route,position_xy,progress_m=None,*,target_y_m=(.36,0.,-.36),blend_m=1.6,far_x_m=15.,goal_start_x_m=16.5):
    """Return the arc-grid join index and three H75 reference rows in left/straight/right order.

    Supply the controller's actual progress when available. For a forecast pose alone, use
    its nearest line-segment projection, as in FrozenExits.branch_ids(). All measurements
    and target ordinates refer to the approach's forward world-x / left world-y frame.
    """
    s=np.asarray(route['s']);xy=np.asarray(route['xy']);h=np.asarray(route['heading']);k=np.asarray(route['curvature'])
    if xy.ndim==3 and xy.shape[0]==1:xy,h,k=xy[0],h[0],k[0]
    p=np.asarray(position_xy,dtype=np.float64)
    if (s.ndim!=1 or len(s)<2 or xy.shape!=(len(s),2) or h.shape!=s.shape or k.shape!=s.shape or p.shape!=(2,)
        or not all(np.isfinite(a).all() for a in (s,xy,h,k,p)) or not (np.diff(s)>0).all() or not (np.diff(xy[:,0])>0).all()
        or len(target_y_m)!=3 or not np.isfinite((*target_y_m,blend_m,far_x_m,goal_start_x_m)).all() or blend_m<=0 or far_x_m>=goal_start_x_m):
        raise ValueError('Expected one finite forward-x approach, increasing arc, a world XY pose and valid three-exit geometry')
    if progress_m is None:
        delta=np.diff(xy,axis=0)
        part=np.clip(((p-xy[:-1])*delta).sum(1)/(delta**2).sum(1),0,1)
        i=np.argmin(((xy[:-1]+part[:,None]*delta-p)**2).sum(1))
        progress_m=(1-part[i])*s[i]+part[i]*s[i+1]
    if not np.isfinite(progress_m):raise ValueError('Nonfinite handoff progress')
    # x+5 cm and the next arc-grid point after the controller's progress are both binding.
    join=min(len(s)-1,max(np.searchsorted(xy[:,0],float(p[0])+.05),np.searchsorted(s,progress_m)+1))
    result={'s':s.copy(),**{key:np.repeat(a[None],3,axis=0) for key,a in [('xy',xy),('heading',h),('curvature',k)]}}
    for j,target in enumerate(target_y_m):departure_route(result,j,join,target,blend_m,far_x_m,goal_start_x_m)
    # The physical runner's active reference bank has FP32 geometry, even when the approach was stored in FP64.
    for key in ('xy','heading','curvature'):result[key]=result[key].astype(np.float32,copy=False)
    return int(join),result


def score_approach(scorer,route,qpos,velocity9,previous_velocity9,seconds,section_x,target_side,*,
                   progress_m=None,speed=2.,target_y_m=(.36,0.,-.36),blend_m=1.6,far_x_m=15.,return_native=False,share_direction_rollouts=False):
    """Construct and score the three references at a measured or predicted handoff."""
    join,options=departure_options(route,np.asarray(qpos)[:2],progress_m,target_y_m=target_y_m,blend_m=blend_m,
                                   far_x_m=far_x_m,goal_start_x_m=scorer.query.goal['x_min_m'])
    result=scorer.score_references(np.asarray(qpos)[None],np.asarray(velocity9)[None],np.asarray(previous_velocity9)[None],
        seconds,options,section_x,target_side,speed,return_native,share_direction_rollouts)
    return join,result


def score_approach_particles(scorer,curves,qpos,velocity9,previous_velocity9,remaining_s,section_x,target_side,*,
                             speed=2.,chunk_size=64):
    """Score a round of handoffs on the same map/gate/arc grid. Each retains its own horizon.

    A single curve is broadcast, or pass one curve per particle. Only the recurrent rollout is
    pooled. The original three-direction decision still receives exactly its own time window.
    """
    from copy import copy
    from types import SimpleNamespace
    import torch
    from jump_outcome import exit_initializer
    from sttw_control.playground_history_model import GroundPredictionState

    n=len(qpos)
    if isinstance(curves,dict):curves=[curves]*n
    remaining=np.asarray(remaining_s,dtype=float)
    if n==0 or len(curves)!=n or remaining.shape!=(n,) or (remaining<0).any() or chunk_size<1:
        raise ValueError('Expected curves and one nonnegative remaining time per particle')
    steps=(remaining/.02).astype(int)
    grid=np.asarray(curves[0]['s'])
    if any(not np.array_equal(route['s'],grid) for route in {id(c):c for c in curves}.values()):
        raise ValueError('The decision must use one common reference arc grid')
    joins=np.empty(n,dtype=int);selected=np.empty(n,dtype=int);admitted=np.empty((n,3),dtype=bool)
    query=scorer.query
    with torch.inference_mode():
        s=scorer.tensor(grid)
        for start in range(0,n,chunk_size):
            stop=min(start+chunk_size,n);window=slice(start,stop)
            rows=[]
            for i in range(start,stop):
                joins[i],options=departure_options(curves[i],qpos[i,:2],goal_start_x_m=query.goal['x_min_m'])
                rows.append(options)
            route=SimpleNamespace(s=s,**{k:scorer.tensor(np.concatenate([r[k] for r in rows]))
                                         for k in ('xy','heading','curvature')})
            q,u,prev=map(scorer.tensor,(qpos[window],velocity9[window],previous_velocity9[window]))
            pose,cur,old,hidden=exit_initializer(q,u,prev,query.mean,query.scale,query.weights,query.relative['height'])
            initial=GroundPredictionState(*(x.repeat_interleave(3,0) for x in (pose,cur,old,hidden)))
            forecast=query.model.rollout_state(initial,s,route.xy,route.heading,route.curvature,
                          int(steps[window].max()),cur.new_full((3*len(q),),speed))
            # Reuse choose() for the actual clearance, crossing, tracking, 26-frame hold and incumbent.
            # Its nine rows per state include three hypothetical incumbents on the same three exits.
            replay=copy(scorer);replay.prediction_query=copy(query)
            for horizon in np.unique(steps[window]):
                group=np.flatnonzero(steps[window]==horizon)
                route_ids=group[:,None]*3+np.arange(3)
                replay_ids=torch.as_tensor(np.repeat(route_ids,3,axis=0).ravel(),device=q.device)
                def recorded(state,s,xy,h,k,requested_steps,request):
                    return {key:forecast[key][:,:requested_steps+1].index_select(0,replay_ids)
                            for key in ('pose','velocity','domain')}
                replay.prediction_query.model=SimpleNamespace(nominal=query.model.nominal,rollout_state=recorded)
                index=torch.as_tensor(group,device=q.device)
                selected[start+group],admitted[start+group]=replay._choose(q[index],u[index],prev[index],
                    remaining[start+group[0]],route,route_ids,section_x,target_side,speed,False,True)
    return joins,selected,admitted

"""CPU comparison on the recorded nine-candidate, 144-particle P2 wiring example."""
import csv,json,time
from pathlib import Path
import numpy as np
import torch
from continuous_departure_plan import P,Boundary,generate_reference,sample_corridor,decision_inputs,decode_target,random_draws
from continuous_departures import score_approach,score_approach_particles
from frozen_exit_value import FrozenExits
from jump_outcome import JumpOutcome

RUN=P/'actions/continuous_examples/departure_plan'
CASE=RUN/'three_alpha'
def table(path):
    with path.open() as f:return list(csv.DictReader(f))
def run():
    torch.set_num_threads(1)
    legacy=json.loads((CASE/'receipt.json').read_text())
    cases=table(CASE/'candidates.csv');archive=table(CASE/'particles.csv')
    folder=P/'batches/train_00/physical';cfg=json.loads((folder/'resolved_config.json').read_text())
    world=cfg['world_map_spec'];edge=world['terrain']['front_x_m']
    with np.load(cfg['platform_online']['relative']['raster']) as z:raster=dict(z)
    with np.load(cfg['ground_handoff']['reference_path']) as z:
        published={'s':z['s'],**{k:z[k][:1] for k in ('xy','heading','curvature')}}
    with np.load(CASE/'all_candidate_xy.npz') as z:archived_xy=z['xy']
    edge_y=np.interp(edge,published['xy'][0,:,0],published['xy'][0,:,1])
    edge_h=np.interp(edge,published['xy'][0,:,0],published['heading'][0])
    q=np.asarray(legacy['observed_qpos'],dtype='f4');v=np.asarray(legacy['observed_qvel'],dtype='f4')
    ground=FrozenExits(folder,load_route_bank=False)
    weights=torch.load(RUN/'legacy_smoke_mixture3.pt',map_location='cpu',weights_only=True)
    model=JumpOutcome(weights['width_in'],'mixture3');model.load_state_dict(weights['state']);model.eval()
    curves=[];qps=[];vs=[];previous=[];times=[];prob=[]
    u,z=random_draws()
    for i,c in enumerate(cases):
        if i:
            a=json.loads(c['parameters'])
            curve,_=generate_reference(published,legacy['committed_s_m'],edge,1.1,
                         Boundary(edge_y+a[0],edge_h+a[1],a[2]),edge_y,edge_h)
        else:curve=published
        assert np.array_equal(curve['xy'][0],archived_xy[i])
        obs=sample_corridor(q[None],v[None],[0],[float(c['alpha'])],curve,raster,world)
        x,anchor,_,_=decision_inputs(obs)
        with torch.inference_mode():
            logit,logw,mu,sigma=model(x)
            indices=torch.searchsorted(logw[0].exp().cumsum(0).contiguous(),u).clamp_max(mu.shape[1]-1)
            latent=mu[:,indices]+sigma[:,indices]*z[None]
            targets={k:t[0].numpy() for k,t in decode_target(anchor[:,None],latent*model.y_scale+model.y_center).items()}
        n=len(u);prob.append(float(logit.sigmoid()))
        curves.extend([curve]*n);qps.extend(targets['query_qpos_native']);vs.extend(targets['query_velocity_state9'])
        previous.extend(targets['previous_velocity_state9']);times.extend(max(0.,10.-round(float(t)/.005)*.005) for t in targets['query_s'])
    qps,vs,previous,times=map(np.asarray,(qps,vs,previous,times));gx,side=legacy['gate_x_m'],legacy['gate_side']
    np.testing.assert_array_equal(qps[:,:2],[[float(r['predicted_x_m']),float(r['predicted_y_m'])] for r in archive])
    # Warm both entrypoints on two existing samples, then time the same 144 inputs.
    def scalar(i,seconds):
        j,(c,a)=score_approach(ground,curves[i],qps[i],vs[i],previous[i],seconds,gx,side,share_direction_rollouts=True)
        return j,c[0],a[0]
    def batch(lo,hi,sec):
        return score_approach_particles(ground,curves[lo:hi],qps[lo:hi],vs[lo:hi],previous[lo:hi],sec,gx,side)
    scalar(0,times[0]);batch(0,2,times[:2])
    start=time.perf_counter()
    original=[scalar(i,t) for i,t in enumerate(times)]
    scalar_s=time.perf_counter()-start
    # The incumbent precedes both CEM rounds. Later CEM draws depend on all earlier scores.
    blocks=[(0,16),(16,80),(80,144)];measured=[];round_s=[]
    for lo,hi in blocks:
        start=time.perf_counter();measured.append(batch(lo,hi,times[lo:hi]));round_s.append(time.perf_counter()-start)
    batch_s=sum(round_s)
    aj,ac,aa=map(np.asarray,zip(*original));bj,bc,ba=[np.concatenate(parts) for parts in zip(*measured)]
    archived_a=np.array([[r[k]=='True' for k in ('allow_left','allow_straight','allow_right')] for r in archive])
    np.testing.assert_array_equal(archived_a,aa)
    np.testing.assert_array_equal([int(r['selected_exit']) for r in archive],ac)
    np.testing.assert_array_equal([int(r['join_index']) for r in archive],aj)
    # Explicitly cut a particle with a long-horizon legal exit to 25 and 26 predicted frames.
    good=int(np.flatnonzero(aa.any(1))[0]);ii=[good,good,good]
    short=np.array([.48,.5,times[good]])
    sh_j,sh_c,sh_a=score_approach_particles(ground,[curves[good]]*3,qps[ii],vs[ii],previous[ii],short,gx,side)
    sj,sc,sa=map(np.asarray,zip(*(scalar(good,t) for t in short)))
    assert np.array_equal(sj,sh_j) and np.array_equal(sc,sh_c) and np.array_equal(sa,sh_a)
    assert not sh_a[:2].any() and sh_a[2].any() and np.all(sh_c[:2]==1)
    counts=lambda x:x.any(1).reshape(len(cases),16).sum(1)
    ranking=lambda x:int(np.argmax(np.array(prob)*counts(x)/16))
    out=CASE/'batched_cpu';out.mkdir(exist_ok=True)
    detail=[dict(candidate=r['candidate'],particle=r['particle'],seconds=t,forecast_steps=int(t/.02),
              old_join=int(j),new_join=int(k),old_selected=int(c),new_selected=int(d),
              old_lsr=''.join(str(int(v)) for v in a),new_lsr=''.join(str(int(v)) for v in b))
         for r,t,j,k,c,d,a,b in zip(archive,times,aj,bj,ac,bc,aa,ba)]
    with (out/'particles.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=detail[0]);writer.writeheader();writer.writerows(detail)
    receipt=dict(source_case=str(CASE),checkpoint=str(RUN/'legacy_smoke_mixture3.pt'),hardware='CPU only, torch single thread',
        particles=len(times),candidates=len(cases),directions_per_particle=3,seconds_minmax=[times.min(),times.max()],
        distinct_horizons=len(set((times/.02).astype(int))),step_minmax=[int((times/.02).min()),int((times/.02).max())],
        old_archive_agrees=True,join_mismatches=int((aj!=bj).sum()),choice_mismatches=int((ac!=bc).sum()),
        admission_mismatches=int((aa!=ba).sum()),wholly_vetoed=int((~aa.any(1)).sum()),
        all_veto_ground_default_straight_count=int((bc[~aa.any(1)]==1).sum()),
        old_positive_by_candidate=counts(aa).tolist(),new_positive_by_candidate=counts(ba).tolist(),
        old_proposal=ranking(aa),batch_proposal=ranking(ba),constant_publication_budget_s=legacy['publish_window_s'],
        retained_published_index_due_to_expired_window=0 if batch_s>legacy['publish_window_s'] else ranking(ba),
        explicit_short_cases=[dict(seconds=t,frames=int(t/.02)+1,selected=int(c),admitted=a.tolist()) for t,c,a in zip(short,sh_c,sh_a)],
        old_scalar_ground_s=scalar_s,new_batched_ground_s=batch_s,round_particle_counts=[b-a for a,b in blocks],
        new_ground_seconds_per_round=round_s,ground_speedup=scalar_s/batch_s,
        timing_scope='one warm CPU pass, includes building three references, rollout, collision/gate/hold evaluation. Excludes jump prediction and optimizer, I/O and setup.')
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
    assert np.array_equal(aj,bj) and np.array_equal(ac,bc) and np.array_equal(aa,ba)
if __name__=='__main__':run()

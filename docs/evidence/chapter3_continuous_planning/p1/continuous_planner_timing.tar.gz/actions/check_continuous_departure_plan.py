"""One bounded known-map planning request. Only an already observed TRAIN initial state and its assigned gate enter."""
import argparse,csv,hashlib,json,time
from pathlib import Path
import numpy as np
import torch
from continuous_departure_plan import P,W,plan,random_draws
from frozen_exit_value import FrozenExits
from jump_outcome import Dataset,JumpOutcome,fit_model
from smoke_outcome import grouping_old_dev
from sttw_control.chapter3_continuous_exit import committed_progress
from sttw_control.torch_path_reference import TorchPathReference
from sttw_control.playground_prediction import euler
from sttw_control.platform_online import velocity_state

HERE=P/'actions/continuous_examples/departure_plan'
def write(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def table(p,rows):
    with p.open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def read_request():
    folder=P/'batches/train_00/physical';frozen=json.loads((folder/'resolved_config.json').read_text())
    first=frozen['ground_handoff']['handoff_variants'][0];assert first['root_slot']==first['action_slot']==0
    gside=int(first['side']);gx=float(first['section_x'])
    world=frozen['world_map_spec']
    with np.load(frozen['platform_online']['relative']['raster']) as z:raster=dict(z)
    with np.load(frozen['ground_handoff']['reference_path']) as z:published={'s':z['s'],**{k:z[k][0:1] for k in ('xy','heading','curvature')}}
    with np.load(P/'export/train/train_00/observed_inputs.npz') as z:q,v=z['t0_qpos_native'][0],z['t0_qvel_native'][0]
    return folder,frozen,first,gside,gx,world,raster,published,q,v

def preview_commitment(route,published,q,v):
    near=int(((published['xy'][0]-q[:2])**2).sum(1).argmin())
    speed=velocity_state(torch.from_numpy(q[None]),torch.from_numpy(v[None]))[:,0];yaw=euler(torch.from_numpy(q[None,3:7]))[:,2]
    pose=torch.tensor([[float(q[0]),float(q[1]),float(yaw[0])]]);request=torch.tensor([2.])
    look=route.pursuit(route.s[near:near+1],pose,speed,request)['lookahead']
    commit=float(committed_progress(route.s[near],look,request,.015).item())
    # Reverse the controller's frozen continuous-arc commitment to get this request's nominal publication slack.
    slack=max(0.,(commit-float(route.s[near])-float(look))/float(request)-.02)
    return near,request,look,commit,slack

def main(device,continuous_alpha=False):
    torch.set_num_threads(1)
    here=HERE/('continuous_alpha_wide_batched' if continuous_alpha else 'three_alpha_batched')
    if device!='cpu':here=here/device.replace(':','_')
    here.mkdir(exist_ok=True,parents=True)
    old=P.parent/'chapter3_continuous_p0b_20261123/analysis/p1_dev_prefixes'
    folder,frozen,first,gside,gx,world,raster,published,q,v=read_request()
    declared=dict(role='one known-map TRAIN CPU engineering check; no measured post-departure labels opened for this decision',map='train_00',root=1250,
       old_support='72 old P0-B DEV records. Reconstruct its original fixed mixture smoke (12 CPU Adam updates, seed 612041) once because no legacy weights were saved. No new formal model fit.',
       date='2026-11-23',current_variant='first TRAIN root, first action slot, assigned near-left gate. Use only its time-zero state.',
       gate_x_m=gx,gate_side=gside,search='two CEM iterations x four real continuous draws plus incumbent, candidate-order seed=923114; tie breaks toward earlier incumbents',
       common_particles='same 16 P1 stratified quantiles and 30-dimensional standard normal vectors used per candidate; jump draw seed 732611; no per-candidate resampling',
       ranges={'y_offset_m':[-.225,.225],'heading_offset_deg':[-8,8],'curvature_m_inv':[-.08,.08],'alpha':[0,1] if continuous_alpha else [0,.5,1]},alpha_mode='continuous' if continuous_alpha else 'nearest of 0, 0.5, 1; transition midpoints go to lower level', immutable='unchanged published prefix and original chassis-heading/lateral reference at step edge',source_checkpoint='legacy_smoke_mixture3.pt',
       stop='single CPU decision only, with 9 opportunities and 144 conditional forecasts; keep current curve/alpha if all rejected. No new vehicle rollout.')
    write(here/'case_contract.json',declared)
    checkpoint=HERE/'legacy_smoke_mixture3.pt';updates=0
    if checkpoint.is_file():
        state=torch.load(checkpoint,map_location='cpu',weights_only=True);model=JumpOutcome(state['width_in'],'mixture3');model.load_state_dict(state['state'])
    else:
        if device!='cpu':raise ValueError('Use the already exported old smoke parameters for GPU timing')
        archive=Dataset.load(old);train=archive.subset(grouping_old_dev(archive)[0])
        model=fit_model(train,'mixture3',12,24,612041)[0];updates=12
        torch.save(dict(width_in=train.x.shape[1],state=model.state_dict()),checkpoint)
    model=model.eval().to(device);ground=FrozenExits(folder,device=device,load_route_bank=False)
    # The unchanged H75 reset selects the nearest published sample and computes its existing pursuit preview.
    hcfg=json.loads((W/frozen['ground_handoff']['bundle']/'config.json').read_text());hcfg['follower']['lookahead_scale']=1.
    route=TorchPathReference(published,hcfg)
    near,request,look,commit,slack=preview_commitment(route,published,q,v)
    output,alpha,log,curves=plan(world,raster,ground,model,q,v,published,float(first['approach_alpha']),commit,gx,gside,
                                 continuous_alpha=continuous_alpha,publish_window_s=slack)
    selected=curves[log['selected']]
    if log['publishable_candidate']==0:assert output is published and alpha==first['approach_alpha']
    assert log['candidate_count']==9 and log['particles_evaluated']==144 and alpha==log['publishable_alpha']
    if log['decision']=='all_vetoed_keep_published':assert output is published and alpha==first['approach_alpha']
    ref=np.stack([x['xy'][0] for x in curves]);idx=int(np.searchsorted(published['s'],commit))
    assert np.array_equal(ref[:,:idx+1],np.broadcast_to(published['xy'][0,:idx+1],ref[:,:idx+1].shape))
    # After the decision, quantify novelty against all 14 references; none are on the planner input path.
    with np.load(P/'actions/approaches.npz') as z:library=z['xy']
    for i,r in enumerate(log['candidate_log']):
        r['nearest_frozen_max_world_xy_m']=float(np.linalg.norm(library-ref[i],axis=-1).max(1).min())
        if i:assert r['nearest_frozen_max_world_xy_m']>0
    tr=log.pop('particle_log');cr=log.pop('candidate_log')
    table(here/'candidates.csv',cr);table(here/'particles.csv',tr)
    np.savez_compressed(here/'highest_scoring_reference.npz',**selected,alpha=log['alpha'])
    np.savez_compressed(here/'publishable_reference.npz',**output,alpha=alpha)
    if not continuous_alpha:assert set(x['alpha'] for x in cr)=={0.,.5,1.}
    np.savez_compressed(here/'all_candidate_xy.npz',s=published['s'],xy=ref,alpha=[x['alpha'] for x in cr],selected=log['selected'])
    u,z=random_draws()
    log.update(device=device,replay_fit_updates_this_invocation=updates,legacy_smoke_fit_updates=12,formal_fit_updates=0,physical_steps=0,
               observed_qpos=q.tolist(),observed_qvel=v.tolist(),projection_sample=near,published_progress_m=float(route.s[near]),initial_preview_m=float(look),
               preview_travel_budget_s=.015,frozen_lower_update_s=.02,model_checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
               common_particles_sha256=hashlib.sha256(u.numpy().tobytes()+z.numpy().tobytes()).hexdigest(),
               positive_score_candidates=sum(r['score']>0 for r in cr),physically_measured_planner_results=0)
    write(here/'receipt.json',log)
    # Timing-only post-decision check on the original recorded vehicle. No suffix enters planning.
    archive=json.loads((folder/'status.json').read_text())['results'][0]
    archive_path=folder/archive['case_dir']/'trajectory.npz'
    with np.load(archive_path) as z:
        t=z['trace'][:,0];x=z['qpos'][:,0];vx0=float(z['qvel'][0,0])
        assert np.array_equal(q,z['qpos'][0]) and np.array_equal(v,z['qvel'][0])
    x_commit=float(published['xy'][0,idx,0]);dx=x_commit-float(q[0]);j=np.flatnonzero(x>=x_commit)[0]
    observed_time=float(np.interp(x_commit,x[j-1:j+1],t[j-1:j+1])-t[0])
    legacy=json.loads((HERE/'receipt.json').read_text())
    timings=dict(current_cpu_s=log['total_s'],historical_continuous_narrow_cpu_s=legacy['total_s'],
       source_trajectory=str(archive_path),input_x_m=float(q[0]),copied_through_x_m=x_commit,forward_distance_m=dx,
       speed_request_m_s=float(request),initial_world_vx_m_s=vx0,at_requested_speed_s=dx/float(request),at_initial_vx_s=dx/vx0,
       archived_arrival_s=observed_time,archive_interpolation_bracket_s=[float(t[j-1]),float(t[j])],
       controller_lookahead_m=float(look),continuous_arc_commitment_m=commit,grid_commitment_arc_m=float(published['s'][idx]),
       nominal_publication_assumption_s=.015,request_deadline_s_from_continuous_arc=slack,
       request_deadline_s_if_extra_grid_slack_used=(float(published['s'][idx])-float(route.s[near])-float(look))/float(request)-.02,
       measured_optimistic_body_arrival_met=log['total_s']<=observed_time,controller_deadline_met=log['deadline_met'],publish_decision=log['publish_decision'],
       proposal=log['selected'],retained_or_publishable=log['publishable_candidate'],actual_hardware_publications=0,
       interpretation='Archive motion to the first copied-through end provides a generous body-arrival check on this one case. Controller lookahead and next lower update require an earlier release. This request allocated publication slack of 15 ms; other commitments imply different budgets.')
    write(here/'timing_window.json',timings)
    if not continuous_alpha and device=='cpu':
        from pandas import read_csv
        scalar=HERE/'three_alpha'
        for filename in ('candidates.csv','particles.csv'):
            old_rows=read_csv(scalar/filename)
            assert old_rows.equals(read_csv(here/filename)),filename
        old_log=json.loads((scalar/'receipt.json').read_text())
        with np.load(scalar/'all_candidate_xy.npz') as old_xy:assert np.array_equal(old_xy['xy'],ref)
        write(here/'scalar_parity.json',dict(comparison='Original sequential-particle CPU output; same fixed physical inputs, CEM draws, candidate curves and common 16 particles',
            generated_xy_arrays_exact=9,candidate_rows_all_fields_exact=9,particle_rows_all_fields_exact=144,exit_admissions_exact=432,
            same_winner=(old_log['selected']==log['selected']),scalar_total_s=old_log['total_s'],batched_total_s=log['total_s'],
            incident_window_s=observed_time,publish_decision=log['publish_decision']))
    print(json.dumps(log,indent=2))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--device',default='cpu');ap.add_argument('--continuous-alpha',action='store_true');a=ap.parse_args();main(a.device,a.continuous_alpha)

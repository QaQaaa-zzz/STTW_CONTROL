"""Plot the actual reference arrays and test the all-veto decision independently."""
from pathlib import Path
import argparse,csv,json
from unittest.mock import patch
import numpy as np
import torch
from continuous_departure_plan import P,plan
from check_continuous_departure_plan import HERE,write,table
from jump_outcome import JumpOutcome
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def audit(continuous_alpha=False):
    here=HERE/('continuous_alpha_wide_batched' if continuous_alpha else 'three_alpha_batched')
    r=json.loads((here/'receipt.json').read_text());case=json.loads((here/'case_contract.json').read_text())
    with (here/'candidates.csv').open() as f:cand=list(csv.DictReader(f))
    with np.load(here/'all_candidate_xy.npz') as z:xy=z['xy'];s=z['s'];winner=int(z['selected'])
    folder=P/'batches/train_00/physical';cfg=json.loads((folder/'resolved_config.json').read_text());world=cfg['world_map_spec']
    with np.load(cfg['ground_handoff']['reference_path']) as z:current={'s':z['s'],**{k:z[k][:1] for k in ('xy','heading','curvature')}}
    with np.load(cfg['platform_online']['relative']['raster']) as z:raster=dict(z)
    with np.load(P/'actions/approaches.npz') as z:old=z['xy']
    i=np.searchsorted(s,r['committed_s_m']);start=float(xy[0,i,0]);edge=world['terrain']['front_x_m'];grid=np.linspace(start,edge,257)
    actual=np.stack([np.interp(grid,x[:,0],x[:,1]) for x in xy]);stored=np.stack([np.interp(grid,x[:,0],x[:,1]) for x in old])
    rows=[]
    for k,y in enumerate(actual):
        distances=np.abs(stored-y);near=int(np.argmin(distances.max(1)))
        rows.append(dict(candidate=k,search_start_x_m=start,step_x_m=edge,published_change_peak_m=float(np.abs(y-actual[0]).max()),
            nearest_archive_on_adjustable_interval=near,nearest_old_lateral_max_m=float(distances[near].max()),nearest_old_lateral_rms_m=float(np.sqrt(np.mean(distances[near]**2)))))
    assert len({x.tobytes() for x in actual[1:]})==8 and all(a['published_change_peak_m']>0 and a['nearest_old_lateral_max_m']>0 for a in rows[1:])
    table(here/'novelty_after_commitment.csv',rows)
    state=torch.load(HERE/'legacy_smoke_mixture3.pt',map_location='cpu',weights_only=True);model=JumpOutcome(state['width_in'],'mixture3')
    model.load_state_dict(state['state']);model.eval();q=np.array(r['observed_qpos'],np.float32);v=np.array(r['observed_qvel'],np.float32)
    initial_alpha=float(cfg['ground_handoff']['handoff_variants'][0]['approach_alpha'])
    veto=lambda ground,curves,*a,**k:(np.zeros(len(curves),int),np.ones(len(curves),int),np.zeros((len(curves),3),dtype=bool))
    with patch('continuous_departure_plan.score_approach_particles',side_effect=veto):
        same,alpha,check,_=plan(world,raster,None,model,q,v,current,initial_alpha,r['committed_s_m'],case['gate_x_m'],case['gate_side'],population=2,iterations=1,continuous_alpha=continuous_alpha,publish_window_s=1.)
    assert check['decision']=='all_vetoed_keep_published' and same is current and alpha==initial_alpha and all(x['score']==0 for x in check['candidate_log'])
    timing=json.loads((here/'timing_window.json').read_text())
    with np.load(here/'publishable_reference.npz') as z:
        assert all(np.array_equal(z[k],current[k]) for k in current) and float(z['alpha'])==initial_alpha
    levels={float(c['alpha']) for c in cand}
    if not continuous_alpha:assert levels=={0.,.5,1.}
    write(here/'decision_audit.json',dict(unique_generated_geometries=8,selected_new_shape=rows[winner],
          all_veto_fixture='Artificial all-reject exit scorer only. Same 3 original reference tensors and same s returned by object identity; alpha unchanged.',
          actual_decision=r['decision'],fixture_decision=check['decision'],receipt_action_only='Offline proposal; nothing was sent to a vehicle.',
          alpha_levels_observed=sorted(levels),eligible_reference_matches_original_exactly=True,publish_decision=r['publish_decision'],
          nominal_request_deadline_s=r['publish_window_s'],archived_body_arrival_s=timing['archived_arrival_s'],actual_cpu_wall_s=r['total_s'],deadline_met=r['deadline_met'],
          zero_formal_updates=True,zero_vehicle_rollouts=True))
    fig=plt.figure(figsize=(10.5,6.1),layout='constrained');gridplot=fig.add_gridspec(2,2,height_ratios=(.8,1.1));top=fig.add_subplot(gridplot[0,:]);profile=fig.add_subplot(gridplot[1,0]);score=fig.add_subplot(gridplot[1,1])
    for k,x in enumerate(xy):
        if k not in (0,winner):top.plot(x[:,0],x[:,1],color='#a5b5bd',lw=1.1);profile.plot(grid,actual[k],color='#a5b5bd',lw=1.1)
    for k,col,label in [(0,'#703b26','Previously published'),(winner,'#005a89','Highest-scoring proposal (too late)')]:
        top.plot(xy[k,:,0],xy[k,:,1],color=col,lw=2,ls='--' if k==0 else '-',label=label)
        profile.plot(grid,actual[k],color=col,lw=2,ls='--' if k==0 else '-')
    top.plot(q[0],q[1],'ko',ms=5,label='Observed initial position')
    top.axvline(edge,ls=':',color='#7e4082',label='Step edge');top.axvline(start,ls=':',color='#354a52',label='End of committed reference')
    top.plot([case['gate_x_m']]*2,[.06,.55],color='#31936a',lw=3,label='Assigned left gate (partial extent)')
    top.set(xlim=(q[0]-.4,case['gate_x_m']+.35),ylim=(-.64,.64),xlabel='World x (m)',ylabel='World y (m)',title='Previously published route retained at the deadline')
    top.set_aspect('equal');top.legend(loc='lower center',bbox_to_anchor=(.5,1.17),ncol=3,fontsize=8,frameon=False)
    profile.axvline(edge-1.1,ls=':',color='#7e4082');profile.text(edge-1.1,.1,' Trigger',fontsize=8,ha='right')
    profile.set(xlabel='World x (m)',ylabel='Reference y (m)',title='Adjustable approach interval',xlim=(start,edge))
    scores=np.array([float(c['score']) for c in cand]);score.bar(np.arange(len(cand)),scores,color=['#703b26' if k==0 else '#005a89' if k==winner else '#a5b5bd' for k in range(len(cand))])
    score.set(xlabel='Candidate (0 = previously published)',ylabel='Predicted joint probability',title='Jump and exit model scores',xticks=np.arange(len(cand)),ylim=(0,max(scores)*1.16))
    fig.savefig(here/'decision_xy.png',dpi=175);plt.close(fig)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--continuous-alpha',action='store_true');torch.set_num_threads(1);audit(ap.parse_args().continuous_alpha)

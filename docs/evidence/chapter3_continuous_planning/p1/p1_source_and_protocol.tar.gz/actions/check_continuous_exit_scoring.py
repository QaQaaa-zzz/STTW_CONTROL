"""Compare frozen full ground forecasts on physical TRAIN observations and dynamically built references."""
import argparse,csv,hashlib,inspect,json,sys,time
from pathlib import Path
from unittest.mock import patch
import numpy as np
import torch
from continuous_departures import departure_options
A=Path(__file__).resolve().parent;P=A.parent;W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path[:0]=[str(P/'model'),str(W/'learning/src'),str(W/'learning/cli')]
from frozen_exit_value import FrozenExits
from sttw_control.platform_online import PlatformDepartureQuery
OUT=A/'continuous_examples/departures'
SRC=P/'model/frozen_exit_value.py'
KEYS=['xy','heading','curvature']
GATE_X=12.7;GATE_SIDE=1;REMAIN=5.1
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,rows):
    with path.open('w') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def inspect_native(call,forecast=None):
    # The native API returns admission and choice. Capture the raw *computed* ranking tensor
    # and predicates at function return, without reimplementing the score or changing that API.
    target=inspect.unwrap(PlatformDepartureQuery.choose).__code__;got=[];prior=sys.getprofile()
    def profile(frame,event,arg):
        if frame.f_code is target and event=='return':
            st=frame.f_locals
            if forecast is not None:
                for k in ('poses','v','domain'):
                    x=st[k].detach().cpu().numpy()
                    forecast[k]=x.reshape(3,3,*x.shape[1:])[1].copy()
            for key in ['score','clearance','safe','in_domain','gate','goal_hold','feasible']:
                got.append(st[key].reshape(-1,3)[1].detach().cpu().numpy().tolist())
    sys.setprofile(profile)
    try:result=call()
    finally:sys.setprofile(prior)
    assert len(got)==7
    return dict(choice=int(result[0][0]),feasible=result[1][0].tolist(),native_choice=result[2][0].tolist(),
                native_admitted=result[3][0].tolist(),direction_scores=got[0],clearance_m=got[1],safe=got[2],
                in_domain=got[3],correct_gate=got[4],goal_hold=got[5],native_feasible=got[6])
def first_training_cases(folder):
    with (folder/'p1_lanes.csv').open() as f:rows=list(csv.DictReader(f))
    out={}
    for row in rows:
        g=int(row['geometry'])
        if g in (1,2) and g not in out and row['planned_departure']=='0' and row['query_file']:
            j=int(row['query_file_row']);z=dict(np.load(row['query_file']))
            assert float(z['remaining_s'])>=REMAIN
            out[g]=dict(lane=int(row['lane']),root=int(row['bank_row']),tick=int(z['tick']),q=z['qpos'][j:j+1],
              v=z['velocity'][j:j+1],prev=z['previous_velocity'][j:j+1],progress=float(z['projection_progress'][j]),
              ids=z['branch_ids'][j:j+1],query_file=row['query_file'],query_file_row=j)
    assert set(out)=={1,2};return out
def run(before=False):
    folder=P/'batches/train_00/physical';cases=first_training_cases(folder);fixed=FrozenExits(folder);torch.set_num_threads(1)
    with np.load(A/'approaches.npz') as z:library=dict(z)
    fixed_case={}
    for g,o in cases.items():
        for mode in [False,True]:
            fixed_case[str((g,mode))]=inspect_native(lambda:fixed.score(o['q'],o['v'],o['prev'],REMAIN,o['ids'],GATE_X,GATE_SIDE,2.,return_native=True,share_direction_rollouts=mode))
    backup=OUT/'scorer_before_refactor.json'
    if before:
        if backup.exists():raise ValueError('Historical scorer output already exists')
        backup.write_text(json.dumps(dict(source_sha256=digest(SRC),cases=fixed_case),indent=2)+'\n');return
    from continuous_departures import score_approach
    import frozen_exit_value
    old=json.loads(backup.read_text());assert fixed_case==old['cases']
    with patch.object(frozen_exit_value,'mapped_arrays',side_effect=AssertionError('Dynamic scorer must not open the route bank')):
        dynamic=FrozenExits(folder,load_route_bank=False)
    assert not hasattr(dynamic,'bank') and not hasattr(dynamic,'approach')
    reports=[];result={};times=[]
    fixtures=[('signed_left',1,{'s':library['s'],**{k:library[k][1] for k in KEYS}}),('signed_right',2,{'s':library['s'],**{k:library[k][2] for k in KEYS}})]
    for name in ['left_A','right_B']:
        with np.load(A/'continuous_examples'/(name+'.npz')) as z:fixtures.append((name,1,dict(z)))
    for name,g,curve in fixtures:
        o=cases[g];legacy=name.startswith('signed')
        # Controller progress is known for legacy rows; a different proposed curve requires
        # projecting the same recorded pose onto that input, not transplanting its old progress.
        pr=o['progress'] if legacy else None
        for mode in [False,True]:
            fn=lambda:score_approach(dynamic,curve,o['q'][0],o['v'][0],o['prev'][0],REMAIN,GATE_X,GATE_SIDE,
                     progress_m=pr,return_native=True,share_direction_rollouts=mode)
            forecast={} if not legacy and mode else None
            stats=inspect_native(lambda:fn()[1],forecast);join,_=fn()
            if forecast is not None:
                np.savez_compressed(OUT/(name+'_predicted_ground.npz'),**forecast,observed_qpos=o['q'][0],model_dt_s=.02,
                   measured_train_lane=o['lane'],gate_x_m=GATE_X,side=GATE_SIDE)
                measured=[]
                for _ in range(7):
                    start=time.perf_counter_ns();fn();measured.append((time.perf_counter_ns()-start)/1e6)
                times.append(dict(approach=name,mode='share_direction_rollouts',repetitions=len(measured),cpu_threads=torch.get_num_threads(),
                    steps=int(REMAIN/.02),median_ms=float(np.median(measured)),p95_ms=float(np.percentile(measured,95)),
                    scope='geometry, frozen ground forecasts and selector; warmed models, no disk I/O or telemetry'))
            if legacy:assert stats==fixed_case[str((g,mode))]
            result[str((name,mode))]=stats
            for i,d in enumerate(('left','straight','right')):
                reports.append(dict(approach=name,provenance='archived_geometry' if legacy else 'new_curve',geometry_id_required=False,
                      measured_train_lane=o['lane'],measured_train_root=o['root'],query_tick=o['tick'],world_x_m=float(o['q'][0,0]),
                      world_y_m=float(o['q'][0,1]),controller_progress_supplied=legacy,join=join,remaining_s=REMAIN,forecast_hz=50,
                      model_steps=int(REMAIN/.02),section_x_m=GATE_X,target_side=GATE_SIDE,speed_mps=2.,share_direction_rollouts=mode,direction=d,
                      physical_task_result='not_observed_for_this_evaluation',raw_score=stats['direction_scores'][i],
                      predicted_min_clearance_m=stats['clearance_m'][i],clearance_admitted=stats['safe'][i],
                      in_domain=stats['in_domain'][i],predicted_correct_gate=stats['correct_gate'][i],predicted_goal_hold=stats['goal_hold'][i],
                      admitted=stats['feasible'][i],native_chosen_for_this_incumbent=stats['native_choice'][i],
                      final_direction_with_straight_incumbent=stats['choice'],matched_original_geometry_score=legacy))
    write(OUT/'full_ground_forecast.csv',reports);write(OUT/'full_ground_timings.csv',times)
    summary=dict(role='Frozen numerical ground-model forecasts only',old_scorer_sha256=old['source_sha256'],shared_scorer_sha256=digest(SRC),
        original_scorer_outputs_unchanged_for_both_modes=True,old_and_dynamic_outputs_exact=True,new_bank_free_construction_verified=True,
        actual_measured_train_states={str(g):{k:v for k,v in o.items() if k in ('lane','root','tick','query_file','query_file_row')} for g,o in cases.items()},
        common_gate=dict(x_m=GATE_X,side=GATE_SIDE,remaining_s=REMAIN,steps=int(REMAIN/.02),speed_mps=2.),
        choices={name:result[str((name,False))] for name,g,curve in fixtures},timings=times,geometry_driven=True,physical_steps=0,training_updates=0)
    (OUT/'full_ground_forecast_receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--capture-original',action='store_true');run(ap.parse_args().capture_original)

"""CPU-only comparison of on-demand exit geometry, the original bank and two unseen input curves."""
import csv,json,os,sys,time,types
from pathlib import Path
import numpy as np
from continuous_departures import departure_options
A=Path(__file__).resolve().parent
P=A.parent;W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path[:0]=[str(P/'model'),str(W/'learning/src'),str(W/'learning/cli')]
from frozen_exit_value import FrozenExits,mapped_arrays
K=('xy','heading','curvature')
def write(file,rows):
    with file.open('w') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def main():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from sttw_control.torch_path_reference import TorchPathReference
    import torch
    out=A/'continuous_examples/departures';out.mkdir(exist_ok=True)
    ref=dict(np.load(A/'approaches.npz'));bank=mapped_arrays(P/'shared/departures.npz')
    lookup=types.SimpleNamespace(approach=ref['xy'],bank=bank,bank_len=len(ref['s']))
    original={g:{'s':ref['s'],**{k:ref[k][g] for k in K}} for g in (1,2)}
    f=P/'batches/train_00/physical/p1_lanes.csv'
    recorded=[];first=None;probes={}
    with f.open() as stream: archive=list(csv.DictReader(stream))
    for r in archive:
        g=int(r['geometry'])
        if g not in original or r['planned_departure']!='0' or not r['query_file']:continue
        j=int(r['query_file_row']);z=dict(np.load(r['query_file']));pos=z['qpos'][j,:2];progress=z['projection_progress'][j]
        arc,arr=departure_options(original[g],pos,progress)
        refs=FrozenExits.branch_ids(lookup,g,pos,progress);np.testing.assert_array_equal(refs,z['branch_ids'][j])
        assert np.all(refs==len(ref['xy'])+(g*3+np.arange(3))*len(ref['s'])+arc)
        diffs={k:float(np.abs(arr[k]-bank[k][refs]).max()) for k in K}
        assert all(arr[k].tobytes()==bank[k][refs].tobytes() for k in K), (g,arc,diffs)
        arc0,arr0=departure_options(original[g],pos)
        nom=FrozenExits.branch_ids(lookup,g,pos)
        assert all(arr0[k].tobytes()==bank[k][nom].tobytes() for k in K)
        recorded.append(dict(geometry=g,lane=r['lane'],root=r['bank_row'],query_tick=r['query_tick'],world_x_m=float(pos[0]),world_y_m=float(pos[1]),progress_m=float(progress),join=arc,pose_only_join=arc0,**{'max_abs_'+k:v for k,v in diffs.items()}))
        probes.setdefault(g,(pos.copy(),float(progress)))
    write(out/'legacy_measured_queries.csv',recorded)
    assert set(probes)=={1,2}
    common_pose=probes[1][0]  # Same archived position used as a numerical probe for both new references.
    fig,axes=plt.subplots(2,2,figsize=(11,5.2),layout='constrained')
    colors=['#005f86','#686868','#a23c21'];names=['left','straight','right']
    timing=[];examples=[]
    for i,name in enumerate(('left_A','right_B')):
        route=dict(np.load(A/'continuous_examples'/(name+'.npz')))
        # A prediction does not supply the exact controller progress on an unseen reference.
        # Independently project this world XY and compare both public interfaces.
        xy=route['xy'][0];s=route['s'];segs=np.diff(xy,axis=0).astype(float)
        u=((common_pose.astype(float)-xy[:-1])*segs).sum(1)/np.einsum('ij,ij->i',segs,segs);u=np.clip(u,0,1)
        seg=np.linalg.norm(xy[:-1]+u[:,None]*segs-common_pose,axis=1).argmin()
        progress=(1-u[seg])*s[seg]+u[seg]*s[seg+1]
        join,opts=departure_options(route,common_pose,progress);j2,opt2=departure_options(route,common_pose)
        assert join==j2 and all(np.array_equal(opts[k],opt2[k]) for k in K)
        assert all(np.isfinite(opts[k]).all() for k in K)
        for k in K:np.testing.assert_array_equal(opts[k][:,:join+1],np.repeat(route[k][:,:join+1],3,0))
        saved=out/(name+'_exits.npz');np.savez_compressed(saved,**opts)
        native=TorchPathReference(opts,{},device='cpu',route_ids=[0,1,2]);use=native.at(torch.full((3,),14.0))[0].numpy()
        assert use[0,1]>use[1,1]>use[2,1]
        y=np.array([[np.interp(px,xx[:,0],xx[:,1]) for px in (12.7,14.,15.,16.5)] for xx in opts['xy']])
        for d in range(3):examples.append(dict(approach=name,direction=names[d],join=join,join_arc_m=float(s[join]),join_x_m=float(opts['xy'][d,join,0]),observed_x_fixture_only=float(common_pose[0]),observed_y_fixture_only=float(common_pose[1]),projected_progress_m=float(progress),y_at_x12p7_m=y[d,0],y_at_x14_m=y[d,1],y_at_x15_m=y[d,2],y_at_x16p5_m=y[d,3],file=saved.name))
        for ax,limits in zip(axes[i],[(5,17.2),(common_pose[0]-.2,16.9)]):
            ax.plot(xy[:,0],xy[:,1],color='#897a55',lw=2.3,alpha=.55,label='Supplied approach')
            for d,label in enumerate(names):
                xx=opts['xy'][d,join:];ax.plot(xx[:,0],xx[:,1],color=colors[d],lw=1.7,ls=('-','--','-.')[d],label=label.capitalize()+' reference')
            ax.plot(xy[join,0],xy[join,1],marker='o',markerfacecolor='white',markeredgecolor='black',label='Reference splice',ls='none')
            ax.plot(*common_pose,'kx',label='Common pose probe',ms=5)
            ax.axvline(10.3,color='#8552a0',ls=':',lw=1);ax.set_xlim(*limits);ax.set_ylim(-.5,.50);ax.set_aspect('equal');ax.set_xlabel('World x (m)');ax.set_ylabel('World y (m)')
        axes[i,0].set_title(name+'   |   approach and exit options',loc='left');axes[i,1].set_title('Exit detail   |   reference geometry',loc='left')
        for mode,pr in [('supplied_progress',progress),('pose_only',None)]:
            for _ in range(20):departure_options(route,common_pose,pr)
            times=[]
            for _ in range(500):
                t=time.perf_counter_ns();departure_options(route,common_pose,pr);times.append((time.perf_counter_ns()-t)/1e6)
            timing.append(dict(approach=name,mode=mode,calls=len(times),points_per_direction=len(s),directions_per_call=3,median_ms=float(np.median(times)),p95_ms=float(np.percentile(times,95)),max_ms=float(max(times))))
    axes[0,0].legend(ncol=3,loc='lower left',bbox_to_anchor=(0,1.5),frameon=False,fontsize=8)
    fig.savefig(out/'references_xy.png',dpi=190);plt.close(fig)
    write(out/'new_reference_checks.csv',examples);write(out/'cpu_geometry_timings.csv',timing)
    receipt=dict(role='Offline geometry-only CPU diagnostic. No new dynamics, fit, selector, or closed-loop execution.',original_queries=len(recorded),per_geometry={str(g):sum(x['geometry']==g for x in recorded) for g in original},legacy_physical_branch_rows=3*len(recorded),all_original_xy_heading_curvature_bitwise_equal=True,pose_only_queries_preserve_P1_lookup=True,new_approaches=['left_A','right_B'],physical_steps=0,fit_updates=0,tested_refs=len(examples),original_pose_as_fixture_only=dict(train_map='train_00',geometry=1,world_xy_m=common_pose.tolist()),generation_source=str(W/'learning/cli/run_platform_task_oracle.py'),timing=timing)
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()

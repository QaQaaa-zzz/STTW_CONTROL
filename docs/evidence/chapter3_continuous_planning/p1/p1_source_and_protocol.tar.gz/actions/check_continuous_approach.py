"""CPU-only geometric checks of the continuous construction against the registered P1 inputs."""
import json,sys
from pathlib import Path
import numpy as np,pandas as pd
from scipy.integrate import quad
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import torch
from continuous_approach import Boundary, Quintic,generate_reference
sys.path.insert(0,'/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src')
from sttw_control.torch_path_reference import TorchPathReference
A=Path(__file__).resolve().parent
out=A/'continuous_examples';out.mkdir(exist_ok=True)
# Synthetic already-published straight geometry; independent of the old/P1 reference banks.
s=np.arange(1200,dtype=float)*.025
source=dict(s=s,xy=np.c_[s,np.zeros_like(s)].astype(np.float32),heading=np.zeros(len(s),np.float32),curvature=np.zeros(len(s),np.float32))
np.savez_compressed(out/'published_straight.npz',**source)
front,offset,commit=10.3,1.1,5.012
examples={'left_A':Boundary(.082,np.deg2rad(2.3),-.028),'right_B':Boundary(-.061,np.deg2rad(-1.35),.041)}
def neg(z):return Boundary(-z.y,-z.heading,-z.curvature)
def mirror_route(z):
 return {**z,'xy':z['xy']*np.array([1,-1],dtype=z['xy'].dtype),'heading':-z['heading'],'curvature':-z['curvature']}
def assert_parity(first,mirror):
 for name in ('s','xy','heading','curvature'):np.testing.assert_array_equal(first[name],mirror_route(mirror)[name])
def forward(route,co,tar,ey=0.,ea=0.):return generate_reference(route,co,front,offset,tar,ey,ea)
zero,_=forward(source,commit,Boundary(0.,0.,0.));assert np.max(abs(zero['xy'][0,:,1]))==0 and np.max(abs(zero['heading']))==0 and np.max(abs(zero['curvature']))==0
with np.load(A/'approaches.npz') as z:old=dict(z)
tbl=pd.read_csv(A/'action_slots.csv').drop_duplicates('route_id')
rows=[];proximity=[];measure=[]
for name,t in examples.items():
 rt,meta=forward(source,commit,t);rm,_=forward(source,commit,neg(t));assert_parity(rt,rm)
 np.savez_compressed(out/(name+'.npz'),**rt);join=meta['join_index']
 for f in ('xy','heading','curvature'):np.testing.assert_array_equal(rt[f][0,:join+1],source[f][:join+1])
 # Continuity in the underlying analytic curve, independent of uniform-grid sampling.
 b0=Boundary(float(source['xy'][join,1]),float(source['heading'][join]),float(source['curvature'][join]))
 p=Quintic(meta['join_x_m'],b0,meta['target_x_m'],t);q=Quintic(meta['target_x_m'],t,front,Boundary(0.,0.,0.))
 residual=max(float(np.max(np.abs(np.asarray(poly.at(x))-np.array([state.y,state.heading,state.curvature])))) for poly,x,state in [(p,p.x0,b0),(p,p.x1,t),(q,q.x0,t),(q,q.x1,Boundary(0.,0.,0.))]);assert residual<1e-10
 # Independent adaptive quadrature for arc sampling. Use the native float grid as exported to H75.
 arcq=lambda obj,x:quad(lambda x:1./np.cos(float(obj.at(x)[1])),obj.x0,x,epsabs=1e-12)[0]
 d0=arcq(p,p.x1);d1=arcq(q,q.x1)
 xy=rt['xy'][0];sel=np.flatnonzero((xy[:,0]>=meta['join_x_m'])&(xy[:,0]<front));ae=[]
 for i in sel[::5]:
  x=xy[i,0];expected=arcq(p,x) if x<p.x1 else d0+arcq(q,x)
  ae.append(abs(expected-(s[i]-s[join])))
 arc_error=max(ae);assert arc_error<2e-6
 # Actual route-consumer interpolation at analytic join/target/edge arc coordinates.
 consumer=TorchPathReference(rt,{},device='cpu')
 obs=[]
 for landmark,ss,state in [('join',s[join],b0),('target',meta['target_s_m'],t),('edge',meta['edge_s_m'],Boundary(0.,0.,0.))]:
  cxy,ch,ck=consumer.at(torch.tensor([ss],dtype=torch.float32));me=np.r_[cxy[0].numpy(),ch.item(),ck.item()]
  obs.append(dict(candidate=name,landmark=landmark,s_m=ss,consumer_xy=me[:2].tolist(),consumer_heading_deg=np.rad2deg(me[2]),consumer_curvature_m_inv=me[3],target_y_error_m=me[1]-state.y,target_heading_error_deg=np.rad2deg(me[2]-state.heading),target_curvature_error_m_inv=me[3]-state.curvature))
 measure+=obs
 xx=np.linspace(meta['join_x_m'],front,1600); y=np.where(xx<=p.x1,p.at(np.minimum(xx,p.x1))[0],q.at(np.maximum(xx,p.x1))[0])
 oldd=[];approach_d=[]
 for i,path in enumerate(old['xy']):
  delta=y-np.interp(xx,path[:,0],path[:,1]);oldd.append(np.max(abs(delta))); approach_d.append(np.max(np.abs(delta[xx<=p.x1])))
  proximity.append(dict(candidate=name,archived_route_id=i,max_abs_lateral_gap_m=oldd[-1],pretrigger_max_abs_lateral_gap_m=approach_d[-1],rms_lateral_gap_m=np.sqrt(np.mean(delta**2))))
 assert min(oldd)>1e-3 and min(approach_d)>1e-3
 xpre=np.linspace(p.x0,p.x1,4097);xpost=np.linspace(q.x0,q.x1,4097)
 kpre=max(abs(p.at(xpre)[2]));kpost=max(abs(q.at(xpost)[2]))
 maxk=max(kpre,kpost);nominal=2.
 assert kpre<=tbl.approach_max_abs_kappa_per_m.max() and kpost<=tbl.rb_blend_max_abs_kappa_per_m.max()
 for field,val in [('entry_y_m',t.y),('entry_heading_deg',np.rad2deg(t.heading)),('entry_kappa_per_m',t.curvature)]:assert tbl[field].min()<=val<=tbl[field].max()
 rows.append(dict(candidate=name,**meta,target_heading_deg=np.rad2deg(t.heading),nominal_speed_m_s=nominal,max_abs_approach_curvature_m_inv=kpre,approach_peak_below_all_archived_pretrigger_peaks=bool(kpre<tbl.approach_max_abs_kappa_per_m.min()),max_abs_trigger_to_edge_curvature_m_inv=kpost,edge_segment_peak_inside_archived_minmax=bool(tbl.rb_blend_max_abs_kappa_per_m.min()<=kpost<=tbl.rb_blend_max_abs_kappa_per_m.max()),max_nominal_yaw_rate_rad_s=nominal*maxk,max_nominal_lateral_accel_m_s2=nominal**2*maxk,nearest_archived_route_id_by_worst_y=int(np.argmin(oldd)),min_over_14_max_abs_y_gap_m=min(oldd),min_over_14_pretrigger_max_abs_y_gap_m=min(approach_d),nearest_pretrigger_route_id=int(np.argmin(approach_d)),bc_value_heading_curvature_max_abs_residual=residual,max_independent_arc_residual_m=arc_error,prefix_samples_exact=join+1))
# Mirror/refinement with a nonstraight, nonzero-curvature committed end frame, not only y=0.
# Arc-consistent sampled incoming curve, obtained by dense forward analytic integration.
xx=np.linspace(0,31,20001);mm=.055*.55*np.cos(.55*xx);ss=np.r_[0,np.cumsum((np.hypot(1,mm)[:-1]+np.hypot(1,mm)[1:])*.5*np.diff(xx))];x=np.interp(s,ss,xx)
f=.055*np.sin(.55*x);m=.055*.55*np.cos(.55*x);b=-.055*.55**2*np.sin(.55*x);sine=dict(s=s,xy=np.c_[x,f],heading=np.arctan(m),curvature=b/(1+m*m)**1.5)
first,fm=forward(sine,commit,examples['left_A'],.01,.03);second,_=forward(mirror_route(sine),commit,neg(examples['left_A']),-.01,-.03);assert_parity(first,second)
for k in ('xy','heading','curvature'):np.testing.assert_array_equal(first[k][0,:fm['join_index']+1],sine[k][:fm['join_index']+1])
for late in (front-offset,front):
 try:forward(source,late,examples['left_A'])
 except ValueError as e:assert 'before' in str(e)
 else:raise AssertionError('Late anchor silently wrote a replacement')
pd.DataFrame(rows).to_csv(out/'geometry_checks.csv',index=False);pd.DataFrame(proximity).to_csv(out/'all14_reference_differences.csv',index=False);pd.DataFrame(measure).to_csv(out/'consumer_landmark_checks.csv',index=False)
extent=[float(min(r['join_x_m'] for r in rows)),front]
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Noto Sans CJK SC','Noto Sans CJK JP','DejaVu Sans'],'axes.unicode_minus':False})
fig,axes=plt.subplots(2,1,figsize=(10.5,5.7),layout='constrained',height_ratios=[1,1.12])
for r in old['xy']:
 sel=(r[:,0]>=3.9)&(r[:,0]<=10.9);axes[0].plot(*r[sel].T,color='#c9ced0',lw=.75,alpha=.75)
for c,(name,t) in zip(('#c56522','#157f76'),examples.items()):
 rt,_=forward(source,commit,t);xy=rt['xy'][0];sel=(xy[:,0]>=3.9)&(xy[:,0]<=10.9)
 axes[0].plot(*xy[sel].T,c=c,lw=2,label=f"{name} · y={t.y:+.3f} m, θ={np.rad2deg(t.heading):+.2f}°")
 axes[1].plot(xy[sel,0],rt['curvature'][0,sel],c=c,lw=1.8)
 axes[0].scatter([front-offset],[t.y],marker='o',s=30,c=c)
for ax in axes:
 ax.axvline(extent[0],color='#4f5360',ls=':',lw=1);ax.axvline(front-offset,color='#7a488d',ls='--',lw=1);ax.axvline(front,color='#353a3c',ls=':',lw=1);ax.set_xlim(3.9,10.9);ax.grid(alpha=.18);ax.set_xlabel('世界前进方向 x（m）')
axes[0].set_ylim(-.5,.5);axes[0].set_aspect('equal',adjustable='box');axes[0].set_ylabel('横向 y（m）');axes[0].legend(loc='lower left',ncol=2,frameon=False,fontsize=8)
axes[1].set_ylabel('曲率（1/m）');axes[1].set_title('竖线从左至右是已承诺段末端、跳跃触发位置、台阶边缘',fontsize=10)
fig.suptitle('由两组连续目标现场生成的参考曲线\n灰色为采集用的 14 条参考，彩色为新生成曲线；下图显示触发点和台阶前后的曲率变化',fontsize=12)
fig.savefig(out/'continuous_reference_xy.png',dpi=155);plt.close(fig)
receipt=dict(scope='CPU-only generation and reference interpolation. No physical rollout, no new trained model, no safety certification.',construction='x-forward planar quintic on each of two intervals; y, dy/dx, d2y/dx2 fixed from (lateral position, heading, curvature) at both ends. Common caller-specified post-edge tangent with zero curvature. Uniform arc grid preserved, untouched prefix through first original sample >= commitment.',front=front,trigger_offset=offset,commitment_distance_supplied=commit,strict_straight_zero_y_heading_curvature=True,strict_mirrored_arrays_straight_and_nonstraight_prefix=True,late_commit_rejected=True,all_14_differences_verified=True,consumer='Actual TorchPathReference.at, CPU FP32, on 1 x 1200 route bank',finite_grid='Constraint values in analytic curve are exact to floating-point precision; sampled interpolants may differ inside a 2.5cm arc cell. Inspect consumer_landmark_checks.csv.',ranges=tbl[['entry_y_m','entry_heading_deg','entry_kappa_per_m','approach_max_abs_kappa_per_m','rb_blend_max_abs_kappa_per_m']].agg(['min','max']).to_dict(),limitations=['The example commitment uses an explicitly declared sample cutoff; the publisher must supply actual progress + already-consumed preview and travel over control/publication latency. No default zero commitment. A late commitment leaves too little pre-trigger room and is rejected if already past target; a short remaining length may demand excessive curvature.','The common edge tangent matters: changing endpoint y/heading across candidates changes the route followed near handback and can confound entry comparisons. The supplied neutral tail itself differs from several archived donors.','The requested trigger-point y, heading and signed curvature each fall inside their archived one-coordinate min/max. By contrast the approach-segment peak |curvature| is 0.028 / 0.041 m^-1, both BELOW the smallest archived peak (0.064841; maximum 0.858172 m^-1). Only the upper limit is respected. Trigger-to-edge peaks 0.526163 / 0.365764 m^-1 individually fall inside the archived 0..1.432408 m^-1 range. These comparisons are descriptive and are not evidence of multivariate training support. See jump_inputs.csv for the separate 39-coordinate audit.','Nominal yaw rate v*k and lateral acceleration v^2*k are geometric demands at 2 m/s. These values do not demonstrate actuator tracking or flight feasibility.'])
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(pd.DataFrame(rows).to_string(index=False))

"""Prepare cross-map P1 candidate references and non-test collection assignments on CPU."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.interpolate import CubicHermiteSpline


LEGACY=[(0,0.),(1,0.),(2,0.),(1,.5),(1,1.)]
WEIGHTS=np.array([[0.,.20,.15],[.39,.10,.06],[0.,.33,.55],[.51,.14,.26],[.08,.10,.81]])
SIGN_COLOURS={-1:'#a75424',0:'#5a6472',1:'#007397'}
FIELDS=('xy','heading','curvature')


def generate(parent,out):
    proto=json.loads((parent/'protocol.json').read_text()); trigger=float(proto['trigger_m'])
    front=json.loads((parent/'right_offset/world.json').read_text())['terrain']['front_x_m']
    assert np.isclose(trigger,9.2) and np.isclose(front,10.3) and [tuple(x) for x in proto['old_actions']]==LEGACY
    with np.load(parent/'approaches.npz') as archive:
        old={k:archive[k] for k in archive.files}
    arc=old['s']; dx=float(np.median(np.diff(arc)))
    # Generate as functions of physical world x, then sample on exactly the frozen tracking arclength grid.
    # Extend only the terminal straight section to allow the arclength reparameterization to finish.
    mesh=np.arange(-5.,25.21,dx/5)
    native=[]
    for xy,h in zip(old['xy'],old['heading'],strict=True):
        x,y=xy.T
        fn=CubicHermiteSpline(x,y,np.tan(h),extrapolate=False)
        native.append(fn)
    def donor_values(index,xq):
        bound=np.clip(xq,native[index].x[0],native[index].x[-1])
        return native[index](bound)
    refs={k:list(old[k][:3].copy()) for k in FIELDS}
    names=list(proto['geometry'][:3])
    meta=[dict(source=f'exact_P0B_geometry_{i}',side=0,weight_flat=np.nan,weight_half=np.nan,weight_signed=np.nan,
               nominal_y=np.nan,nominal_heading_deg=np.nan,rejoin=i) for i in range(3)]
    slots=[dict(action_slot=j,route_id=i,role='legacy_anchor',fixed_alpha=aa,pair=-1,sign=0) for j,(i,aa) in enumerate(LEGACY)]
    for pair,w in enumerate(list(WEIGHTS)+[np.zeros(3)]):
        for sign in ([1,-1] if pair<5 else [0]):
            donors=(3,4,1) if sign==1 else (0,5,2)
            rejoin=(1 if sign==1 else 2 if sign==-1 else 0)
            y0=sign*float(w@np.array([.22,.11,.22]))
            slope=sign*float(w@np.tan(np.deg2rad([0.,4.,8.])))
            shape=sum(weight*donor_values(i,mesh) for weight,i in zip(w,donors,strict=True))
            val=sum(weight*float(fn(trigger)) for weight,fn in zip(w,(native[i] for i in donors),strict=True))
            deriv=sum(weight*float(fn(trigger,1)) for weight,fn in zip(w,(native[i] for i in donors),strict=True))
            delta=mesh-trigger
            shape+=((y0-val)+(slope-deriv)*delta)*np.exp(-.5*(delta/.65)**2)
            u=np.clip(delta/(front-trigger),0.,1.)
            blend=u**3*(10.-15.*u+6.*u*u)
            shape=(1-blend)*shape+blend*donor_values(rejoin,mesh)
            s=arc[0]+np.r_[0.,np.cumsum(np.hypot(np.diff(mesh),np.diff(shape)))]
            xx=np.interp(arc,s,mesh); yy=np.interp(xx,mesh,shape)
            hh=np.arctan2(np.gradient(yy),np.gradient(xx));kk=np.gradient(hh,arc)
            rid=len(names); names.append(f'pair_{pair+1}_'+('left' if sign==1 else 'right') if sign else 'central')
            refs['xy'].append(np.column_stack((xx,yy)));refs['heading'].append(hh);refs['curvature'].append(kk)
            meta.append(dict(source='continuous_blend',side=sign,weight_flat=w[0],weight_half=w[1],weight_signed=w[2],
                             nominal_y=y0,nominal_heading_deg=np.rad2deg(np.arctan(slope)),rejoin=rejoin))
            slots.append(dict(action_slot=len(slots),route_id=rid,role='interpolated',fixed_alpha=np.nan,pair=pair,sign=sign))
    refs={k:np.stack(v) for k,v in refs.items()}
    for i,aa in LEGACY:
        for k in FIELDS:np.testing.assert_array_equal(refs[k][i],old[k][i])
    bounds_inputs=[]
    for i in range(6):
        x,y=old['xy'][i].T;h=old['heading'][i];k=old['curvature'][i];m=(x>=1)&(x<=trigger);z=(x>=trigger)&(x<=front)
        bounds_inputs.append(dict(route_id=i,name=proto['geometry'][i],entry_y_m=np.interp(trigger,x,y),entry_heading_deg=np.rad2deg(np.interp(trigger,x,h)),
                                  approach_max_abs_kappa_per_m=np.max(np.abs(k[m])),rb_blend_max_abs_kappa_per_m=np.max(np.abs(k[z]))))
    pd.DataFrame(bounds_inputs).to_csv(out/'p0b_six_reference_envelope.csv',index=False)
    existing=pd.DataFrame(bounds_inputs)
    measures=[]
    for rid,(xy,h,k,met) in enumerate(zip(refs['xy'],refs['heading'],refs['curvature'],meta,strict=True)):
        x,y=xy.T; m=(x>=1.)&(x<=trigger); rb=(x>trigger)&(x<=front); aft=(x>=front+.05)&(x<=20)
        assert np.all(np.diff(x)>0) and np.isfinite(xy).all()
        yy=float(np.interp(trigger,x,y));hh=float(np.rad2deg(np.interp(trigger,x,h)))
        measurements=dict(route_id=rid,name=names[rid],entry_y_m=yy,entry_heading_deg=hh,
             entry_kappa_per_m=float(np.interp(trigger,x,k)),approach_y_min_m=float(y[m].min()),approach_y_max_m=float(y[m].max()),
             approach_max_abs_kappa_per_m=float(np.abs(k[m]).max()),rb_blend_max_abs_kappa_per_m=float(np.abs(k[rb]).max()),
             max_postedge_donor_y_diff_m=float(np.max(np.abs(y[aft]-np.interp(x[aft],old['xy'][met['rejoin'],:,0],old['xy'][met['rejoin'],:,1])))),
             **met)
        if rid>=3:
            assert abs(yy-met['nominal_y'])<.0002 and abs(hh-met['nominal_heading_deg'])<.1
            assert existing.entry_y_m.min()<=yy<=existing.entry_y_m.max()
            assert existing.entry_heading_deg.min()<=hh<=existing.entry_heading_deg.max()
            assert measurements['approach_max_abs_kappa_per_m']<=existing.approach_max_abs_kappa_per_m.max()
            assert measurements['rb_blend_max_abs_kappa_per_m']<=existing.rb_blend_max_abs_kappa_per_m.max()
        measures.append(measurements)
    geometry=pd.DataFrame(measures)
    design=pd.DataFrame(slots).merge(geometry,on='route_id',validate='many_to_one')
    design['alpha_rule']=np.where(design.role.eq('legacy_anchor'),'fixed_alpha','((root_slot + 2*pair) mod 12 + 0.5) / 12')
    design.to_csv(out/'action_slots.csv',index=False)
    roots=pd.read_csv(out.parent/'split.csv'); eligible=roots[roots.role.isin(['train','dev','calibration'])]
    selected=eligible[['role','map_slot','root_slot','bank_row']].merge(design[['action_slot','route_id','fixed_alpha','pair','sign']],how='cross')
    use_fixed=selected.fixed_alpha.notna()
    # All 10 map slots use exactly the same action tuples at a given root slot.
    selected['alpha_numerator_24']=np.where(use_fixed,selected.fixed_alpha.fillna(0)*24,2*((selected.root_slot+2*selected.pair)%12)+1).astype(int)
    selected['alpha']=selected.alpha_numerator_24/24
    selected.drop(columns='fixed_alpha',inplace=True)
    assert len(selected)==1920 and selected.groupby(['role','map_slot','bank_row']).action_slot.nunique().eq(16).all()
    counts=selected.drop_duplicates(['route_id','alpha_numerator_24','role','map_slot']).groupby(['route_id','alpha_numerator_24','role']).size().unstack(fill_value=0)
    assert (counts['train']==6).all() and (counts['dev']==2).all() and (counts['calibration']==2).all()
    cross=selected[~use_fixed].groupby(['role','map_slot','route_id']).alpha_numerator_24.nunique()
    assert cross.eq(12).all()
    pairgrid=selected[(~use_fixed)&selected.sign.ne(0)].groupby(['role','map_slot','root_slot','pair'])
    assert pairgrid.alpha.nunique().eq(1).all() and pairgrid.sign.nunique().eq(2).all()
    assert selected[use_fixed].groupby(['role','map_slot','action_slot']).size().eq(12).all()
    selected.to_csv(out/'root_action_schedule.csv.gz',index=False)
    np.savez_compressed(out/'approaches.npz',s=arc,**refs)
    npzsize=(out/'approaches.npz').stat().st_size
    # This is a prospective storage calculation. The legacy banks store three alternatives per join.
    n=len(arc);m=len(names);one=lambda g:(g+3*g*n)*n*(2+1+1)*4+n*arc.dtype.itemsize
    paired=geometry[geometry.side.ne(0)].groupby(lambda i:(i-3)//2)
    fig,axs=plt.subplots(3,1,figsize=(10.5,7.4),gridspec_kw={'height_ratios':[1.1,1,1.7]},layout='constrained')
    for ax,xlo,xhi,ylo,yhi in [(axs[0],1.,12.3,-.77,.77),(axs[1],8.6,10.6,-.47,.47)]:
        for i in range(14):
            xy=refs['xy'][i];color='#424d5a' if i<3 else SIGN_COLOURS[meta[i]['side']]
            ax.plot(*xy.T,color=color,ls='--' if i<3 else '-',lw=1.3 if i<3 else 1.0,alpha=.72,zorder=3 if i<3 else 2)
        ax.axvline(trigger,color='#606c6b',ls=':',lw=1);ax.axvline(front,color='#247355',ls=':',lw=1)
        ax.set(xlim=(xlo,xhi),ylim=(ylo,yhi),aspect='equal',ylabel='World y (m)',xlabel='World x (m)')
    axs[0].set_title('Known-map approach references · input design only',loc='left',weight='bold')
    axs[1].set_title('Geometry at the skill handoff (9.2 m) and step edge (10.3 m)',loc='left',fontsize=10)
    ax=axs[2]
    ax.axvline(0,color='#b8bfbc',lw=.8);ax.axhline(0,color='#b8bfbc',lw=.8)
    for i,r in geometry.iterrows():
        col='#373e48' if i<3 else SIGN_COLOURS[r.side]
        ax.scatter(r.entry_y_m,r.entry_heading_deg,marker='s' if i<3 else 'o',s=39,c=col,zorder=3)
        ax.annotate(str(i),(r.entry_y_m,r.entry_heading_deg),xytext=(5,-8 if i%2 else 4),textcoords='offset points',color=col,fontsize=8)
    ax.set(xlabel='Handoff lateral offset (m)',ylabel='Handoff heading (degrees)',xlim=(-.245,.245),ylim=(-9.25,9.25))
    ax.set_title('Three archived geometries (squares) and eleven new geometries (circles); labels are route IDs',loc='left',fontsize=10)
    fig.savefig(out/'candidate_reference_xy.png',dpi=160);plt.close(fig)
    gnew=geometry.iloc[3:]
    physical_intervals=dict()
    for field in ('entry_y_m','entry_heading_deg','approach_max_abs_kappa_per_m','rb_blend_max_abs_kappa_per_m',
                 'approach_y_min_m','approach_y_max_m','max_postedge_donor_y_diff_m'):
        physical_intervals[field]=[float(gnew[field].min()),float(gnew[field].max())]
    receipt=dict(role='Prospective sampling geometry only; no simulation, physical viability outcomes or testing performed.',
        frozen_split=str(out.parent/'split.csv'),p0b_curve_source=str(parent/'approaches.npz'),old_actions=LEGACY,
        p0b_curve_sha256=hashlib.sha256((parent/'approaches.npz').read_bytes()).hexdigest(),new_curve_sha256=hashlib.sha256((out/'approaches.npz').read_bytes()).hexdigest(),
        action_slots_per_root=16,distinct_geometry_count=m,legacy_anchor_count=5,new_nonanchor_action_slots_per_root=11,
        new_geometry_alpha_combinations=int(len(counts)-5),all_geometry_alpha_combinations=len(counts),
        new_alpha_values_on_each_geometry=sorted(selected.loc[~use_fixed,'alpha'].unique().tolist()),
        alpha_source='The 12 exact rational midpoints at odd numerators/24; rotate by 2*pair over root slots. Same alpha for both members of each pair at the same root. Five fixed old anchors use exactly 0, 0.5, or 1 from P0-B. Simulator tests action tuples at finite support.',
        geometry_source='Five left-right pairs plus central; mix baseline, half and full signed source references on the common physical x axis, then adjust y and tangent locally. Positive/negative sources are P0-B rows (3,4,1)/(0,5,2). Entry at 9.2 m, with quintic return by 10.3 m to signed left or right donor (central to original baseline). Source originals have asymmetric prehistories, so symmetry is checked at the handoff, not imposed pointwise on the entire path. All referenced curves share the original 1200-point arc-length grid.',
        native_anchor_comparison='np.array_equal across all s, xy, heading, curvature samples for 3 geometries/5 action tuples (the three alpha choices for old route 1 use identical geometry).',
        candidate_world_ranges=physical_intervals,
        p0b_max_pre_handoff_curvature_per_m=float(existing.approach_max_abs_kappa_per_m.max()),
        p0b_max_handoff_to_edge_curvature_per_m=float(existing.rb_blend_max_abs_kappa_per_m.max()),
        max_mirror_offset_sum_m=float(paired.entry_y_m.sum().abs().max()),max_mirror_heading_sum_deg=float(paired.entry_heading_deg.sum().abs().max()),
        maps={'train':6,'dev':2,'calibration':2},all_action_combinations_appear_on_each_map=True,
        root_count=len(eligible),root_action_rows=len(selected),hidden_force_repetitions_per_root_action=3,
        count_unique_prefixes=3*len(selected),count_physical_lanes_if_two_suffixes_each=6*len(selected),
        sealed_test_roots_excluded=int(roots.role.eq('sealed_test').sum()),walls_or_seed_in_sampler=False,
        archive_bytes=npzsize,uncompressed_reference_array_bytes=sum(v.nbytes for v in refs.values())+arc.nbytes,
        optional_three_exit_dense_float32_bank_bytes_one_shared_file=one(m),
        hypothetical_dense_per_root_unique_135_geometry_bytes=one(135),
        geometry_compactness='Realized physical ranges are design checks against P0-B commanded curves; they do not certify relock or path tracking. The dense departure bank was neither allocated nor generated. Reuse the same shared bank for maps with identical departure/goal geometry; if far-gate or goal changes, rebuild the corresponding suffix rules rather than silently reusing a mismatched bank.')
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:receipt[k] for k in ['candidate_world_ranges','max_mirror_offset_sum_m','max_mirror_heading_sum_deg','archive_bytes','optional_three_exit_dense_float32_bank_bytes_one_shared_file','all_geometry_alpha_combinations','root_action_rows']},indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--p0b',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args(); generate(args.p0b.resolve(),args.output.resolve())

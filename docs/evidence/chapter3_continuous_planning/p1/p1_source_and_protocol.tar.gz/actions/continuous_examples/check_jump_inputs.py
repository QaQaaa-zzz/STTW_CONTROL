"""Feed two generated approach curves through the P1 departure-time observation path."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd

here = Path(__file__).resolve().parent
root = here.parents[1]
sys.path[:0] = [str(root/'export'), str(root/'model')]
from export_prefixes import decision_inputs as measure_corridor
from jump_outcome import decision_inputs as features

training = root/'export/train/train_00'
index = pd.read_csv(training/'prefix_index.csv')
with np.load(training/'observed_inputs.npz') as archive:
    reference = {k: archive[k] for k in archive.files}
i = int(index.query('root == 1250 and action_slot == 0').iloc[0].row)
q = reference['t0_qpos_native'][[i]]
v = reference['t0_qvel_native'][[i]]
world = json.loads((root/'maps/train_00/world.json').read_text())
with np.load(root/'maps/train_00/terrain.npz') as archive:
    terrain = dict(archive)
with np.load(root/'actions/approaches.npz') as archive:
    old = dict(archive)
replay = measure_corridor(q, v, [int(index.geometry[i])], reference['alpha'][[i]], old, terrain, world)
assert all(np.array_equal(replay[k], reference[k][[i]]) for k in replay)
seen = features(reference)[3].numpy()[:, :-1]
reports = []
for name in ('left_A', 'right_B'):
    with np.load(here/(name+'.npz')) as generated:
        sample = measure_corridor(q, v, [0], [.5], generated, terrain, world)
    x, _, _, action = features(sample)
    a = action[0, :-1].numpy()
    reports.append(dict(curve=name, departure_root=1250, alpha=.5,
                        input_width=x.shape[1], finite=bool(x.isfinite().all()),
                        observed_shape_coordinates=len(a),
                        above_training_max=int((a > seen.max(0)+1e-6).sum()),
                        below_training_min=int((a < seen.min(0)-1e-6).sum()),
                        nearest_observed_shape_rms=float(np.sqrt(((seen-a)**2).mean(1)).min())))
table = pd.DataFrame(reports)
table.to_csv(here/'jump_inputs.csv', index=False)
print(table.to_string(index=False))

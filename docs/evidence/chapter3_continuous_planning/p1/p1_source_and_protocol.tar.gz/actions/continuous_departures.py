"""Build raised-platform exit references directly from one supplied approach in world coordinates."""
from pathlib import Path
import sys
import numpy as np

CLI=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/cli')
if str(CLI) not in sys.path:sys.path.insert(0,str(CLI))
from run_platform_task_oracle import departure_route

def departure_options(route,position_xy,progress_m=None,*,target_y_m=(.36,0.,-.36),blend_m=1.6,far_x_m=15.,goal_start_x_m=16.5):
    """Return the arc-grid join index and three H75 reference rows in left/straight/right order.

    Supply the controller's actual progress when available. For a forecast pose alone, use
    its nearest line-segment projection, as in FrozenExits.branch_ids(). All measurements
    and target ordinates refer to the approach's forward world-x / left world-y frame.
    """
    s=np.asarray(route['s']);xy=np.asarray(route['xy']);h=np.asarray(route['heading']);k=np.asarray(route['curvature'])
    if xy.ndim==3 and xy.shape[0]==1:xy,h,k=xy[0],h[0],k[0]
    p=np.asarray(position_xy,dtype=np.float64)
    if (s.ndim!=1 or len(s)<2 or xy.shape!=(len(s),2) or h.shape!=s.shape or k.shape!=s.shape or p.shape!=(2,)
        or not all(np.isfinite(a).all() for a in (s,xy,h,k,p)) or not (np.diff(s)>0).all() or not (np.diff(xy[:,0])>0).all()
        or len(target_y_m)!=3 or not np.isfinite((*target_y_m,blend_m,far_x_m,goal_start_x_m)).all() or blend_m<=0 or far_x_m>=goal_start_x_m):
        raise ValueError('Expected one finite forward-x approach, increasing arc, a world XY pose and valid three-exit geometry')
    if progress_m is None:
        delta=np.diff(xy,axis=0)
        part=np.clip(((p-xy[:-1])*delta).sum(1)/(delta**2).sum(1),0,1)
        i=np.argmin(((xy[:-1]+part[:,None]*delta-p)**2).sum(1))
        progress_m=(1-part[i])*s[i]+part[i]*s[i+1]
    if not np.isfinite(progress_m):raise ValueError('Nonfinite handoff progress')
    # x+5 cm and the next arc-grid point after the controller's progress are both binding.
    join=min(len(s)-1,max(np.searchsorted(xy[:,0],float(p[0])+.05),np.searchsorted(s,progress_m)+1))
    result={'s':s.copy(),**{key:np.repeat(a[None],3,axis=0) for key,a in [('xy',xy),('heading',h),('curvature',k)]}}
    for j,target in enumerate(target_y_m):departure_route(result,j,join,target,blend_m,far_x_m,goal_start_x_m)
    # The physical runner's active reference bank has FP32 geometry, even when the approach was stored in FP64.
    for key in ('xy','heading','curvature'):result[key]=result[key].astype(np.float32,copy=False)
    return int(join),result


def score_approach(scorer,route,qpos,velocity9,previous_velocity9,seconds,section_x,target_side,*,
                   progress_m=None,speed=2.,target_y_m=(.36,0.,-.36),blend_m=1.6,far_x_m=15.,return_native=False,share_direction_rollouts=False):
    """Construct and score the three references at a measured or predicted handoff."""
    join,options=departure_options(route,np.asarray(qpos)[:2],progress_m,target_y_m=target_y_m,blend_m=blend_m,
                                   far_x_m=far_x_m,goal_start_x_m=scorer.query.goal['x_min_m'])
    result=scorer.score_references(np.asarray(qpos)[None],np.asarray(velocity9)[None],np.asarray(previous_velocity9)[None],
        seconds,options,section_x,target_side,speed,return_native,share_direction_rollouts)
    return join,result

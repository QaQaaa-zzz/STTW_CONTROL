"""CPU-only P1 input preparation. Never runs the physical evaluator."""
import argparse
import csv
from hashlib import sha256
import gzip
import json
import os
from pathlib import Path
import sys
import tempfile
import zipfile

import numpy as np

OUT=Path(__file__).resolve().parent
WORK=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path.insert(0,str(WORK/'learning/cli'))
sys.path.insert(0,str(WORK/'learning/src'))
OLD=OUT.parent/'chapter3_continuous_p0b_20261123'
MARGIN=OUT.parent/'chapter3_continuous_margin_fixed_20261123'
BUNDLE=OUT/'shared'
FIELDS=('xy','heading','curvature')
BINS=(('near',12.7,1),('near',12.7,-1),('far',15.,1),('far',15.,-1))
def read(p):return json.loads(p.read_text())
def save(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def digest(p):
    from hashlib import file_digest
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
def build_bank():
    from run_platform_task_oracle import departure_route
    BUNDLE.mkdir(exist_ok=True)
    newfile=OUT/'actions/approaches.npz'
    oldfile=OLD/'departures.npz'
    donor=OLD/'neutral.npz'
    specs={str(p):digest(p) for p in (newfile,oldfile,donor)}
    record=BUNDLE/'route_bank_receipt.json'
    if record.exists():
        r=read(record)
        if r['sources']==specs and all(digest(Path(p))==h for p,h in r['outputs'].items()):return r
        raise ValueError('Existing bank identity differs; preserve it and inspect the discrepancy')
    with np.load(newfile) as z:ref=dict(z)
    with np.load(OLD/'approaches.npz') as z:
        legacy={i:j for i in range(len(ref['xy'])) for j in range(len(z['xy'])) if all(np.array_equal(ref[k][i],z[k][j]) for k in FIELDS)}
        if legacy!={0:0,1:1,2:2}:raise ValueError(f'Unexpected frozen approach anchors: {legacy}')
        np.testing.assert_array_equal(ref['s'],z['s'])
    n=len(ref['s']);m=len(ref['xy']);nrows=m+3*m*n
    assert (m,n)==(14,1200)
    goal=read(OLD/'right_offset/world.json')['goal']['x_min_m']
    with np.load(donor) as z:
        for k in FIELDS:np.testing.assert_array_equal(z[k],np.repeat(z[k][:1],6,axis=0))
        neutral={'s':z['s'],**{k:np.repeat(z[k][:1],m,axis=0) for k in FIELDS}}
    np.savez_compressed(BUNDLE/'neutral.npz',**neutral)
    with tempfile.TemporaryDirectory(dir=BUNDLE) as storage:
        arrays={}
        with np.load(oldfile) as old:
            for k in FIELDS:
                shape=(nrows,*ref[k].shape[1:])
                a=np.lib.format.open_memmap(Path(storage)/(k+'.npy'),mode='w+',dtype=np.float32,shape=shape)
                src=old[k]
                a[:m]=ref[k]
                for i,j in legacy.items():
                    np.testing.assert_array_equal(src[j],a[i])
                    source=src[6+j*3*n:6+(j+1)*3*n]
                    target=a[m+i*3*n:m+(i+1)*3*n];target[:]=source
                    np.testing.assert_array_equal(source,target)
                arrays[k]=a
                del src
        for rid in sorted(set(range(m))-set(legacy)):
            for direction,y in enumerate((.36,0.,-.36)):
                for jj in range(n):
                    one={'s':ref['s'],**{k:ref[k][rid:rid+1].copy() for k in FIELDS}}
                    departure_route(one,0,jj,y,1.6,15.,goal)
                    target=m+(rid*3+direction)*n+jj
                    for k in FIELDS:arrays[k][target]=one[k][0]
            print('compiled departure bank route',rid,flush=True)
        for a in arrays.values():a.flush()
        np.save(Path(storage)/'s.npy',ref['s'])
        temp=BUNDLE/'departures.partial'
        with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as stream:
            for k in ['s',*FIELDS]:stream.write(Path(storage)/(k+'.npy'),k+'.npy')
        temp.rename(BUNDLE/'departures.npz')
        for a in arrays.values():a._mmap.close()
    outputs={str(p):digest(p) for p in [BUNDLE/'neutral.npz',BUNDLE/'departures.npz']}
    receipt=dict(sources=specs,outputs=outputs,geometries=m,arc_samples=n,rows=nrows,compiled_goal_start_m=goal,
          original_geometry_matches=legacy,exact_original_approaches_after_float32=len(legacy),exact_original_egress_join_rows=len(legacy)*3*n,
          layout='First 14 rows are approach routes. An exit row is 14+(route_id*3+direction)*1200+join_index.',
          directions={'0':'left +0.36 m','1':'straight','2':'right -0.36 m'},
          new_geometry_provenance='Call unchanged frozen run_platform_task_oracle.departure_route: 1.6 m blend; x=15 m fade; original goal start. All 3 directions and every join grid point.',
          neutral='All 14 indexable neutral rows copy identical original neutral initialization; actual route selected at original start delay.')
    save(record,receipt);return receipt

def make_configs():
    template=read(MARGIN/'right_offset/part_0/config.json')
    original=read(OLD/'protocol.json')
    registry=read(OUT/'maps/protocol.json')['records']
    with gzip.open(OUT/'actions/root_action_schedule.csv.gz','rt') as f:schedule=list(csv.DictReader(f))
    with (OUT/'split.csv').open() as f:
        roots={(r['role'],int(r['map_slot']),int(r['root_slot'])):int(r['bank_row']) for r in csv.DictReader(f)
               if r['role'] in ('train','dev','calibration')}
    batches=[]
    force_levels=(0,-5,5)
    for info in registry:
        role,slot=info['role'],int(info['map_slot']);name=f'{role}_{slot:02d}';bank_dir=OUT/'maps'/name
        loc=OUT/'batches'/name;loc.mkdir(parents=True,exist_ok=True)
        variants=[];lanes=[];directions=[]
        chosen=sorted((int(r['root_slot']),int(r['action_slot']),int(r['route_id']),float(r['alpha']),
                       int(r['alpha_numerator_24']),int(r['bank_row'])) for r in schedule if r['role']==role and int(r['map_slot'])==slot)
        if len(chosen)!=192:raise ValueError(f'Incomplete root/action allocation at {name}')
        for root_slot,action_slot,route,alpha,num,bank_row in chosen:
            if roots[(role,slot,root_slot)]!=bank_row:raise ValueError('Root/action join failed')
            section,x,side=BINS[(root_slot+action_slot)%4]
            for force in force_levels:
                for dd in (0,2):
                    j=len(variants);arm=('left','straight','right')[dd]
                    v=dict(template['ground_handoff']['handoff_variants'][0],root_variant=bank_row,bank_row=bank_row,
                           data_split=role,root_slot=root_slot,map_slot=slot,map_id=name,action_slot=action_slot,
                           geometry=route,approach_alpha=alpha,alpha_numerator_24=num,planner='C',section_x=x,
                           side=side,bin=section,force_y_N=force,planned_departure=dd,departure=arm,arm=arm)
                    variants.append(v);lanes.append([route,'h75',j]);directions.append(dd)
        cfg=dict(template);cfg.pop('p0_branches')
        cfg.update(role=f'P1 {role}: paired fixed exits after measured RB relock. Shadow observer only.',
                   world_map=str(bank_dir/'world.json'),approach_initial_bank=str(OUT/'initial_bank.npz'),
                   evaluation_lanes=lanes,ccd_capacity=8*len(lanes),collect_model_state=False)
        cfg['ground_handoff']=dict(template['ground_handoff'],reference_path=str(BUNDLE/'neutral.npz'),handoff_variants=variants)
        cfg['paired_departures']=dict(approach_file=str(OUT/'actions/approaches.npz'),route_bank=str(BUNDLE/'departures.npz'),
                                      direction_ids=directions)
        cfg['platform_online']=dict(template['platform_online'],relative=dict(template['platform_online']['relative'],raster=str(bank_dir/'terrain.npz')))
        save(loc/'config.json',cfg)
        batches.append(dict(name=name,role=role,map_slot=slot,bank_rows=sorted({c[-1] for c in chosen}),
             config=str(loc/'config.json'),config_sha256=digest(loc/'config.json'),world=str(bank_dir/'world.json'),
             physical_model=str(bank_dir/'terrain.mjb'),raster=str(bank_dir/'terrain.npz'),physical=str(loc/'physical'),
             lanes=len(lanes),distinct_prefixes=len(lanes)//2))
    if len(batches)!=10 or len({x for b in batches for x in b['bank_rows']})!=120:raise ValueError('Incorrect map split')
    contract=dict(stage='CPU input preparation; no physics executed',source=original['source_config'],
        inherited_protocol=str(OLD/'protocol.json'),banks=dict(approaches=str(OUT/'actions/approaches.npz'),
        neutral=str(BUNDLE/'neutral.npz'),departures=str(BUNDLE/'departures.npz'),initial=str(OUT/'initial_bank.npz')),
        splits=dict(train=6,dev=2,calibration=2),batches=batches,total_physical_lanes=11520,total_distinct_prefixes=5760,
        all_episode_s=10.,dt_phys_s=.001,substeps_per_control=5,dt_control_s=.005,ground_policy_dt_s=.02,
        horizon_upper_lane_substeps=115200000,trigger_x_m=9.200000000000001,terrain_top_m=.16,
        push='0, -5 and +5 world-y N. Nonzero forces apply for at most 20 control ticks from the native airborne marker, per physical status; 0 is an event marker only.',
        stationary_role='This data stage fits no weights and does not select an online expanded-library entry policy.',
        gate_assignment='For all three pushes and both physical directions at fixed root/action, (root_slot+action_slot)%4 indexes [near left,near right,far left,far right]. Near x=12.7 m, far x=15.0 m. 4 actions per gate at each root.',
        planned_exit_publication='Common neutral through start tick 3; after relock, same straight default until first shadow query tick +3 (15 ms). The C shadow verdict does not override the committed direction. Score actual applied_tick from status.',
        shadow_margin_m=template['platform_online']['margin_m'],footprint='One shared 14-geometry departure bank, same asset paths for every map.',
        motion_weights={'ground_h75':template['ground_handoff']['bundle'],'query_ground_model':template['platform_online']['ground_model'],
                        'query_relative_initializer':template['platform_online']['relative']['initializer'],'rb_run1_registry':'learning/configs/playground_rb_skill_sources.json'},
        lane_identity='Always use evaluation_lanes[i] / handoff_variants[i] / physical status.results[i]. Each adjacent lane pair shares map,bank_row,root_slot,action_slot,geometry,alpha,force,side and gate; directions are 0 then 2.',
        query_table='physical/p1_query/tick_TTTT.npz, event tick=first control tick AFTER recorded handoff; lanes[] are local physical indices. A never-relocked trajectory has no invented handback row.',
        query_fields=['lanes','tick','previous_tick','qpos','qvel','previous_qpos','previous_qvel','velocity','previous_velocity',
                      'body_speed','requested_speed','branch_ids','incumbent_direction','shadow_choice','shadow_any_admitted',
                      'shadow_incumbent_admitted','section_x','side','handoff_s','remaining_s','route_at_query','projection_progress'],
        query_velocity='velocity and previous_velocity are exactly the native PlatformDepartureQuery.choose arguments; previous raw qpos/qvel are the frozen ring slot at tick-4 (20 ms).',
        pre_action='physical/p1_applied_controls.npz fields targets[tick,lane,4],valid[tick,lane]. Same order: steering position, rear speed, hip, knee. These are actual owner-selected commands applied over [tick,tick+1) if valid. Dense qpos/qvel and contact telemetry remain in trajectory.npz.',
        observed_prebranch_history='Query sidecars additionally store read-only H75 tensors, RB observation/history/last action, held target and physical warmstart/controller fields at query, for offline parity checks. Prefix audit includes pose, velocity, real control, mapped phase, contact predicates versus raw contact loads, handback time and observed terminal.',
        evidence_limit='Matching archived state/input is an observation claim. Compressed global solver contact buffers are not an exact replay certificate. Shadow query_batch_ms includes observer staging overhead; use frozen 15ms physical scheduler for this experiment.',
        entry_command='python '+str(OUT/'collect.py')+' --all')
    save(OUT/'collection_contract.json',contract)
    return contract

def zip_arrays(path):
    import struct
    out={}
    with zipfile.ZipFile(path) as z, path.open('rb') as f:
        for info in z.infolist():
            if info.compress_type!=zipfile.ZIP_STORED:raise ValueError('Expected uncompressed indexed bank')
            f.seek(info.header_offset+26)
            filename_len,extra_len=struct.unpack('<HH',f.read(4))
            f.seek(info.header_offset+30+filename_len+extra_len)
            version=np.lib.format.read_magic(f)
            shape,fortran,dtype={(1,0):np.lib.format.read_array_header_1_0,(2,0):np.lib.format.read_array_header_2_0}[version](f)
            out[info.filename[:-4]]=np.memmap(path,mode='r',offset=f.tell(),dtype=dtype,shape=shape,order='F' if fortran else 'C')
    return out

def certify_bank():
    from run_platform_task_oracle import departure_route
    src=OLD/'departures.npz';dst=BUNDLE/'departures.npz'
    old,big=zip_arrays(src),zip_arrays(dst)
    with np.load(OUT/'actions/approaches.npz') as z:ref=dict(z)
    with np.load(OLD/'approaches.npz') as z:
        legacy={i:j for i in range(len(ref['xy'])) for j in range(len(z['xy'])) if all(np.array_equal(ref[k][i],z[k][j]) for k in FIELDS)}
    if legacy!={0:0,1:1,2:2}:raise ValueError('Unexpected original anchor membership')
    m=len(ref['xy']);n=len(ref['s']);goal=read(OLD/'right_offset/world.json')['goal']['x_min_m']
    for k in FIELDS:
        if len(big[k])!=m+3*m*n:raise ValueError('Incomplete bank rows')
        np.testing.assert_array_equal(big[k][:m],ref[k].astype(np.float32))
        for i,j in legacy.items():
            for off in range(0,3*n,120):
                np.testing.assert_array_equal(big[k][m+i*3*n+off:m+i*3*n+off+120],
                                              old[k][6+j*3*n+off:6+j*3*n+off+120])
    for rid in sorted(set(range(m))-set(legacy)):
        for direction,y in enumerate((.36,0.,-.36)):
            for join in (0,240,572,600,900,n-1):
                v={'s':ref['s'],**{k:ref[k][rid:rid+1].copy() for k in FIELDS}}
                departure_route(v,0,join,y,1.6,15.,goal)
                for k in FIELDS:np.testing.assert_array_equal(big[k][m+(rid*3+direction)*n+join],v[k][0].astype(np.float32))
    for k in FIELDS: 
        for j in range(0,len(big[k]),128):
            if not np.isfinite(big[k][j:j+128]).all():raise ValueError('Nonfinite shared departure bank')
    np.testing.assert_array_equal(big['s'],ref['s'])
    sources={str(p):digest(p) for p in (OUT/'actions/approaches.npz',src,OLD/'neutral.npz')}
    outputs={str(p):digest(p) for p in (BUNDLE/'neutral.npz',dst)}
    r=dict(sources=sources,outputs=outputs,geometries=m,arc_samples=n,rows=len(big['xy']),compiled_goal_start_m=goal,
           original_geometry_matches=legacy,exact_original_egress_join_rows=3*n*len(legacy),recomputed_new_join_rows=11*3*6,
           row_formula='14 + (route_id*3 + physical_direction)*1200 + join. Direction 0 goes to world y=+.36, 1 to zero, 2 to −.36.',
           construction='Legacy geometries 0,1,2 copy all old three-branch rows verbatim; all 11 new routes use original departure_route. One global NPZ, indexed identically by every map.',
           all_rows_finite=True,neutral='14 identical initialized rows expanded from original neutral path; actual approach assignment at tick 3.')
    save(BUNDLE/'route_bank_receipt.json',r)
    return r

def validate():
    from collections import Counter,defaultdict
    import ast
    import inspect
    import torch
    import mujoco
    from sttw_control.torch_path_reference import TorchPathReference
    from sttw_control.pendulum_skill import PendulumSkill
    from sttw_control.playground_history_model import load_history_model
    from evaluate_playground_handoff import transplant
    from sttw_control.playground_adapters import JumpAdapter
    from sttw_control.platform_online import PlatformDepartureQuery
    import sttw_control.playground_handoff_evaluation as runner
    os.chdir(WORK)
    assert not torch.cuda.is_available(), 'Preparation must run with CUDA_VISIBLE_DEVICES empty'
    contract=read(OUT/'collection_contract.json')
    prereg=read(OUT/'collection_preregistration.json')
    maps={r['id']:r for r in read(OUT/'maps/manifest.json')['records']}
    protocol=read(OLD/'protocol.json')
    template=read(MARGIN/'right_offset/part_0/config.json')
    identity=read(WORK/template['ground_handoff']['bundle']/'identity.json')
    registry=WORK/'learning/configs/playground_rb_skill_sources.json'
    skill=PendulumSkill(registry,'rb_run1')
    for k in ['actor_sha256','checkpoint_identity_sha256','normalizer_sha256']:
        assert skill.record[k]==protocol['frozen_weights']['rb_run1'][k]
    f=WORK/template['ground_handoff']['bundle']/'actor.npz'
    assert digest(f)==protocol['frozen_weights']['H75']['artifact_sha256']==identity['files']['actor.npz']
    querydir=Path(template['platform_online']['ground_model'])
    query_model=load_history_model(querydir,device='cpu')
    assert not query_model.training
    weights={str(f):digest(f) for f in [f,registry,Path(skill.record['formal_config']),querydir/'best.pt',querydir/'nominal.npz',
             querydir/'contract.json',Path(template['platform_online']['relative']['initializer']),WORK/template['ground_handoff']['settings']]}
    assert Path(skill.bundle.xml_path).resolve()==Path(read(OUT/'maps/protocol.json')['source_xml']).resolve()
    init=Path(contract['banks']['initial']);approaches=Path(contract['banks']['approaches'])
    with np.load(init) as z:bank=dict(z)
    with np.load(approaches) as z:arr=dict(z)
    with np.load(contract['banks']['neutral']) as z:neutral=dict(z)
    assert bank['qpos'].shape[1]==12 and bank['qvel'].shape[1]==11
    nr=len(arr['xy']);n=len(arr['s']);assert nr==14 and n==1200
    data=zip_arrays(BUNDLE/'departures.npz')
    np.testing.assert_array_equal(neutral['s'],data['s'])
    for key in FIELDS:np.testing.assert_array_equal(neutral[key],np.broadcast_to(neutral[key][:1],neutral[key].shape))
    assert all(np.all((np.diff(data['xy'][start:start+64],axis=1)**2).sum(-1)>0) for start in range(0,len(data['xy']),64))
    route=TorchPathReference(neutral,{},device='cpu',route_ids=list(range(nr)))
    zeros=torch.zeros(nr);assert route.at(zeros)[0].shape==(nr,2)
    rec=read(BUNDLE/'route_bank_receipt.json')
    assert all(digest(Path(p))==h for p,h in rec['outputs'].items())
    config_state={};unions=set();tot=Counter()
    hcfg=read(WORK/template['ground_handoff']['bundle']/'config.json')
    for b in contract['batches']:
        name=b['name'];m=maps[name];c=read(Path(b['config']));w=read(Path(m['world']))
        assert m['roots']==b['bank_rows'] and not unions.intersection(m['roots'])
        unions.update(m['roots'])
        assert all(digest(Path(m[k]))==m['sha256'][k] for k in ('world','mjb','raster'))
        assert c['world_map']==m['world'] and c['platform_online']['relative']['raster']==m['raster']
        assert c['paired_departures']['approach_file']==str(approaches) and c['paired_departures']['route_bank']==str(BUNDLE/'departures.npz')
        assert c['ground_handoff']['reference_path']==str(BUNDLE/'neutral.npz')
        assert c['ground_handoff']['settings']==template['ground_handoff']['settings']
        assert c['ground_handoff']['bundle']==template['ground_handoff']['bundle'] and c['approach_initial_bank']==str(init)
        assert all(c[k]==template[k] for k in ('ground_physics','contact_substep_telemetry','shared_adapters','audit_actuator_owner',
               'fixed_order_tree_reductions','canonical_constraint_rows','ordered_solver_reductions','world_contact_capacity','native_rb_entry_context'))
        assert 'p0_branches' not in c and not c['collect_model_state'] and not c.get('rb_adaptation_bundles')
        assert c['platform_online']['ground_model']==str(querydir) and c['platform_online']['margin_m']==.05330585315823555
        assert c['platform_online']['latency_ticks']=={'start':3,'departure':3}
        lanes=c['evaluation_lanes'];variants=c['ground_handoff']['handoff_variants'];dd=c['paired_departures']['direction_ids']
        assert len(lanes)==len(variants)==len(dd)==1152
        groups=defaultdict(list);gates=defaultdict(set);ks=defaultdict(list)
        for lane,(route_id,mode,idx) in enumerate(lanes):
            v=variants[idx]
            assert idx==lane and 0<=route_id<nr and mode=='h75' and v['planner']=='C' and v['geometry']==route_id
            assert v['planned_departure']==dd[lane]==(0,2)[lane%2] and v['arm']==v['departure']==('left','straight','right')[dd[lane]]
            assert v['map_id']==name and v['root_variant']==v['bank_row']==m['roots'][v['root_slot']] and 0<=v['action_slot']<16
            assert v['approach_alpha']==v['alpha_numerator_24']/24 and 0<=v['approach_alpha']<=1
            assert (v['bin'],v['section_x'],v['side'])==BINS[(v['root_slot']+v['action_slot'])%4]
            assert np.isclose(w['terrain']['front_x_m']+v['activation_offset_m'],9.2) and w['terrain']['far_bank_height_m']==.16
            pkey=(v['bank_row'],v['action_slot'],v['force_y_N'])
            groups[pkey].append((lane,dd[lane]));gates[pkey[:2]].add((v['side'],v['section_x']))
            ks[pkey[:2]].append(v['force_y_N'])
            if lane%2:
                vv=variants[lane-1]
                assert {k:x for k,x in vv.items() if k not in ('arm','departure','planned_departure')}=={k:x for k,x in v.items() if k not in ('arm','departure','planned_departure')}
        assert len(groups)==576 and all(z[1]==(z[0][0]+1,2) and z[0][1]==0 for z in groups.values())
        assert len(gates)==192 and all(len(x)==1 for x in gates.values()) and all(sorted(x)==[-5,-5,0,0,5,5] for x in ks.values())
        assert all(np.isfinite(v[m['roots']]).all() for v in bank.values())
        assert digest(Path(b['config']))==b['config_sha256']
        with tempfile.TemporaryDirectory(dir=OUT) as td:
            binary=transplant(skill.bundle,w['terrain'],Path(td),5,c['ground_physics'])
            assert digest(Path(td)/'terrain.mjb')==m['sha256']['mjb'] and binary.opt.timestep==.001 and binary.opt.integrator==mujoco.mjtIntegrator.mjINT_RK4
        config_state[name]=dict(mjb_sha256=m['sha256']['mjb'],config_sha256=b['config_sha256'],root_rows=m['roots'],lane_count=len(lanes),distinct_prefixes=len(groups))
        tot[b['role']]+=len(groups)
        print('CPU config and full MJB recompile match:',name,flush=True)
    assert len(unions)==120 and len(config_state)==10 and sum(tot.values())==prereg['unique_prefixes']==5760
    for role,count in tot.items():assert count==prereg['roles'][role]['prefixes']
    observer=ast.parse((OUT/'collect.py').read_text())
    upstream=inspect.getsource(runner.evaluate_handoff)
    for key,fn in [('save_target',JumpAdapter.select),('save_query',PlatformDepartureQuery.choose)]:
        node=next(x for x in ast.walk(observer) if isinstance(x,ast.FunctionDef) and x.name==key)
        assert [a.arg for a in node.args.args]==list(inspect.signature(fn).parameters)
    for s in ("target=jump_adapter.select(phase,ground_target,target,joint_bias)","chosen,admitted,incumbent=query.choose(",
              "selected=torch.where(reselect[ids],chosen,directions[ids])","velocity_history[tick%4] = (q,v)",
              "variants[i].get('approach_alpha'","policy=TorchPathPolicy(bundle/'actor.npz'","reselect=tensor([c['planner']=='C-R'",
              "shadow=tensor([c['planner']=='C'","release=torch.where(just_locked,tick+latency['departure'],release)"):
        assert s in upstream,s
    sections=dict(contract_sha256=digest(OUT/'collection_contract.json'),collector_sha256=digest(OUT/'collect.py'),
             audit_sha256=digest(OUT/'audit_pairs.py'),preregistration_sha256=digest(OUT/'collection_preregistration.json'),
             compiled_routes=rec,weights=weights,initial_bank_sha256=digest(init),maps=config_state,role_unique_prefixes=dict(tot),
             frozen_rb_identity={k:skill.record[k] for k in ('checkpoint','checkpoint_identity_sha256','actor_sha256','normalizer_sha256')},
             checks=['All ten submitted MJBs recompiled using evaluator transplant and native RB bundle; byte-identical.',
                     'Original PendulumSkill native artifact identity loaded on CPU; original H75 export matched runtime identity and P0 contract. Frozen ground prediction state dict loaded.',
                     'Neutral route IDs 0..13 selected via native TorchPathReference. All shared exit arc segments have positive length; forty-two direction/geometry combinations address bank rows.',
                     'All 11520 lane configs, 5760 paired prefixes, three unrevealed pushes, fixed shared gates, root splits, route IDs, action weights and source wiring checked.'],
             simulator_steps_executed_in_preparation=0,training_updates_in_preparation=0)
    return sections

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rebuild-input-configs',action='store_true')
    opts=parser.parse_args()
    if not (BUNDLE/'departures.npz').exists():build_bank()
    if not (BUNDLE/'route_bank_receipt.json').exists():certify_bank()
    if opts.rebuild_input_configs or not (OUT/'collection_contract.json').exists():make_configs()
    result=validate()
    save(OUT/'collection_ready.json',result)
    print('ready for registered GPU collection',OUT/'collection_ready.json')

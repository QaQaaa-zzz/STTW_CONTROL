"""Reproduce the ten registered P1 map assets with the frozen Chapter 3 map compiler."""
import csv, hashlib, json, sys, time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime, timezone
import mujoco, numpy as np
from evaluate_playground_handoff import transplant
from predict_platform_departures import physical_raster

OUT=Path(__file__).resolve().parent
P0=OUT.parent.parent/'chapter3_continuous_p0b_20261123'
CWD=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
read=lambda p:json.loads(Path(p).read_text())
def dump(p,o):p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def arrayhash(a):return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()
PARENT=read(P0/'protocol.json'); W=Path(PARENT['source_config']).parents[2]
TEMPL=read(W/'chapter_mainline/post_review/wall_layouts/test_freeze_manifest.json')['maps']
FROZENXML=Path(read(CWD/'learning/configs/playground_rb_skill_sources.json')['model']['path'])
PHYSICS=read(P0/'right_offset/part_0/config.json')['ground_physics']
# Offsets (m) are paired forward/lateral translations of each wall only.
SPECS=[
 ('train',0,'left',62213101,[[-.038,-.010]]),('train',1,'right',62213103,[[.032,.010]]),
 ('train',2,'staggered',62213107,[[-.032,.010],[.028,-.008]]),('train',3,'left',62213109,[[.034,.009]]),
 ('train',4,'right',62213113,[[-.036,-.010]]),('train',5,'staggered',62213117,[[.030,-.009],[-.032,.010]]),
 ('dev',0,'left',62213119,[[-.018,.006]]),('dev',1,'staggered',62213123,[[.016,.005],[-.022,-.006]]),
 ('calibration',0,'right',62213127,[[.020,-.005]]),('calibration',1,'staggered',62213129,[[-.014,-.006],[.022,.005]])]
FAMS={'left':'config_l','right':'config_r','staggered':'config_double'}
def declaration():
 historic_paths={**{f'historical_wall_{k}':v['path'] for k,v in TEMPL.items()},**{f'P0B_{k}':v['path'] for k,v in PARENT['layouts'].items()},**{'historical_'+k:v for k,v in read(W/'review_114/plan.json')['maps'].items()},**{'historical_'+k:v['path'] for k,v in read(W/'chapter_mainline/post_review/realtime_15ms/test_freeze_manifest.json')['maps'].items()}}
 excludes={k:dict(path=v,world_sha256=sha(v),seed=read(v)['terrain']['rough_source']['seed'],walls=read(v)['terrain']['forbidden_rectangles']) for k,v in historic_paths.items()}
 data=(s for s in csv.DictReader((OUT.parent/'split.csv').open()) if s['role'] in {'train','dev','calibration'})
 groups={}
 for row in data:groups.setdefault((row['role'],int(row['map_slot'])),[]).append(int(row['bank_row']))
 records=[]
 for role,i,fam,seed,offsets in SPECS:
  key=f'{role}_{i:02d}';template=TEMPL[FAMS[fam]];assert sha(template['path'])==template['sha256']
  basis=np.asarray(template['walls']);t=np.asarray(offsets);walls=(basis+t[:,[0,0,1,1]]).round(6)
  records.append(dict(id=key,role=role,map_slot=i,family=fam,seed=seed,template=template['path'],template_sha256=template['sha256'],wall_offsets_xy_m=offsets,walls_xyxy_m=walls.tolist(),roots=groups[role,i],world=str(OUT/key/'world.json'),mjb=str(OUT/key/'terrain.mjb'),raster=str(OUT/key/'terrain.npz')))
 assert len(groups)==10 and len({x['seed'] for x in records})==10 and all(len(x['roots'])==12 for x in records)
 assert not ({x['seed'] for x in records}&{v['seed'] for v in excludes.values()})
 assert all(not np.array_equal(x['walls_xyxy_m'],y['walls']) for x in records for y in excludes.values())
 assert len({str(x['walls_xyxy_m']) for x in records})==10
 return dict(role='Frozen P1 model development conditions; no P2 map or outcome inspected',registered_utc=datetime.now(timezone.utc).isoformat(),map_slots='Role-local map slot from ../split.csv; 12 distinct initial bank rows per map.',coordinate_order='World bounds and walls are [xmin,xmax,ymin,ymax]. Per-wall translation is [dx,dy] metres; positive y is left.',rationale='Train has two maps per old wall family with opposing small displacements. Four remaining slots mirror the double-wall condition across development/calibration and share the single left/right cases. The largest movement is 3.8 cm forward/backward and 1.0 cm sideways, within the 4.0 cm / 1.2 cm offsets already used in P0B. Preserve width, height, sign of lateral placement, wall order, goal, step, roughness distribution and the smooth takeoff/landing zones. Changes are fixed in advance; no outcome-based selection.',
   geometry_fixed=dict(step_x_m=10.3,step_height_m=.16,step_halfwidth_m=1.,level_approach_x_m=[8.3,10.3],level_landing_x_m=[10.3,12.3],rough_source_target_interval_m=[12.85,20.0],rough_source_far_x_remap_m=-.55),source_xml=str(FROZENXML),source_xml_sha256=sha(FROZENXML),ground_physics=PHYSICS,control_dt=.005,substeps=5,required_mujoco='3.6.0',source_scripts={k:sha(CWD/'learning/cli'/k) for k in ['evaluate_playground_handoff.py','predict_platform_departures.py']},exclude_worlds=excludes,parent_physics_receipt=str(P0/'terrain_build_receipt.json'),initial_bank=str(OUT.parent/'initial_bank.npz'),split=str(OUT.parent/'split.csv'),split_sha256=sha(OUT.parent/'split.csv'),records=records)
def build(rec):
 name=rec['id'];p=OUT/name;p.mkdir(exist_ok=True);w=read(rec['template']);w['map_id']='p1_'+name+'_'+str(rec['seed']); t=w['terrain'];t['rough_source']['seed']=rec['seed'];t['forbidden_rectangles']=rec['walls_xyxy_m'];t['rough_source']['forbidden_rectangles']=rec['walls_xyxy_m']
 dump(p/'world.json',w)
 transplant(SimpleNamespace(xml_path=FROZENXML),t,p,5,PHYSICS);physical_raster(p/'terrain.mjb',p/'terrain.npz')
 m=mujoco.MjModel.from_binary_path(str(p/'terrain.mjb'));old=mujoco.MjModel.from_binary_path(str(P0/('staggered' if rec['family']=='staggered' else 'right_offset')/'terrain.mjb'))
 assert m.opt.timestep==old.opt.timestep==.001 and m.opt.integrator==old.opt.integrator
 for field in ('body_mass','body_inertia','body_ipos','jnt_range','dof_damping','actuator_gear','actuator_gainprm','actuator_biasprm','pair_friction','pair_solref','pair_solimp','geom_friction','geom_solref','geom_solimp'):np.testing.assert_array_equal(getattr(m,field),getattr(old,field))
 step=m.geom('step');np.testing.assert_allclose(step.pos,old.geom('step').pos);np.testing.assert_allclose(step.size,old.geom('step').size)
 ii=[i for i in range(m.ngeom) if m.geom(i).name.startswith('planning_obstacle_')];assert len(ii)==len(rec['walls_xyxy_m'])
 walls=[]
 for idx,expected in zip(ii,rec['walls_xyxy_m']):
  x,y,z=m.geom_pos[idx];a,b,c=m.geom_size[idx];bounds=[x-a,x+a,y-b,y+b];np.testing.assert_allclose(bounds,expected,atol=1e-12);np.testing.assert_allclose([z-c,z+c],[.16,.66],atol=1e-12);walls.append(bounds)
 with np.load(p/'terrain.npz') as arr:
  h=arr['height'];supp=arr['support'];spa=arr['spacing'].item();x,y=np.arange(h.shape[1])*spa-5,np.arange(h.shape[0])*spa-4
  yl=np.abs(y)<=.95;pre=h[np.ix_(yl,(x>=8.325)&(x<=10.275))];post=h[np.ix_(yl,(x>=10.325)&(x<=12.275))];assert np.max(np.abs(pre))<1e-6 and np.max(np.abs(post-.16))<1e-6 and np.all(supp[np.ix_(yl,(x>=8.325)&(x<=12.275))]==1)
  terrain_id=arrayhash(h);rough=[float(h[np.ix_(yl,(x>=a)&(x<=b))].std()) for a,b in ((2.55,8.25),(12.35,19.4))];assert min(rough)>.0001
 return dict(**rec,map_id=w['map_id'],sha256=dict(world=sha(p/'world.json'),mjb=sha(p/'terrain.mjb'),raster=sha(p/'terrain.npz')),raster_heights_sha256=terrain_id,xy_bounds=w['bounds_xy_m'],physical_walls=walls,ngeom=m.ngeom,apron_height_minmax_m=[float(pre.min()),float(pre.max()),float(post.min()),float(post.max())],rough_height_std_m=rough)
def draw(records):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.patches import Rectangle
 rp=OUT.parent/'actions/approaches.npz'
 with np.load(rp) as z: routes=z['xy']
 fig,axes=plt.subplots(5,2,figsize=(14,13),layout='constrained')
 for ax,rec in zip(axes.flat,records):
  with np.load(rec['raster']) as z:h=z['height'].copy()
  xc=np.arange(h.shape[1])*.025-5; yc=np.arange(h.shape[0])*.025-4
  h[:,xc>=10.3]-=.16
  im=ax.imshow(h,origin='lower',extent=(-5.0125,25.0125,-4.0125,4.0125),vmin=0,vmax=.065,cmap='Greys',aspect='equal',interpolation='nearest')
  for path in routes:
   sel=(path[:,0]>=7.6)&(path[:,0]<=10.3)
   ax.plot(path[sel,0],path[sel,1],color='#00738d',alpha=.48,lw=.85)
  for xmin,xmax,ymin,ymax in rec['physical_walls']:ax.add_patch(Rectangle((xmin,ymin),xmax-xmin,ymax-ymin,fc='#c5472b',ec='#7e271a',lw=.8))
  ax.axvline(10.3,color='#71448b',lw=1);ax.axvline(12.3,color='#349369',ls=':',lw=.8);ax.set(xlim=(7.6,15.1),ylim=(-1.05,1.05),xlabel='world x (m)',ylabel='world y (m)')
  ax.set_title(f"{rec['id']}  |  {rec['family']}  |  seed {rec['seed']}",loc='left',fontsize=10)
 fig.suptitle('P1 map bank and 14 frozen approach references\nTeal: approach to step   |   Purple: step edge   |   Dotted green: level landing area ends   |   Red: walls\nShading: terrain height above local nominal ground/platform, common scale 0–6.5 cm',fontsize=11)
 fig.savefig(OUT/'map_reference_xy.png',dpi=155);plt.close(fig)
 return dict(path=str(OUT/'map_reference_xy.png'),route_bank=str(rp),route_bank_sha256=sha(rp),n_references=len(routes))
if __name__=='__main__':
 assert mujoco.__version__=='3.6.0';t=time.monotonic();target=OUT/'protocol.json'
 if not target.is_file():dump(target,declaration())
 frozen=read(target)
 with ProcessPoolExecutor(max_workers=3) as pool:records=list(pool.map(build,frozen['records']))
 assert len({x['raster_heights_sha256'] for x in records})==10
 for p in (P0/'right_offset/terrain.npz',P0/'staggered/terrain.npz',W/'review_114/primary_terrain.npz',W/'review_114/alternate_terrain.npz'):
  with np.load(p) as z:assert arrayhash(z['height']) not in {x['raster_heights_sha256'] for x in records}
 picture=draw(records)
 dump(OUT/'manifest.json',dict(protocol=str(target),protocol_sha256=sha(target),mujoco=mujoco.__version__,python=sys.executable,physical_worlds_executed=0,training_updates=0,elapsed_s=time.monotonic()-t,xy=picture,records=records))
 print('Maps compiled', len(records),'seconds',time.monotonic()-t,flush=True)

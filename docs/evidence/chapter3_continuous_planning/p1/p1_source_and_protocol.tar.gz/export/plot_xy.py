"""Render measured P1 routes, preserving true endpoints. Inputs are completed per-map exports."""
import argparse,base64,gzip,html,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd
from export_prefixes import P,OUT,read,save

COL={'task done':'#08766d','wall contact':'#ab381e','no verified handback':'#72519b','wrong gate':'#aa6a10','other endpoint':'#4d6377'}
def category(r):
 if r['physical_task_done']:return 'task done'
 if r['physical_wall']:return 'wall contact'
 if not r['verified_relock']:return 'no verified handback'
 if r['physical_goal'] and not r['correct_gate']:return 'wrong gate'
 return 'other endpoint'
def compact(a,stride=6):
 if not len(a):return []
 idx=np.unique(np.r_[np.arange(0,len(a),stride),len(a)-1]);return np.round(a[idx].astype(float),4).tolist()
def background(ax,w):
 for a,b,c,d in w['terrain']['forbidden_rectangles']:ax.add_patch(Rectangle((a,c),b-a,d-c,color='#ad4b36',alpha=.5))
 gx=w['goal'];ax.add_patch(Rectangle((gx['x_min_m'],-gx['abs_y_max_m']),gx['x_max_m']-gx['x_min_m'],2*gx['abs_y_max_m'],fc='#d7edcf',alpha=.7))
 ax.axvline(w['terrain']['front_x_m'],color='#52616d',ls=':',lw=1);ax.set_aspect('equal',adjustable='box');ax.set_xlabel('world x (m)');ax.set_ylabel('world y (m)');ax.grid(lw=.25,alpha=.3)
def real_examples(records):
 ranked=sorted(records,key=lambda r:(r['root'],r['action_slot'],abs(r['force']),r['force'],r['lane']))
 for fields in (('root','action_slot','force'),('root','action_slot'),('root',)):
  bins={}
  for row in ranked:bins.setdefault(tuple(row[k] for k in fields),[]).append(row)
  for values in bins.values():
   win=[x for x in values if x['outcome']=='task done'];loss=[x for x in values if x['outcome']!='task done']
   if win and loss:return [win[0],loss[0]],list(fields)
 return [],[]
def map_xy(batch):
 dest=OUT/batch['role']/batch['name'];out=dest/'xy';out.mkdir(parents=True,exist_ok=True);suff=pd.read_csv(dest/'suffix_index.csv');pidx=pd.read_csv(dest/'prefix_index.csv')
 lane_meta=pd.read_csv(Path(batch['physical'])/'p1_lanes.csv').set_index('lane')
 world=read(batch['world']); records=[]; raw={}
 for r in suff.to_dict('records'):
  ri=int(r['row']); q=pidx.iloc[ri];met=lane_meta.loc[r['lane']]
  with np.load(r['trajectory']) as z:tr=z['trace'];xy=tr[:,1:3].astype(float);app=z['reference_xy'];final=z['published_reference_xy']
  assert abs(tr[-1,0]-r['duration_s'])<1e-5
  finite=np.flatnonzero(np.isfinite(xy).all(axis=1)); assert len(finite) and np.array_equal(finite,np.arange(finite[-1]+1))
  xy=xy[:finite[-1]+1];last_xy_s=float(tr[finite[-1],0]);missing_xy=len(tr)-len(xy)
  # Draw the planned approach through handback/release, and the published exit after release.
  applied=int(r['assigned_tick']);endproj=xy[min(applied if applied>=0 else len(xy)-1,len(xy)-1),0]
  approach=app[(app[:,0]>=xy[0,0]-.05)&(app[:,0]<=endproj+.025)]
  ex=final[(final[:,0]>=endproj-.025)&(final[:,0]<=max(xy[-1,0]+.1,world['goal']['x_max_m']))] if r['physical_target_effective'] else final[:0]
  start=int(met.pulse_start_tick);used=int(met.applied_force_ticks);mark=xy[start:min(len(xy),start+used+1)] if start>=0 and used else xy[:0]
  hand=round(r['native_handoff_s']/.005) if pd.notna(r['native_handoff_s']) else -1
  assert hand<len(xy)
  row=dict(prefix=ri,root=r['root'],action_slot=r['action_slot'],geometry=r['geometry'],alpha=r['alpha'],force=r['hidden_force_N_grouping_only'],lane=r['lane'],arm=r['arm'],end_s=r['duration_s'],last_finite_xy_s=last_xy_s,missing_terminal_xy_frames=missing_xy,outcome=category(r),termination=r['termination'],gate=r['section']+(' left' if r['target_side']==1 else ' right'),section_x=r['section_x'],direction=r['target_side'],wall=r['physical_wall'],verified=r['verified_relock'],observed_query=r['observed_query'],pulse_start_tick=start,applied_force_ticks=used,actual_file=r['trajectory'],t0_xy=xy[0].tolist(),terminal_xy=xy[-1].tolist(),observed_relock_xy=xy[hand].tolist() if hand>=0 else None,receipt=r['query_file'] if pd.notna(r['query_file']) else None)
  raw[r['lane']]=(xy,approach,ex,mark);records.append(row)
 assert len(records)==2*len(pidx)==1152 and len({r['root'] for r in records})==12
 pages=[];outcome_order=list(COL)
 def plot(panel,file,title,mixed=False):
  fig,axes=plt.subplots(2,1,figsize=(12,6),layout='constrained')
  xys=np.concatenate([raw[r['lane']][0] for r in panel]);ymin=float(xys[:,1].min());ymax=float(xys[:,1].max())
  for j,ax in enumerate(axes):
   background(ax,world);seen=set()
   for r in panel:
    xy,ap,ex,mark=raw[r['lane']]
    for rr,ls in ((ap,'--'),(ex,':')):
     if len(rr):
      token=(ls,rr.shape[0],rr[0,0],rr[-1,1],r['geometry'],r['arm']); 
      if token not in seen:
       ax.plot(rr[:,0],rr[:,1],ls,color='#272727',lw=1.0 if mixed else .65,alpha=.8 if mixed else .45,zorder=3);seen.add(token)
    color=COL[r['outcome']];ax.plot(xy[:,0],xy[:,1],color=color,lw=1.9 if mixed else .7,alpha=.95 if mixed else .55)
    ax.scatter(*xy[-1],marker='o' if r['outcome']=='task done' else 'x',s=22 if mixed else 8,color=color,zorder=5)
    if mixed and len(mark):ax.plot(mark[:,0],mark[:,1],color='#ce3378',lw=3,zorder=5)
    if mixed and r['observed_relock_xy'] is not None:ax.scatter(*r['observed_relock_xy'],marker='D',facecolors='none',edgecolors=color,s=40,zorder=6)
   if j==0: ax.set_xlim(min(-.1,xys[:,0].min()-.15),max(18.7,xys[:,0].max()+.2));ax.set_ylim(min(-1,ymin-.08),max(1.,ymax+.08));ax.set_title('Full physical path')
   else:ax.set_xlim(9.3,max(18.7,xys[:,0].max()+.2));ax.set_ylim(min(-.75,ymin-.06),max(.75,ymax+.06));ax.set_title('Step, wall, gate and terminal position')
   if mixed:
    for sx,side in {(r['section_x'],r['direction']) for r in panel}:ax.plot([sx,sx],[.06*side,1.*side],color='#3450a4',lw=2,alpha=.6)
  handles=[Line2D([],[],color=COL[k],lw=2,label=k) for k in outcome_order if any(r['outcome']==k for r in panel)]
  handles += [Line2D([],[],color='k',ls='--',label='approach reference'),Line2D([],[],color='k',ls=':',label='published exit reference')]
  if mixed:handles += [Line2D([],[],color='#ce3378',lw=3,label='applied pulse interval'),Line2D([],[],color='#555',marker='D',ls='',markerfacecolor='none',label='native relock')]
  axes[1].legend(handles=handles,ncol=min(4,len(handles)),fontsize=8,loc='upper center',bbox_to_anchor=(.5,-.25));fig.suptitle(title,fontsize=12)
  fig.savefig(file,dpi=145,bbox_inches='tight');plt.close(fig)
 for root in sorted({r['root'] for r in records}):
  panel=[r for r in records if r['root']==root]; png=f'root_{root}.png'; page=f'root_{root}.html';plot(panel,out/png,f"{batch['name']}   |   root {root}   |   {len(panel)} measured branches   |   phase2 H75 / RB run1")
  payload=[]
  for r in panel:
   xy,a,e,m=raw[r['lane']];payload.append(dict(**r,xy=compact(xy),app=compact(a),exit=compact(e),push=compact(m,1)))
  scene=dict(walls=world['terrain']['forbidden_rectangles'],goal=world['goal'],edge=world['terrain']['front_x_m'],colors=COL,records=payload)
  markup=(Path(__file__).parent/'xy_template.html').read_text().replace('DATAHERE',json.dumps(scene,separators=(',',':'),allow_nan=False)).replace('TITLEHERE',f"{batch['name']} · root {root}").replace('PNGHERE',png)
  (out/page).write_text(markup);pages.append((root,page,png))
 selected,level=real_examples(records)
 if selected:plot(selected,out/'paired_example.png',f"{batch['name']} | root {selected[0]['root']} | "+' vs. '.join(f"action {r['action_slot']}, {r['force']:+} N, {r['arm']} exit: {r['outcome']}" for r in selected),True)
 pd.DataFrame(records).assign(root_browser=lambda d:'root_'+d.root.astype(str)+'.html').to_csv(out/'trajectory_index.csv',index=False)
 links=''.join(f'<li>Root {r} · <a href="{page}">choose action and pulse</a> · <a href="{png}">all measured routes</a></li>' for r,page,png in pages)
 (out/'index.html').write_text(f'<!doctype html><meta charset="utf-8"><title>{batch["name"]} measured XY</title><h1>{batch["name"]} measured XY</h1><p>12 roots · 576 approach/pulse prefixes · 1,152 measured vehicle branches. All plots use world metres at equal scale.</p>'+('<p><a href="paired_example.png">Same-root success and failure</a></p>' if selected else '')+f'<ul>{links}</ul><p><a href="trajectory_index.csv">Raw trajectory index</a></p>')
 save(out/'receipt.json',dict(physical_lanes=len(records),prefixes=len(pidx),roots=len(pages),png_count=len(pages)+bool(selected),total_observed_track_points=sum(len(v[0]) for v in raw.values()),browser_stride_ticks=6,missing_terminal_xy_frames=sum(r['missing_terminal_xy_frames'] for r in records),branches_missing_terminal_xy=sum(r['missing_terminal_xy_frames']>0 for r in records),full_xy_source='Every finite native 5 ms trace[:,1:3] drawn on overview and example PNG. If a terminal position is nonfinite, mark the last observed XY and record the true terminal time and unobservable XY duration separately. Browser samples every sixth observed control tick plus terminal and labels the native endpoint; full raw NPZ is indexed. No future position after observed termination.',chosen_example_contract='First ordered root/action/pulse with a physical task success and physical task failure, followed by first root/action or first root only if needed. Use only as an illustration.',example_shared_fields=level,example=selected,all_outcomes=pd.Series([r['outcome'] for r in records]).value_counts().to_dict()))
 print('XY complete',batch['name'],len(records),len(pages),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--map',required=True);a=p.parse_args();map_xy(next(b for b in read(P/'collection_contract.json')['batches'] if b['name']==a.map))

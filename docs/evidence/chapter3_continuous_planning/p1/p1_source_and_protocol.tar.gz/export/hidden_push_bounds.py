"""Finite-panel minimum errors for identical observable inputs under the three registered pushes."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd


def bounds(directory):
    ix=pd.read_csv(directory/'prefix_index.csv')
    with np.load(directory/'measured_targets.npz') as labels:
        succeeded=labels['verified_relock']
        measured=labels['regression_valid']
        position=labels['query_qpos_native'][:,:2]
    with np.load(directory/'observed_inputs.npz') as z:
        features={name:z[name] for name in z.files}
    rows=[]
    for (root,action), g in ix.groupby(['root','action_slot']):
        ids=g.row.to_numpy()
        assert set(g.hidden_force_N_grouping_only)=={-5,0,5} and len(ids)==3
        for x in features.values():
            np.testing.assert_array_equal(x[ids],np.broadcast_to(x[ids[0]],x[ids].shape))
        f=succeeded[ids]; s=int(f.sum());n=len(ids)
        xy=position[ids[measured[ids]]]
        err=((xy-xy.mean(0))**2).sum() if len(xy) else 0.
        rows.append(dict(root=root,action_slot=action,geometry=g.geometry.iloc[0],alpha=g.alpha.iloc[0],
            success_count=s,prefixes=n,best_mistakes=min(s,n-s),min_brier_sum=s*(n-s)/n,
            observed_states=len(xy),min_xy_squared_sum_m2=err,
            successful_pushes_N=','.join(str(v) for v in g.hidden_force_N_grouping_only[f])))
    table=pd.DataFrame(rows)
    result={'map':str(ix.layout.iloc[0]),'role':str(ix.role.iloc[0]),'prefixes':len(ix),
         'root_action_groups':len(table),'groups_by_number_of_relocks':table.success_count.value_counts().reindex(range(4),fill_value=0).to_dict(),
         'mixed_groups':int(table.success_count.isin([1,2]).sum()),'min_classification_errors':int(table.best_mistakes.sum()),
         'min_brier':table.min_brier_sum.sum()/len(ix),'measured_states':int(table.observed_states.sum()),
         'min_xy_rmse_on_measured_m':float(np.sqrt(table.min_xy_squared_sum_m2.sum()/table.observed_states.sum())) if table.observed_states.sum() else None,
         'conditioning':'One departure-time prediction per identical eight-field observation. All three registered pushes equally weighted. XY error conditions on measured successful re-lock and uses position when the ground planner is first queried.',
         'derivation':'With k successes in 3 trials, any fixed class misses at least min(k,3-k). The best constant probability is k/3, giving summed squared error k*(3-k)/3. The mean of the observed XY points minimizes their summed squared Euclidean distance. These are lower bounds even if two distinct groups share the same inputs.'}
    table.to_csv(directory/'hidden_push_by_action.csv',index=False)
    (directory/'hidden_push_bounds.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path)
    print(json.dumps(bounds(parser.parse_args().directory)))

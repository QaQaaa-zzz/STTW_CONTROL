"""Check the frozen P1 mapping plus archived P0-B real inputs and actual query state on CPU."""
import json, sys,tempfile
from pathlib import Path
import numpy as np,pandas as pd,torch
from export_prefixes import P,OUT,read,save,digest,config_rows,decision_inputs,query_record,OBSERVED
sys.path.insert(0,str(P/'model'))
from jump_outcome import Dataset
from sttw_control.platform_online import velocity_state

ct=read(P/'collection_contract.json');batches=ct['batches']; info=[]
for b in batches:
 cfg,l,r=config_rows(b)
 info.append(dict(map_id=b['name'],role=b['role'],physical_lanes=len(l)+len(r),root_actions=len(l.groupby(['bank_row','action_slot'])),three_push_prefixes=len(l),left_right_paired_before_outcomes=True))
df=pd.DataFrame(info);df[df.role.isin(['train','dev'])][['map_id','role']].to_csv(OUT/'formal_train_dev.csv',index=False)
df[df.role=='calibration'][['map_id','role']].to_csv(OUT/'calibration.csv',index=False)
old=P.parent/'chapter3_continuous_p0b_20261123';dev=old/'analysis/p1_dev_prefixes'
ix=pd.read_csv(dev/'prefix_index.csv')
with np.load(dev/'observed_inputs.npz') as z:inputs=dict(z)
with np.load(dev/'measured_targets.npz') as z:targets=dict(z)
with np.load(old/'approaches.npz') as z:curves=dict(z)
for layout,ids in ix.groupby('layout').indices.items():
 world=read(old/layout/'world.json')
 with np.load(old/layout/'terrain.npz') as z:raster=dict(z)
 rebuilt=decision_inputs(inputs['t0_qpos_native'][ids],inputs['t0_qvel_native'][ids],ix.geometry.to_numpy()[ids],ix.alpha.to_numpy()[ids],curves,raster,world)
 for k in OBSERVED:np.testing.assert_array_equal(rebuilt[k],inputs[k][ids])
sampled=ix[ix.handback_snapshot.notna()].groupby('layout',sort=False).head(1)
for r in sampled.itertuples():
 with np.load(r.trajectory) as z:q,v=z['qpos'],z['qvel']
 with np.load(r.handback_snapshot) as z:
  k=int(r.query_tick_grouping_only);j=int(np.where(z['lanes']==r.lane)[0][0]);oldfields=dict(qpos=z['physics_qpos'],qvel=z['physics_qvel'],previous_qpos=z[f'query_pose_history_{k%4}'],previous_qvel=z[f'query_velocity_history_{k%4}'])
  packet=dict(**oldfields,tick=k,previous_tick=k-4,lanes=z['lanes'],velocity=velocity_state(torch.from_numpy(oldfields['qpos']),torch.from_numpy(oldfields['qvel'])).numpy(),previous_velocity=velocity_state(torch.from_numpy(oldfields['previous_qpos']),torch.from_numpy(oldfields['previous_qvel'])).numpy())
  mapped=query_record(packet,j,r.lane,q,v)
  for field,key in [('qpos','query_qpos_native'),('qvel','query_qvel_native'),('previous_qpos','previous_qpos_native'),('previous_qvel','previous_qvel_native'),('velocity','query_velocity_state9'),('previous_velocity','previous_velocity_state9')]:
   np.testing.assert_array_equal(mapped[field],targets[key][r.row])
ok=np.flatnonzero(targets['is_relocked']);loss=np.flatnonzero(~targets['is_relocked']);testids=[ok[0],ok[1],loss[0]]
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);np.savez(p/'observed_inputs.npz',**{k:v[testids] for k,v in inputs.items()})
 t={k:v[testids].copy() for k,v in targets.items()}; t['verified_relock']=t['is_relocked'];t['observed_query']=np.array([True,False,False])
 for k in ('query_qpos_native','query_velocity_state9','previous_velocity_state9'):t[k][1]=np.nan
 np.savez(p/'measured_targets.npz',**t);ix.iloc[testids].assign(row=np.arange(3)).to_csv(p/'prefix_index.csv',index=False);loaded=Dataset.load(p)
 assert loaded.success.tolist()==[True,True,False] and loaded.measured.tolist()==[True,False,False]
save(OUT/'interface_validation.json',dict(scope='Precollection check on frozen P1 configs plus prior real P0-B records, no P1 trajectories emitted.',maps=info,total_P1_prefixes_scheduled=sum(x['three_push_prefixes'] for x in info),eight_archived_inputs_exact={'rows':len(ix),'layouts':ix.layout.nunique(),'keys':OBSERVED,'archive':str(dev)},prior_query_native_snapshot_checks=dict(count=len(sampled),rows=sampled.row.tolist(),trace_native_pose_velocity_and_prior_history='bitwise matched',limitation='legacy snapshot stores native q/v; velocities reconstructed for this compatibility check. P1 exports must additionally read the actual velocity and previous_velocity passed to choose().'),
 supervised_loader_three_row_mask_test=dict(rows_from_historical_archive=[int(k) for k in testids],purpose='exercise a missing query by deliberately clearing one successful archived query in a temporary test fixture; no P1 supervision written',classification=[True,True,False],regression=[True,False,False]),official_fit_splits='formal_train_dev.csv contains eight maps; calibration.csv is separate.',contract_sha256=digest(P/'collection_contract.json')))
print('OK',len(ix),'historical rows x 8 fields, two measured prior native query snapshots, three example masks,',len(info),'frozen P1 configurations')

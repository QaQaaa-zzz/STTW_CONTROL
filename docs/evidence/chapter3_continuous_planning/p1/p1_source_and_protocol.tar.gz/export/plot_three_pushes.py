"""Draw the three actual trials for one root and one approach slot."""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

a=argparse.ArgumentParser();a.add_argument('directory',type=Path);a.add_argument('root',type=int);a.add_argument('action',type=int);cfg=a.parse_args()
p=cfg.directory;root=cfg.root;slot=cfg.action
source = pd.read_csv(p/'suffix_index.csv')
case = source[(source.root==root)&(source.action_slot==slot)&source.arm.eq('left')].sort_values('hidden_force_N_grouping_only')
assert len(case)==3
world=json.loads((p.parents[2]/'maps'/p.name/'world.json').read_text());ter=world['terrain'];goal=world['goal']
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Noto Sans CJK SC','Noto Sans CJK JP','DejaVu Sans'],'axes.unicode_minus':False})
fig,(xy,height)=plt.subplots(2,1,figsize=(10.5,5.4),gridspec_kw={'height_ratios':[1.25,1]},layout='constrained')
fig.suptitle(f'同一起点、同一条接近路线，三次不同横推　｜　{p.name} · 起点 {root} · 动作 {slot}',fontsize=15)
colors={-5:'#cc640f',0:'#166c65',5:'#604ca0'}
for r in case.itertuples(index=False):
    with np.load(r.trajectory) as z:
        q=z['qpos'];t=z['trace'][:,0]
    force=getattr(r,'hidden_force_N_grouping_only')
    valid=np.isfinite(q[:,:3]).all(1)&(t<=r.duration_s+1e-5)
    qa=q[valid];ta=t[valid]
    lab=f'{force:+d} N　'+('越阶并复锁' if r.verified_relock else '未复锁')
    xy.plot(qa[:,0],qa[:,1],color=colors[force],lw=1.8,label=lab)
    xy.plot(qa[-1,0],qa[-1,1],marker='x',ms=6,color=colors[force])
    if r.verified_relock:
        j=abs(ta-r.native_handoff_s).argmin()
        xy.plot(qa[j,0],qa[j,1],marker='o',ms=5,mfc='white',color=colors[force])
    height.plot(ta,qa[:,2],color=colors[force],lw=1.7)
    ix=pd.read_csv(Path(r.trajectory).parents[1]/'p1_lanes.csv',usecols=['lane','pulse_start_tick','applied_force_ticks'])
    row=ix[ix.lane==r.lane].iloc[0]
    if force:
        active=(ta>=row.pulse_start_tick*.005)&(ta<(row.pulse_start_tick+row.applied_force_ticks)*.005)
        height.plot(ta[active],qa[active,2],color=colors[force],lw=4)
with np.load(p.parents[2]/'actions/approaches.npz') as curves:
    ref=curves['xy'][int(case.geometry.iloc[0])]
approach=ref[ref[:,0]<=ter['front_x_m']+world['forward_obstacle']['activation_offset_m']]
xy.plot(approach[:,0],approach[:,1],color='#737f88',ls=':',lw=1.4,label='所选接近路线')
for x0,x1,y0,y1 in ter['forbidden_rectangles']:
    xy.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc='#343c40'))
xy.axvline(ter['front_x_m'],ls='--',color='#777',lw=.8)
xy.set(xlabel='世界前进方向 x（m）',ylabel='横向 y（m）',aspect='equal',xlim=(1,18.5),ylim=(-1.15,1.15))
xy.legend(loc='upper left',bbox_to_anchor=(0,1.38),ncol=4,frameon=False,fontsize=9)
height.set(xlabel='从出发开始的时间（s）',ylabel='车体根部高度（m）',title='线条加粗的 0.10 秒内施加横推')
height.spines[['right','top']].set_visible(False);xy.spines[['right','top']].set_visible(False)
fig.savefig(p/'xy'/f'three_pushes_{root}_slot_{slot}.png',dpi=150)

"""CPU audit of actual prefix and shadow/publication records; retains both physical arms for all pairs."""
import csv
import json
from pathlib import Path
import sys
import numpy as np

OUT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def same(a,b):return a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes()
def table(path,rows):
    with path.open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def audit(name):
    b=next(b for b in read(OUT/'collection_contract.json')['batches'] if b['name']==name)
    physical=Path(b['physical']);status=read(physical/'status.json');rows=status['results']
    if status['stage']!='complete' or len(rows)!=1152:raise ValueError('Physical batch incomplete')
    cfg=read(physical/'resolved_config.json');variants=cfg['ground_handoff']['handoff_variants']
    with np.load(physical/'p1_applied_controls.npz') as z:controls=z['targets'];valid=z['valid']
    if controls.shape[1:]!=(1152,4) or controls.shape[:2]!=valid.shape:raise ValueError('Bad actual command schema')
    queries={}; data={}
    for path in sorted((physical/'p1_query').glob('tick_*.npz')):
        with np.load(path) as z:ev=dict(z)
        t=int(ev['tick']);pt=int(ev['previous_tick'])
        if pt!=t-4:raise ValueError('Incorrect history offset')
        for j,l in enumerate(ev['lanes']):
            l=int(l)
            if l in queries:raise ValueError('Duplicate shadow event')
            queries[l]=(t,pt,path,j)
            data[l]={k:v[j] for k,v in ev.items() if k not in ('tick','previous_tick','remaining_s')}
    counts={};profiles=[];pairs=[]
    for i in range(0,len(rows),2):
        arms=[];outcomes=[];starts=[]
        for l in (i,i+1):
            r=rows[l];v=r['variant'];direction=(0,2)[l%2]
            if r['variant']!=variants[l] or v['planned_departure']!=direction or v['planner']!='C':
                raise ValueError(f'Frozen pair identity differs at lane {l}')
            path=physical/r['case_dir']/'trajectory.npz'
            with np.load(path) as z:arm={k:z[k] for k in ('qpos','qvel','trace','contact_substep','wheel_contact_flags','world_flags')}
            arm['target']=controls[:,l];arm['valid']=valid[:,l];arms.append(arm)
            stop=round(r['duration_s']/.005)
            if len(arm['qpos'])!=stop+1 or not np.all(arm['valid'][:stop]) or np.any(arm['valid'][stop:]):
                raise ValueError('Physical endpoint and actual control schedule disagree')
            h=None if r['handoff_s'] is None else round(r['handoff_s']/.005)
            expected=h is not None and h+1<=stop
            if expected!=(l in queries):raise ValueError(f'Missing or premature shadow query in lane {l}')
            due=r['departure_due_tick'];applied=r['departure_applied_tick'];query=None if not expected else queries[l]
            if query:
                t,pt,qpath,j=query;dd=data[l]
                if t!=h+1 or due!=t+3 or int(dd['incumbent_direction'])!=direction or r['proposed_departure']!=direction:
                    raise ValueError('Shadow or physical direction/clock contract differs')
                if not all(same(dd[k],arm['qpos' if 'qpos' in k else 'qvel'][t if not k.startswith('previous') else pt])
                           for k in ('qpos','qvel','previous_qpos','previous_qvel')):
                    raise ValueError(f'Shadow query or 20 ms history differs from actual physical trace: {l}')
                if due<=stop and (applied!=due or r['selected_departure']!=direction):
                    raise ValueError('Due physical release failed to select the frozen physical branch')
                if due>stop and applied>=0:raise ValueError('Unexpected post-terminal release')
            elif applied>=0:raise ValueError('A no-query lane reports a physical release')
            fields=dict(batch=name,lane=l,prefix=i//2,bank_row=v['bank_row'],root_slot=v['root_slot'],action_slot=v['action_slot'],
                geometry=v['geometry'],alpha=v['approach_alpha'],force_N=v['force_y_N'],side=v['side'],section=v['bin'],
                planned_departure=direction,termination=r['termination'],duration_tick=stop,rb_entry_s=r['rb_entry_s'],pulse_start_tick=r['air_event_tick'],
                applied_force_ticks=r['applied_force_ticks'],handoff_s=r['handoff_s'],query_tick=query[0] if query else None,
                previous_tick=query[1] if query else None,query_file=str(query[2]) if query else '',query_file_row=query[3] if query else None,
                shadow_choice=int(data[l]['shadow_choice']) if query else None,shadow_any_admitted=bool(data[l]['shadow_any_admitted']) if query else None,
                shadow_incumbent_admitted=bool(data[l]['shadow_incumbent_admitted']) if query else None,
                physical_due_tick=due,physical_assigned_tick=applied,physical_selected_direction=r['selected_departure'],
                physical_target_effective=(0<=applied<stop),actual_targets_file=str(physical/'p1_applied_controls.npz'),trajectory=str(path))
            profiles.append(fields);outcomes.append(fields);starts.append(min(stop,query[0] if query else stop))
        aa,bb=arms;a,b2=outcomes;last=min(starts)
        observables=['qpos','qvel','trace','wheel_contact_flags','world_flags']
        equal={k:same(aa[k][:last+1],bb[k][:last+1]) for k in observables}
        commands=same(aa['target'][:last],bb['target'][:last]) and same(aa['valid'][:last],bb['valid'][:last])
        ca,cb=[arm['contact_substep'][:last+1] for arm in arms]
        cp=same(ca[:,:,:3]<=1e-5,cb[:,:,:3]<=1e-5) and same(ca[:,:,3]==0,cb[:,:,3]==0)
        sameclock=all(a[k]==b2[k] for k in ['rb_entry_s','pulse_start_tick','applied_force_ticks','handoff_s','query_tick'])
        at_query=i in data and i+1 in data
        omit={'lanes','incumbent_direction','shadow_choice','shadow_incumbent_admitted','shadow_any_admitted'}
        different=[k for k in data[i] if k not in omit and not same(np.asarray(data[i][k]),np.asarray(data[i+1][k]))] if at_query else []
        common=all(equal.values()) and commands and cp and sameclock and not different
        if not common:result='unmatched_observed_prefix_or_state'
        elif at_query:result='matched_observed_handoff'
        elif starts[0]==starts[1] and a['termination']==b2['termination']:result='matched_observed_prequery_endpoint'
        else:result='unmatched_prequery_endpoint'
        counts[result]=counts.get(result,0)+1
        pairs.append(dict(batch=name,prefix=i//2,bank_row=a['bank_row'],action_slot=a['action_slot'],geometry=a['geometry'],
            alpha=a['alpha'],force_N=a['force_N'],side=a['side'],section=a['section'],left_lane=i,right_lane=i+1,
            checked_end_tick=last,**{k+'_equal':v for k,v in equal.items()},actual_controls_equal=commands,
            raw_substep_loads_equal=same(ca,cb),contact_threshold_predicates_equal=cp,phase_pulse_query_times_equal=sameclock,
            observed_shadow_state_differences=','.join(different),status=result))
    table(physical/'p1_lanes.csv',profiles);table(physical/'p1_prefixes.csv',pairs)
    result=dict(stage='complete',physical_lanes=len(profiles),distinct_prefixes=len(pairs),counts=counts,shadow_lanes=len(queries),
        observed_kinematics_and_controls='All contiguous qpos, qvel and actual applied target frames up to the first query or actual endpoint.',
        certificate='Exact recorded state/controller/query fields plus threshold predicates; raw floating-point contact loads reported separately. No claim of full device solver identity.')
    (physical/'p1_pair_summary.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':audit(sys.argv[1])

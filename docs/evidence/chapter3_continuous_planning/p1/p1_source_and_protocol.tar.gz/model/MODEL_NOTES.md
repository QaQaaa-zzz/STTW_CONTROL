# P1 jump-outcome estimators

As of 2026-11-23 the runners and frozen downstream state interface have passed CPU smoke tests on a small subset of the two old, inspected P0-B development maps. New P1 physical data, calibration maps and sealed test cases played no part in the fit or operating-point selection.

## From the initial decision to the first post-handoff query

The single decision is made at the measured initial reset, before the 15 ms approach-publication delay. Inputs come from an allowlist of eight decision-time arrays in observed_inputs.npz. They carry the actual initial native pose, initial velocity, candidate path profile and preference α, known step geometry, and elevation/support raster along the approach. The numerical 230-D vector includes physical path summaries at 13 distances for continuity between represented candidates. Map, source root and hidden push identities are indexing metadata only. The three different future pushes of each root/candidate in the old archives had bit-identical numerical inputs.

The first head estimates the probability of verified re-lock. Every failure contributes to its binary cross entropy. On a verified re-lock with an observed first query the model also learns 30 coordinates: re-lock time; world-frame displacement from reset; relative SO(3) rotation vector; five joint displacements; and the two nine-element velocity vectors at query and 20 ms before query. For the old archive and this protocol the query occurs one 5 ms control tick after re-lock. The consumer receives native qpos, query velocity and its actual 20 ms predecessor, in that order. The two velocities are future targets, never initial observations. A verified re-lock without an observed query remains a positive probability label and has missing state targets; this implementation does not fit its isolated re-lock time. An observed query without verified re-lock supplies no successful-state target.

For prediction the time is bounded and rounded to 5 ms, quaternion reconstructed and normalized, and the steering, hip and knee projected to nominal joint ranges. Wheel angles remain unwrapped. qpos need not constitute a physically reachable pose; projecting joints, normalizing quaternions and generating a finite downstream result check encoding only. The raw codec can be called without nominal-stop projection to reproduce the measured soft-stop solver states.

## Matched model and empirical comparisons

The two neural variants share the 230→48→48 SiLU architecture, three expert proposals/scales and one re-lock head, with 22,456 trainable parameters each. In single-Gaussian mode all expert proposals are combined into a single conditional center and per-coordinate residual scale. Its central trajectory provides the point-estimate comparator. Mixture mode keeps three components and samples a single component for all 30 coordinates, then one full residual vector. This captures cross-coordinate dependence induced by mode choice. The within-component covariance is diagonal. Either variant can return conditional samples with a separate success probability, or unconditional samples with missing states on failures. A risk calculation using conditional draws must still weight by the re-lock probability.

Training uses Bernoulli cross entropy on every prefix plus joint conditional negative log-likelihood on a measured successful state, divided by 30 to balance its scale. The sum is averaged over all rows. Per-coordinate standardization uses the training subset only. An identical seeded batch stream, Adam settings and update count serve both variants. The summary reports binary loss, Brier score, normalized conditional log-loss, elapsed-time MAE, position RMSE and quaternion geodesic error separately from the training loss.

Both non-network baselines return a probability and whole measured outcome vectors. The first averages over all support roots. The second uses five distinct roots nearest the query initial state; root distance uses train-standardized initial y, canonical quaternion, and the six initial translational/angular rates. Roots are validated against distinct numerical resets. Each root has equal weight regardless of its record count. Inside each support root, distance between candidates is the square root of the mean squared difference across 13 path samples of y/0.22 m, heading/0.14 rad and curvature/0.85 m⁻¹, plus squared Δα. Nearest distance below 0.025 uses just that action; otherwise the three nearest actions get inverse-square weights. Repeated treatments within an action are equally weighted. A successful query sample transports the entire measured relative-pose/time/velocity vector to the new reset. Empty successful support yields an undefined conditional state. Thresholds and scaling are engineering choices fixed for this smoke, requiring prospective declaration before the formal comparison.

## Numerical evidence

The smoke fit used 72 old rows from six roots on right_offset and evaluated 24 rows from two different roots on staggered. Each root contributed four complete action designs and three future push values. It ran 12 CPU Adam updates, batch 24, learning rate 0.001, seed 612041. Of the evaluation rows, 13 contained re-locks with observable query states. Repeated outcomes sharing a root are correlated.

| Model | Validation Brier ↓ | Conditional NLL per standardized coordinate ↓ | Re-lock time MAE, s | Query-plane position RMSE, m |
|---|---:|---:|---:|---:|
| Single Gaussian | .18958 | 1.37600 | .09385 | .31051 |
| Three-component mixture | .19043 | 1.36816 | .09231 | .31028 |
| Action empirical rate | .16906 | — | — | — |
| Five distinct neighbors | .17286 | — | — | — |

Neither network improved the empirical probability scores on this smoke. The small difference between network conditional log-loss values does not select an architecture. The 13 measured successes round-tripped qpos to max absolute coordinate error 9.54e-7 and time to 4.77e-7 s, both twist vectors exactly. The real frozen 28-input affine initializer reproduced the measured hidden coordinates to 8.95e-7. For each variant 16 newly sampled conditional particles went through the frozen real HistoryDynamics.step for one 20 ms prediction with finite outputs. A synthetic check forced well-separated modes and verified a common component across 512 generated particles. The raw metrics and optimization trace are in smoke_receipt.json and smoke_optimization.csv.

## CPU invocation

Set the work directory to this model folder. Conda/venv executable and source checkout used for the smoke:

```sh
export CUDA_VISIBLE_DEVICES=''
export PYTHONPATH=/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src
PY=/home/qy/mujoco_playground/.venv/bin/python
"$PY" smoke_outcome.py --old-dev /media/qy/6A7E3DB07E3D75C3/STTW_runs/chapter3_continuous_p0b_20261123/analysis/p1_dev_prefixes
"$PY" fit_outcome.py --help
```

For an already authorized fixed-budget fit the command form is `fit_outcome.py --data EXPORT_ROOT --split FROZEN_SPLIT.csv --out NEW_DIR --steps N --batch-size B --seed S --device cuda`. The approved GPU job requires a visible CUDA device; the empty visibility setting above belongs only to the CPU smoke. The estimator tensors, Adam and evaluation run on the chosen device. Seeded row permutations are generated on CPU to match modes. The empirical comparators run on CPU and checkpoints are exported as portable CPU tensors. CUDA routing has been implemented but has not been exercised on hardware. The split CSV lists map_id,role where role is train or dev. Each map folder EXPORT_ROOT/role/map_id contains observed_inputs.npz, measured_targets.npz and prefix_index.csv. A flat archive with a frozen row,role split is also accepted. Fit rejects train/dev map or root overlap and identical physical resets across roles. It writes both .pt parameter files, optimizer traces and measured train/dev summaries. Python callers use Dataset.load, JumpOutcome.forecast, empirical_forecast and exit_initializer. Each Particle may be passed onward only where its state is defined. No formal fit was launched here.

## Formal selection to freeze prospectively

Freeze maps, disjoint physical roots, seeds, update count or checkpoint grid, calibration procedure and stopping criteria before training. A fixed final update is the implemented default for both models. An optional future early-stopping design should use identical candidate update counts and validation cadence for both variants, e.g. every 5 epochs after 20, stop evaluating after 8 consecutive non-improving dev checks, retaining the best predeclared dev criterion with earliest tie. Nominate the simpler point-estimate variant if the gain of the mixture is unresolved. Threshold-setting needs separate calibration maps after model selection. A fair downstream comparison fixes the release/abstention rate or verifies both retained-case safety and useful coverage, counts false-safe releases against their own released denominator, keeps all failures, and resamples entire independent roots within maps. The sealed maps are for the predeclared final comparison. No smoke comparison establishes distribution calibration, risk superiority, physical feasibility or real-world performance.

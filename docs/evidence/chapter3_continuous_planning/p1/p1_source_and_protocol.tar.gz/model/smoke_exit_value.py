"""6 previously inspected DEV prefixes; no new physics and no new-map fitting."""
from pathlib import Path
import argparse,json,time
import numpy as np
import pandas as pd
import torch
from jump_outcome import Dataset,fit_model,empirical_forecast
from smoke_outcome import grouping_old_dev
from frozen_exit_value import FrozenExits,NAMES,evaluate_particles,aggregate

SEED=612041
SECTION='near'
SIDE=-1
X=12.7
DT=.005
TAG=dict(map_id='staggered',root=1183,target_side=SIDE,section=SECTION,section_x=X,source_arm='near_left')

def run(source,out):
    t=time.monotonic();torch.set_num_threads(1);out.mkdir(parents=True,exist_ok=True)
    ds=Dataset.load(source); trainrows,_=grouping_old_dev(ds);train=ds.subset(trainrows)
    ix=ds.index
    rows=ix[ix.root.eq(1183)&ix.layout.eq('staggered')&ix.geometry.isin([0,1])&ix.alpha.eq(0)].copy()
    assert len(rows)==6
    folder=Path(rows.iloc[0].physical_status).parent
    # The old_selection event is the original frozen, straight-incumbent detector evaluated for this gate.
    reference={}
    needed={v.group_start_lane+4 for v in rows.itertuples()}
    for line in (folder/'p0_events.jsonl').open():
        e=json.loads(line)
        if e['kind']!='old_selection':continue
        for j,l in enumerate(e['lanes']):
            if l in needed:reference[l]=(np.array(e['old_candidates'][j]),e['choice'][j],e['admitted'][j],e['incumbent_admitted'][j],e['tick'])
    actual=[]; candidates=[]; options={}; meta={}
    with np.load(source/'measured_targets.npz') as labels:
        for r in rows.itertuples():
            slot=int(r.geometry);lane=r.group_start_lane+4
            is_q=r.row<len(labels['query_s']) and np.isfinite(labels['query_s'][r.row])
            m=dict(TAG,action_slot=slot,geometry=slot,alpha=r.alpha,force_n=r.hidden_force_N_grouping_only,
                   verified_relock=bool(labels['is_relocked'][r.row]),observed_query=bool(is_q),archive_row=r.row,
                   state=r.state,certified_development_parity=bool(r.cross_suffix_certified))
            if is_q:
                ids,c,a,inc,tick=reference[lane]
                assert round(float(labels['query_s'][r.row])/DT)==tick
                actual.append(dict(m,method='measured',seed=SEED,particle=0,query_s=float(labels['query_s'][r.row]),
                                   q=labels['query_qpos_native'][r.row],v=labels['query_velocity_state9'][r.row],
                                   prev=labels['previous_velocity_state9'][r.row],observed_ids=ids,archived_choice=c if a else 1,
                                   archived_admitted=a,archived_incumbent=inc))
            meta[r.row]=m
    # Reuse the old smoke's exact 72 support rows and 12 matching updates; held prefixes supply no inputs but t0 and known geometry.
    models={k:fit_model(train,k,12,24,SEED)[0] for k in ('mean','mixture3')}
    for slot,series in rows.groupby('geometry'):
        rr=series.row.to_numpy(copy=True); query=ds.subset(rr[:1])
        assert (ds.x[rr]==query.x[0]).all()
        for method,k in [('mean',None),('mixture3',None),('empirical_action',None),('five_separate_roots',5)]:
            if method in models:
                pred=models[method].forecast(query.x,query.q0,draws=1 if method=='mean' else 4,seed=SEED,
                                             conditional=True,central=(method=='mean'))
                defined=pred['is_relocked'][0]
            else:
                pred=empirical_forecast(train,query,k,draws=4,seed=SEED,conditional=True);defined=pred['state_defined'][0]
            options[slot,method]=float(pred['p_relock'][0])
            if not defined.all(): raise ValueError('An old smoke action has no conditional support; cannot evaluate its state particles')
            for i in range(len(defined)):
                candidates.append(dict(TAG,action_slot=slot,geometry=slot,alpha=0.,method=method,seed=SEED,particle=i,
                       query_s=float(pred['query_s'][0,i]),q=pred['query_qpos_native'][0,i].numpy(),
                       v=pred['query_velocity_state9'][0,i].numpy(),prev=pred['previous_velocity_state9'][0,i].numpy()))
    evaluate_particles(FrozenExits(folder),candidates+actual,horizon_cap_s=5.1)
    byrow={r['archive_row']:r for r in actual}
    measured=[]
    for r in rows.itertuples():
        test=byrow.get(r.row)
        final=meta[r.row].copy()
        if test is not None:
            test.update(cpu_choice_equal=test['measured_choice']==test['archived_choice'],
                        cpu_admission_equal=(any(test['feasible_'+name] for name in NAMES)==test['archived_admitted']),
                        cpu_incumbent_equal=test['feasible_straight']==test['archived_incumbent'])
            final.update(test)
        measured.append(final)
    preds=[]
    for (slot,method),prob in options.items():
        chunk=[r for r in candidates if r['action_slot']==slot and r['method']==method]
        preds.append(dict(TAG,action_slot=slot,geometry=slot,alpha=0.,method=method,seed=SEED,**aggregate(chunk,prob)))
    phys=pd.read_csv(source.parent/'physical_lanes.csv.gz')
    phys=phys[phys.layout.eq(TAG['map_id'])&phys.root.eq(TAG['root'])&phys.alpha.eq(0)&phys.geometry.isin([0,1])&phys.arm.isin(NAMES)]
    labels=[];bylabel={}
    for r in phys.itertuples():
        raw=bool(r.verified and pd.notna(r.near_cross_y) and .06<=SIDE*r.near_cross_y<=3.9 and r.goal and not r.wall)
        ixrow=rows[rows.geometry.eq(r.geometry)&rows.hidden_force_N_grouping_only.eq(r.force)].iloc[0]
        tag=meta[ixrow.row];cert=tag['certified_development_parity']
        lab=dict(TAG,action_slot=r.geometry,force_n=r.force,actual_exit=NAMES.index(r.arm),name=r.arm,actual_gate_y=r.near_cross_y,
                 correct_gate=bool(.06<=SIDE*r.near_cross_y<=3.9),physical_goal=r.goal,physical_wall=r.wall,raw_task_done=raw,
                 state=tag['state'],certified_development_parity=cert,strict_label=raw if tag['state']=='matched' else None,
                 certified_label=raw if cert else None,trajectory=r.trajectory)
        labels.append(lab);bylabel[r.geometry,r.force,NAMES.index(r.arm)]=lab
    comparisons=[]
    for m in measured:
        for p in preds:
            if p['action_slot']!=m['action_slot']:continue
            outrow={k:p[k] for k in ('map_id','root','action_slot','target_side','section','method','seed','score_any','score_lr','fixed_choice_before_relock')}
            outrow.update(force_n=m['force_n'],verified_relock=m['verified_relock'],observed_query=m['observed_query'])
            for key,c in [('adaptive',m.get('measured_choice')),('fixed',p['fixed_choice_before_relock'])]:
                if not m['verified_relock']:
                    outrow[key+'_strict']=outrow[key+'_certified']=False
                elif c is None:
                    outrow[key+'_strict']=outrow[key+'_certified']=None
                else:
                    hit=bylabel.get((m['action_slot'],m['force_n'],c),{})
                    outrow[key+'_strict']=hit.get('strict_label')
                    outrow[key+'_certified']=hit.get('certified_label')
                outrow[key+'_exit']=c
            comparisons.append(outrow)
    tables=[('particle_exit_queries',candidates),('measured_exit_queries',measured),('physical_suffix_labels',labels),
            ('prefix_gate_predictions',preds),('outcome_readback',comparisons)]
    for name,tab in tables:
        frame=pd.DataFrame(tab)
        if name=='particle_exit_queries':frame=frame.rename(columns={'measured_choice':'particle_choice'})
        frame.to_csv(out/(name+'.csv'),index=False)
    assert all(p['cpu_choice_equal'] and p['cpu_admission_equal'] and p['cpu_incumbent_equal'] for p in actual)
    assert len(measured)==6 and len(actual)==4 and len(candidates)==26 and len(labels)==18
    assert len({(r['action_slot'],r['method']) for r in preds})==8
    info=dict(role='old two-map DEV CPU numerical smoke only',train_rows=len(trainrows),decisions=len(options),
              hidden_force_prefixes=len(rows),measured_queries=len(actual),predicted_particles=len(candidates),per_particle_three_exits=3,
              measured_choice_matches=sum(x['cpu_choice_equal'] for x in actual),measured_any_admit_matches=sum(x['cpu_admission_equal'] for x in actual),
              measured_incumbent_matches=sum(x['cpu_incumbent_equal'] for x in actual),pose_only_anchor_matches=sum(x['anchor']==x['pose_only_anchor'] for x in actual),
              wall_seconds=time.monotonic()-t,sources=[str(source),str(folder)],horizon='min(5.1 s, 10s minus forecast/observed query tick); 20 ms increments')
    (out/'receipt.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--old-dev',required=True,type=Path);p.add_argument('--out',type=Path,default=Path(__file__).parent/'downstream_smoke')
    a=p.parse_args();run(a.old_dev,a.out)

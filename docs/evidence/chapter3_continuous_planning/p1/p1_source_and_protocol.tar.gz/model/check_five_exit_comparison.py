"""Synthetic numerical checks, no new map loading or fitting."""
from itertools import product
from pathlib import Path
import json
import numpy as np
import pandas as pd
from compare_five_exit_evidence import ARMS,KEY,DRAW,physical_labels,compare

b=[];arms=[];native=[];pred=[]
for slot in range(4):
    gate=dict(map_id='fixture',root=31,action_slot=slot,section='near',target_side=1)
    for model,val in [('mean',[.9,.8,.2,.1]),('mixture3',[.8,.9,.2,.1]),('tie',[.8,.8,.8,.8])]:
        pred.append(dict(gate,method=model,seed='fixed',score_any=val[slot]))
    for force in (-5,0,5):
        t=dict(gate,force_n=force);low={k:0 for k in ARMS};high=low.copy()
        if slot==0 and force==-5:low['straight']=high['straight']=1
        if slot==0 and force==5:high['near_right_cem']=1
        if slot==1:low['fixed_left']=high['fixed_left']=1
        if slot==3:high['fixed_right']=1
        tphys={**t,'side':t['target_side']};tphys.pop('target_side')
        b.append(dict(tphys,five_feasible_lo=max(low.values()),five_feasible_hi=max(high.values())))
        choice=1 if force==-5 else 0
        for name in ARMS:
            cert=(high[name]==low[name])
            # There is a physical collision on an unused right exit at a known infeasible prefix.
            hit=(slot==0 and force==0 and name=='fixed_right') or (slot==0 and force==5 and name=='fixed_left')
            arms.append(dict(tphys,arm=name,success_lo=low[name],success_hi=high[name],prefix_certified=cert,physical_wall=hit,
                             first_publication=9 if slot==1 and force==-5 else 2,trajectory=name))
        native.append(dict(t,policy='native_three',observed_query=slot!=2,chosen_direction=None if slot==2 else choice,choice_evidence='fixture',
                           set_lr_lo=max(low['fixed_left'],low['fixed_right']),set_lr_hi=max(high['fixed_left'],high['fixed_right'])))
truth=physical_labels(pd.DataFrame(b),pd.DataFrame(arms),pd.DataFrame(native),step_reader=lambda _:7)
summary,pairs,rows=compare(pd.DataFrame(pred),truth,formal=False)
m=summary.set_index('method').loc['mean'];t=summary.set_index('method').loc['tie']
assert (m.five_false_feasible_count_lo,m.five_false_feasible_count_hi)==(1,2)
assert (m.two_false_feasible_count_lo,m.two_false_feasible_count_hi)==(3,3)
assert (m.five_definitely_false_chosen_arm_wall_n,m.five_definitely_false_chosen_arm_known_n)==(0,1)
assert (m.observed_chosen_arm_collision_n,m.observed_chosen_arm_n)==(1,3)
assert (m.five_false_and_wall_among_observed_chosen_lo,m.five_false_and_wall_among_observed_chosen_hi)==(0,1)
assert (m.newly_feasible_among_admitted_lo,m.newly_feasible_among_admitted_hi)==(1,2)
assert (t.cutoff_ties,t.selected_from_cutoff_ties)==(4,1)
assert summary.query("method=='mixture3'").iloc[0].observed_chosen_arm_n==2
a=rows[rows.method.eq('mean')].reset_index(drop=True)
unknown=np.flatnonzero(a.five_lo.ne(a.five_hi))
values=[]
for labels in product([0,1],repeat=len(unknown)):
    f=a.five_lo.to_numpy().copy();f[unknown]=labels
    values.append(sum(f[a.admitted])/sum(f))
assert np.isclose(min(values),m.five_feasible_recall_lo) and np.isclose(max(values),m.five_feasible_recall_hi)
pr=pairs[(pairs.method_A=='mean')&(pairs.method_B=='mixture3')].iloc[0]
assert (pr.five_A_only_rescued_lo,pr.five_A_only_rescued_hi,pr.five_B_only_lost_lo,pr.five_B_only_lost_hi)==(1,2,3,3)
assert (pr.five_net_A_minus_B_lo,pr.five_net_A_minus_B_hi)==(-2,-1)
shuffle=pd.DataFrame(pred).sample(frac=1,random_state=42)
_,_,rows2=compare(shuffle,truth,formal=False)
assert rows.sort_values(['method',*DRAW]).admitted.to_list()==rows2.sort_values(['method',*DRAW]).admitted.to_list()
zero=truth.copy()
for s in ['five','two','extra','new_feasible','chosen_success']:
    zero[s+'_hi']=zero[s+'_lo']=0
zero['chosen_wall_observed']=np.nan
zz=compare(pd.DataFrame(pred),zero,formal=False)[0]
assert zz.five_feasible_recall_lo.isna().all() and zz.five_feasible_recall_hi.isna().all()
r=dict(role='synthetic only; four actions, three hidden treatments, three mock scores',ranked_actions=4,admitted=1,common_hash_across_row_orders=True,
       false_feasible_two=[3,3],false_feasible_five=[1,2],feasible_recall_five=[float(min(values)),float(max(values))],
       possible_truth_completions=len(values),confirmed_false_selected_wall=[0,1],all_admitted_selected_wall=[1,3],
       rescued_if_A=[1,2],lost_if_A=[3,3],net=[-2,-1],no_feasible_recall_missing=True,no_fresh_physical_data=True)
(Path(__file__).resolve().parent/'five_exit_comparison_fixture.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))

"""Fit both matched estimators only when given a predeclared development/training split."""
import argparse
import json
from pathlib import Path

import pandas as pd
import torch
from development_metrics import empirical_rows, model_rows, save_tables

from jump_outcome import Dataset, MODE_NAMES, empirical_particles, evaluate, fit_model


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,required=True,help='Directory with the P1 exports')
    parser.add_argument('--split',type=Path,required=True,help='Frozen CSV with map_id,role (separate map folders) or row,role (single archive). Use train and dev only.')
    parser.add_argument('--out',type=Path,required=True,help='New destination directory for both model checkpoints and metrics')
    parser.add_argument('--steps',type=int,required=True);parser.add_argument('--batch-size',type=int,required=True)
    parser.add_argument('--seed',type=int,required=True);parser.add_argument('--learning-rate',type=float,default=.001)
    parser.add_argument('--device',choices=('cpu','cuda'),default='cpu',help='Explicit compute device for both supervised fits')
    parser.add_argument('--tensorboard-root', type=Path, help='Write supervised loss and development metrics here')
    args=parser.parse_args()
    if args.device=='cuda' and not torch.cuda.is_available(): raise ValueError('CUDA requested but unavailable')
    torch.set_num_threads(1)
    split=pd.read_csv(args.split)
    if set(split.role)!= {'train','dev'}:
        raise ValueError('Use separate training/development rows only; calibration and TEST are not fit inputs')
    if 'map_id' in split:
        if split.map_id.duplicated().any(): raise ValueError('Duplicated map role or batch')
        by_role={'train':[],'dev':[]}
        for item in split.itertuples():
            ds=Dataset.load(args.data/item.role/item.map_id)
            if set(ds.index.layout)!={item.map_id}: raise ValueError('Map identity does not match export folder')
            by_role[item.role].append(ds)
        train,dev=Dataset.join(by_role['train']),Dataset.join(by_role['dev'])
    else:
        ds=Dataset.load(args.data)
        if split.row.duplicated().any() or not split.row.between(0,len(ds.x)-1).all():
            raise ValueError('Frozen split must reference unique exported row numbers')
        ids={role:split.loc[split.role.eq(role),'row'].to_numpy() for role in ('train','dev')}
        train,dev=(ds.subset(ids[part]) for part in ('train','dev'))
    if set(train.index.root)&set(dev.index.root) or set(train.index.layout)&set(dev.index.layout):
        raise ValueError('Training and validation must use disjoint maps and roots')
    reset_key=lambda s:{row.tobytes() for row in s.x[:,:23].numpy()}
    if reset_key(train)&reset_key(dev): raise ValueError('An identical physical reset occurs in both roles')
    if args.steps<1 or not 1<=args.batch_size<=len(train.x) or args.learning_rate<=0:
        raise ValueError('Require positive optimizer settings and a supported batch size')
    args.out.mkdir(parents=True,exist_ok=False)
    summary={'task':'train/DEV model comparison, no seal opening','data':str(args.data.resolve()),'frozen_split':str(args.split.resolve()),
             'device':args.device,'steps':args.steps,'batch_size':args.batch_size,'seed':args.seed,'learning_rate':args.learning_rate,'models':{}}
    logs=[]
    predictions=[]
    for mode in MODE_NAMES:
        writer=None
        if args.tensorboard_root:
            from torch.utils.tensorboard import SummaryWriter
            writer=SummaryWriter(str(args.tensorboard_root/f'seed_{args.seed}'/mode),flush_secs=5)
        model,trace=fit_model(train,mode,args.steps,args.batch_size,args.seed,args.learning_rate,device=args.device,writer=writer)
        torch.save({'state':{key:v.detach().cpu() for key,v in model.state_dict().items()},'mode':mode,'input_width':train.x.shape[1],'width':48},args.out/(mode+'.pt'))
        summary['models'][mode]={'train':evaluate(model,train),'dev':evaluate(model,dev),'parameters':sum(p.numel() for p in model.parameters())}
        predictions.append(model_rows(model,dev,mode,args.seed))
        if writer:
            for key in ('brier','bce','loss'):
                writer.add_scalar('development/'+key,summary['models'][mode]['dev'][key],args.steps)
            writer.close()
        logs.extend(dict(item,mode=mode) for item in trace)
    for name,k in [('empirical_action',None),('five_separate_roots',5)]:
        support=empirical_particles(train,dev,k)
        rows=empirical_rows(dev,support,name,args.seed)
        predictions.append(rows)
        summary['models'][name]={'dev':{'n':len(rows),'brier':float(((rows.probability-rows.relocked.astype(float))**2).mean())}}
    save_tables(predictions,args.out)
    pd.DataFrame(logs).to_csv(args.out/'optimization.csv',index=False)
    (args.out/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':
    main()

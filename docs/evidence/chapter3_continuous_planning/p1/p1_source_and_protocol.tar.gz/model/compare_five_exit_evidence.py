"""Compare frozen three-exit predictions against two/five physically tested sets on common DEV roots."""
import argparse
from itertools import combinations
import json
from pathlib import Path
import sys
import zipfile
import numpy as np
import pandas as pd

MODEL=Path(__file__).resolve().parent
BASE=MODEL.parent
sys.path.insert(0,str(BASE/'export'))
from evaluate_two_exit_admission import KEY,GATE,DRAW,rank_actions,recall_bounds

ARMS=['fixed_left','straight','fixed_right','near_left_cem','near_right_cem']
LR=[ARMS[0],ARMS[2]]
SETS=['two','five']
METHODS={'mean','mixture3','empirical_action','five_separate_roots'}

def steps_on_trace(path):
    with zipfile.ZipFile(path) as z,z.open('trace.npy') as s:
        v=np.lib.format.read_magic(s)
        read=np.lib.format.read_array_header_1_0 if v==(1,0) else np.lib.format.read_array_header_2_0
        return read(s)[0][0]-1

def physical_labels(b,arms,native,step_reader=steps_on_trace):
    b=b.rename(columns={'side':'target_side'}).copy()
    arms=arms.rename(columns={'side':'target_side'})
    if arms.duplicated(DRAW+['arm']).any() or b.duplicated(DRAW).any():raise ValueError('Five-exit verifier produced duplicate keys')
    arms=arms.merge(b[DRAW+GATE],on=DRAW+GATE,validate='many_to_one')
    grp=arms.groupby(DRAW,sort=False)
    if len(arms)!=len(b)*5 or not grp.arm.apply(lambda s:set(s)==set(ARMS)).all():raise ValueError('Five measured arms required for each scheduled gate')
    for suffix in ['lo','hi']:
        full=grp['success_'+suffix].max().rename('checked').reset_index()
        check=b.merge(full,on=DRAW,validate='one_to_one')
        if not check['five_feasible_'+suffix].eq(check.checked).all():raise ValueError('Aggregate five-arm verifier disagrees with per-arm provenance')
        b=b.merge(arms[arms.arm.isin(LR)].groupby(DRAW)['success_'+suffix].max().rename('two_'+suffix).reset_index(),on=DRAW,validate='one_to_one')
        b=b.merge(arms[~arms.arm.isin(LR)].groupby(DRAW)['success_'+suffix].max().rename('extra_'+suffix).reset_index(),on=DRAW,validate='one_to_one')
        b['five_'+suffix]=b['five_feasible_'+suffix]
    # Improvement in existence, retaining that the two alternatives are a subset of five.
    b['new_feasible_lo']=b.extra_lo*(1-b.two_hi)
    b['new_feasible_hi']=b.extra_hi*(1-b.two_lo)
    native=native[native.policy.eq('native_three')]
    existing=b.merge(native[DRAW+GATE+['chosen_direction','observed_query','choice_evidence','set_lr_lo','set_lr_hi']],on=DRAW+GATE,validate='one_to_one')
    if len(existing)!=len(b):raise ValueError('Missing frozen physical policy choices on the five-exit subset')
    # The independent five-exit audit owns these bounds. Report discrepancies against earlier two-exit certificates transparently.
    existing['lr_certificate_differs']=existing.set_lr_lo.ne(existing.two_lo)|existing.set_lr_hi.ne(existing.two_hi)
    ix=arms.set_index(DRAW+['arm'],verify_integrity=True)
    for r in existing.itertuples():
        fields={k:getattr(r,k) for k in DRAW}
        observed=bool(r.observed_query); c=r.chosen_direction
        a=ARMS[int(c)] if observed and pd.notna(c) else ('fixed_left' if not observed else None)
        arm=ix.loc[tuple(fields.values())+(a,)] if a is not None else None
        k=r.Index
        existing.loc[k,'chosen_physical_arm']=a
        if arm is None:
            existing.loc[k,['chosen_success_lo','chosen_success_hi']]=[0,1]
            existing.loc[k,'wall_evidence']='unresolved_choice'
            continue
        existing.loc[k,['chosen_success_lo','chosen_success_hi']]=[int(arm.success_lo),int(arm.success_hi)]
        if not observed:
            reason='no_exit_chosen_before_terminal'
        elif not bool(arm.prefix_certified):
            reason='uncertified_prefix'
        elif pd.isna(arm.first_publication) or int(arm.first_publication)<0 or int(arm.first_publication)>=step_reader(arm.trajectory):
            reason='no_executed_interval_after_publication'
        else:
            reason='identified_executed_chosen_arm'
            existing.loc[k,'chosen_wall_observed']=int(arm.physical_wall)
            existing.loc[k,'chosen_executed_trajectory']=arm.trajectory
        existing.loc[k,'wall_evidence']=reason
    existing['chosen_wall_observed']=existing.get('chosen_wall_observed',pd.Series(np.nan,index=existing.index))
    return existing


def compare(pred,truth,formal=True):
    keys=truth[KEY+GATE].drop_duplicates()
    if keys.duplicated(KEY).any() or truth.groupby(KEY).force_n.apply(lambda x:set(x)!= {-5,0,5} or len(x)!=3).any():
        raise ValueError('Physical gate or hidden push design shifted')
    ranks=pred.merge(keys,on=KEY+GATE,validate='many_to_one')
    if formal:
        expected={(m,str(s)) for m in ('mean','mixture3') for s in (61123,61124,61125)}|{(m,'shared') for m in ('empirical_action','five_separate_roots')}
        if len(keys)!=96 or keys.root.nunique()!=6 or not keys.groupby('root').size().eq(16).all() or set(ranks.groupby(['method','seed']).groups)!=expected:raise ValueError('Incomplete DEV method/seed/root population')
    summary=[];draws=[];net=[]
    for (method,seed),p in ranks.groupby(['method','seed'],sort=True):
        ordered=rank_actions(p,'score_any')
        n=len(ordered);cut=n//4
        if n!=len(keys) or n%4 or cut<1:raise ValueError('Incomplete rank panel')
        ordered['admitted']=ordered['rank']<=cut
        tied=ordered._rank_value.eq(ordered._rank_value.iloc[cut-1])
        d=truth.merge(ordered[KEY+['method','seed','score_any','rank','admitted','tie_key','score_undefined']],on=KEY,validate='many_to_one')
        draws.append(d)
        a=d[d.admitted];r=d[~d.admitted];N=len(a)
        row=dict(map_id=keys.map_id.iloc[0],method=method,seed=seed,opportunities=n,admitted_actions=cut,total_prefixes=len(d),admitted_prefixes=N,
                 cutoff=ordered.score_any.iloc[cut-1],cutoff_ties=int(tied.sum()),selected_from_cutoff_ties=int((ordered.admitted&tied).sum()),
                 above_cutoff=int((ordered._rank_value>ordered._rank_value.iloc[cut-1]).sum()),undefined_actions=int(ordered.score_undefined.sum()),
                 admitted_undefined_actions=int(ordered.iloc[:cut].score_undefined.sum()),two_certificate_disagreements=int(d.lr_certificate_differs.sum()))
        for tag in SETS:
            lo,hi=tag+'_lo',tag+'_hi'
            ok,possible=int(a[lo].sum()),int(a[hi].sum());rlo,rhi=int(r[lo].sum()),int(r[hi].sum())
            row.update({tag+'_feasible_admitted_lo':ok,tag+'_feasible_admitted_hi':possible,tag+'_feasible_rejected_lo':rlo,tag+'_feasible_rejected_hi':rhi,
                        tag+'_false_feasible_count_lo':N-possible,tag+'_false_feasible_count_hi':N-ok,tag+'_false_feasible_rate_lo':(N-possible)/N,
                        tag+'_false_feasible_rate_hi':(N-ok)/N,tag+'_feasible_total_lo':ok+rlo,tag+'_feasible_total_hi':possible+rhi})
            row[tag+'_feasible_recall_lo'],row[tag+'_feasible_recall_hi']=recall_bounds(ok,possible,rlo,rhi)
            wrong=a[a[hi].eq(0)];observed=wrong.chosen_wall_observed.dropna()
            row.update({tag+'_definitely_false_n':len(wrong),tag+'_definitely_false_chosen_arm_wall_n':int(observed.sum()),
                        tag+'_definitely_false_chosen_arm_known_n':len(observed),tag+'_definitely_false_without_chosen_wall_evidence':len(wrong)-len(observed),
                        tag+'_false_and_wall_among_observed_chosen_lo':int((a.chosen_wall_observed.eq(1)&a[hi].eq(0)).sum()),
                        tag+'_false_and_wall_among_observed_chosen_hi':int((a.chosen_wall_observed.eq(1)&a[lo].eq(0)).sum())})
        wall=a.chosen_wall_observed.dropna()
        row.update(newly_feasible_among_admitted_lo=int(a.new_feasible_lo.sum()),newly_feasible_among_admitted_hi=int(a.new_feasible_hi.sum()),
                   observed_chosen_arm_collision_n=int(wall.sum()),observed_chosen_arm_n=len(wall),unresolved_or_no_chosen_arm_n=N-len(wall),
                   matched_chosen_task_success_lo=int(a.chosen_success_lo.sum()),matched_chosen_task_success_hi=int(a.chosen_success_hi.sum()))
        summary.append(row)
    draws=pd.concat(draws,ignore_index=True)
    series={key:d.set_index(DRAW,verify_integrity=True).sort_index() for key,d in draws.groupby(['method','seed'])}
    for (ka,a),(kb,b) in combinations(series.items(),2):
        if not a.index.equals(b.index):raise ValueError('Method pair missing physical outcomes')
        diff=a.admitted.astype(int)-b.admitted.astype(int)
        gain=a[diff==1];loss=a[diff==-1]
        rec=dict(map_id=a.index[0][0],method_A=ka[0],seed_A=ka[1],method_B=kb[0],seed_B=kb[1],
                 both_admitted=int((a.admitted&b.admitted).sum()),only_A_prefixes=len(gain),only_B_prefixes=len(loss))
        for tag in ('two','five','chosen_success'):
            gl,gh=int(gain[tag+'_lo'].sum()),int(gain[tag+'_hi'].sum());ll,lh=int(loss[tag+'_lo'].sum()),int(loss[tag+'_hi'].sum())
            rec.update({tag+'_A_only_rescued_lo':gl,tag+'_A_only_rescued_hi':gh,tag+'_B_only_lost_lo':ll,tag+'_B_only_lost_hi':lh,
                        tag+'_net_A_minus_B_lo':gl-lh,tag+'_net_A_minus_B_hi':gh-ll})
        net.append(rec)
    return pd.DataFrame(summary),pd.DataFrame(net),draws

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--predictions',type=Path,default=MODEL/'formal_downstream/prefix_gate_predictions.csv')
    p.add_argument('--two-policy',type=Path,default=MODEL/'formal_downstream/physical_evaluation/physical_policy_outcomes.csv')
    p.add_argument('--five-root',type=Path,default=BASE/'five_exits');p.add_argument('--out',type=Path,default=MODEL/'formal_downstream/five_exit_comparison')
    args=p.parse_args()
    pred=pd.read_csv(args.predictions,dtype={'seed':str});native=pd.read_csv(args.two_policy)
    protocol=json.loads((args.five_root/'protocol.json').read_text());tabs=[];pairs=[];paths=[]
    for name in ('dev_00','dev_01'):
        declared=next(x for x in protocol['maps'] if x['map']==name)
        folder=args.five_root/name
        b=pd.read_csv(folder/'five_feasibility_bounds.csv');a=pd.read_csv(folder/'physical_outcomes.csv')
        if set(b.map_id)!={name} or set(b.root)!=set(declared['roots']) or len(b)!=288 or len(a)!=1440:raise ValueError('Wrong five-exit data role or incomplete map')
        truth=physical_labels(b,a,native)
        tab,pr,draw=compare(pred[pred.map_id.eq(name)],truth);tabs.append(tab);pairs.append(pr);paths.append(draw)
    args.out.mkdir(parents=True,exist_ok=True)
    for f,rows in [('by_map',tabs),('paired_rescues_losses',pairs),('ranked_prefix_evidence',paths)]:
        pd.concat(rows,ignore_index=True).to_csv(args.out/(f+'.csv'),index=False)
    (args.out/'receipt.json').write_text(json.dumps(dict(role='two DEV maps; physical comparison of frozen score_any against nested observed candidate sets',
           maps=['dev_00','dev_01'],opportunities=192,prefixes=576,admitted_prefixes_per_map_per_method=72,
           preds=str(args.predictions),two_policy=str(args.two_policy),five_verification=str(args.five_root),
           score='unchanged original three-exit score_any; 25% recalculated on six predeclared roots per map'),indent=2)+'\n')
if __name__=='__main__':main()

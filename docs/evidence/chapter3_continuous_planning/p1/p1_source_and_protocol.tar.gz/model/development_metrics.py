"""Physical-unit prediction errors and per-map reliability on development data."""
import numpy as np
import pandas as pd
import torch
from sttw_control.playground_prediction import euler
from jump_outcome import decode_target


@torch.no_grad()
def model_rows(net, data, model, seed):
    out = data.index[['layout', 'root', 'row']].copy().reset_index(drop=True)
    out['model'] = model
    out['seed'] = seed
    dev = net.x_center.device
    x, q0 = data.x.to(dev), data.q0.to(dev)
    out['probability'] = net(x)[0].sigmoid().cpu().numpy()
    out['relocked'] = data.success.numpy()
    m = data.measured
    out['observed_state'] = m.numpy()
    if not m.any():
        return out
    x, q0 = x[m.to(dev)], q0[m.to(dev)]
    observed = decode_target(q0, data.y[m].to(dev), project_joints=False)
    central = net.forecast(x,q0,conditional=True,central=True)
    # Conditional marginal ranges before calibration.
    particles = net.forecast(x,q0,draws=128,seed=1741,conditional=True)
    add_state_errors(out,m,observed,central,particles)
    return out


@torch.no_grad()
def empirical_rows(data, support, name, seed):
    out=data.index[['layout','root','row']].copy().reset_index(drop=True)
    out=out.assign(model=name,seed=seed,probability=[p for p,_,_ in support],
                   relocked=data.success.numpy(),observed_state=data.measured.numpy())
    m=data.measured & torch.tensor([len(states)>0 for _,states,_ in support])
    if not m.any():
        return out
    centers=[]; samples=[]
    rng=torch.Generator().manual_seed(1741)
    for i in torch.where(m)[0].tolist():
        _,states,w=support[i]
        centers.append((states*w[:,None]).sum(0))
        samples.append(states[torch.multinomial(w,128,replacement=True,generator=rng)])
    q0=data.q0[m]
    actual=decode_target(q0,data.y[m],project_joints=False)
    central=decode_target(q0[:,None],torch.stack(centers)[:,None])
    particles=decode_target(q0[:,None].expand(-1,128,-1),torch.stack(samples))
    add_state_errors(out,m,actual,central,particles)
    return out


def add_state_errors(out,m,observed,central,particles):
    truth = observed['query_qpos_native']
    estimate = central['query_qpos_native'][:,0]
    rot = euler(estimate[:,3:7]) - euler(truth[:,3:7])
    angle_error = torch.rad2deg(torch.atan2(rot.sin(),rot.cos())).abs()
    out.loc[m.numpy(),'roll_abs_deg'] = angle_error[:,0].cpu().numpy()
    out.loc[m.numpy(),'yaw_abs_deg'] = angle_error[:,2].cpu().numpy()
    out.loc[m.numpy(),'xy_sq_m2'] = (truth[:,:2]-estimate[:,:2]).square().sum(1).cpu().numpy()
    out.loc[m.numpy(),'time_abs_s'] = (observed['relock_s']-central['relock_s'][:,0]).abs().cpu().numpy()
    coordinates={'landing_x':(particles['query_qpos_native'][:,:,0],truth[:,0]),
                 'landing_y':(particles['query_qpos_native'][:,:,1],truth[:,1]),
                 'relock_time':(particles['relock_s'],observed['relock_s'])}
    for name,(samples,actual) in coordinates.items():
        lo,hi=torch.quantile(samples,samples.new_tensor([.05,.95]),dim=1)
        out.loc[m.numpy(),name+'_covered90'] = ((lo<=actual)&(actual<=hi)).float().cpu().numpy()
        out.loc[m.numpy(),name+'_width90'] = (hi-lo).cpu().numpy()


def save_tables(rows, path):
    data = pd.concat(rows,ignore_index=True)
    data['brier_error'] = (data.probability-data.relocked.astype(float))**2
    data.to_csv(path/'development_predictions.csv.gz',index=False)
    def summarize(g):
        value={'prefixes':len(g),'roots':g.root.nunique(),'maps':g.layout.nunique(),
               'relocked':int(g.relocked.sum()),'brier':g.brier_error.mean()}
        for key in ('time_abs_s','yaw_abs_deg','roll_abs_deg','landing_x_covered90',
                    'landing_y_covered90','relock_time_covered90','landing_x_width90',
                    'landing_y_width90','relock_time_width90'):
            if key in g:value[key]=g[key].mean()
        value['states_observed']=int(g.observed_state.sum())
        if 'xy_sq_m2' in g:
            value['states_scored']=g.xy_sq_m2.count()
            value['xy_rmse_m']=np.sqrt(g.xy_sq_m2.mean())
        return value
    scopes=[('map',['model','seed','layout']),('combined',['model','seed']),('root',['model','seed','layout','root'])]
    for name,keys in scopes:
        stats=[dict(zip(keys,ids),**summarize(g)) for ids,g in data.groupby(keys,sort=False)]
        pd.DataFrame(stats).to_csv(path/f'development_by_{name}.csv',index=False)
    data['probability_bin']=np.minimum(9,(10*data.probability).astype(int))
    data.groupby(['model','seed','layout','probability_bin']).agg(prefixes=('row','size'),
        roots=('root','nunique'),mean_prediction=('probability','mean'),observed_frequency=('relocked','mean')).to_csv(path/'development_reliability.csv')

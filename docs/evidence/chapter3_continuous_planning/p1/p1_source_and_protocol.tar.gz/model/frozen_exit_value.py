"""One-step jump predictions → the unmodified frozen three-exit ground scorer, CPU or CUDA."""
import json
from pathlib import Path
from collections import defaultdict
from types import SimpleNamespace
import struct
import zipfile

import mujoco
import numpy as np
import torch

from sttw_control.platform_online import PlatformDepartureQuery
from sttw_control.playground_history_model import load_history_model
from sttw_control.playground_prediction import BodyEnvelope
from sttw_control.playground_terrain_features import TerrainFeatures

NAMES=('left','straight','right')


def mapped_arrays(file):
    """The immutable bank is a stored NPZ; expose selected rows without materializing the whole bank."""
    result={}
    with zipfile.ZipFile(file) as z,open(file,'rb') as f:
        for name in ('s','xy','heading','curvature'):
            inf=z.getinfo(name+'.npy')
            if inf.compress_type!=zipfile.ZIP_STORED: raise ValueError('This loader requires a stored route bank')
            f.seek(inf.header_offset+26);a,b=struct.unpack('<HH',f.read(4));f.seek(a+b,1)
            ver=np.lib.format.read_magic(f)
            parse=np.lib.format.read_array_header_1_0 if ver==(1,0) else np.lib.format.read_array_header_2_0
            shape,fortran,dtype=parse(f)
            result[name]=np.memmap(file,mode='r',dtype=dtype,offset=f.tell(),shape=shape,order='F' if fortran else 'C')
    return result


class FrozenExits:
    def __init__(self,physical_folder,device='cpu'):
        self.device=device
        f=Path(physical_folder)
        cfg=json.loads((f/'resolved_config.json').read_text())
        online=cfg['platform_online'];rel=online['relative']
        route=cfg['paired_departures'];self.bank=mapped_arrays(route['route_bank'])
        with np.load(route['approach_file']) as z:self.approach=np.array(z['xy'])
        hand=cfg['ground_handoff']
        # Its existing constructor hardcodes CUDA; initialize only immutable tensors on the requested
        # device. The full 20 ms rollout, articulated envelope and all decision logic are original methods.
        query=PlatformDepartureQuery.__new__(PlatformDepartureQuery)
        query.model=load_history_model(Path(online['ground_model']),device=device)
        query.relative=rel
        self.tensor=lambda a:torch.as_tensor(a,dtype=torch.float32,device=device)
        query.pose_order=torch.tensor([0,1,2,3,4,5,6,8,9,7,10,11],device=device)
        with np.load(rel['raster']) as z:raster=dict(z)
        raster['height']-=rel['height']
        query.model.terrain=TerrainFeatures(**raster,device=device)
        with np.load(rel['initializer']) as z:query.mean,query.scale,query.weights=[self.tensor(z[k]) for k in ('mu','scale','weight')]
        physics=mujoco.MjModel.from_binary_path(str(f/'terrain.mjb'))
        query.envelope=BodyEnvelope(physics,device=device,dimensions=3)
        walls=[j for j in range(physics.ngeom) if physics.geom(j).name.startswith('planning_obstacle_')]
        query.center=self.tensor(physics.geom_pos[walls]);query.half=self.tensor(physics.geom_size[walls])
        query.goal=hand['goal'];query.margin=online['margin_m'];query.halfwidth=hand['road_half_width_m']
        self.query=query
        self.s=self.tensor(np.array(self.bank['s']))
        self.bank_len=len(self.s)

    def branch_ids(self,geometry,position,progress=None):
        """Include x+5 cm commitment; future state uses projection onto the known approach."""
        approach=self.approach[geometry]
        edge=np.searchsorted(approach[:,0],position[0]+.05)
        if progress is None:
            delta=np.diff(approach,axis=0)
            w=np.clip(((position[:2]-approach[:-1])*delta).sum(1)/(delta**2).sum(1),0,1)
            best=np.argmin(((approach[:-1]+w[:,None]*delta-position[:2])**2).sum(1))
            progress=(1-w[best])*self.bank['s'][best]+w[best]*self.bank['s'][best+1]
        join=min(self.bank_len-1,max(int(edge),int(np.searchsorted(self.bank['s'],progress))+1))
        return len(self.approach)+(geometry*3+np.arange(3))*self.bank_len+join

    @torch.inference_mode()
    def score(self,q,current,previous,seconds,ids,section_x,target_side,speed=2.):
        """Score three alternatives around each input. Group calls by equal rollout length upstream."""
        q=self.tensor(q);current=self.tensor(current);previous=self.tensor(previous)
        n=len(q); device=self.device
        ids=np.asarray(ids,dtype=np.int64)
        unique,inv=np.unique(ids,return_inverse=True)
        route=SimpleNamespace(s=self.s,**{k:self.tensor(self.bank[k][unique]) for k in ('xy','heading','curvature')})
        # All three incumbent settings get the identical set of three routes. The middle row is
        # the deployed straight-incumbent choice. Each row's own incumbent flag supplies its feasibility.
        routes=torch.tensor(inv.reshape(n,3),device=device).repeat_interleave(3,0)
        expand=lambda x:x.repeat_interleave(3,0)
        incumbent=torch.arange(3,device=device).repeat(n)
        choice,admitted,retained=self.query.choose(expand(q),expand(current[:,0]),
            self.tensor(np.full(n*3,speed)),route,routes,self.tensor(np.full(n*3,section_x)),
            self.tensor(np.full(n*3,target_side)),incumbent,seconds,expand(current),expand(previous))
        passed=admitted.reshape(n,3)[:,1]; nominal=choice.reshape(n,3)[:,1]
        result=torch.where(passed,nominal,torch.ones_like(nominal))
        return result.cpu().numpy(),retained.reshape(n,3).cpu().numpy()


def evaluate_particles(f,particles,horizon_cap_s=None,episode_s=10.,speed_mps=2.):
    """Each particle gets its own remaining time, anchored routes and complete 20 ms rollout."""
    groups=defaultdict(list)
    for p in particles:
        tick=round(p['query_s']/.005)
        seconds=max(0.,episode_s-tick*.005)
        if horizon_cap_s is not None:seconds=min(horizon_cap_s,seconds)
        ids=p.pop('observed_ids',None)
        estimated=f.branch_ids(p['geometry'],p['q'])
        if ids is None:ids=estimated
        p.update(seconds=seconds,steps=int(seconds/.02),anchor=int((ids[0]-len(f.approach))%f.bank_len),
                 pose_only_anchor=int((estimated[0]-len(f.approach))%f.bank_len))
        p['route_ids']=ids
        groups[(p['steps'],p['section_x'],p['target_side'])].append(p)
    for (steps,x,side),ps in groups.items():
        chosen,feasible=f.score(np.stack([p['q'] for p in ps]),np.stack([p['v'] for p in ps]),np.stack([p['prev'] for p in ps]),
                             ps[0]['seconds'],np.stack([p['route_ids'] for p in ps]),x,side,speed=speed_mps)
        for p,c,valid in zip(ps,chosen,feasible,strict=True):
            p.update(measured_choice=int(c),**dict(zip(('feasible_'+name for name in NAMES),map(bool,valid),strict=True)))
            p.update(zip(('bank_row_'+name for name in NAMES),p.pop('route_ids').tolist(),strict=True))
            for k in ('q','v','prev'):del p[k]
    return particles

def aggregate(rows,prob):
    if not rows:
        value=0. if prob==0. else None
        return dict(p_relock=prob,particles=0,score_any=value,score_lr=value,
                    **{'p_joint_feasible_'+n:value for n in NAMES},fixed_choice_before_relock=1 if prob==0 else None)
    flag=np.asarray([[p['feasible_'+name] for name in NAMES] for p in rows])
    nominal=flag.any(axis=1);lr=flag[:,[0,2]].any(axis=1)
    # This fixed-direction diagnostic commits a turn before re-lock (tie priority straight, left, right).
    averages=flag.mean(axis=0)
    rank=np.array([1,0,2]); fixed=int(rank[np.argmax(averages[rank])])
    return dict(p_relock=prob,particles=len(rows),score_any=prob*nominal.mean(),score_lr=prob*lr.mean(),
                **{'p_joint_feasible_'+n:prob*val for n,val in zip(NAMES,averages,strict=True)},
                fixed_choice_before_relock=fixed)


"""Compute simultaneous prediction radii around whole-state particles on held-apart maps."""
import argparse
import json
import math
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from jump_outcome import DT, Dataset, JumpOutcome, encode_target
from run_downstream_dev import decision_rows, predicted_states


def rank_radius(scores, coverage):
    rank = math.ceil((len(scores)+1)*coverage)
    return rank, (float(np.sort(scores)[rank-1]) if rank<=len(scores) else math.inf)


@torch.inference_mode()
def score_map(support, data, decisions, method, net=None):
    family = (method, 'selected')
    _, opportunities = predicted_states(decisions, {family: net}, support, [family])
    scale = support.y[support.measured].std(0, unbiased=False).clamp_min(.001)
    by_action = data.index.groupby(['root', 'action_slot']).indices
    rows = []
    measured_mask = data.measured
    for (n, _, _), (tag, probability, samples) in opportunities.items():
        ids = by_action[tag['root'], tag['action_slot']]
        if samples:
            relock = torch.tensor([(round(p['query_s'] / DT) - 1) * DT for p in samples])
            q, v, previous = (torch.from_numpy(np.stack([p[k] for p in samples]))
                              for k in ('q', 'v', 'prev'))
            particles = encode_target(decisions.q0[n].expand(len(samples), -1), relock, q, v, previous)
        for i in ids:
            obs = data.index.iloc[i]
            measured = bool(measured_mask[i])
            score = np.nan
            if measured:
                score = float(((particles - data.y[i]).abs() / scale).amax(1).min()) if samples else np.inf
            rows.append(dict(layout=obs.layout, root=int(obs.root), action_slot=int(obs.action_slot),
                             row=int(obs.row), relock=bool(data.success[i]), measured=measured,
                             particle_count=len(samples), score=score, probability=probability))
    return pd.DataFrame(rows)


def summarize(table,coverage):
    groups=[];radii=[]
    for family,rows in [('registered_16',table),('common_five_anchors',table[table.action_slot<5])]:
        subset=[]
        for (layout,root),g in rows.groupby(['layout','root']):
            measured=g[g.measured]
            subset.append(dict(design=family,layout=layout,root=root,prefixes=len(g),relocks=int(g.relock.sum()),
                state_labels=len(measured),undefined_predictions=int((measured.particle_count==0).sum()),
                max_score=measured.score.max() if len(measured) else 0.))
        roots=pd.DataFrame(subset)
        groups.extend(subset)
        for layout,m in roots.groupby('layout'):
            rank,radius=rank_radius(m.max_score.to_numpy(),coverage)
            radii.append(dict(design=family,scope='same_map_root',layout=layout,units=len(m),rank=rank,
                radius=radius,finite=bool(np.isfinite(radius)),coverage=coverage))
        worst=roots.groupby('layout').max_score.max()
        rank,radius=rank_radius(worst.to_numpy(),coverage)
        radii.append(dict(design=family,scope='whole_new_map',layout='all',units=len(worst),rank=rank,
            radius=radius,finite=bool(np.isfinite(radius)),coverage=coverage))
    return pd.DataFrame(groups),pd.DataFrame(radii)


def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--data',type=Path,required=True);a.add_argument('--training-split',type=Path,required=True)
    a.add_argument('--calibration-split',type=Path,required=True);a.add_argument('--out',type=Path,required=True)
    a.add_argument('--method',choices=['mean','mixture3','empirical_action','five_separate_roots'],required=True)
    a.add_argument('--checkpoint',type=Path)
    a.add_argument('--device', choices=('cpu','cuda'),default='cpu')
    args=a.parse_args();torch.set_num_threads(1)
    train=pd.read_csv(args.training_split).query("role=='train'")
    cal=pd.read_csv(args.calibration_split)
    if set(cal.role)!={'calibration'} or set(cal.map_id)&set(train.map_id):
        raise ValueError('Calibration and training require distinct registered maps.')
    support=Dataset.join([Dataset.load(args.data/r.role/r.map_id) for r in train.itertuples()])
    net=None
    if args.method in ('mean','mixture3'):
        ck=torch.load(args.checkpoint,map_location='cpu',weights_only=True)
        if ck['mode']!=args.method:raise ValueError('Model type differs from selected checkpoint.')
        net=JumpOutcome(ck['input_width'],ck['mode'],width=ck['width']);net.load_state_dict(ck['state']);net.to(args.device).eval()
    batches=[]
    for r in cal.itertuples():
        data=Dataset.load(args.data/r.role/r.map_id)
        if set(data.index.root)&set(support.index.root):raise ValueError('Overlapping physical roots.')
        decisions,_ = decision_rows(args.data/r.role/r.map_id,False)
        batches.append(score_map(support,data,decisions,args.method,net))
    rows=pd.concat(batches,ignore_index=True)
    roots,radii=summarize(rows,.90)
    args.out.mkdir(parents=True,exist_ok=True)
    rows.to_csv(args.out/'particle_scores.csv.gz',index=False)
    roots.to_csv(args.out/'maxima_by_root.csv',index=False)
    radii.to_csv(args.out/'joint_radii.csv',index=False)
    print(radii.to_string(index=False))

if __name__=='__main__':main()

"""Derive four map inputs and a frozen suffix-reuse matrix without reading DEV/CAL results."""
from collections import Counter
from pathlib import Path
import csv,hashlib,json,inspect
import numpy as np
R=Path(__file__).resolve().parent
P=R.parent
W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
NAMES=['dev_00','dev_01','calibration_00','calibration_01']
PAIRS=[NAMES[:2],NAMES[2:]]
EXITS=['straight','near_left_cem','near_right_cem']
def read(path):return json.loads(Path(path).read_text())
def save(path,x):Path(path).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run():
    ref=P.parent/'chapter3_continuous_single_update_20261123'
    old=read(ref/'right_offset/part_0/physical/resolved_config.json')['p0_branches']
    summary=read(ref/'analysis/paired/receipt.json')['summary']
    paths=read(P/'collection_contract.json')['batches']
    assert sha(old['timing_file'])==old['timing_sha256'] and len(old['latency_ms'])==100 and old['schedule_ticks']==2001
    manifest=[];index=[]
    for name in NAMES:
        b=next(b for b in paths if b['name']==name);c=read(b['config']);v0=c['ground_handoff']['handoff_variants']
        assert sha(b['config'])==b['config_sha256']
        loc=R/name;loc.mkdir(exist_ok=True);variants=[];ev=[];takes=[]
        for il in range(0,len(v0),2):
            l,r=v0[il:il+2]
            if l['root_slot']>=6:continue
            assert l['arm']=='left' and r['arm']=='right' and all(l[k]==r[k] for k in l if k not in ('arm','departure','planned_departure'))
            group=len(variants)//3
            for j,typ in enumerate(EXITS):
                lane=len(variants)
                # All three first call the original shadow on their assigned task; the
                # separate CEM planner below receives its fixed near-left or near-right objective.
                v=dict(l,arm=typ,departure='straight',planned_departure=1,source_arm_role=(1,3,4)[j],
                       source_left_lane=il,source_right_lane=il+1,primary_gate_side=l['side'],
                       primary_section_x=l['section_x'],primary_section=l['bin'],
                       cem_section_x=(12.7 if j else None),cem_side=((1,-1)[j-1] if j else None))
                variants.append(v);ev.append([v['geometry'],'h75',lane]);takes.append(1)
                index.append(dict(map=name,group=group,root=v['bank_row'],root_slot=v['root_slot'],action_slot=v['action_slot'],geometry=v['geometry'],alpha=v['approach_alpha'],force_N=v['force_y_N'],target_side=v['side'],target_gate=v['bin'],section_x=v['section_x'],source_left_lane=il,source_right_lane=il+1,new_lane=lane,physical_arm=typ,online_cem_target_side=v['cem_side'],online_cem_target_x=v['cem_section_x'],source_physical=b['physical']))
        assert len(variants)==864 and len({(x['bank_row'],x['action_slot'],x['force_y_N']) for x in variants})==288
        g=dict(c['ground_handoff'],handoff_variants=variants)
        d=dict(c,ground_handoff=g,evaluation_lanes=ev,paired_departures=dict(c['paired_departures'],direction_ids=takes),
               ccd_capacity=8*len(ev),p0_branches=dict(old,group_size=3,roots=b['bank_rows'][:6]))
        assert d['platform_online']['margin_m']==.05330585315823555 and d['platform_online']['latency_ticks']=={'start':3,'departure':3}
        keep={k for k in c if k not in ('ground_handoff','evaluation_lanes','paired_departures','ccd_capacity')};assert all(d[k]==c[k] for k in keep)
        assert c['paired_departures']['route_bank']==d['paired_departures']['route_bank']
        save(loc/'config.json',d);manifest.append(dict(map=name,role=b['role'],config=str(loc/'config.json'),config_sha256=sha(loc/'config.json'),source_config=b['config'],source_sha256=b['config_sha256'],model=b['physical_model'],model_sha256=sha(b['physical_model']),source_physical=b['physical'],world=b['world'],output=str(loc/'physical'),roots=b['bank_rows'][:6],lanes=len(ev)))
    with (R/'reuse_matrix.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=index[0]);w.writeheader();w.writerows(index)
    m=dict(stage='Prepared and CPU-checked, zero new physics',source=str(P/'collection_preregistration.json'),maps=manifest,map_pairs=PAIRS,old_timing_file=old['timing_file'],old_timing_sha256=old['timing_sha256'],old_single_vs_rolling=summary,original_suffixes=2304,new_physical_lanes=3456,actions_total=5760,prefixes=1152,notes=[
        'Four maps x six roots x sixteen actions x three forces; coexisting in the original P1 panel are 1152 possible left and 1152 possible right outcomes. Every additional map worker carries exactly 864 straight/near-left CEM/near-right CEM worlds; each paired GPU job carries 1728 without padding. Distinct horizons and physical workers are preserved.',
        'Fixed near CEM target x=12.7, y sign +1/-1 independent of the evaluation gate. All five outcomes are evaluated against the actual near/far and side preassigned to a root/action, constant across pushes. Relabel another gate only from unchanged physical paths; never claim a near-CEM policy retargeted to another gate produced these data.',
        'The physical primary is the original left replica. Verify the observed dynamics and actual actuator targets against that same anchor for each alternative. Its own paired original right is identified only on recorded matching prefix or common prequery endpoint. Every unmatched alternative stays in [0,1]; do not reject an entire five-arm panel because one alternative diverged.',
        'CEM is single-query; use frozen 5.33cm, 16 proposals/two iterations, original 100 measured per-robot latencies, 100ms deadline, policy-boundary publication, validity/expiry and default rejoin. Straight/old fixed exits use native +15ms schedule; these are different actuator publication clocks and must be reported separately. Both CEM arms sample the identical latency indexed by local prefix id.',
        'Source agent and native per-group future plan information are excluded from matching. Verify source original left prequery t-20ms, native control, phase and terminal. Sensitivity comparisons for pairs of CEM exits may certify directly when they match each other but not the chosen source anchor; those do not identify the primary-five result.',
        'Maps cannot share one unmodified native Warp kernel: each needs its physical terrain. The two 864-world workers independently share the GPU; a counted 1728 requires repeated synchronized overlap and clock advance, not just launched processes. Monitor global and per-process sampled VRAM. If simultaneous pair is infeasible stop and re-register the separate 4x1440 fallback with no original-left/right reuse claim. No automatic extra rollouts.'
    ])
    save(R/'protocol.json',m)
    print(len(index),'physical candidates ready')
if __name__=='__main__':run()

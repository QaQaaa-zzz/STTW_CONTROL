"""Identify each suffix independently on the preassigned primary left physical prefix."""
import argparse,csv,functools,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
from prepare import R,P,W,read,save
sys.path[:0]=[str(W/'learning/cli'),str(W/'learning/src'),'/home/qy/DVGC/JIT/src']
from analyze_chapter3_continuous_p0_branches import prefix_flight_force
from run_playground_task_reversal import crossings_by_section
OMIT={'tick','previous_tick','lanes','remaining_s','incumbent_direction','shadow_choice','shadow_any_admitted','shadow_incumbent_admitted'}
def equal(x,y):return x.dtype==y.dtype and x.shape==y.shape and x.tobytes()==y.tobytes()
@functools.lru_cache(maxsize=4)
def snap(path):
    with np.load(path) as z:return dict(z)
def query_index(path):
    out={}
    for f in sorted(path.glob('tick_*.npz')):
        with np.load(f) as z:ids=z['lanes'];tick=int(z['tick']);pt=int(z['previous_tick'])
        assert pt==tick-4
        for i,lane in enumerate(ids):
            if int(lane) in out:raise ValueError('Repeated first handoff')
            out[int(lane)]=(tick,f,i)
    return out
def trajectory(path):
    with np.load(path) as z:return {k:z[k] for k in ('qpos','qvel','trace','contact_substep','world_flags','wheel_contact_flags','reference_xy')}
def pair(aa,bb,ca,cb,sa,sb,ra,rb,until):
    ma,mb=sa is not None,sb is not None;ta,tb=(len(t['qpos'])-1 for t in (aa,bb))
    last=min(until,ta,tb)
    clocks=['rb_entry_s','handoff_s','air_event_tick','applied_force_ticks']
    same_clock=all(ra[k]==rb[k] for k in clocks) and ma==mb and (not ma or sa[0]==sb[0])
    checked={k:equal(aa[k][:last+1],bb[k][:last+1]) for k in ('qpos','qvel','trace','world_flags','wheel_contact_flags')}
    checked['reference']=equal(aa['reference_xy'],bb['reference_xy'])
    for k in ca:checked[k]=equal(ca[k][:last],cb[k][:last])
    counts,raw=True,True
    if ma and mb:
        if sa[0]!=sb[0]:counts=False
        a,b=snap(sa[1]),snap(sb[1]);keys=set(a)-OMIT
        if keys!=set(b)-OMIT:raise ValueError(f'Query archive schema mismatch: {(keys^(set(b)-OMIT))}')
        differences=[k for k in keys if not equal(np.asarray(a[k][sa[2]]),np.asarray(b[k][sb[2]]))]
    else:differences=[]
    ac,bc=(x['contact_substep'][:last+1] for x in (aa,bb));eps=1e-5
    checked['contact_predicates']=equal(ac[:,:,:3]<=eps,bc[:,:,:3]<=eps) and equal(ac[:,:,3]==0,bc[:,:,3]==0)
    checked['same_query_observables']=not differences
    if not ma and not mb:counts=(ta==tb and until>=ta and ra['termination']==rb['termination'])
    ok=same_clock and counts and all(checked.values())
    return dict(prefix_certified=bool(ok),compared_until_tick=last,matched_phase_times=same_clock,query_differences=','.join(sorted(differences)),
                mismatched_fields=','.join(k for k,v in checked.items() if not v),raw_contact_loads_identical=equal(ac,bc))
def selections(path):
    events=[json.loads(line) for line in path.read_text().splitlines()]
    lanes={}
    for e in events:
        for j,ix in enumerate(e['lanes']):
            x=lanes.setdefault(ix,dict(nquery=0,pub=-1,query=-1,due=-1,expiry=-1,ms=None,selected=False,in_time=None,accepted=None,pursuit=-1,actor=-1))
            kind=e['kind']
            if kind=='query':
                x['nquery']+=1;x.update(query=e['tick'],due=e['due'][j],ms=e['ms'][j],accepted=e['admitted'][j])
            elif kind=='publication':
                x.update(in_time=e['in_time'][j],selected=e['published'][j])
                if x['selected']:x['pub']=e['tick']
            elif kind=='expired_to_default':x['expiry']=e['tick']
            elif kind in ('h75_actor_consumed','pursuit_consumed') and e['publication_tick'][j]==x['pub'] and x['pub']>=0:
                x['actor' if kind=='h75_actor_consumed' else 'pursuit']=e['tick']
    return lanes
def verify(name):
    import mujoco
    prot=read(R/'protocol.json');batch=next(x for x in prot['maps'] if x['map']==name)
    folder=Path(batch['output']);old=Path(batch['source_physical']);st=read(folder/'status.json');src=read(old/'status.json')
    assert st['stage']==src['stage']=='complete' and len(st['results'])==864 and len(src['results'])==1152
    rr=st['results'];base=src['results'];contract=read(Path(batch['config']))
    cases=pd.read_csv(P/'export'/batch['role']/name/'suffix_index.csv').set_index('lane',verify_integrity=True)
    src_q=query_index(old/'p1_query');new_q=query_index(folder/'five_query');cem_q=query_index(folder/'five_cem_query');ev=selections(folder/'p0_events.jsonl')
    phys=mujoco.MjModel.from_binary_path(batch['model']);world=read(batch['world'])
    with np.load(old/'p1_applied_controls.npz') as z:old_actions={k:z[k] for k in ('targets','valid')}
    with np.load(folder/'five_applied_controls.npz') as z:new_actions={k:z[k] for k in ('targets','valid')}
    rows=[];bounds=[]
    for start in range(0,len(rr),3):
        v=rr[start]['variant'];l=v['source_left_lane'];r=v['source_right_lane'];anchor=base[l];lq=src_q.get(l)
        afile=old/anchor['case_dir']/'trajectory.npz';at=trajectory(afile);ac={k:x[:,l] for k,x in old_actions.items()}
        meta=dict(map_id=name,group=start//3,root=v['bank_row'],action_slot=v['action_slot'],alpha=v['approach_alpha'],geometry=v['geometry'],force_n=v['force_y_N'],section=v['bin'],side=v['side'])
        primary_verified=bool(cases.loc[l,'verified_relock']);eligible=primary_verified and lq is not None
        outside=[]
        for typ,i,root,logs,query,cmd,oldarm in [('fixed_left',l,old,base,lq,old_actions,True),('fixed_right',r,old,base,src_q.get(r),old_actions,True)]+[(rr[i]['variant']['arm'],i,folder,rr,new_q.get(i),new_actions,False) for i in range(start,start+3)]:
            row=logs[i];rv=row['variant'];trace=root/row['case_dir']/'trajectory.npz'
            assert [rv[k] for k in ('bank_row','action_slot','geometry','approach_alpha','force_y_N','side','section_x')]==[v[k] for k in ('bank_row','action_slot','geometry','approach_alpha','force_y_N','side','section_x')]
            tt=at if typ=='fixed_left' else trajectory(trace)
            end=len(tt['qpos'])-1;source_end=len(at['qpos'])-1
            event=ev.get(i,{}) if typ.startswith('near_') else {}
            if typ.startswith('near_'):
                if event.get('nquery',0)!=int(query is not None):raise ValueError('Single CEM query count differs from observed handoff')
                if query and (event['query']!=query[0] or event['due']!=((query[0]+int(np.ceil(event['ms']/5))+3)//4)*4):raise ValueError('CEM first query / due mismatch')
                if (i in cem_q)!=(query is not None):raise ValueError('First actual CEM argument recording missing/unexpected')
                if query:
                    ct,cf,cj=cem_q[i];qa=snap(cf);h=snap(query[1]);hj=query[2]
                    assert ct==query[0] and int(qa['side'][cj])==(1 if typ=='near_left_cem' else -1) and np.isclose(qa['section'][cj],12.7)
                    for k,jk in [('q','qpos'),('velocity','velocity'),('previous','previous_velocity')]:
                        if not equal(qa[k][cj],h[jk][hj]):raise ValueError('CEM pose, velocity, or previous observation changed before request')
                    assert bool(qa['admitted'][cj])==bool(event['accepted']) and float(qa['remaining_s'])==10.-ct*.005
                if event.get('pub',-1)>=0 and not(event['selected'] and event['accepted'] and event['in_time'] and event['pub']==event['due']):raise ValueError('Invalid CEM publication')
                applied=event.get('pub',-1)
            else:
                applied=row['departure_applied_tick']
                if query and row['departure_due_tick']!=query[0]+3:raise ValueError('Fixed-arm publication timing differs')
            earliest=min(x for x in (source_end,end,anchor['departure_applied_tick'] if anchor['departure_applied_tick']>=0 else source_end,applied if applied>=0 else end))
            checks=pair(at,tt,ac,{k:x[:,i] for k,x in cmd.items()},lq,query,anchor,row,earliest)
            if oldarm:
                observed=cases.loc[i]
                if str(Path(observed.trajectory))!=str(trace):raise ValueError('Source trajectory join failed')
                good=bool(observed.physical_task_done);wall=bool(observed.physical_wall);verified=bool(observed.verified_relock);gate=bool(observed.correct_gate)
            else:
                verified=bool(prefix_flight_force(row,trace,phys,world['terrain'])['verified'])
                cy=next(x for x in crossings_by_section(tt['trace'],row['handoff_s'] if row['handoff_s'] is not None else np.inf,[12.7,13.6,15.]) if x[0]==v['bin'])[-1]
                gate=bool(cy is not None and .06<=cy*v['side']<=3.9)
                wall=bool(row['forbidden_contact_steps']);good=bool(verified and gate and row['goal'] and not wall)
            cert=checks['prefix_certified']
            if cert and query is not None and verified!=primary_verified:raise ValueError('Matching queried prefixes disagree on the verified jump')
            outcome=(int(good),int(good)) if cert else (0,1)
            if not eligible:outcome=(int(cases.loc[l,'physical_task_done']),)*2
            w=(int(wall),int(wall)) if cert else (0,1)
            if lq is None:w=(int(cases.loc[l,'physical_wall']),)*2
            d=dict(**meta,arm=typ,lane=i,original_left_lane=l,original_right_lane=r,trajectory=str(trace),source_left=str(afile),
                observed_query_tick=None if query is None else query[0],first_publication=applied,verified_jump=verified,physical_gate=gate,
                physical_goal=row['goal'],physical_wall=wall,raw_task_done=good,termination=row['termination'],success_lo=outcome[0],success_hi=outcome[1],
                wall_lo=w[0],wall_hi=w[1],**checks,**{'cem_'+k:x for k,x in event.items()})
            rows.append(d);outside.append(d)
        assert len(outside)==5 and outside[0]['prefix_certified']
        if outside[3].get('cem_query',-1)>=0 and outside[4].get('cem_query',-1)>=0 and outside[3]['observed_query_tick']==outside[4]['observed_query_tick']:
            assert outside[3]['cem_ms']==outside[4]['cem_ms'] and outside[3]['cem_due']==outside[4]['cem_due']
        common_cem=None
        if start+1 in cem_q and start+2 in cem_q:
            a,b=(cem_q[j] for j in [start+1,start+2]);za,zb=snap(a[1]),snap(b[1])
            equal_args=('q','velocity','previous','committed_s','section','gate_status','hold_s','rows','reference_xy','reference_heading','reference_curvature')
            common_cem=(a[0]==b[0] and all(equal(za[k][a[2]],zb[k][b[2]]) for k in equal_args) and float(za['remaining_s'])==float(zb['remaining_s']))
        bounds.append(dict(**meta,cem_same_measured_inputs_except_target_side=common_cem,verified_relock=primary_verified,primary_query=(lq[0] if lq else None),identified_arms=sum(x['success_lo']==x['success_hi'] for x in outside),
            five_feasible_lo=max(x['success_lo'] for x in outside),five_feasible_hi=max(x['success_hi'] for x in outside)))
    pd.DataFrame(rows).to_csv(R/name/'physical_outcomes.csv',index=False);pd.DataFrame(bounds).to_csv(R/name/'five_feasibility_bounds.csv',index=False)
    save(R/name/'identification.json',dict(rows=len(rows),prefixes=len(bounds),matched_rows=sum(x['prefix_certified'] for x in rows),
         feasible_count_lower=sum(x['five_feasible_lo'] for x in bounds),feasible_count_upper=sum(x['five_feasible_hi'] for x in bounds),
         conclusion='Bounds over the five specified control policies only, not general physical reachability. Preserve actual unmatched trajectories separately.'))
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--map',choices=['dev_00','dev_01','calibration_00','calibration_01'],required=True)
    verify(ap.parse_args().map)

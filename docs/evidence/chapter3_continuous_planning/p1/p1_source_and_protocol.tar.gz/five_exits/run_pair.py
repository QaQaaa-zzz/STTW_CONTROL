"""Run two homogeneous 864-car map workers concurrently under the shared GPU job lock."""
from contextlib import redirect_stdout,redirect_stderr
import argparse,csv,fcntl,json,multiprocessing as mp,os,subprocess,sys,time
from pathlib import Path
from multiprocessing.connection import wait
import numpy as np
from prepare import R,P,W,read,save,sha
LOCK=Path('/home/qy/STTW_CONTROL/research-hub/.gpu-job.lock')
CHECKPOINTS={0,1,8,32,2000,*range(128,2000,128)}
def role_values(ids):
    return (1,3,4)[ids%3]
def cpu_overlap(paths):
    tapes=[{r['tick']:r for r in (json.loads(s) for s in path.read_text().splitlines())} for path in paths]
    if any(set(x)!=CHECKPOINTS for x in tapes):raise RuntimeError('Incomplete physical progress records')
    report=[]
    for last,t in zip(sorted(CHECKPOINTS),sorted(CHECKPOINTS)[1:]):
        a,b=[x[t] for x in tapes];pa,pb=[x[last] for x in tapes]
        overlap=min(a['arrived_ns'],b['arrived_ns'])-max(pa['released_ns'],pb['released_ns'])
        if overlap<=0 or a['worlds']!=864 or b['worlds']!=864 or any(x['alive'] and (abs(x['live_time_min_s']-t*.005)>.002 or abs(x['live_time_max_s']-t*.005)>.002) for x in (a,b)):raise ValueError('Two physical workers did not show overlapping synchronized GPU intervals')
        report.append(dict(from_tick=last,to_tick=t,overlap_s=overlap*1e-9,worlds=1728,active_worlds_at_end=a['alive']+b['alive'],
                 worker_gpu_MiB=[a.get('process_gpu_MiB'),b.get('process_gpu_MiB')],gpu_used_total_MiB=max(a['gpu_used_MiB'],b['gpu_used_MiB']),min_free_MiB=min(a['gpu_free_MiB'],b['gpu_free_MiB'])))
    if not any(x['to_tick']>0 and x['active_worlds_at_end']==1728 for x in report):raise ValueError('No simultaneous interval of 1728 living physical worlds')
    return report

def physical(b,barrier):
    import torch,jax
    import evaluate_playground_handoff as evaluator
    import sttw_control.playground_handoff_evaluation as handoff
    import sttw_control.chapter3_p0_physical as module
    from sttw_control.playground_adapters import JumpAdapter
    from sttw_control.platform_online import velocity_state
    out=Path(b['output']);original=handoff.evaluate_handoff;select=JumpAdapter.select
    tapes={};events=[];cem_events=[]
    class FiveBranches(module.P0Branches):
        def __init__(self,cfg,out,query,route,contracts,q,v):
            super().__init__(cfg,out,query,route,contracts,q,v)
            self.arm=self.arm.new_tensor([1,3,4]).repeat(self.n//3)
            # The native outer scorer keeps the original assigned evaluation gate.
            # Only the continuous planner receives a fixed near-left or near-right goal.
            self.section=q.new_tensor([c['cem_section_x'] if c['cem_section_x'] is not None else c['section_x'] for c in contracts])
            self.side=q.new_tensor([c['cem_side'] if c['cem_side'] is not None else c['side'] for c in contracts])
            native_plan=self.models.plan
            def capture_plan(q,velocity,previous,route,committed_s,section,side,remaining_s,*,gate_status=0,hold_s=0.,rows=None):
                env=sys._getframe(1).f_locals
                result=native_plan(q,velocity,previous,route,committed_s,section,side,remaining_s,gate_status=gate_status,hold_s=hold_s,rows=rows)
                items=dict(lanes=env['ids'],q=q,velocity=velocity,previous=previous,committed_s=committed_s,
                    section=section,side=side,gate_status=gate_status,hold_s=hold_s,rows=rows,
                    reference_xy=route.xy[rows],reference_heading=route.heading[rows],reference_curvature=route.curvature[rows],
                    admitted=result.admitted,incumbent_admitted=result.incumbent_admitted,valid_for_s=result.valid_for_s)
                cem_events.append((env['tick'],float(remaining_s),{k:v.detach().clone() for k,v in items.items()}))
                return result
            self.models.plan=capture_plan
        def audit(self,tick,env,just_locked):
            if tick in CHECKPOINTS:
                d=env['data'];d.qpos.block_until_ready();torch.cuda.synchronize()
                times=torch.from_dlpack(d.time);mi,ma=float(times.min()),float(times.max())
                live=times[env['alive']];free,total=torch.cuda.mem_get_info()
                entry=dict(tick=tick,worlds=d.qpos.shape[0],alive=int(env['alive'].sum()),device=str(d.qpos.device),
                    sim_time_min_s=mi,sim_time_max_s=ma,live_time_min_s=float(live.min()) if len(live) else None,live_time_max_s=float(live.max()) if len(live) else None,arrived_ns=time.monotonic_ns(),pid=os.getpid(),
                    gpu_used_MiB=(total-free)/2**20,gpu_free_MiB=free/2**20,torch_peak_reserved_MiB=torch.cuda.max_memory_reserved()/2**20)
                gpu_list=subprocess.run(['nvidia-smi','--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True)
                owned={int(v[0]):int(v[1]) for line in gpu_list.stdout.splitlines() if len(v:=line.split(','))==2 and v[1].strip().isdigit()}
                entry['process_gpu_MiB']=owned.get(os.getpid())
                barrier.wait()
                entry['released_ns']=time.monotonic_ns()
                with (out/'paired_gpu_milestones.jsonl').open('a') as f:f.write(json.dumps(entry)+'\n')
            ids=torch.where(just_locked)[0]
            if len(ids):
                q,v=env['q'],env['v'];pq,pv=env['velocity_history'][tick%4]
                fields=dict(lanes=ids,qpos=q[ids],qvel=v[ids],previous_qpos=pq[ids],previous_qvel=pv[ids],
                    velocity=velocity_state(q[ids],v[ids]),previous_velocity=velocity_state(pq[ids],pv[ids]),
                    route_at_query=env['route'].route_ids[ids],projection_progress=env['middle'].projection['progress'][ids],
                    handoff_s=env['handoff_time'][ids],requested_speed=env['nominal_continuation_speed'][ids])
                approach_ids=env['approach_ids'][ids];xs=env['approach_x'];arcs=env['arc64']
                after=torch.stack([torch.searchsorted(x,q[ids,0].double().contiguous()+.05) for x in xs])
                join=torch.maximum(after[approach_ids,torch.arange(len(ids),device=q.device)],torch.searchsorted(arcs,env['middle'].projection['progress'][ids].double().contiguous())+1).clamp_max(len(arcs)-1)
                fields['branch_ids']=len(xs)+(approach_ids[:,None]*3+torch.arange(3,device=q.device))*len(arcs)+join[:,None]
                fields['section_x']=env['section'][ids];fields['side']=env['side'][ids]
                quat=q[ids,3:7];bw,bx,by,bz=quat.T
                axis=torch.stack((1-2*(by.square()+bz.square()),2*(bx*by+bw*bz),2*(bx*bz-bw*by)),1)
                fields['body_speed']=(axis*v[ids,:3]).sum(1)
                for name,obj in [('middle',env['middle']),('policy',env['middle'].policy),('controller',env['ctl'])]:
                    fields.update({k:x[ids] for k,x in module.lane_tensors(vars(obj),name,self.n).items()})
                for name in ('phase','target','lock','far_time','upper_ready_time','stable_time','recovering','pulse_start','pulse_ticks'):fields['runtime_'+name]=env[name][ids]
                for name in ('qpos','qvel','act','ctrl','qacc_warmstart','qfrc_applied','eq_active','time'):fields['physics_'+name]=torch.from_dlpack(getattr(env['data'],name))[ids]
                for name in ('history','obs','last','rb_events'):
                    for j,leaf in enumerate(jax.tree.leaves(env[name])):fields[f'{name}_{j}']=torch.from_dlpack(leaf)[ids]
                events.append((tick,{k:x.detach().clone() for k,x in fields.items()}))
            super().audit(tick,env,just_locked)
    def capture(self,phase,ground_targets,rb_targets,joint_bias):
        v=select(self,phase,ground_targets,rb_targets,joint_bias);env=sys._getframe(1).f_locals;tick=env['tick']
        if not tapes:
            tapes['targets']=v.new_empty((2000,len(v),4));tapes['valid']=torch.empty((2000,len(v)),device=v.device,dtype=torch.bool)
        tapes['targets'][tick].copy_(v.detach());tapes['valid'][tick].copy_(env['alive']);tapes['last']=tick+1
        return v
    def gate(model,*args):
        if sha(out/'terrain.mjb')!=b['model_sha256'] or model.opt.timestep!=.001:raise ValueError('Physical map/tick differs from original two-exit data')
        return original(model,*args)
    JumpAdapter.select=capture;module.P0Branches=FiveBranches;handoff.evaluate_handoff=gate
    sys.argv=[str(Path(evaluator.__file__)),'--config',b['config'],'--output',str(out),'--skills','rb_run1','--modes','h75','--routes','0','1','--physics-substeps','5','--seconds','10']
    evaluator.main()
    snap=out/'five_query';snap.mkdir()
    for tick,fields in events:np.savez_compressed(snap/f'tick_{tick:04d}.npz',tick=tick,previous_tick=tick-4,**{k:v.cpu().numpy() for k,v in fields.items()})
    cdir=out/'five_cem_query';cdir.mkdir()
    for tick,seconds,fields in cem_events:np.savez_compressed(cdir/f'tick_{tick:04d}.npz',tick=tick,previous_tick=tick-4,remaining_s=seconds,**{k:v.cpu().numpy() for k,v in fields.items()})
    t=tapes['last'];np.savez_compressed(out/'five_applied_controls.npz',targets=tapes['targets'][:t].cpu().numpy(),valid=tapes['valid'][:t].cpu().numpy(),dt_s=.005)
def worker(b,barrier):
    os.chdir(W)
    sys.path[:0]=[str(W/'learning/src'),str(W/'learning/cli'),'/home/qy/DVGC/JIT/src']
    with (Path(b['config']).parent/'worker.log').open('w',buffering=1) as log,redirect_stdout(log),redirect_stderr(log):
        try:physical(b,barrier)
        except BaseException:
            import traceback
            traceback.print_exc();barrier.abort();raise
def notify(path,phase,msg):
    subprocess.run(['/usr/bin/python3',str(W/'learning/scripts/notify_chapter3_job.py'),'--message',msg,'--title','第三章五出口 '+phase,'--receipt',str(path/(phase+'_bark.json'))])
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--pair',choices=['dev','calibration'],required=True);a=ap.parse_args()
    p=read(R/'protocol.json')
    ready=read(R/'cpu_validation.json')
    if any(sha(f)!=v for f,v in ready['source_sha256'].items()):raise ValueError('Frozen runner or physical scheduler differs from validation')
    rows=[b for b in p['maps'] if b['role']==a.pair]
    if len(rows)!=2:raise ValueError('Exactly two active map workers required')
    jobs=R/(a.pair+'_pair');ctx=mp.get_context('spawn');barrier=ctx.Barrier(2)
    for b in rows:
        if sha(b['config'])!=b['config_sha256'] or sha(b['source_config'])!=b['source_sha256']:raise ValueError('Frozen input mismatch')
        if not (Path(b['source_physical'])/'p1_pair_summary.json').is_file():raise ValueError('Need the actual primary physical archive for a five-way comparison')
        if Path(b['output']).exists():raise ValueError('Existing physical directory; will not replay a partial batch')
    jobs.mkdir(exist_ok=False)
    # Avoid one of two JAX clients reserving GPU allocator space for both upfront.
    os.environ['XLA_PYTHON_CLIENT_PREALLOCATE']='false'
    with LOCK.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX);notify(jobs,'start',f'{a.pair} 两张地图并行，每个864车，合计1728；物理并行须由同步时钟验证。')
        processes=[ctx.Process(target=worker,args=(b,barrier),name=b['map']) for b in rows]
        for proc in processes:proc.start()
        remaining={proc.sentinel:proc for proc in processes}
        while remaining:
            for fd in wait(list(remaining)):
                proc=remaining.pop(fd);proc.join()
                if proc.exitcode:barrier.abort()
        rc=[s.exitcode for s in processes]
        if any(rc):
            notify(jobs,'error',f'{a.pair} 子进程退出码 {rc}；保留两批已实测样本，不自动补跑。')
            raise RuntimeError(f'Physical child return codes: {rc}')
        res=cpu_overlap([Path(b['output'])/'paired_gpu_milestones.jsonl' for b in rows])
    save(jobs/'actual_parallelism.json',dict(maps=[b['map'] for b in rows],per_worker_worlds=864,total_shape=1728,intervals=res,
         meaning='Both workers advanced their own full GPU physics time during overlapping wall-clock intervals; simultaneous individual GPU kernels not inferred.'))
    notify(jobs,'complete',f'{a.pair} 两批均生成真实物理终点，并发推进已核验；等待逐车配对。')
if __name__=='__main__':main()

"""CPU checks for configurations, old source matching, scheduler and parallelism receipts."""
import csv,json,sys,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import pandas as pd
import torch
from prepare import W,P,R,read,sha,save
from run_pair import cpu_overlap,CHECKPOINTS,role_values
from verify import pair,trajectory,query_index,selections
sys.path[:0]=[str(W/'learning/src'),str(W/'learning/cli'),'/home/qy/DVGC/JIT/src']
from sttw_control import chapter3_p0_physical as mod
def scheduler_test(td):
    class Planner:
        def __init__(self,*a,**k):pass
        def plan(self,q,v,past,route,progress,section,side,seconds,**kw):
            ids=kw['rows'];n=len(q)
            return SimpleNamespace(xy=route.xy[ids].clone(),heading=route.heading[ids].clone(),curvature=route.curvature[ids].clone(),
                admitted=side>0,incumbent_admitted=side>0,valid_for_s=torch.full((n,),.09))
    class Query:
        def choose(self,*args):
            old=args[7];return old,old.bool(),old.bool()
    t=torch.linspace(0,16,65);q=torch.zeros(3,12);q[:,3]=1.;v=torch.zeros(3,11);route=SimpleNamespace(s=t,xy=torch.stack([t,torch.zeros_like(t)],1)[None].repeat(198,1,1),
                                                heading=torch.zeros(198,65),curvature=torch.zeros(198,65),route_ids=torch.arange(3))
    with patch.object(mod,'ContinuousExitPlanner',Planner),patch.object(torch.cuda,'synchronize',lambda:None):
        rows=[{'section_x':12.7,'side':k} for k in (-1,1,-1)]
        cfg=dict(group_size=3,schedule_ticks=2001,deadline_ms=100,latency_ms=[33.156866])
        parents=mod.P0Branches(cfg,td,Query(),route,rows,q,v)
        parents.arm=torch.tensor([role_values(i) for i in range(3)])
        middle=SimpleNamespace(projection={'progress':torch.zeros(3)},follower={'lookahead':torch.ones(3)},v_user=torch.full((3,),2.))
        e=dict(q=q,v=v,route=route,middle=middle,alive=torch.ones(3,dtype=torch.bool),handoff_time=torch.ones(3),approach_x=[t],approach_ids=torch.zeros(3,dtype=torch.long),arc64=t,join=torch.ones(3,dtype=torch.long),nominal_continuation_speed=torch.full((3,),2.),hold=torch.zeros(3))
        for tick in range(200,235):parents.step(tick,e,torch.full((3,),tick==200,dtype=torch.bool),torch.zeros(3,9))
        parents.finish()
    ev=selections(td/'p0_events.jsonl')
    assert 0 not in ev and ev[1]['nquery']==ev[2]['nquery']==1 and ev[1]['query']==ev[2]['query']==200
    assert ev[1]['due']==ev[2]['due']==208 and ev[1]['pub']==208 and ev[1]['expiry']>208 and ev[2]['pub']==-1
    return dict(cases='Artificial three-arm fixture, frozen scheduler with controlled planner votes',request_tick=200,both_cem_due_tick=208,published_left_tick=208,published_right=False,left_expiry_tick=ev[1]['expiry'],source='original P0Branches.step, publication checks and rejoin_default',physics_steps=0)
def prior_queries():
    # Only previously obtained TRAIN data. No five-exit or DEV/CAL outcome inspection.
    root=P/'batches/train_00/physical';src=read(root/'status.json')['results'];qx=query_index(root/'p1_query')
    ix=pd.read_csv(root/'p1_prefixes.csv')
    keep=[ix[ix.status==s].iloc[0] for s in ['matched_observed_handoff','matched_observed_prequery_endpoint']]
    results=[]
    with np.load(root/'p1_applied_controls.npz') as z:actions={k:z[k] for k in ('targets','valid')}
    for x in keep:
        l,r=int(x.left_lane),int(x.right_lane);records=[src[i] for i in [l,r]];ts=[trajectory(root/row['case_dir']/'trajectory.npz') for row in records]
        c=[{k:y[:,i] for k,y in actions.items()} for i in [l,r]];until=min((v['departure_applied_tick'] if v['departure_applied_tick']>=0 else len(t['qpos'])-1) for t,v in zip(ts,records))
        m=pair(*ts,*c,qx.get(l),qx.get(r),*records,until)
        assert m['prefix_certified']
        if l in qx:
            changed={k:y.copy() for k,y in c[1].items()};changed['targets'][0,0]=1+changed['targets'][0,0]
            assert not pair(*ts,c[0],changed,qx.get(l),qx.get(r),*records,until)['prefix_certified']
        results.append(dict(source='archived train_00 left/right controls and trajectories',source_lanes=[l,r],compare_until_tick=m['compared_until_tick'],query=l in qx,certified=True))
    return results
def main():
    p=read(R/'protocol.json');m=pd.read_csv(R/'reuse_matrix.csv')
    assert len(m)==3456 and len(m[['map','root','action_slot','force_N']].drop_duplicates())==1152 and m.groupby(['map','group']).size().eq(3).all()
    for b in p['maps']:
        c=read(b['config']);assert sha(b['config'])==b['config_sha256'] and sha(b['source_config'])==b['source_sha256']
        v=c['ground_handoff']['handoff_variants'];assert len(v)==864
        for i,r in enumerate(v):
            assert r['source_arm_role']==role_values(i) and r['planned_departure']==1
            assert r['cem_side']==(None,1,-1)[i%3] and c['paired_departures']['direction_ids'][i]==1
            assert r['side']==r['primary_gate_side'] and r['section_x']==r['primary_section_x']
        assert c['p0_branches']['group_size']==3 and c['p0_branches']['schedule_ticks']==2001 and len(c['p0_branches']['latency_ms'])==100
    with tempfile.TemporaryDirectory(dir=R) as tmp:
        tmp=Path(tmp);a=scheduler_test(tmp);files=[]
        for worker in [0,1]:
            path=tmp/f'workers{worker}.jsonl';files.append(path)
            records=[dict(tick=t,worlds=864,alive=864,process_gpu_MiB=11,gpu_used_MiB=22,gpu_free_MiB=20,live_time_min_s=t*.005,live_time_max_s=t*.005,arrived_ns=t*1000+worker+1,released_ns=t*1000+worker+3) for t in sorted(CHECKPOINTS)]
            path.write_text('\n'.join(json.dumps(x) for x in records)); 
        assert len(cpu_overlap(files))==len(CHECKPOINTS)-1
    identity=[R/'protocol.json',R/'run_pair.py',R/'prepare.py',R/'verify.py',R/'check_cpu.py',
        W/'learning/cli/evaluate_playground_handoff.py',W/'learning/src/sttw_control/playground_handoff_evaluation.py',
        W/'learning/src/sttw_control/chapter3_p0_physical.py',W/'learning/src/sttw_control/chapter3_continuous_exit.py']
    result=dict(source_sha256={str(f):sha(f) for f in identity},status='CPU verified; no new physical simulation launched',new_physical_simulator_steps=0,full_config_lanes=3456,eligible_existing_lanes=2304,logical_panel=5760,old_training_examples=prior_queries(),scheduler_fixture=a,parallelism_record_check='validated with artificial timestamps; real memory use and overlap can only be established by the GPU job',real_five_exit_identification_pending=True)
    save(R/'cpu_validation.json',result);print(json.dumps(result))
if __name__=='__main__':main()

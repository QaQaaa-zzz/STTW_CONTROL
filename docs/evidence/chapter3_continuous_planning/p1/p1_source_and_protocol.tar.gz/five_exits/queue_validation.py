"""One bounded queue for the registered five-exit physical development/calibration panel."""
import argparse,csv,datetime,hashlib,json,os,select,subprocess,sys,tempfile,time
from pathlib import Path
P=Path(__file__).resolve().parents[1]
R=P/'five_exits'
WORK=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
VENV=Path('/home/qy/mujoco_playground/.venv/bin/python')
SYSTEM=Path('/usr/bin/python3')
DEV_UNIT='sttw-ch3-p1-outcome-downstream.service'
THIS_UNIT='sttw-ch3-p1-five-exit-validation.service'
WAKE_UNIT='sttw-ch3-rolling-goal-check.service'
UPSTREAM=P/'model/formal_downstream'
def clock():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def load(p):return json.loads(Path(p).read_text())
def write(p,x):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n');os.replace(tmp,p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def systemd(unit):
    names=['Id','LoadState','ActiveState','SubState','MainPID','ExecMainPID','InvocationID','Result','ExecMainStatus','ExecMainCode','ExecMainExitTimestampMonotonic']
    cmd=['systemctl','--user','show',unit,*['--property='+k for k in names]]
    return dict(s.split('=',1) for s in subprocess.run(cmd,capture_output=True,text=True).stdout.splitlines() if '=' in s)
def stage(state,name,**extra):
    state.update(stage=name,updated_utc=clock(),**extra);write(R/'queue_status.json',state)
def wake():
    return subprocess.run(['systemctl','--user','start','--no-block',WAKE_UNIT],capture_output=True,text=True).returncode
def message(title,body,receipt):
    return subprocess.run([str(SYSTEM),str(WORK/'learning/scripts/notify_chapter3_job.py'),'--title',title,'--message',body,'--receipt',str(R/receipt)],cwd=WORK).returncode
def command(args,env,log_path):
    with log_path.open('a',buffering=1) as stream:subprocess.run(args,cwd=WORK,env=env,stdout=stream,stderr=subprocess.STDOUT,check=True)
def physical_environment():
    e=os.environ.copy();e.pop('JAX_PLATFORMS',None)
    e.update(CUDA_VISIBLE_DEVICES='0',PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1',XLA_PYTHON_CLIENT_PREALLOCATE='false',
             PYTHONPATH=':'.join(map(str,[WORK/'learning/src',WORK/'learning/cli','/home/qy/DVGC/JIT/src'])))
    return e
def upstream_receipts():
    status=load(UPSTREAM/'queue_status.json');path=UPSTREAM/'physical_evaluation/receipt.json';result=load(path)
    if status['stage']!='complete' or result['maps']!=['dev_00','dev_01'] or result['prototype_fixtures'] or result['formal_role']!='DEV only' or result['map_root_action_opportunities']!=384:
        raise ValueError('The registered two-exit DEV physical evaluation has not completed')
    return dict(status=str(UPSTREAM/'queue_status.json'),physical_receipt=str(path),physical_receipt_sha256=sha(path))
def wait_for_original(job):
    before=systemd(DEV_UNIT);inv=job['upstream_invocation'];pid=job['upstream_pid']
    if before.get('LoadState')=='loaded' and before.get('InvocationID') and before['InvocationID']!=inv:raise ValueError('DEV service invocation changed')
    if before.get('ActiveState') in ('active','activating') and int(before.get('MainPID') or 0)==pid:
        try:fd=os.pidfd_open(pid)
        except ProcessLookupError:pass
        else:
            try:select.select([fd],[],[])
            finally:os.close(fd)
    # A pidfd reports process death just before the systemd state atomically settles.
    end=time.monotonic()+8
    while True:
        q=systemd(DEV_UNIT)
        if q.get('ActiveState') in ('failed','inactive') or q.get('SubState')=='exited':break
        if not q.get('InvocationID') or q['InvocationID']!=inv or time.monotonic()>=end:raise RuntimeError(f'DEV terminal status unavailable: {q}')
        time.sleep(.15)
    if q.get('LoadState')=='loaded':
        if (q.get('InvocationID') and q['InvocationID']!=inv) or q.get('Result')!='success' or q.get('ExecMainStatus')!='0' or q.get('ActiveState')=='failed':
            raise RuntimeError(f'DEV service did not finish successfully: {q}')
    elif q.get('LoadState')=='not-found':
        # A successful, unreferenced transient service may unload immediately. Require its
        # own final verified success receipt as well as this exact submitted instance's start.
        journal=subprocess.run(['journalctl','--user',f'USER_UNIT={DEV_UNIT}',f'USER_INVOCATION_ID={inv}','-o','json','--no-pager'],capture_output=True,text=True,check=True)
        records=[json.loads(x) for x in journal.stdout.splitlines() if x]
        if not any(r.get('JOB_RESULT')=='done' for r in records) or any(r.get('UNIT_RESULT','success')!='success' or r.get('JOB_RESULT','done') not in ('done','success') for r in records):raise ValueError('Cannot verify original transient DEV unit')
    else:raise RuntimeError(f'Unexpected predecessor state: {q}')
    return dict(systemd=q,**upstream_receipts())
def run():
    job=load(R/'queue_receipt.json');state=dict(unit=THIS_UNIT,dependency=DEV_UNIT,dependency_pid=job['upstream_pid'],maps_completed=[],new_training_updates=0)
    try:
        stage(state,'waiting_for_two_exit_dev');terminal=wait_for_original(job)
        stage(state,'upstream_validated',upstream=terminal)
        e=physical_environment();cpu=dict(e,CUDA_VISIBLE_DEVICES='',JAX_PLATFORMS='cpu');spec=load(R/'protocol.json')
        for role in ('dev','calibration'):
            nm=[b for b in spec['maps'] if b['role']==role]
            stage(state,'running_'+role+'_physics')
            command([str(VENV),'-u',str(R/'run_pair.py'),'--pair',role],e,R/(role+'_queue.log'))
            gp=load(R/(role+'_pair')/'actual_parallelism.json')
            if gp['per_worker_worlds']!=864 or gp['total_shape']!=1728 or len(gp['intervals'])<2 or not any(i['active_worlds_at_end']==1728 and i['overlap_s']>0 for i in gp['intervals']):
                raise ValueError(f'{role}: genuine concurrent GPU physics not verified')
            for b in nm:
                name=b['map'];dest=P/'export'/role/name
                stage(state,'verifying_'+name)
                if not (dest/'export_receipt.json').is_file():
                    command([str(VENV),'-u',str(P/'export/export_prefixes.py'),'--map',name],cpu,R/(role+'_queue.log'))
                old=load(dest/'export_receipt.json')
                if old.get('stage')!='complete' or old.get('benchmark_only') or old['map_id']!=name or old['physical_lanes']!=1152 or old['config_sha256']!=b['source_sha256']:
                    raise ValueError(f'{name}: actual two-arm primary physical identity mismatch')
                command([str(VENV),'-u',str(R/'verify.py'),'--map',name],cpu,R/(role+'_queue.log'))
                verified=load(R/name/'identification.json')
                if verified['rows']!=1440 or verified['prefixes']!=288 or not (0<=verified['feasible_count_lower']<=verified['feasible_count_upper']<=288):raise ValueError(f'{name}: physical branch bounds census inconsistent')
                state['maps_completed'].append(dict(map=name,role=role,additional_physical_lanes=864,identified_rows=verified['matched_rows'],
                            identification=str(R/name/'identification.json'),parallelism=str(R/(role+'_pair')/'actual_parallelism.json')))
        stage(state,'complete',new_physical_lanes=3456,reused_original_candidates=2304,physical_candidates=5760,prefixes=1152,
              calibration_scope='Physical suffix acquisition and pairing only; no calibration model-performance evaluation.')
        message('第三章五出口物理核验完成','开发和校准四图物理轨迹已逐车核验，实际后缀、未识别区间和并行回执均已保存。','queue_complete_bark.json')
    except BaseException as ex:
        stage(state,'failed',failed_stage=state.get('stage'),error_type=type(ex).__name__,error=str(ex))
        message('第三章五出口队列异常',f"{state['failed_stage']}：{ex}。查看 {R/'queue_status.json'}",'queue_error_bark.json')
        raise
    wake()
def submit():
    if (R/'queue_receipt.json').exists():raise RuntimeError('A queue submission receipt already exists; inspect that invocation')
    before=systemd(DEV_UNIT);other=systemd(THIS_UNIT)
    if before.get('LoadState')!='loaded' or before['ActiveState']!='active' or int(before['MainPID'])<1 or not before['InvocationID']:
        raise RuntimeError(f'Wait for the concrete registered two-exit DEV unit: {before}')
    if other.get('LoadState')=='loaded':raise RuntimeError('A five-exit unit already exists')
    rec=dict(submitted_utc=clock(),unit=THIS_UNIT,upstream=DEV_UNIT,upstream_pid=int(before['MainPID']),upstream_invocation=before['InvocationID'],
        protocol=str(R/'protocol.json'),protocol_sha256=sha(R/'protocol.json'),cpu_validation_sha256=sha(R/'cpu_validation.json'),
        queue_source_sha256=sha(Path(__file__)),map_order=['dev_00','dev_01','calibration_00','calibration_01'],physical_steps_at_registration=0,
        no_model_calibration=True,shared_gpu_lock='Owned by run_pair.py only, once per map pair',registered_ledger_revision=3969)
    write(R/'queue_receipt.json',rec)
    cmd=['systemd-run','--user','--unit='+THIS_UNIT,'--description=Chapter 3 five-exit paired physics after formal two-exit DEV',
         '--property=Type=exec','--property=RemainAfterExit=yes','--property=OnFailure='+WAKE_UNIT,'--working-directory='+str(WORK),str(SYSTEM),'-u',str(Path(__file__).resolve()),'--execute']
    out=subprocess.run(cmd,cwd=WORK,capture_output=True,text=True)
    rec.update(systemd_returncode=out.returncode,systemd_output=(out.stdout+out.stderr).strip(),command=cmd,systemd=systemd(THIS_UNIT))
    write(R/'queue_receipt.json',rec);out.check_returncode();print(json.dumps(rec,indent=2,ensure_ascii=False))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--submit',action='store_true');g.add_argument('--execute',action='store_true');g.add_argument('--check',action='store_true')
    a=p.parse_args()
    if a.submit:submit()
    elif a.execute:run()
    else:
        conf=load(R/'protocol.json');ready=load(R/'cpu_validation.json')
        assert VENV.is_file() and len(conf['maps'])==4 and conf['actions_total']==5760 and all(sha(f)==h for f,h in ready['source_sha256'].items()) and hasattr(os,'pidfd_open')
        print(json.dumps({'mode':'CPU setup validation only','device_mask':physical_environment()['CUDA_VISIBLE_DEVICES'],'upstream':DEV_UNIT,'unit':THIS_UNIT,'wake_unit':WAKE_UNIT,'submitted_by_check':False,'registered_physical_lane_budget':3456}))

"""Run observation wrappers with two artificial CPU rows; no MuJoCo or physical step."""
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import numpy as np
import torch
import collect
import evaluate_playground_handoff as evaluator
from sttw_control.playground_adapters import JumpAdapter
from sttw_control.platform_online import PlatformDepartureQuery

P=Path(__file__).resolve().parent
def run():
    assert not torch.cuda.is_available()
    original_select=JumpAdapter.select
    from unittest.mock import patch
    returned=tuple(torch.tensor(v) for v in ([1,2],[True,True],[False,True]))
    def mock_choose(*args,**kwargs):return returned
    with TemporaryDirectory(dir=P) as td:
        tmp=Path(td)
        def stub_evaluator():
            tick=0;ids=torch.arange(2);alive=torch.tensor([True,True]);phase=torch.tensor([0,1])
            m=torch.arange(8.).reshape(2,4);z=torch.zeros(2,2)
            adapter=JumpAdapter(z.clone(),torch.ones(2),torch.ones(2)*-100,torch.ones(2)*100,False)
            v0=original_select(adapter,phase,m,m+10,z);v1=adapter.select(phase,m,m+10,z)
            torch.testing.assert_close(v0,v1,rtol=0,atol=0)
            # The full simulation calls these through its 200 Hz integration and query loop.
            for tick in range(1,5):adapter.select(phase,m,m+10,z)
            q=torch.arange(24.).reshape(2,12);v=torch.arange(22.).reshape(2,11);velocity=torch.arange(18.).reshape(2,9)
            velocity_history=[(q-2,v-2)]*4
            lock=far_time=upper_ready_time=stable_time=recovering=pulse_start=pulse_ticks=handoff_time=torch.zeros(2)
            target=v1;route=SimpleNamespace(route_ids=ids);middle=SimpleNamespace(policy=SimpleNamespace(test=torch.tensor([1,2])),projection={'progress':ids})
            ctl=SimpleNamespace(eso=ids); history=obs=last=rb_events=(m,)
            data=SimpleNamespace(qpos=q,qvel=v,ctrl=target,qacc_warmstart=v,qfrc_applied=v,time=ids,eq_active=alive,act=torch.empty(2,0))
            branch_ids=torch.arange(6).reshape(2,3)
            obj=PlatformDepartureQuery.__new__(PlatformDepartureQuery)
            result=obj.choose(q,ids.float(),ids.float(),route,branch_ids,ids.float()+12.7,torch.tensor([1.,1.]),torch.tensor([0,2]),6.,velocity,velocity-2)
            assert result is returned
            (tmp/'terrain.mjb').write_text('artificial observer test only')
        with patch.object(evaluator,'main',new=stub_evaluator),patch.object(PlatformDepartureQuery,'choose',new=mock_choose),patch.object(JumpAdapter,'select'):
            # Restore the actual target selector before the observer captures it.
            JumpAdapter.select=original_select
            collect.observed_run(dict(physical=td,config='unused',lanes=2,name='artificial'))
        with np.load(tmp/'p1_query/tick_0004.npz') as event:
            np.testing.assert_array_equal(event['lanes'],[0,1]);np.testing.assert_array_equal(event['incumbent_direction'],[0,2])
            np.testing.assert_array_equal(event['previous_qvel']+2,event['qvel']);np.testing.assert_array_equal(event['previous_qpos']+2,event['qpos'])
            np.testing.assert_array_equal(event['previous_velocity']+2,event['velocity']);np.testing.assert_array_equal(event['branch_ids'],np.arange(6).reshape(2,3))
            assert int(event['previous_tick'])==0 and len(event['physics_act'])==2
            fields=sorted(event.files)
        with np.load(tmp/'p1_applied_controls.npz') as z:
            assert z['valid'].all() and z['targets'].shape==(5,2,4)
            np.testing.assert_array_equal(z['targets'][0],np.array([[0,1,2,3],[14,15,16,17]],np.float32))
    receipt=dict(role='CPU synthetic field/identity test only',physical_steps=0,training_updates=0,controls_verified='Five artificial two-row selector returns unchanged and recorded.',query_inputs_verified=fields,actual_device_shadow_timing='Await first physical batch')
    (P/'observer_cpu_check.json').write_text(json.dumps(receipt,indent=2)+'\n')
if __name__=='__main__':run()

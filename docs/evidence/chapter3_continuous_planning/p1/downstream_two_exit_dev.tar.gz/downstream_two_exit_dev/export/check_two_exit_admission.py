"""Exercise the frozen rank/suffix rules on artificial cases and archived development tables."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from evaluate_two_exit_admission import audit_map,policy_rows,recall_bounds,OUT,rank_actions

def synthetic(parts=False):
    pp=[];ff=[];qq=[];scores=[]
    for slot in range(4):
        for method in ['constant_A','constant_B']:
            scores.append(dict(map_id='demo',root=11,action_slot=slot,section='near',target_side=1,method=method,seed='shared',score_any=.125))
        for force in [-5,0,5]:
            keys=dict(map_id='demo',root=11,action_slot=slot,force_n=force)
            verified=slot!=3;oq=slot!=3;cert=slot!=2;status='matched_observed_handoff' if cert and oq else ('matched_observed_prequery_endpoint' if cert else 'unmatched_observed_prefix_or_state')
            base=6*slot+(force+5)//5*2
            pp.append(dict(**keys,lane=base,right_lane=base+1,cross_suffix_certified=cert,suffix_pair_status=status))
            for i,arm in enumerate(['left','right']):
                success=bool((i==1 and verified) or (i==0 and slot==2 and force==5))
                ff.append(dict(**keys,arm=arm,lane=base+i,trajectory='artificial',suffix_pair_status=status,target_side=1,section='near',verified_relock=verified,observed_query=oq,physical_task_done=success,physical_target_effective=oq,physical_wall=not success and oq,termination='goal' if success else ('forbidden_obstacle_contact' if oq else 'tracking_domain_exit')))
            if oq:
                choice=1 if slot==1 else 2
                qq.append(dict(**keys,source_arm='left',section='near',target_side=1,observed_query=True,measured_choice=choice,feasible_left=False,feasible_straight=slot==1,feasible_right=slot!=1))
    ps,fs,qs,ss=map(pd.DataFrame,(pp,ff,qq,scores))
    if parts:return ps,fs,qs,ss
    wide=policy_rows(ps,fs,qs)
    n=wide[wide.policy=='native_three'].set_index(['action_slot','force_n'])
    assert n.loc[(0,0),'success_lo']==1 and n.loc[(0,0),'success_hi']==1
    assert n.loc[(1,0),'choice_evidence']=='straight_not_executed' and n.loc[(1,0),'success_lo']==0 and n.loc[(1,0),'success_hi']==1
    assert n.loc[(2,0),'set_lr_lo']==0 and n.loc[(2,0),'set_lr_hi']==1 and n.loc[(2,5),'set_lr_lo']==1
    assert n.loc[(3,0),'domain_lo']==1 and n.loc[(3,0),'set_all_hi']==0
    rr=wide[wide.policy=='restricted_two'].set_index(['action_slot','force_n'])
    assert rr.loc[(1,0),'chosen_direction']==0 and rr.loc[(1,0),'fallback_after_query'] and rr.loc[(1,0),'success_hi']==0
    out,c,d=audit_map(ss,wide,formal=False)
    fix=c[c.groups_admitted==1]
    assert all(fix.cutoff_ties==4) and all(fix.ties_admitted==1) and all(fix.admitted==3) and all(fix.total==12)
    assert all(d.success_delta_n_lo==0) and all(d.success_delta_n_hi==0)
    assert all(out.groupby(['root','action_slot','method','seed','policy']).admitted.nunique()==1)
    for method,ga in ss.groupby('method'):
        normal=rank_actions(ga,'score_any');shuffled=rank_actions(ga.sample(frac=1,random_state=5),'score_any')
        assert normal.action_slot.tolist()==shuffled.action_slot.tolist()
    empty=ss[ss.method=='constant_A'].assign(p_relock=.5,particles=1).copy()
    empty.loc[empty.action_slot.isin([0,1]),['score_any','particles']]=[np.nan,0]
    ordered=rank_actions(empty,'score_any')
    assert ordered.score_undefined.tolist()==[False,False,True,True] and ordered._rank_value.tolist()==[.125,.125,-1.,-1.]
    assert recall_bounds(0,1,0,0)==(1.,1.) and recall_bounds(0,0,0,1)==(0.,0.) and recall_bounds(0,0,0,0)==(None,None)
    return {'role':'artificial 4-action x 3-push fixture','opportunities':4,'draws':12,'cutoff_equal_scores':4,'top_count':1,'tied_methods_identical_bounds':True,'negative_cases':'unexecuted straight, uncertified right, prequery termination and forced two-exit fallback all checked'}

def native_archive():
    base=OUT.parent/'model/downstream_smoke';m=pd.read_csv(base/'measured_exit_queries.csv');p=pd.read_csv(base/'prefix_gate_predictions.csv');f=pd.read_csv(base/'physical_suffix_labels.csv')
    keys=['map_id','root','action_slot','force_n','target_side','section']; assert not m.duplicated(keys).any()
    observed=m[m.observed_query==True].copy()
    assert observed.source_arm.eq('near_left').all() and observed.cpu_choice_equal.all() and observed.cpu_admission_equal.all()
    t=observed.merge(f,on=keys,validate='one_to_many')
    chosen=t[t.actual_exit==t.measured_choice]
    assert len(chosen)==len(observed) and p.score_any.between(0,1).all() and p.score_lr.le(p.score_any).all()
    return {'role':'existing P0-B DEV synthetic-model wiring audit, no formal P1 data','physical_prefixes_with_observed_query':len(observed),'native_choices_matching_old_archive':int(observed.cpu_choice_equal.sum()),'observed_chosen_left_or_right':int(chosen.actual_exit.isin([0,2]).sum()),'actual_straight_labels_withheld_on_P1_like_two_exit_panel':int((chosen.actual_exit==1).sum()),'sources':{str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in (base/'prefix_gate_predictions.csv',base/'measured_exit_queries.csv',base/'physical_suffix_labels.csv')}}

def full_shape_cli():
    import tempfile
    import shutil
    import sys
    from unittest.mock import patch
    import evaluate_two_exit_admission as evaluation
    part=synthetic(parts=True)
    with tempfile.TemporaryDirectory(dir=OUT) as tmp:
        root=Path(tmp);ex=root/'export';dest=root/'result';ex.mkdir();(root/'model').mkdir()
        shutil.copyfile(OUT/'two_exit_admission_protocol.json',ex/'two_exit_admission_protocol.json')
        shutil.copyfile(OUT.parent/'model/fit_preregistration.json',root/'model/fit_preregistration.json')
        pp=[];mm=[]
        for mapnum,name in enumerate(('dev_00','dev_01')):
            data=[[],[],[],[]]
            for root_i in range(12):
                for a in range(4):
                    for j,x in enumerate(part):
                        y=x.copy();y['map_id']=name;y['root']=100+mapnum*12+root_i;y['action_slot']+=4*a
                        for k in ['lane','right_lane']:
                            if k in y:y[k]+=(4*root_i+a)*24
                        data[j].append(y)
            ps,fs,qs,ss=[pd.concat(g,ignore_index=True) for g in data]
            prefix=ex/'dev'/name;prefix.mkdir(parents=True)
            (prefix/'export_receipt.json').write_text(json.dumps(dict(stage='complete',benchmark_only=False,role='dev',map_id=name)))
            for table,f in [(ps,'prefix_index.csv'),(fs,'suffix_index.csv')]:table.rename(columns={'force_n':'hidden_force_N_grouping_only'}).to_csv(prefix/f,index=False)
            base_scores=ss[ss.method=='constant_A'].copy()
            expanded=[base_scores.assign(method=method,seed=str(seed)) for method in ('mean','mixture3') for seed in (61123,61124,61125)]
            expanded.extend(base_scores.assign(method=method,seed='shared') for method in ('empirical_action','five_separate_roots'))
            pp.append(pd.concat(expanded,ignore_index=True));mm.append(qs)
        pd.concat(pp).to_csv(root/'pred.csv',index=False);pd.concat(mm).to_csv(root/'m.csv',index=False)
        with patch.object(evaluation,'OUT',ex),patch.object(sys,'argv',['audit','--predictions',str(root/'pred.csv'),'--measured',str(root/'m.csv'),'--output',str(dest)]): evaluation.main()
        d=pd.read_csv(dest/'primary_25_pooled.csv')
        assert d.total.eq(1152).all() and d.admitted.eq(288).all()
        b=pd.read_csv(dest/'paired_method_bounds_pooled.csv')
        assert b.policy_failure_delta_n_lo.eq(0).all() and b.policy_failure_delta_n_hi.eq(0).all()
        for name in ('native_three','restricted_two'):
            q=pd.read_csv(dest/f'primary_25_{name}.csv');assert q.policy.eq(name).all() and q.groups_admitted.eq(48).all() and q.cutoff_ties.eq(192).all()
        assert pd.read_csv(dest/'primary_25_by_root_gate_force.csv').shape[0]>0
    return dict(role='temporary synthetic development-sized fixture; all temporary data removed',maps=2,root_action_groups_per_map=192,draws_per_map=576,accepted_draws_per_map=144,combined_accepted=288,csv_outputs_valid=True)

if __name__=='__main__':
    summary={'synthetic':synthetic(),'old_dev':native_archive(),'full_cli_synthetic':full_shape_cli(),'new_P1_outcomes_examined':0,'physics_steps':0}
    (OUT/'two_exit_admission_validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary)

"""P1 fixed-coverage physical suffix audit for the two held-out development maps."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
KEY=['map_id','root','action_slot']
GATE=['section','target_side']
DRAW=[*KEY,'force_n']
OFFSETS={0:'left',1:'straight',2:'right'}
NAMES={'success':'physical_task_done','wall':'physical_wall','domain':'termination'}
POLICIES=('native_three','restricted_two')
MEAS=['measured_choice','feasible_left','feasible_straight','feasible_right']
BINARY=('success','wall','domain','set_lr','set_all')

def yes(value):
    if not (value is True or value is False or value in (True,False,'True','False','true','false',1,0)):raise ValueError(f'Missing or invalid boolean: {value!r}')
    return value in (True,'True','true',1)

def measured_label(row,k):
    return int(row['termination']=='tracking_domain_exit') if k=='domain' else int(yes(row[NAMES[k]]))

def rank_actions(actions,score):
    if actions.duplicated(KEY).any():raise ValueError('Duplicate planning opportunities')
    df=actions.copy();v=df[score].astype(float);missing=v.isna()
    if not v[~missing].between(0,1).all():raise ValueError('A finite probability score must be between zero and one')
    if missing.any() and (not {'p_relock','particles'}.issubset(df) or not ((df.loc[missing,'p_relock']>0)&df.loc[missing,'particles'].eq(0)).all()):raise ValueError('Undefined scores must document a missing conditional particle distribution')
    df['score_undefined']=missing
    df['_rank_value']=v.fillna(-1.)
    tie=lambda x:hashlib.sha256(f'P1-fixed-25-v1|{x.map_id}|{int(x.root)}|{int(x.action_slot)}'.encode()).hexdigest()
    df['tie_key']=[tie(row) for row in df.itertuples()]
    df=df.sort_values(['_rank_value','tie_key','root','action_slot'],ascending=[False,True,True,True]).reset_index(drop=True)
    df['rank']=np.arange(1,len(df)+1)
    return df

def policy_rows(prefix,suffix,measured):
    # Both maps' physical replicas share keys; the left draw anchors all counterfactuals.
    if prefix.duplicated(DRAW).any() or suffix.duplicated([*DRAW,'arm']).any():raise ValueError('Nonunique physical keys')
    sa={(*key,arm):r for (*key,arm),r in suffix.set_index([*DRAW,'arm'],drop=False).iterrows()}
    ms=measured.set_index(DRAW,verify_integrity=True).to_dict('index')
    rows=[]
    for _,pr in prefix.iterrows():
        key=tuple(pr[k] for k in DRAW);l,r=(sa[(*key,arm)] for arm in ('left','right'))
        if l.lane!=pr.lane or r.lane!=pr.right_lane or l.suffix_pair_status!=pr.suffix_pair_status or r.suffix_pair_status!=pr.suffix_pair_status:raise ValueError('Exported physical row identity mismatch')
        oq= yes(l.observed_query); verified=yes(l.verified_relock); cert=yes(pr.cross_suffix_certified)
        if not all(l[k]==r[k] for k in GATE):raise ValueError('Physical arms have different task gates')
        if cert and (yes(r.verified_relock)!=verified or yes(r.observed_query)!=oq):raise ValueError('Certified prefix disagrees on measured query or relock')
        if cert and not oq and any(measured_label(l,k)!=measured_label(r,k) for k in NAMES):raise ValueError('Same certified prequery endpoint gave different physical labels')
        sl=measured_label(l,'success');sr=measured_label(r,'success') if cert else None
        if sl and not verified:raise ValueError('Success requires verified relock')
        lrlo=int(sl or bool(sr));lrhi=int(lrlo or (oq and verified and sr is None));allhi=int(lrlo or (oq and verified))
        m=ms.get(key)
        if m is not None:
            if m['source_arm']!='left' or yes(m['observed_query'])!=oq:raise ValueError('Postevent selection must use the measured preassigned left anchor')
            if any(l[k]!=m[k] for k in GATE):raise ValueError('Measured-query contract differs from physical contract')
        usable=oq and m is not None and all(pd.notna(m[k]) for k in MEAS)
        if usable:
            votes=np.array([yes(m[k]) for k in MEAS[1:]]);choice=int(m['measured_choice'])
            if choice not in (0,1,2) or (not votes.any() and choice!=1) or (votes.any() and not votes[choice]) or (votes[1] and choice!=1):raise ValueError('Measured native choice violates its frozen straight-incumbent contract')
        for pol in POLICIES:
            fallback=False;chosen=None;src=None
            if not oq:reason='no_query_real_terminal';src=l
            elif not usable:reason='missing_measured_choice'
            else:
                if pol=='native_three':
                    chosen=choice;fallback=not bool(votes.any())
                else:
                    left,right=bool(votes[0]),bool(votes[2]);fallback=not(left or right)
                    chosen=(0 if left else 2) if left!=right else (0 if l.target_side==1 else 2)
                if chosen==0:reason='left_primary';src=l
                elif chosen==2 and cert:reason='certified_right';src=r
                elif chosen==1:reason='straight_not_executed'
                else:reason='right_prefix_uncertified'
            row={k:pr[k] for k in DRAW};row.update({k:l[k] for k in GATE})
            row.update(policy=pol,observed_query=oq,verified_relock=verified,cross_suffix_certified=cert,
                chosen_direction=chosen,fallback_after_query=fallback,choice_evidence=reason,left_success=sl,right_same_prefix_success=sr,
                left_trajectory=l.trajectory,right_trajectory=r.trajectory,known_chosen_trajectory='' if src is None else src.trajectory,
                known_chosen_target_effective=None if src is None else yes(src.physical_target_effective),
                known_chosen_termination='' if src is None else src.termination)
            for k in NAMES:
                lo,hi=(0,1) if src is None else (measured_label(src,k),)*2
                if k=='success' and not verified:lo=hi=0
                row[k+'_lo']=lo;row[k+'_hi']=hi
            row.update(set_lr_lo=lrlo,set_lr_hi=lrhi,set_all_lo=lrlo,set_all_hi=allhi)
            rows.append(row)
    if set(ms)-{tuple(x) for x in prefix[DRAW].itertuples(index=False,name=None)}:raise ValueError('Measured replay includes unknown physical prefixes')
    return pd.DataFrame(rows)

def recall_bounds(a,A,r,R):
    # Conditional on at least one feasible physical case existing in the panel.
    if not A+R:return (None,None)
    return ((a/(a+R) if a+R else 1.),(A/(A+r) if A+r else 0.))

def count_row(rank,num,cut,whole,inside):
    # whole/inside are cumulative sums; no missing physical opportunity is dropped.
    n=int(inside['n']);o=dict(groups_admitted=cut,groups_total=num,admitted=n,total=int(whole['n']),
        score_min=rank._score.min(),score_max=rank._score.max(),cutoff_score=None,cutoff_ties=None,ties_admitted=None,
        groups_strictly_above_cutoff=None,groups_at_or_above_cutoff=None,undefined_groups=int(rank.score_undefined.sum()),undefined_admitted_groups=int(rank.score_undefined.iloc[:cut].sum()))
    if cut:
        sc=rank._rank_value.iloc[cut-1];above=int((rank._rank_value>sc).sum());ties=int((rank._rank_value==sc).sum())
        o.update(cutoff_score=None if sc<0 else sc,cutoff_ties=ties,ties_admitted=cut-above,groups_strictly_above_cutoff=above,groups_at_or_above_cutoff=above+ties)
    for k in BINARY:
        lo,hi=(int(inside[k+'_'+b]) for b in ('lo','hi'))
        o[k+'_n_lo']=lo;o[k+'_n_hi']=hi
        if k.startswith('set'):
            r,R=int(whole[k+'_lo'])-lo,int(whole[k+'_hi'])-hi
            o[k+'_recall_lo'],o[k+'_recall_hi']=recall_bounds(lo,hi,r,R)
        if k in ('success','set_lr','set_all'):
            short={'success':'policy_failure','set_lr':'no_two_exit','set_all':'no_full_family_exit'}[k]
            o[short+'_n_lo']=n-hi;o[short+'_n_hi']=n-lo
            o[short+'_risk_lo']=(n-hi)/n if n else None
            o[short+'_risk_hi']=(n-lo)/n if n else None
    for k in ('set_lr','set_all'):
        # Number of admitted successful physical decisions / all physically feasible prefixes.
        # Numerator and denominator may be partly unidentified; these ratio bounds are conservative.
        feasible_lo,feasible_hi=int(whole[k+'_lo']),int(whole[k+'_hi'])
        ok_lo,ok_hi=int(inside['success_lo']),int(inside['success_hi'])
        if k=='set_lr' and ((rank.attrs.get('policy') or '')!='restricted_two'):
            continue  # A successful original straight exit does not imply left/right feasibility.
        o[k+'_successful_releases_per_feasible_lo']=ok_lo/feasible_hi if feasible_hi else None
        o[k+'_successful_releases_per_feasible_hi']=(ok_hi/max(feasible_lo,ok_hi) if max(feasible_lo,ok_hi) else 0.) if feasible_hi else None
    for k in ['query','relock','certified','default','no_query','missing_choice','straight_unexecuted','uncertified_right']:
        o[k+'_n']=int(inside[k])
    return o

def audit_map(ranks,wide,formal=True):
    all_op=wide[KEY+GATE].drop_duplicates()
    if all_op.duplicated(KEY).any():raise ValueError('Push-dependent physical contract')
    if formal and (len(all_op)!=192 or all_op.root.nunique()!=12 or not all_op.groupby('root').size().eq(16).all()):raise ValueError('Incomplete formal map')
    ranks=ranks.merge(all_op,on=KEY+GATE,how='inner',validate='many_to_one')
    if ranks['seed'].isna().any():raise ValueError('Use shared seed name for a deterministic baseline')
    counts=[];saved=[];comparisons=[]
    for (m,seed),pred in ranks.groupby(['method','seed'],sort=True):
        if set(map(tuple,pred[KEY].values))!=set(map(tuple,all_op[KEY].values)):raise ValueError('Incomplete model score panel')
        for sn in ('score_any','score_lr'):
            if sn not in pred:continue
            ranks1=rank_actions(pred,sn).rename(columns={sn:'_score'})
            nt=len(ranks1);assert nt%4==0;k25=nt//4
            for pol in POLICIES if sn=='score_any' else ('restricted_two',):
                obs=wide[wide.policy==pol].merge(ranks1[KEY+['rank','_score','tie_key','score_undefined']],on=KEY,validate='many_to_one').sort_values(['rank','force_n']).reset_index(drop=True)
                if len(obs)!=nt*3 or any(set(x)!= {-5,0,5} for _,x in obs.groupby('rank').force_n):raise ValueError('Every action needs three distinct pushes')
                obs['admitted']=obs['rank']<=k25
                ids=dict(map_id=obs.map_id.iloc[0],method=m,seed=seed,score_type=sn,policy=pol)
                saved.append(obs.assign(method=m,seed=seed,score_type=sn))
                table=obs[[k+'_'+d for k in BINARY for d in ('lo','hi')]].copy()
                table['rank']=obs['rank'];table['n']=1;table['query']=obs.observed_query;table['relock']=obs.verified_relock
                table['certified']=obs.cross_suffix_certified;table['default']=obs.fallback_after_query
                for dst,reason in [('no_query','no_query_real_terminal'),('missing_choice','missing_measured_choice'),('straight_unexecuted','straight_not_executed'),('uncertified_right','right_prefix_uncertified')]:
                    table[dst]=obs.choice_evidence.eq(reason)
                ranks1.attrs['policy']=pol
                sum_by=table.groupby('rank',sort=True).sum().cumsum()
                zero=sum_by.iloc[0]*0
                for k in range(nt+1):
                    counts.append(dict(**ids,**count_row(ranks1,nt,k,sum_by.iloc[-1],sum_by.iloc[k-1] if k else zero)))
    if not saved:raise ValueError('Empty method panel')
    saved=pd.concat(saved,ignore_index=True);counts=pd.DataFrame(counts)
    for (sn,pol),z in saved.groupby(['score_type','policy']):
        models={k:h.set_index(DRAW,verify_integrity=True).sort_index() for k,h in z.groupby(['method','seed'])}
        for (ka,a),(kb,b) in itertools.combinations(models.items(),2):
            if not a.index.equals(b.index):raise ValueError('Method-pair populations differ')
            w=a.admitted.astype(int)-b.admitted.astype(int)
            rec=dict(map_id=z.map_id.iloc[0],score_type=sn,policy=pol,method_a=ka[0],seed_a=ka[1],method_b=kb[0],seed_b=kb[1],per_method_admitted=int(a.admitted.sum()),both_admit=int((a.admitted&b.admitted).sum()),only_a=int((w==1).sum()),only_b=int((w==-1).sum()))
            for k in ('success','wall','domain','set_lr','set_all'):
                lo=a[k+'_lo'];hi=a[k+'_hi']
                mn=int(lo[w==1].sum()-hi[w==-1].sum());mx=int(hi[w==1].sum()-lo[w==-1].sum())
                rec[k+'_delta_n_lo']=mn;rec[k+'_delta_n_hi']=mx
                if k=='success':rec['policy_failure_delta_n_lo']=-mx;rec['policy_failure_delta_n_hi']=-mn
            comparisons.append(rec)
    return saved,counts,pd.DataFrame(comparisons)

def read_physical(folder):
    pr=pd.read_csv(folder/'prefix_index.csv').rename(columns={'hidden_force_N_grouping_only':'force_n'})
    sf=pd.read_csv(folder/'suffix_index.csv').rename(columns={'hidden_force_N_grouping_only':'force_n'})
    return pr,sf

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--predictions',type=Path,required=True)
    ap.add_argument('--measured',type=Path,required=True)
    ap.add_argument('--map',choices=['dev_00','dev_01'],action='append')
    ap.add_argument('--output',type=Path,required=True)
    arg=ap.parse_args();maps=arg.map or ['dev_00','dev_01']
    p=pd.read_csv(arg.predictions,dtype={'seed':'str'});m=pd.read_csv(arg.measured)
    if len(set(maps))!=len(maps):ap.error('Map names must be unique')
    if not set(KEY+GATE+['method','seed','score_any']).issubset(p):raise ValueError('Required predictions schema missing')
    p['seed']=p['seed'].fillna('shared').str.replace(r'\.0$','',regex=True)
    expected_seeds={str(x) for x in json.loads((OUT.parent/'model/fit_preregistration.json').read_text())['shared_neural']['seeds']}
    if not set(DRAW+GATE+MEAS+['source_arm','observed_query']).issubset(m):raise ValueError('Required measured-query schema missing')
    out=arg.output;out.mkdir(exist_ok=True,parents=True)
    f=[];s=[];c=[];physical=[];msets=[];source_exports=[]
    for name in maps:
        base=OUT/'dev'/name;rc=json.loads((base/'export_receipt.json').read_text())
        if rc['stage']!='complete' or rc['benchmark_only'] or rc['role']!='dev' or rc['map_id']!=name:raise ValueError('Unexpected role or physical export stage')
        pr,suf=read_physical(base)
        source_exports.extend([base/'prefix_index.csv',base/'suffix_index.csv',base/'export_receipt.json'])
        scope=suf[suf.arm=='left'][DRAW+GATE]
        # A predictor may score every goal; only the one allocated before the push belongs to this trial.
        preds=p[p.map_id==name];actual=m[m.map_id==name].merge(scope,on=DRAW+GATE,how='inner',validate='many_to_one')
        groups=set(map(tuple,preds[['method','seed']].drop_duplicates().values))
        if {k for k,_ in groups}!={'mean','mixture3','empirical_action','five_separate_roots'} or any({seed for k,seed in groups if k==method}!=expected_seeds for method in ('mean','mixture3')):raise ValueError('Formal fitted family or prespecified neural seeds incomplete')
        if msets and groups!=msets[0]:raise ValueError('Methods/seeds incomplete across development maps')
        msets.append(groups)
        wide=policy_rows(pr,suf,actual);physical.append(wide)
        ss,ff,cc=audit_map(preds,wide);s.append(ss);f.append(ff);c.append(cc)
    f=pd.concat(f,ignore_index=True);s=pd.concat(s,ignore_index=True)
    f.to_csv(out/'coverage_sweep.csv',index=False)
    f[f.groups_admitted*4==f.groups_total].to_csv(out/'primary_25_by_map.csv',index=False)
    fixed=f[f.groups_admitted*4==f.groups_total].copy()
    for policy in POLICIES:fixed[fixed.policy==policy].to_csv(out/f'primary_25_{policy}.csv',index=False)
    c=pd.concat(c,ignore_index=True);c.to_csv(out/'paired_method_bounds.csv',index=False)
    paired_keys=['score_type','policy','method_a','seed_a','method_b','seed_b']
    if len(c):c.drop(columns='map_id').groupby(paired_keys,as_index=False).sum().to_csv(out/'paired_method_bounds_pooled.csv',index=False)
    s.to_csv(out/'all_scored_physical_draws.csv.gz',index=False)
    pd.concat(physical,ignore_index=True).to_csv(out/'physical_policy_outcomes.csv',index=False)
    pooled=[];strata=[]
    group=['method','seed','score_type','policy']
    for key,z in s.groupby(group,sort=True):
        meta=dict(zip(group,key))
        for fields,bucket in [((),pooled),(('map_id','root'),strata),(('map_id','target_side','section'),strata),(('map_id','force_n'),strata)]:
            for sk,ss in (z.groupby(list(fields)) if fields else [((),z)]):
                sk=sk if isinstance(sk,tuple) else (sk,)
                zz=ss[ss.admitted];n=len(zz);entry=dict(**meta,**dict(zip(fields,sk)),stratum='+'.join(fields) if fields else 'pooled',total=len(ss),admitted=n,admission_rate=n/len(ss))
                for label in BINARY:
                    lo,hi=int(zz[label+'_lo'].sum()),int(zz[label+'_hi'].sum())
                    entry[label+'_n_lo']=lo;entry[label+'_n_hi']=hi
                    entry[label+'_rate_lo']=lo/n if n else None;entry[label+'_rate_hi']=hi/n if n else None
                    if label in ('success','set_lr','set_all'):
                        prefix={'success':'policy_failure','set_lr':'no_two_exit','set_all':'no_full_family_exit'}[label]
                        entry[prefix+'_n_lo']=n-hi;entry[prefix+'_n_hi']=n-lo
                        entry[prefix+'_risk_lo']=(n-hi)/n if n else None;entry[prefix+'_risk_hi']=(n-lo)/n if n else None
                    if label.startswith('set'):
                        rlo=int(ss[label+'_lo'].sum())-lo;rhi=int(ss[label+'_hi'].sum())-hi
                        entry[label+'_recall_lo'],entry[label+'_recall_hi']=recall_bounds(lo,hi,rlo,rhi)
                        if label=='set_all' or meta['policy']=='restricted_two':
                            endl=int(ss[label+'_lo'].sum());endh=int(ss[label+'_hi'].sum())
                            sl=int(zz.success_lo.sum());sh=int(zz.success_hi.sum())
                            entry[label+'_successful_releases_per_feasible_lo']=sl/endh if endh else None
                            entry[label+'_successful_releases_per_feasible_hi']=(sh/max(endl,sh) if max(endl,sh) else 0.) if endh else None
                bucket.append(entry)
    pd.DataFrame(pooled).to_csv(out/'primary_25_pooled.csv',index=False)
    pd.DataFrame(strata).to_csv(out/'primary_25_by_root_gate_force.csv',index=False)
    sources=[arg.predictions,arg.measured,OUT/'two_exit_admission_protocol.json',OUT.parent/'model/fit_preregistration.json',*source_exports]
    summary={'maps':maps,'formal_role':'DEV only','prototype_fixtures':False,'map_root_action_opportunities':sum(v.groups_total.iloc[0] for _,v in f.groupby('map_id')),'files':{str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in sources},'estimand':'25% rank, three push outcomes per action. Two-exit diagnostic and native policy are separate. Bounds are identification intervals conditional on the finite panel.'}
    (out/'receipt.json').write_text(json.dumps(summary,indent=2,default=int)+'\n')
if __name__=='__main__':main()

# P1 开发图正式评分入口

正式入口只加载 train_00…05 的支持样本、已登记的两张开发图和 61123/61124/61125 三组固定末次权重。六个网络、两个经验方法各保留自己的成绩。三推共享的 t0、候选曲线、α 和指定门只推理一次；事后推力、复锁状态、物理出口和终止标签都不进入这一步。推理输入从 observed_inputs.npz 明确取出；查询和真实后缀在评分完成后读取。

单峰每个动作只用一个中心点。三峰及两个经验方法各取 16 个完整状态。根、图、动作与方法使用预先生成的相同逆 CDF 分层分位数和高斯残差阵列；经验法使用相同分位数在真实条件结果的累计质量上抽样。共同随机数独立于地图、起点和推力，不把任何 ID 作为特征或随机数种子。粒子上的可行性并集与复锁率相乘产生 score_any，左右两侧的联合并集产生 score_lr。经验法若预测有复锁概率但没有可用状态，其分数保留缺失，整组仍进入排名分母。

**预算。** 两图共 384 次不同的起跳前候选动作决策，八个方法与种子组合共 3,072 个分数，最多 31,872 个预测接手状态。每个预测状态只有三条不同的方向轨迹。原选择器会分别令左、直、右为当前出口测试是否保留，直接调用会展开 9 条动力学轨迹。新接口在三个当前出口设定中复用每个方向的完整位置和速度序列，原有包络、碰墙检查、评分和选择仍作用在全部 9 行上。正式上限为 95,616 条完整逐步动力学推演和 286,848 个准入决策行。实测双臂的档案对照保留完整九行路径，另外最多 2,304 个实测状态、20,736 条动力学推演。另计可选计时预算。[预算协议](downstream_preregistration.json)

**实际复锁状态。** 首次查询按档案中真实 three branch_ids、qpos、当前/前 20 ms 速度、余时和请求速度运行冻结原评估器。各物理副本都先按原 incumbent 比较 shadow 原始 choice、any_admitted、incumbent_admitted；另以同一左主前缀、直行为当前选择复算决策。直行准入则沿用，否则按原规则选择准入的出口，全否决时执行直行兜底。左右副本的真实物理出口预先指定。GPU/CPU 数值导致的回放不一致若发生，以 observed_both 为分母逐项保存。预测粒子只知道姿态和已知入口，使用几何投影近似未来未知的跟踪器历史进度。两出口物理评分由原统计器回读，未执行的直行标签为未知。

**正式命令。** 等六次已登记拟合全部完成、两个 DEV 导出齐全并获得共用 GPU 作业槽后，从本目录执行。正式命令本轮未运行。

```sh
export PYTHONPATH=/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src
PY=/home/qy/mujoco_playground/.venv/bin/python
"$PY" run_downstream_dev.py --registered --device cuda --benchmark
"$PY" ../export/evaluate_two_exit_admission.py \
    --predictions formal_downstream/prefix_gate_predictions.csv \
    --measured formal_downstream/measured_exit_queries.csv \
    --output formal_downstream/physical_evaluation
```

新 GPU 运行会推进完整神经计算和原地面模型。经验近邻仍使用 CPU。批量器每组最多 24 个接手状态。single_robot_timing.csv 以同一辆车、一道预先指定近左门计算单候选和全 16 候选，两类任务各给 4 方法一次预热、5 次实测。计时从已准备好的当前特征/候选到分数可用，包含生成轨迹和选支，排除传感、采样资产初始化和实际执行器下发。既有三出口 15 ms 首次发布和连续出口 100 ms 重算限时分别列超时，P1 离线评分保留所有案例。多机器人/多候选吞吐与单车耗时分别记录。

**工程验收。** CPU 使用 train_00 首根 1250 的两个预定动作及三推，监督模型仍只拟合旧 DEV 72 行。166 个预测状态中，原 9 动力学分支与复用 3 方向后的选支 166/166、各方向准入 498/498 相同。两个物理出口各 6 个实测查询，原生选支/准入/当前出口准入及姿态估计拼接点分别 12/12 一致。5/6 主前缀全否决后应走直行，原始 shadow 中被打分最高的方向不能冒充已执行的直行。共享统计器完整识别 5 次直行标签未知、1 次可识别右出口。单候选、单次 CPU 首根近左门调用耗时 135 ms（中心点）、1,457 ms（三峰）、1,303 ms（经验频率）、1,301 ms（五近邻），四者均超过 15 ms 和 100 ms。这些是有限 CPU 观察，未得到 GPU 或全 16 候选的时延分布。复现实测使用上面的解释器运行 `run_downstream_dev.py --check-train00 --device cpu`。[验收记录](train00_downstream_check/receipt.json) · [逐粒子等价](train00_downstream_check/reused_direction_parity.json) · [单次计时](train00_downstream_check/single_robot_timing.csv) · [统计回读](train00_downstream_check/two_policy_readback.csv)

## 五出口实测集合的最终开发验收

两张开发图的五出口 verify 完成后，从本目录运行 `/home/qy/mujoco_playground/.venv/bin/python compare_five_exit_evidence.py`。比较器读取同一次跳前预测保存的 score_any、已复算的原生三出口名义选择，以及各图的 physical_outcomes.csv 和 five_feasibility_bounds.csv。每图仅取预先指定的 6 个根和 96 个动作，沿用固定哈希破平局，各方法独立放行前 24 个动作及对应 72 个隐藏推力前缀。五种物理策略为原左、直、右出口和预定近左、近右两个 CEM 后缀。此分析衡量跳前排序对这些实测机会的辨识能力，没有改动模型得分或新增在线决策。

输出目录为 `formal_downstream/five_exit_comparison/`。by_map.csv 在同一排名、同一推力和同一套物理前缀认证下分别列出左/右两出口及五出口集合。每个前缀若确定至少一条成功，记 [1,1]；五条均确定失败才记 [0,0]；其余保留 [0,1]。错放率上下界分别是（放行数−可能可行数）/放行数和（放行数−确定可行数）/放行数。设被放行的可行数介于 a 与 A，未放行者介于 r 与 R，则可行检出率介于 a/(a+R) 与 A/(A+r)；仅有放行者可能可行时为 1，仅有未放行者可能可行时为 0，全体均确定不可行时留空。未知病例间存在额外依赖时，区间可以偏宽。两出口初次核验与扩展核验的原始认证差异另列。

碰墙按真实复锁后的冻结三出口策略选择独立报告。只有该方向的物理前缀经过认证、该路线实际下发且下发后至少发生一个物理时间步，才计入已观察的选支碰墙分母。没有产生选择的终止、前缀不匹配或无执行时间分别标注，未选方向的碰墙不计。对确认错放还给出“已确认选支碰墙数/能识别选支碰墙的确认错放数”；在已观察的碰墙中，因集合标签未知形成的错放碰墙上下界另列。

paired_rescues_losses.csv 逐一比较同图两种排名。A 独有放行集合中可行的数量为 A 相对 B 新检出的机会，B 独有放行集合中可行的数量为 A 丢失的机会，共同放行/拒绝相互抵消。两物理集合及名义选支实际成功的上下界分别列出。ranked_prefix_evidence.csv 可逐根、推力和门回查选择、平局、终止及选中轨迹。只做过无物理数据的合成核验；用 `python check_five_exit_comparison.py` 可复现。[合成核验记录](five_exit_comparison_fixture.json)

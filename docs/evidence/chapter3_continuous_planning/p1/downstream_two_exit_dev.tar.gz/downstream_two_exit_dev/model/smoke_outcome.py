"""Small old-DEV smoke, unit checks and one genuine frozen downstream model step on CPU."""
import argparse
import io
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from jump_outcome import (Dataset,DIM,JumpOutcome,MODE_NAMES,decode_target,
                          empirical_particles,empirical_forecast,evaluate,exit_initializer,fit_model)


def grouping_old_dev(ds):
    ix=ds.index
    selected=((ix.geometry.eq(0)|ix.geometry.eq(2))&ix.alpha.eq(0)) | (ix.geometry.eq(1)&ix.alpha.isin([0,.5]))
    support=np.flatnonzero(selected & ix.layout.eq('right_offset') & ix.root.between(1171,1176))
    held=np.flatnonzero(selected & ix.layout.eq('staggered') & ix.root.between(1183,1184))
    if len(support)!=72 or len(held)!=24: raise ValueError('Smoke requires the specified old P0-B DEV archive')
    assert set(ix.iloc[support].root).isdisjoint(ix.iloc[held].root)
    return support,held


@torch.no_grad()
def test_joint_and_failures(x,q0):
    net=JumpOutcome(x.shape[1],'mixture3')
    # Make three separated modes. Their position and the two velocity histories carry the same code.
    for p in net.parameters():p.zero_()
    bias=net.joint_head.bias.view(3,-1)
    bias[:,1:1+DIM]=torch.tensor([-9.,0.,9.])[:,None]
    bias[:,1+DIM:]=-30.
    particle=net.forecast(x[:1],q0[:1],draws=512,seed=1901,conditional=True)
    code=(particle['query_qpos_native'][...,0]-q0[0,0])/9.
    cur=particle['query_velocity_state9'][...,0]/9.; prev=particle['previous_velocity_state9'][...,0]/9.
    assert torch.all(code.round()==cur.round()) and torch.all(code.round()==prev.round())
    assert torch.unique(code.round()).numel()==3
    net.relock_head.bias.fill_(-100.)
    pf=net.forecast(x[:1],q0[:1],draws=16)
    assert not pf['is_relocked'].any() and pf['query_qpos_native'].isnan().all() and pf['previous_velocity_state9'].isnan().all()
    loss,_,cond=net.losses(x[:1],torch.tensor([False]),torch.full((1,DIM),float('nan')))
    assert float(cond)==0. and loss.isfinite()
    yes=torch.tensor([True])
    _,pos,cond=net.losses(x[:1],yes,torch.full((1,DIM),float('nan')))
    assert float(pos)>90. and float(cond)==0.
    return {'relock_without_observed_query_preserved':True,'joint_component_consistent_draws':512,'failed_particles_with_missing_state':16,'failed_only_batch_conditional_sum':0.}


@torch.no_grad()
def downstream_test(held,net,source):
    from sttw_control.playground_history_model import load_history_model
    from sttw_control.playground_terrain_features import TerrainFeatures
    sample=net.forecast(held.x[:2],held.q0[:2],draws=8,seed=813,conditional=True)
    p=Path(held.index.iloc[0].physical_status).parent
    cfg=json.loads((p/'resolved_config.json').read_text())['platform_online']; rel=cfg['relative']
    with np.load(rel['initializer']) as z:
        mu,scale,weights=[torch.tensor(z[k],dtype=torch.float32) for k in ('mu','scale','weight')]
    model=load_history_model(Path(cfg['ground_model']),device='cpu')
    with np.load(rel['raster']) as z:raster=dict(z)
    raster['height']-=rel['height']
    model.terrain=TerrainFeatures(**raster,device='cpu')
    def init(q,c,past):
        return exit_initializer(q,c,past,mu,scale,weights,rel['height'])
    pack=init(sample['query_qpos_native'].reshape(-1,12),sample['query_velocity_state9'].reshape(-1,9),
              sample['previous_velocity_state9'].reshape(-1,9))
    with np.load(held.index.iloc[0].candidate_curve_bank) as z:
        s=torch.tensor(z['s'],dtype=torch.float32)
        g=int(held.index.iloc[0].geometry)
        routes=[torch.tensor(z[k][g],dtype=torch.float32).unsqueeze(0).expand((len(pack[0]),)+z[k][g].shape)
                for k in ('xy','heading','curvature')]
    pose,nxt,hidden,domain=model.step(*pack,s,*routes,torch.full((len(pack[0]),),2.),None,None)
    assert all(t.isfinite().all() for t in [pose,nxt,hidden,domain])
    assert torch.max(abs(pose[:,3:7].norm(dim=-1)-1))<1e-5
    # Physical-state codec check, independent comparison against literal archived initializer inputs.
    with np.load(source/'measured_targets.npz') as z:
        indices=held.index.loc[held.success.numpy(),'row'].to_numpy()
        orig_q=torch.tensor(z['query_qpos_native'][indices]);cur=torch.tensor(z['query_velocity_state9'][indices]);prev=torch.tensor(z['previous_velocity_state9'][indices])
        t=torch.tensor(z['relock_s'][indices]).float()
    raw=decode_target(held.q0[held.success],held.y[held.success],project_joints=False)
    qhat=raw['query_qpos_native'];err=float((orig_q-qhat).abs().max()); terr=float((raw['relock_s']-t).abs().max())
    assert err<2e-5 and terr<1e-5 and torch.equal(raw['query_velocity_state9'],cur) and torch.equal(raw['previous_velocity_state9'],prev)
    obs=torch.cat([orig_q[:,[0,1,2,3,4,5,6,8,10,11]],cur,prev],-1)
    gold=((obs-mu)/scale)@weights[1:]+weights[0]
    rebuilt=init(qhat,raw['query_velocity_state9'],raw['previous_velocity_state9'])[3]
    hidden_err=float((rebuilt-gold).abs().max())
    assert hidden_err<.002
    nominal=decode_target(held.q0[held.success],held.y[held.success],project_joints=True)['query_qpos_native']
    return dict(n_real_checked=len(t),raw_codec_max_qpos_error=err,clock_max_error_s=terr,twists_roundtrip_exact=True,
                projected_real_qpos_max_delta=float((nominal-qhat).abs().max()),frozen_initializer_max_hidden_delta=hidden_err,
                affine_initializer_shape=list(weights.shape),sampled_particles=len(pose),real_consumer='HistoryDynamics.step',
                horizon_s=.02,state_output_shape=list(pose.shape),hidden_output_shape=list(hidden.shape),
                every_step_output_finite=True,sampled_next_quat_max_norm_error=float((pose[:,3:7].norm(dim=-1)-1).abs().max()),
                initializer_file=rel['initializer'],downstream_weight_dir=cfg['ground_model'])


def run(source,out):
    torch.set_num_threads(1);out.mkdir(parents=True,exist_ok=True)
    ds=Dataset.load(source);support,validation=grouping_old_dev(ds)
    train,held=ds.subset(support),ds.subset(validation)
    # Three hidden push rows share all allowable inputs. Root/force/map IDs are available only for grouping.
    assert all((ds.x[v]==ds.x[v[0]]).all() for v in ds.index.groupby(['layout','root','geometry','alpha']).indices.values())
    test=test_joint_and_failures(held.x,held.q0)
    all_logs=[];results={}
    for mode in MODE_NAMES:
        net,steps=fit_model(train,mode,steps=12,batch_size=24,seed=612041,lr=1e-3)
        saved=io.BytesIO()
        torch.save(net.state_dict(),saved);saved.seek(0)
        loaded=JumpOutcome(train.x.shape[1],mode)
        loaded.load_state_dict(torch.load(saved,map_location='cpu',weights_only=True))
        assert all(torch.equal(a,b) for a,b in zip(net(held.x),loaded(held.x),strict=True))
        for item in steps:item['mode']=mode
        all_logs+=steps
        results[mode]={'parameters':sum(p.numel() for p in net.parameters()),'train':evaluate(net,train),'validation':evaluate(net,held),
                       'downstream':downstream_test(held,net,source)}
    # Baselines use labels only in support and initial state/candidate geometry only for held-out prediction.
    for name,k in [('empirical_action',None),('five_separate_roots',5)]:
        part=empirical_particles(train,held,k)
        probs=torch.tensor([item[0] for item in part])
        draws=empirical_forecast(train,held,k,draws=16,conditional=False)
        assert draws['query_qpos_native'][draws['state_defined']].isfinite().all()
        assert draws['query_qpos_native'][~draws['state_defined']].isnan().all()
        for prob,ys,w in part:
            assert len(ys)==len(w) and (not len(w) or torch.isclose(w.sum(),torch.tensor(1.),atol=1e-5))
            if prob==0: assert not len(ys)
        results[name]=dict(validation={'n':len(probs),'relocks':int(held.success.sum()),
                        'brier':float((probs-held.success.float()).square().mean())},
                        n_empty_conditional_support=sum(not len(item[1]) for item in part))
    assert results['mean']['parameters']==results['mixture3']['parameters']
    receipt=dict(role='Fixed-budget numerical smoke on two previously inspected P0-B development maps. No P1 physical collection, independent test or real-robot evidence.',
                 old_source=str(source),source_train_roots=sorted(train.index.root.unique().tolist()),source_validation_roots=sorted(held.index.root.unique().tolist()),
                 selected_pairs=[[0,0.],[1,0.],[1,.5],[2,0.]],training_records=len(train.x),validation_records=len(held.x),input_width=train.x.shape[1],target_width=DIM,
                 common_width=[48,48],components=3,seed=612041,optimizer='Adam',learning_rate=.001,steps=12,batch_size=24,
                 checkpoint='Fixed final smoke step; no selection or reported independent performance.',
                 tests=dict(test,checkpoint_roundtrip_both_exact=True),models=results)
    pd.DataFrame(all_logs).to_csv(out/'smoke_optimization.csv',index=False)
    (out/'smoke_receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--old-dev',type=Path,required=True)
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
    args=p.parse_args();run(args.old_dev.resolve(),args.out.resolve())

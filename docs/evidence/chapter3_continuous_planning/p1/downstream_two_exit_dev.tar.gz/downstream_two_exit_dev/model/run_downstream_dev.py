"""Fixed P1 development downstream forecasts; optional isolated wiring check on first training map."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import time
import numpy as np
import pandas as pd
import torch

from frozen_exit_value import FrozenExits,aggregate,evaluate_particles
from jump_outcome import Dataset,DIM,JumpOutcome,MODE_NAMES,decode_target,decision_inputs,empirical_particles,fit_model
from smoke_outcome import grouping_old_dev

MODEL=Path(__file__).resolve().parent
P=MODEL.parent
CFG=json.loads((MODEL/'downstream_preregistration.json').read_text())
OLD=P.parent/'chapter3_continuous_p0b_20261123/analysis/p1_dev_prefixes'
KEY=['map_id','root','action_slot']
FAMILIES=('empirical_action','five_separate_roots')
DRAWS=CFG['sampled_conditional_states']
SEED=CFG['draw_seed']


def load_support(check):
    if check:
        old=Dataset.load(OLD)
        train=old.subset(grouping_old_dev(old)[0])
        return train,{(mode,str(seed)):fit_model(train,mode,12,24,seed)[0] for seed in CFG['neural_seeds'] for mode in MODE_NAMES}
    contract=json.loads((MODEL/'fit_preregistration.json').read_text())
    assert contract['maps_train']==CFG['train_maps'] and contract['maps_dev']==CFG['dev_maps']
    assert contract['shared_neural']['seeds']==CFG['neural_seeds']
    fit=MODEL/'formal_fit';state=json.loads((fit/'stage.json').read_text());assert state['stage']=='complete'
    train=Dataset.join([Dataset.load(P/'export'/'train'/m) for m in CFG['train_maps']])
    nets={}
    for seed in CFG['neural_seeds']:
        d=fit/f'seed_{seed}';info=json.loads((d/'summary.json').read_text())
        assert info['steps']==540 and info['seed']==seed and info['batch_size']==128
        for mode in MODE_NAMES:
            c=torch.load(d/(mode+'.pt'),map_location='cpu',weights_only=True)
            assert c['mode']==mode and c['input_width']==train.x.shape[1]
            net=JumpOutcome(c['input_width'],mode,c['width']);net.load_state_dict(c['state'])
            nets[mode,str(seed)]=net.eval()
    return train,nets


def decision_rows(folder,check):
    cols=['row','map_id','root','action_slot','geometry','alpha','hidden_force_N_grouping_only']
    idx=pd.read_csv(folder/'prefix_index.csv',usecols=cols)
    # The scheduled gate is read without opening any query, outcome or physical trajectories.
    gates=pd.read_csv(folder/'suffix_index.csv',usecols=['row','arm','target_side','section','section_x'])
    idx=idx.merge(gates[gates.arm.eq('left')].drop(columns='arm'),on='row',validate='one_to_one').sort_values('row')
    assert np.array_equal(idx.row,np.arange(len(idx))) and set(idx.map_id)=={folder.name}
    if check:
        root=idx.root.iloc[0];idx=idx[idx.root.eq(root)&idx.action_slot.isin([0,1])]
    parts=[]; reps=[]
    with np.load(folder/'observed_inputs.npz',allow_pickle=False) as z:
        arrays={k:z[k] for k in z.files}
    for _,g in idx.groupby(['root','action_slot'],sort=True):
        rr=g.row.to_numpy()
        assert set(g.hidden_force_N_grouping_only)=={-5,0,5} and len(g)==3 and g[KEY+['target_side','section','section_x','geometry','alpha']].nunique().eq(1).all()
        assert all(np.array_equal(v[rr],np.broadcast_to(v[rr[0]],v[rr].shape)) for v in arrays.values())
        parts.append(int(rr[0]));reps.append(g.iloc[0])
    meta=pd.DataFrame(reps).drop(columns=['hidden_force_N_grouping_only']).reset_index(drop=True)
    observed={k:v[parts] for k,v in arrays.items()}
    x,q,reset,a=decision_inputs(observed)
    # No new-map measured target is opened on the prospective score path.
    ds=Dataset(x,q,reset,a,torch.zeros(len(q),dtype=torch.bool),torch.full((len(q),DIM),torch.nan),meta)
    return ds,idx


def random_draws():
    rng=np.random.default_rng(SEED)
    u=(np.arange(DRAWS)+rng.random(DRAWS))/DRAWS
    return torch.tensor(rng.permutation(u),dtype=torch.float32),torch.tensor(rng.normal(size=(DRAWS,DIM)),dtype=torch.float32)


@torch.inference_mode()
def predicted_states(data,models,train,families=None):
    rows=[];opportunities={}
    common_u,common_noise=random_draws()
    if families is None:families=list(models)+[(name,'shared') for name in FAMILIES]
    for method,seed in families:
        if method in MODE_NAMES:
            net=models[method,seed]
            device=net.x_center.device
            logit,logw,center,scale=net(data.x.to(device))
            u=common_u.to(device).expand(len(data.x),-1)
            z=common_noise.to(device).expand(len(data.x),-1,-1)
            probs=logit.sigmoid().cpu()
            if method=='mean': latent=center[:,0,None,:]
            else:
                mode=torch.searchsorted(logw.exp().cumsum(-1).contiguous(),u.contiguous()).clamp_max(2)
                n=torch.arange(len(data.x),device=device)[:,None];latent=center[n,mode]+scale[n,mode]*z
            states={k:v.cpu() for k,v in decode_target(data.q0[:,None,:].to(device),latent*net.y_scale+net.y_center).items()}
        else:
            support=empirical_particles(train,data,None if method==FAMILIES[0] else 5)
            probs=torch.tensor([min(1.,max(0.,s[0])) for s in support])
        for n,r in enumerate(data.index.itertuples()):
            tag=dict(map_id=r.map_id,root=int(r.root),action_slot=int(r.action_slot),geometry=int(r.geometry),
                     alpha=float(r.alpha),section=r.section,section_x=float(r.section_x),target_side=int(r.target_side),method=method,seed=seed)
            key=(n,method,seed)
            chunk=[]
            if method in MODE_NAMES:
                fields={k:v[n] for k,v in states.items()}
            else:
                _,s,w=support[n]
                if len(s):
                    pick=torch.searchsorted(w.cumsum(0).contiguous(),common_u).clamp_max(len(w)-1)
                    fields=decode_target(data.q0[n:n+1],s[pick])
                else:fields=None
            if fields is not None:
                for i in range(len(fields['query_s'])):
                    p=dict(tag,particle=i,query_s=float(fields['query_s'][i]),q=fields['query_qpos_native'][i].numpy(),
                           v=fields['query_velocity_state9'][i].numpy(),prev=fields['previous_velocity_state9'][i].numpy())
                    chunk.append(p)
            rows.extend(chunk);opportunities[key]=(tag,float(probs[n]),chunk)
    return rows,opportunities


def score_predictions(engine,data,models,train,families=None):
    start=time.perf_counter()
    rows,items=predicted_states(data,models,train,families)
    evaluate_particles(engine,rows)
    res=[dict(t,**aggregate(samples,p)) for t,p,samples in items.values()]
    return res,rows,time.perf_counter()-start


def measured_states(engine,folder,subset):
    sf=pd.read_csv(folder/'suffix_index.csv')
    sf=sf[sf.row.isin(subset.row)].copy()
    keys=['map_id','root','action_slot','geometry','section','section_x','target_side','verified_relock','observed_query','arm']
    base={};particles=[]
    for r in sf.itertuples():
        b={k:getattr(r,k) for k in keys};b.update(force_n=int(r.hidden_force_N_grouping_only),source_arm=r.arm,lane=int(r.lane),row=int(r.row))
        base[(int(r.row),r.arm)]=b
    for path,rows in sf[sf.observed_query].groupby('query_file'):
        with np.load(path) as data:
            fields=['tick','remaining_s','lanes','branch_ids','qpos','velocity','previous_velocity','incumbent_direction','shadow_choice',
                    'shadow_any_admitted','shadow_incumbent_admitted','requested_speed','section_x','side']
            a={k:data[k] for k in fields}
        for r in rows.itertuples():
            j=int(r.query_file_row);b=base[int(r.row),r.arm]
            assert a['lanes'][j]==r.lane and a['incumbent_direction'][j]==r.declared_direction and int(a['tick'])==int(r.query_tick)
            assert np.float32(r.section_x)==a['section_x'][j] and r.target_side==a['side'][j]
            b.update(actual_incumbent=int(a['incumbent_direction'][j]),archived_raw_choice=int(a['shadow_choice'][j]),
                     archived_any_admitted=bool(a['shadow_any_admitted'][j]),archived_incumbent_admitted=bool(a['shadow_incumbent_admitted'][j]),
                     observed_ids=a['branch_ids'][j],query_s=int(a['tick'])*.005,observed_remaining_s=float(a['remaining_s']),
                     q=a['qpos'][j],v=a['velocity'][j],prev=a['previous_velocity'][j],requested_speed=float(a['requested_speed'][j]),
                     actual_query_file=path,actual_query_file_row=j)
            particles.append(b)
    evaluate_particles(engine,particles)
    for b in particles:
        b.update(native_choice_equal=(b['raw_choice_own_incumbent']==b['archived_raw_choice']),
                 native_any_equal=(b['admitted_own_incumbent']==b['archived_any_admitted']),
                 native_incumbent_equal=(b['kept_own_incumbent']==b['archived_incumbent_admitted']),
                 common_raw_differs_from_logged_raw=(b['raw_common_straight_choice']!=b['archived_raw_choice']),
                 own_effective_choice=(b['archived_raw_choice'] if b['archived_any_admitted'] else 1),
                 common_effective_differs_from_logged_with_straight_fallback=(b['measured_choice']!=(b['archived_raw_choice'] if b['archived_any_admitted'] else 1)))
    arm_audit=pd.DataFrame(list(base.values()))
    return arm_audit[arm_audit.arm.eq('left')].copy(),arm_audit


def benchmark(engine,data,nets,support,name,check=False):
    # Initialize engine/weights before measuring. These are single-robot requests, one known near-left gate.
    ix=np.flatnonzero(data.index.root.eq(data.index.root.iloc[0]).to_numpy())
    assert len(ix)==(2 if check else 16)
    records=[]
    for size in ((1,) if check else (1,16)):
        query=data.subset(ix[:size])
        query.index=query.index.assign(section='near',section_x=12.7,target_side=1)
        for method in (*MODE_NAMES,*FAMILIES):
            seed=str(CFG['seed_priority']) if method in MODE_NAMES else 'shared'
            for repeat in range(1 if check else 6):
                if engine.device=='cuda':torch.cuda.synchronize()
                t0=time.perf_counter()
                res,pts,_=score_predictions(engine,query,nets,support,[(method,seed)])
                if engine.device=='cuda':torch.cuda.synchronize()
                elapsed=(time.perf_counter()-t0)*1000.
                records.append(dict(map_id=name,root=int(query.index.root.iloc[0]),method=method,seed=seed,n_candidates=size,
                    conditional_states=len(pts),rep=repeat,warmup=(not check and repeat==0),scope=('cpu_wiring_one_call' if check else 'registered_single_robot'),elapsed_ms=elapsed,
                    over_old_publication_15ms=elapsed>15.,over_rolling_deadline_100ms=elapsed>100.))
    return records


def run(args):
    torch.set_num_threads(1)
    if args.device=='cuda' and not torch.cuda.is_available():raise ValueError('CUDA requested but unavailable')
    check=args.check_train00
    if check and args.benchmark:raise ValueError('Single-robot 16-candidate timing belongs to the separate registered timing run')
    if check and args.device!='cpu':raise ValueError('Engineering check uses CPU only')
    output=args.out or MODEL/('train00_downstream_check' if check else 'formal_downstream')
    output.mkdir(exist_ok=True,parents=True)
    support,nets=load_support(check)
    for net in nets.values():net.to(args.device)
    keep=[];obs=[];audit=[];times=[];particles=[];counts={}
    for name in (['train_00'] if check else CFG['dev_maps']):
        folder=P/'export'/('train' if check else 'dev')/name
        receipt=json.loads((folder/'export_receipt.json').read_text());assert receipt['stage']=='complete' and receipt['map_id']==name and not receipt['benchmark_only']
        data,subset=decision_rows(folder,check)
        if not check:
            assert len(data.x)==192 and len(subset)==576 and not set(data.index.root)&set(support.index.root)
        engine=FrozenExits(P/'batches'/name/'physical',args.device)
        res,pts,elapsed=score_predictions(engine,data,nets,support)
        keep.extend(res);particles.extend(pts)
        src,arm=measured_states(engine,folder,subset);obs.append(src);audit.append(arm)
        c=arm[arm.observed_query]
        counts[name]=dict(opportunities=len(data.x),scored_method_rows=len(res),forecast_states=len(pts),suffix_rows=len(arm),
                          observed_left=len(src[src.observed_query]),observed_both=len(c),native_choice_matches=int(c.native_choice_equal.sum()),
                          native_any_matches=int(c.native_any_equal.sum()),native_incumbent_matches=int(c.native_incumbent_equal.sum()),
                          measured_vs_poseonly_anchor_matches=int(c.anchor.eq(c.pose_only_anchor).sum()),seconds_offline_batch=elapsed)
        if check or (args.benchmark and name==CFG['dev_maps'][0]):times.extend(benchmark(engine,data,nets,support,name,check))
    pd.DataFrame(keep).to_csv(output/'prefix_gate_predictions.csv',index=False)
    pd.concat(obs,ignore_index=True).to_csv(output/'measured_exit_queries.csv',index=False)
    pd.concat(audit,ignore_index=True).to_csv(output/'measured_both_arm_shadow.csv',index=False)
    pd.DataFrame(particles).rename(columns={'measured_choice':'particle_choice'}).to_csv(output/'particle_exit_queries.csv.gz',index=False)
    if times:pd.DataFrame(times).to_csv(output/'single_robot_timing.csv',index=False)
    report=dict(role='train_00 CPU wiring with old temporary models' if check else 'registered two-map DEV',
                device_ground=args.device,device_neural=args.device,device_empirical='cpu',training='12 smoke updates on old DEV' if check else 'six registered final models',
                calibrated_or_test=False,draws=DRAWS,maps=counts,latency_probe=bool(times))
    (output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    g=p.add_mutually_exclusive_group(required=True);g.add_argument('--registered',action='store_true');g.add_argument('--check-train00',action='store_true')
    p.add_argument('--device',choices=('cpu','cuda'),default='cpu');p.add_argument('--out',type=Path)
    p.add_argument('--benchmark',action='store_true',help='Optional single-robot timing on first registered development map')
    args=p.parse_args();run(args)

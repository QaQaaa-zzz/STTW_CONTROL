"""Run one registered downstream comparison after the specified completed fit, then CPU score."""
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

MODEL=Path(__file__).resolve().parent
P=MODEL.parent
WORK=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
PY=Path('/home/qy/mujoco_playground/.venv/bin/python')
FIT='sttw-ch3-p1-outcome-fit.service'
OUT=MODEL/'formal_downstream'
REPORT=OUT/'physical_evaluation'
GPU_CMD=[str(PY),str(MODEL/'run_downstream_dev.py'),'--registered','--device','cuda','--benchmark']
CPU_CMD=[str(PY),str(P/'export/evaluate_two_exit_admission.py'),'--predictions',str(OUT/'prefix_gate_predictions.csv'),
         '--measured',str(OUT/'measured_exit_queries.csv'),'--output',str(REPORT)]

def state(stage,**extra):
    OUT.mkdir(exist_ok=True)
    data=dict(stage=stage,utc=datetime.now(timezone.utc).isoformat(),service='sttw-ch3-p1-outcome-downstream.service',
              invocation=os.environ.get('INVOCATION_ID'),fit_unit=FIT,fit_invocation=os.environ.get('STTW_FIT_INVOCATION'),
              fit_main_pid=int(os.environ['STTW_FIT_PID']),gpu_command=GPU_CMD,cpu_command=CPU_CMD,**extra)
    tmp=OUT/'queue_status.tmp'
    tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(OUT/'queue_status.json')

def unit_status():
    cmd=['systemctl','--user','show',FIT,'-p','LoadState','-p','InvocationID','-p','MainPID','-p','ActiveState','-p','Result']
    result=subprocess.run(cmd,text=True,capture_output=True)
    return dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)

def main():
    if sys.argv[1:] == ['--inside-gpu-lock']:
        # All project rollouts use the same lock. Check for a separate, noncooperating GPU application too.
        while True:
            gpu=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'],text=True).strip()
            if not gpu:break
            state('waiting_for_external_gpu_process',compute_processes=gpu.splitlines())
            time.sleep(30)
        state('running_registered_gpu_dev')
        os.execv(GPU_CMD[0],GPU_CMD)
    expected=int(os.environ['STTW_FIT_PID'])
    if (OUT/'queue_status.json').is_file() and json.loads((OUT/'queue_status.json').read_text())['stage']=='complete':
        raise RuntimeError('A completed downstream evaluation is already recorded')
    current=unit_status()
    if int(current.get('MainPID') or 0)>0:
        if current['InvocationID']!=os.environ['STTW_FIT_INVOCATION'] or int(current['MainPID'])!=expected:
            raise RuntimeError('The active upstream fit is a different invocation')
        state('waiting_for_fit_completion')
        # Distribution Python exposes Linux pidfds; the experimental MuJoCo interpreter does not.
        watch='import os,select,sys; fd=os.pidfd_open(int(sys.argv[1])); p=select.poll(); p.register(fd,select.POLLIN); p.poll()'
        subprocess.run(['/usr/bin/python3','-c',watch,str(expected)],check=True)
    current=unit_status()
    if current.get('LoadState')=='loaded' and (current.get('Result')!='success' or current.get('ActiveState')=='failed'):
        raise RuntimeError('Upstream fit did not exit successfully: '+str(current))
    fit=json.loads((MODEL/'formal_fit/stage.json').read_text())
    if fit.get('stage')!='complete' or fit.get('seeds')!=[61123,61124,61125] or fit.get('optimisation_steps')!=3240:
        raise RuntimeError('Missing successful terminal receipt from the registered six fits')
    state('waiting_for_shared_gpu_slot',upstream_fit=fit)
    subprocess.run([str(WORK/'learning/scripts/gpu_queue.sh'),str(PY),str(Path(__file__).resolve()),'--inside-gpu-lock'],check=True)
    state('running_two_exit_cpu_evaluation')
    subprocess.run(CPU_CMD,check=True,env=dict(os.environ,CUDA_VISIBLE_DEVICES=''))
    r=json.loads((REPORT/'receipt.json').read_text())
    if r['maps']!=['dev_00','dev_01'] or r['map_root_action_opportunities']!=384 or r['prototype_fixtures']:
        raise RuntimeError('The physical receipt does not cover the registered 384 development opportunities')
    state('complete',gpu_receipt=str(OUT/'receipt.json'),physical_receipt=str(REPORT/'receipt.json'),map_root_action_opportunities=384)

if __name__=='__main__':
    try:main()
    except Exception as exc:
        state('failed',error=str(exc));raise

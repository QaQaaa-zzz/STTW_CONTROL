"""One-step hurdle model for the STTW query state. No rollouts or fitting on import."""
from dataclasses import dataclass
from pathlib import Path
import math

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F


DIM = 30  # 1 time, 3 xyz, 3 SO(3) rotation-vector, 5 joints, 2 x 9 velocities
DT = .005
HORIZON = 10.
POSE_ORDER = [0,1,2,3,4,5,6,8,9,7,10,11]
MODE_NAMES = ('mean','mixture3')


def unit(q):
    return F.normalize(q,dim=-1)


def qmul(a,b):
    w=a[...,:1]*b[...,:1]-(a[...,1:]*b[...,1:]).sum(-1,keepdim=True)
    return torch.cat([w,a[...,:1]*b[...,1:]+b[...,:1]*a[...,1:]+torch.cross(a[...,1:],b[...,1:],dim=-1)],-1)


def encode_target(q0, relock, q, current, previous):
    """Local displacement and relative rotation; call on measured successes only."""
    qbase=unit(q0[...,3:7])
    rel=unit(qmul(torch.cat([qbase[...,:1],-qbase[...,1:]],-1),unit(q[...,3:7])))
    rel=torch.where(rel[...,:1]<0,-rel,rel)
    length=rel[...,1:].norm(dim=-1,keepdim=True)
    angle=2*torch.atan2(length,rel[...,:1])
    rv=rel[...,1:]*torch.where(length>1e-7,angle/length.clamp_min(1e-12),2*torch.ones_like(length))
    time=torch.logit((relock/(HORIZON-DT)).clamp(1e-7,1-1e-7))[...,None]
    return torch.cat([time,q[...,:3]-q0[...,:3],rv,q[...,7:]-q0[...,7:],current,previous],-1)


def decode_target(q0,y, project_joints=True):
    rv=y[...,4:7]; ang=rv.norm(dim=-1,keepdim=True)
    half=.5*ang
    rotation=torch.cat((half.cos(),.5*torch.sinc(half/math.pi)*rv),-1)
    q= unit(qmul(unit(q0[...,3:7]),rotation))
    native=torch.cat((q0[...,:3]+y[...,1:4],q,q0[...,7:]+y[...,7:12]),-1)
    if project_joints:
        # Rotating wheels retain their native, unwrapped angle. The solver uses soft limits
        # for steering, hip and knee; generated forecasts respect the nominal joint stops.
        native[...,8]=native[...,8].clamp(-.8,.8)
        native[...,10]=native[...,10].clamp(-1.3,.5)
        native[...,11]=native[...,11].clamp(-1.5,2.5)
    relock=(HORIZON-DT)*y[...,0].sigmoid()
    tick=torch.round(relock/DT).clamp(0,round(HORIZON/DT)-1)
    return dict(relock_s=tick*DT,query_s=(tick+1)*DT,query_qpos_native=native,
                query_velocity_state9=y[...,12:21],previous_velocity_state9=y[...,21:30])


def physical_action(profile, q0, step, alpha):
    """Fixed-X metric in physically meaningful units, shared by all methods and maps."""
    # Compare the requested paths before the known step at common world-x offsets.
    result=[]
    for path,q,g,preference in zip(profile,q0,step,alpha,strict=True):
        x=path[:,0]-g[0]
        xx=np.linspace(-5.,-1.1,13)
        y=np.interp(xx,x,path[:,1]+q[1])/.22
        h=np.interp(xx,x,path[:,2])/.14
        k=np.interp(xx,x,path[:,3])/.85
        result.append(np.r_[y,h,k,preference])
    return np.asarray(result,dtype=np.float32)


def decision_inputs(observations):
    """Explicit allowlist. Geometry and terrain are supplied as numeric observations."""
    q=observations['t0_qpos_native'].copy()
    sign=np.where(q[:,3:4]<0,-1.,1.)
    q[:,3:7]*=sign
    q[:,3:7]/=np.linalg.norm(q[:,3:7],axis=1,keepdims=True)
    v=observations['t0_qvel_native']
    twist=observations['t0_velocity_state9']
    profile=observations['approach_profile'];step=observations['step_geometry']
    alpha=observations['alpha']; height=observations['approach_corridor_height_m'];support=observations['approach_corridor_support']
    action=physical_action(profile,q,step,alpha)
    # Average four consecutive raster rows in each longitudinal bin, retaining all three lateral samples.
    terrain=np.concatenate([field[:,:64].reshape(len(q),16,4,3).mean(2).reshape(len(q),48) for field in (height,support)],axis=1)
    features=np.column_stack([q,twist,v[:,9:11],step,profile[:,::4].reshape(len(q),-1),terrain,action])
    metric=np.column_stack((q[:,1],q[:,3:7],v[:,:6]))
    return tuple(torch.tensor(x,dtype=torch.float32) for x in (features,q,metric,action))


@dataclass
class Dataset:
    x: torch.Tensor
    q0: torch.Tensor
    reset_features: torch.Tensor
    action: torch.Tensor
    success: torch.Tensor
    y: torch.Tensor
    index: pd.DataFrame

    def subset(self,rows):
        rows=np.asarray(rows)
        return Dataset(*(v[rows] for v in (self.x,self.q0,self.reset_features,self.action,self.success,self.y)),
                       self.index.iloc[rows].reset_index(drop=True))

    @property
    def measured(self):
        return self.success & self.y.isfinite().all(dim=1)

    @classmethod
    def join(cls,parts):
        if not parts: raise ValueError('Empty map list')
        fields=('x','q0','reset_features','action','success','y')
        return cls(*(torch.cat([getattr(d,f) for d in parts]) for f in fields),
                   pd.concat([d.index for d in parts],ignore_index=True))

    @classmethod
    def load(cls,directory):
        directory=Path(directory)
        ix=pd.read_csv(directory/'prefix_index.csv')
        if 'layout' not in ix and 'map_id' in ix: ix['layout']=ix.map_id
        with np.load(directory/'observed_inputs.npz',allow_pickle=False) as z:
            x,q0,reset,act=decision_inputs(z)
        with np.load(directory/'measured_targets.npz',allow_pickle=False) as z:
            label='verified_relock' if 'verified_relock' in z else 'is_relocked'
            success=torch.from_numpy(z[label].astype(bool))
            observed=torch.from_numpy(z['observed_query'].astype(bool)) if 'observed_query' in z else success
            valid=success & observed
            y=torch.full((len(x),DIM),torch.nan)
            pieces=[torch.tensor(z[k][valid],dtype=torch.float32) for k in
                    ('relock_s','query_qpos_native','query_velocity_state9','previous_velocity_state9')]
            y[valid]=encode_target(q0[valid],*pieces)
        if not np.array_equal(ix.row,np.arange(len(x))) or not x.isfinite().all() or not y[valid].isfinite().all():
            raise ValueError('Unaligned decision rows or nonfinite observations/measured success targets')
        return cls(x,q0,reset,act,success,y,ix)


class JumpOutcome(nn.Module):
    """Same trained parameter count in both modes; no marginal component switching."""
    def __init__(self, width_in, mode, width=48):
        super().__init__()
        if mode not in MODE_NAMES: raise ValueError(mode)
        self.mode=mode
        self.trunk=nn.Sequential(nn.Linear(width_in,width),nn.SiLU(),nn.Linear(width,width),nn.SiLU())
        self.relock_head=nn.Linear(width,1)
        self.joint_head=nn.Linear(width,3*(1+2*DIM))
        self.register_buffer('x_center',torch.zeros(width_in));self.register_buffer('x_scale',torch.ones(width_in))
        self.register_buffer('y_center',torch.zeros(DIM));self.register_buffer('y_scale',torch.ones(DIM))

    @torch.no_grad()
    def calibrate_scales(self,train):
        self.x_center.copy_(train.x.mean(0));self.x_scale.copy_(train.x.std(0,unbiased=False).clamp_min(.005))
        y=train.y[train.measured]
        if len(y)<2: raise ValueError('Need at least two successful training outcomes to scale state targets')
        self.y_center.copy_(y.mean(0));self.y_scale.copy_(y.std(0,unbiased=False).clamp_min(.001))

    def forward(self,x):
        h=self.trunk((x-self.x_center)/self.x_scale)
        relock=self.relock_head(h).squeeze(-1)
        raw=self.joint_head(h).reshape(len(x),3,1+2*DIM)
        weight=raw[:,:,0].log_softmax(-1); center=raw[:,:,1:1+DIM]
        scale=.05+F.softplus(raw[:,:,1+DIM:])
        if self.mode=='mean':
            # One conditional Gaussian at the learned weighted-mean location. A single
            # residual scale per coordinate uses all expert scale heads, with identical budget.
            prob=weight.exp().unsqueeze(-1)
            center=(center*prob).sum(1,keepdim=True)
            scale=(scale*prob).sum(1,keepdim=True)
            weight=weight.new_zeros((len(x),1))
        return relock,weight,center,scale

    def losses(self,x,observed,state):
        logit,weights,center,scale=self(x)
        binary=F.binary_cross_entropy_with_logits(logit,observed.float(),reduction='sum')
        measured=observed & state.isfinite().all(dim=1)
        if measured.any():
            target=((state[measured]-self.y_center)/self.y_scale).unsqueeze(1)
            logp=(-.5*((target-center[measured])/scale[measured])**2-scale[measured].log()-.5*math.log(2*math.pi)).sum(-1)
            conditional=-torch.logsumexp(weights[measured]+logp,dim=1).sum()
        else:
            conditional=logit.new_zeros(())
        # Every prefix has equal weight. Failure contributes BCE alone. Divide standardized
        # joint NLL by the common dimension to avoid overwhelming the Bernoulli objective.
        loss=(binary+conditional/DIM)/len(x)
        return loss, binary, conditional

    @torch.no_grad()
    def forecast(self,x,q0,draws=1,seed=0,conditional=False,central=False):
        """Return p and whole sampled particles. Failed particles carry NaN in every target."""
        rng=torch.Generator(device=x.device).manual_seed(seed)
        logit,logw,mu,sd=self(x)
        p=logit.sigmoid()
        ids=torch.multinomial(logw.exp(),draws,replacement=True,generator=rng)
        row=torch.arange(len(x),device=x.device)[:,None]
        if central:
            latent=(logw.exp()[...,None]*mu).sum(1)[:,None,:].expand(-1,draws,-1)
        else:
            noise=torch.randn((len(x),draws,DIM),generator=rng,device=x.device)
            latent=mu[row,ids]+sd[row,ids]*noise
        state=decode_target(q0[:,None,:].expand(-1,draws,-1),latent*self.y_scale+self.y_center)
        active=torch.ones_like(ids,dtype=torch.bool) if conditional else torch.rand(ids.shape,device=x.device,generator=rng)<p[:,None]
        for k,v in state.items():
            v.masked_fill_(~active if v.ndim==2 else ~active[...,None],float('nan'))
        return dict(p_relock=p,is_relocked=active,component=(torch.full_like(ids,-1) if central else ids).masked_fill(~active,-1),**state)


def exit_initializer(q_native,cur,prev,mu,scale,weight,platform_height):
    """Conventions identical to PlatformDepartureQuery.choose and ContinuousExitPlanner._evaluate."""
    pose=q_native[...,POSE_ORDER].clone()
    observed=torch.cat([pose[...,:8],pose[...,10:12],cur,prev],-1)
    hidden=((observed-mu)/scale)@weight[1:]+weight[0]
    pose[...,2]-=platform_height
    return pose,cur,prev,hidden


def empirical_particles(train,query,k=None):
    """Per root: closest physical actions; optional five-root metric, no query outcome access.

    Matching uses RMS numeric candidate path distance and numeric alpha. Interpolate the
    three nearest available actions per support root with inverse-square distance. Distances
    below .025 use nearest-only (same route, tiny t0 sampling misalignment). Within each
    root/action, all treatments receive equal weight; preserve complete successful vectors.
    """
    group=train.index.groupby('root',sort=True).indices
    keys=set()
    for v in group.values():
        initial=train.x[v,:23]
        key=initial[0].numpy().tobytes()
        if not (initial==initial[0]).all() or key in keys:
            raise ValueError('Source roots must each identify one distinct actual reset')
        keys.add(key)
    if k is not None and len(group)<k: raise ValueError('Fewer than k independent support roots')
    rows=list(group.values()); centers=torch.stack([train.reset_features[v[0]] for v in rows])
    scale=centers.std(0,unbiased=False).clamp_min(.005)
    roots_distance=torch.cdist(query.reset_features/scale,centers/scale)
    candidates=[]
    for v in rows:
        uu,inverse=torch.unique(train.action[v],dim=0,return_inverse=True)
        hist=[np.asarray(v)[(inverse==i).numpy()] for i in range(len(uu))]
        candidates.append((uu,hist))
    result=[]
    for j,probe in enumerate(query.action):
        roots=range(len(rows)) if k is None else roots_distance[j].argsort(stable=True)[:k].tolist()
        idx=[]; ws=[]
        for root in roots:
            actions,hist=candidates[root]
            # Geometries comprise 39 scaled coordinates; alpha has its own equal-scale term.
            d=((actions[:,:-1]-probe[:-1]).square().mean(1)+(actions[:,-1]-probe[-1]).square()).sqrt()
            best=d.argsort(stable=True)[:3]
            if float(d[best[0]])<.025: best=best[:1]
            w=d[best].clamp_min(1.e-6).pow(-2); w/=w.sum()
            for aid,amount in zip(best.tolist(),w.tolist(),strict=True):
                sel=hist[aid];idx.extend(sel);ws.extend([amount/(len(roots)*len(sel))]*len(sel))
        idx=torch.as_tensor(idx,dtype=torch.long); w=torch.tensor(ws)
        good=train.measured[idx];prob=w[train.success[idx]].sum()
        # No successful support means undefined conditional distribution, never fabricated zeros.
        result.append((float(prob),train.y[idx[good]],w[good]/w[good].sum() if good.any() else w[good]))
    return result


def fit_model(train,mode,steps,batch_size,seed,lr=1e-3,device='cpu',writer=None):
    torch.manual_seed(seed)
    net=JumpOutcome(train.x.shape[1],mode)
    net.calibrate_scales(train)
    net.to(device)
    x=train.x.to(device)
    success=train.success.to(device)
    states=train.y.to(device)
    opt=torch.optim.Adam(net.parameters(),lr=lr)
    rng=torch.Generator().manual_seed(seed+1)
    log=[]
    for step in range(steps):
        # Same host-side seed and row order regardless of model mode and compute device.
        ids=torch.randperm(len(train.x),generator=rng)[:batch_size]
        n_states=int(train.measured[ids].sum())
        n_relocks=int(train.success[ids].sum())
        ix=ids.to(device)
        loss,bce,nll=net.losses(x[ix],success[ix],states[ix])
        opt.zero_grad();loss.backward();opt.step()
        log.append(dict(step=step+1,n=len(ix),n_relocked=n_relocks,n_states=n_states,
                        loss=loss.detach().item(),relock_bce=bce.detach().item()/len(ix),
                        state_nll_std_per_positive_dim=nll.detach().item()/(n_states*DIM) if n_states else None))
        if writer:
            writer.add_scalar('train/loss',log[-1]['loss'],step+1)
            writer.add_scalar('train/relock_bce',log[-1]['relock_bce'],step+1)
            if n_states:
                writer.add_scalar('train/state_nll_per_coordinate',log[-1]['state_nll_std_per_positive_dim'],step+1)
    return net,log


def empirical_forecast(train,query,k=None,draws=1,seed=0,conditional=False):
    """Draw whole observed success vectors, transporting relative pose to the query reset."""
    rng=torch.Generator().manual_seed(seed)
    support=empirical_particles(train,query,k)
    probability=torch.tensor([p for p,_,_ in support]).clamp(0,1)
    has_states=torch.tensor([len(states)>0 for _,states,_ in support])
    active=(torch.ones((len(support),draws),dtype=torch.bool) if conditional else
            torch.rand((len(support),draws),generator=rng)<probability[:,None])
    valid=active & has_states[:,None]
    y=torch.full((len(support),draws,DIM),torch.nan)
    for j,(_,states,w) in enumerate(support):
        if len(states):
            pick=torch.multinomial(w,draws,replacement=True,generator=rng)
            y[j,valid[j]]=states[pick[valid[j]]]
    native=decode_target(query.q0[:,None,:].expand(-1,draws,-1),y)
    return dict(p_relock=probability,is_relocked=active,has_conditional_support=has_states,
                state_defined=valid,**native)


@torch.no_grad()
def evaluate(net,data):
    device=net.x_center.device
    x,q0,y,success=(a.to(device) for a in (data.x,data.q0,data.y,data.success))
    p=net(x)[0].sigmoid()
    loss,bce,nll=net.losses(x,success,y)
    m=data.measured.to(device)
    result=dict(n=len(p),relocks=int(data.success.sum()),n_states=int(m.sum()),loss=float(loss),
                brier=float((p-success.float()).square().mean()),bce=float(bce/len(p)),
                state_nll_std_per_success_dim=float(nll/(m.sum()*DIM)) if m.any() else None)
    if m.any():
        central=net.forecast(x[m],q0[m],conditional=True,central=True)
        actual=decode_target(q0[m],y[m],project_joints=False)
        q=central['query_qpos_native'][:,0];g=actual['query_qpos_native']
        quat_dot=(q[:,3:7]*g[:,3:7]).sum(-1).abs().clamp(0,1)
        result['central_positive_errors']={
            'relock_time_mae_s':float((central['relock_s'][:,0]-actual['relock_s']).abs().mean()),
            'query_xy_euclidean_rmse_m':float((q[:,:2]-g[:,:2]).square().sum(-1).mean().sqrt()),
            'query_so3_geodesic_mae_deg':float(torch.rad2deg(2*torch.acos(quat_dot)).mean())}
    return result

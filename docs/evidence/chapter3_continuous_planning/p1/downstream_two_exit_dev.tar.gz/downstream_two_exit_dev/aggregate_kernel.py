"""Unmodified aggregate() from model/frozen_exit_value.py."""
import numpy as np
NAMES=("left","straight","right")
def aggregate(rows,prob):
    if not rows:
        value=0. if prob==0. else None
        return dict(p_relock=prob,particles=0,score_any=value,score_lr=value,
                    **{'p_joint_feasible_'+n:value for n in NAMES},fixed_choice_before_relock=1 if prob==0 else None)
    flag=np.asarray([[p['feasible_'+name] for name in NAMES] for p in rows])
    nominal=flag.any(axis=1);lr=flag[:,[0,2]].any(axis=1)
    # This fixed-direction diagnostic commits a turn before re-lock (tie priority straight, left, right).
    averages=flag.mean(axis=0)
    rank=np.array([1,0,2]); fixed=int(rank[np.argmax(averages[rank])])
    return dict(p_relock=prob,particles=len(rows),score_any=prob*nominal.mean(),score_lr=prob*lr.mean(),
                **{'p_joint_feasible_'+n:prob*val for n,val in zip(NAMES,averages,strict=True)},
                fixed_choice_before_relock=fixed)

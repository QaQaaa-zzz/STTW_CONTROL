"""CPU whole-horizon check on one archived real query per map and observed common direction.
The original ground-model weights, MJB and route-bank paths in provenance.json must be mounted.
"""
import json,sys
from pathlib import Path
import pandas as pd,numpy as np,torch
B=Path(__file__).resolve().parent
P=Path(json.loads((B/'provenance.json').read_text())['original_experiment_run'])
sys.path[:0]=[str(B/'model'),str(B/'worktree_source/learning/src')]
from frozen_exit_value import FrozenExits
def main():
    torch.set_num_threads(1)
    tab=pd.read_csv(B/'model/formal_downstream/measured_both_arm_shadow.csv')
    out=[]
    for m,g in tab[tab.observed_query & tab.arm.eq('left')].groupby('map_id'):
        model=FrozenExits(P/'batches'/m/'physical','cpu')
        for _,rows in g.groupby('measured_choice',sort=True):
            t=rows.sort_values('lane').iloc[0];f=B/Path(t.actual_query_file).relative_to(P);j=int(t.actual_query_file_row)
            with np.load(f) as z:
                q,v,prev,ids=[z[k][j:j+1] for k in ('qpos','velocity','previous_velocity','branch_ids')]
                remain=float(z['remaining_s']);rq=float(z['requested_speed'][j])
            selected,feasible,raw,admitted=model.score(q,v,prev,remain,ids,t.section_x,t.target_side,speed=rq,return_native=True)
            assert selected[0]==t.measured_choice and list(feasible[0])==list(t[['feasible_left','feasible_straight','feasible_right']])
            arm=int(t.actual_incumbent)
            assert raw[0,arm]==t.archived_raw_choice and admitted[0,arm]==t.archived_any_admitted and feasible[0,arm]==t.archived_incumbent_admitted
            out.append(dict(map=m,lane=int(t.lane),query_row=j,steps=int(t.steps),remaining_s=remain,common_direction=int(selected[0]),feasible=feasible[0].tolist(),own_choice=int(raw[0,arm])))
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()

"""Recompute the particle aggregates, original query records, 25% physical policy evaluation and timing counts. CPU only."""
from pathlib import Path
import gzip,hashlib,json,tempfile,subprocess,sys
import numpy as np,pandas as pd
from aggregate_kernel import aggregate
B=Path(__file__).resolve().parent
F=B/'model/formal_downstream';phys=F/'physical_evaluation'
P=Path(json.loads((B/'provenance.json').read_text())['original_experiment_run'])
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def tablebytes(f):
    return gzip.open(f,'rb').read() if f.name.endswith('.gz') else f.read_bytes()
def main():
    pred=pd.read_csv(F/'prefix_gate_predictions.csv',dtype={'seed':str},float_precision='round_trip')
    part=pd.read_csv(F/'particle_exit_queries.csv.gz',dtype={'seed':str},float_precision='round_trip')
    by=['map_id','root','action_slot','method','seed'];assert not pred.duplicated(by).any()
    groups={idx:p for idx,p in part.groupby(by,sort=False)}
    assert len(pred)==3072 and len(part)==31792
    max_abs=0.;undefined=0
    for idx,s in pred.set_index(by).iterrows():
        g=groups.get(idx);records=[] if g is None else g.to_dict('records')
        if g is not None:assert np.array_equal(g.particle,np.arange(len(g))) and (g[['section_x','target_side']].to_numpy()==s[['section_x','target_side']].to_numpy()).all()
        wanted=aggregate(records,s.p_relock)
        for k,v in wanted.items():
            if pd.isna(s[k]):assert pd.isna(v);continue
            error=float(abs(s[k]-v));max_abs=max(max_abs,error)
            assert error<1e-13
        undefined+=int(pd.isna(s.score_any))
    measured=pd.read_csv(F/'measured_exit_queries.csv',float_precision='round_trip')
    arm=pd.read_csv(F/'measured_both_arm_shadow.csv',float_precision='round_trip')
    pd.testing.assert_frame_equal(arm[arm.arm.eq('left')].reset_index(drop=True),measured)
    assert len(arm)==2304 and len(measured)==1152
    fsrc=pd.read_csv(B/'query_sources.csv').set_index('archive_path')
    export=pd.concat([pd.read_csv(B/'export/dev'/m/'suffix_index.csv') for m in ['dev_00','dev_01']]).set_index(['map_id','lane'])
    ix=arm.set_index(['map_id','lane']);np.testing.assert_array_equal(export.loc[ix.index].observed_query,ix.observed_query)
    srcfields={'incumbent_direction':'actual_incumbent','shadow_choice':'archived_raw_choice','shadow_any_admitted':'archived_any_admitted','shadow_incumbent_admitted':'archived_incumbent_admitted','lanes':'lane','side':'target_side','requested_speed':'requested_speed'}
    seen=set();replay=0;source_error=0
    for file,p in arm[arm.observed_query].groupby('actual_query_file'):
        loc=Path(file).relative_to(P);seen.add(str(loc));base=B/loc
        assert digest(base)==fsrc.loc[str(loc),'source_sha256']
        j=p.actual_query_file_row.to_numpy(int)
        with np.load(base) as data:
            assert int(data['tick'])==int(data['previous_tick'])+4
            np.testing.assert_allclose(p.query_s,int(data['tick'])*.005,rtol=0,atol=1e-13)
            np.testing.assert_allclose(p.observed_remaining_s,float(data['remaining_s']),rtol=0,atol=1e-13)
            np.testing.assert_array_equal(np.array(p.section_x,np.float32),data['section_x'][j])
            for k,val in srcfields.items():np.testing.assert_array_equal(p[val].to_numpy(),data[k][j])
            np.testing.assert_array_equal(p[['bank_row_left','bank_row_straight','bank_row_right']].to_numpy(),data['branch_ids'][j])
        lane=export.loc[list(zip(p.map_id,p.lane))]
        assert np.array_equal(lane.query_file_row,j) and lane.query_file.eq(file).all()
        assert p.native_choice_equal.eq(True).all() and p.native_any_equal.eq(True).all() and p.native_incumbent_equal.eq(True).all()
        replay+=len(p)
    assert len(seen)==len(fsrc)==168 and replay==1068
    # Independently associate re-lock probabilities to the previously frozen formal fit before evaluating admission ranks.
    pp={};max_p=0
    src=pd.concat([pd.read_csv(B/'export/dev'/m/'prefix_index.csv',usecols=['map_id','root','action_slot','row']) for m in ['dev_00','dev_01']])
    for seed in [61123,61124,61125]:
        model=pd.read_csv(B/f'model/formal_fit/seed_{seed}/development_predictions.csv.gz',usecols=['layout','root','row','model','probability'],float_precision='round_trip').rename(columns={'layout':'map_id','model':'method'})
        v=model.merge(src,on=['map_id','root','row'],validate='many_to_one').groupby(['map_id','root','action_slot','method']).probability.agg(['min','max'])
        assert np.max(v['max']-v['min'])<1e-6
        local=pred[pred.seed.eq(str(seed))|pred.seed.eq('shared')].set_index(['map_id','root','action_slot','method'])
        error=np.abs(local.p_relock-v.loc[local.index]['min'].clip(upper=1))
        assert error.max()<5e-6;max_p=max(max_p,float(error.max()))
    original_receipt=json.loads((phys/'receipt.json').read_text())
    for path,h in original_receipt['files'].items():assert digest(B/Path(path).relative_to(P))==h
    with tempfile.TemporaryDirectory() as tmp:
        to=Path(tmp);subprocess.run([sys.executable,str(B/'export/evaluate_two_exit_admission.py'),'--predictions',str(F/'prefix_gate_predictions.csv'),'--measured',str(F/'measured_exit_queries.csv'),'--output',str(to)],check=True)
        files=sorted(q for q in phys.iterdir() if q.name.endswith(('.csv','.csv.gz')))
        assert set(f.name for f in files)=={x.name for x in to.iterdir() if x.name!='receipt.json'}
        for f in files:assert tablebytes(f)==tablebytes(to/f.name),f.name
        rec=json.loads((to/'receipt.json').read_text());orig=dict(original_receipt)
        fresh_hash={str(Path(k).relative_to(B)):v for k,v in rec.pop('files').items()}
        old_hash={str(Path(k).relative_to(P)):v for k,v in orig.pop('files').items()}
        assert rec==orig and fresh_hash==old_hash
    timing=pd.read_csv(F/'single_robot_timing.csv')
    assert len(timing)==48 and not timing.duplicated(['method','n_candidates','rep']).any() and timing.warmup.sum()==8
    for col,ms in [('over_old_publication_15ms',15),('over_rolling_deadline_100ms',100)]:np.testing.assert_array_equal(timing.elapsed_ms>ms,timing[col])
    warm=timing[~timing.warmup];assert len(warm)==40
    print(json.dumps(dict(maps=rec['maps'],all_t0_opportunities=384,all_method_scores=len(pred),forecast_particles=len(part),undefined_score_groups=undefined,max_particle_aggregate_abs_error=max_abs,
        primary_weight_probability_max_abs_difference=max_p,raw_query_files=len(seen),verified_physical_queries=replay,unobserved_arms=len(arm)-replay,
        geometry_rows_differs_from_poseonly=int(arm.loc[arm.observed_query].anchor.ne(arm.loc[arm.observed_query].pose_only_anchor).sum()),reproduced_physical_tables=len(files),original_physical_input_hashes=len(old_hash),
        single_robot_warm_count=len(warm),warm_over_15ms=int(warm.over_old_publication_15ms.sum()),warm_over_100ms=int(warm.over_rolling_deadline_100ms.sum())),indent=2))
if __name__=='__main__':main()

"""Seeded fixed rough banks separated by a real open trench (no backing plane)."""
import numpy as np


def build_ditch_terrain(spec, *, return_patches=False):
    front, width = spec['front_x_m'], spec['width_m']
    if width <= 0 or not 0 <= spec['stone_height_min_m'] <= spec['stone_height_max_m'] <= .15 or spec['stones_per_m2'] < 0:
        raise ValueError('Positive trench width, nonnegative density and ordered stone heights in [0, .15] required')
    intervals=spec.get('rough_x_intervals_m',[[2.,8.]])
    if not intervals or any(len(v)!=2 or v[0]>=v[1] for v in intervals):
        raise ValueError('Rough intervals must have increasing endpoints')
    rough_start=min(v[0] for v in intervals);rough_end=max(v[1] for v in intervals)
    rng = np.random.default_rng(spec['seed'])
    vertices, triangles = [], []
    patches = []
    def patch(xs, ys, rough, bank_height):
        x, y = np.meshgrid(xs, ys, indexing='ij')
        z = np.zeros_like(x)
        if rough:
            count = int((xs[-1]-xs[0])*(ys[-1]-ys[0])*spec['stones_per_m2'])
            for _ in range(count):
                cx, cy = rng.uniform(xs[0],xs[-1]), rng.uniform(ys[0],ys[-1])
                radius = rng.uniform(.055,.09)
                height = rng.uniform(spec['stone_height_min_m'],spec['stone_height_max_m'])
                z = np.maximum(z, height*np.maximum(0,1-((x-cx)**2+(y-cy)**2)/radius**2)**2)
            for ridge in spec.get("ridges",[]):
                lo,hi=ridge["x_interval_m"];bottom,top=ridge.get("y_interval_m",[-4.,4.])
                ramp=np.sin(np.pi*np.clip((x-lo)/(hi-lo),0,1))**2
                across=np.clip((y-bottom)/.2,0,1)*np.clip((top-y)/.2,0,1)
                z += ridge["height_m"]*ramp*across
            mask=np.zeros_like(x)
            for lo,hi in intervals:
                mask=np.maximum(mask,np.clip((x-lo)/.1,0,1)*np.clip((hi-x)/.1,0,1))
            if "rough_x_intervals_m" in spec:
                z *= mask
            # Match the surrounding flat mesh at its outer seams.
            z *= np.clip((y-ys[0])/.1,0,1)*np.clip((ys[-1]-y)/.1,0,1)
            z *= np.clip((x-xs[0])/.1,0,1)*np.clip((xs[-1]-x)/.1,0,1)
        start = sum(len(v) for v in vertices)
        vertices.append(np.stack((x,y,z+bank_height),-1).reshape(-1,3))
        patches.append((xs.copy(), ys.copy(), (z+bank_height).copy()))
        a = np.arange(x.size).reshape(x.shape)[:-1,:-1].ravel()+start
        stride = len(ys)
        triangles.extend((np.stack((a,a+stride,a+1),-1),np.stack((a+1,a+stride,a+stride+1),-1)))
    for left,right,bank_height in ((-5.,front,0.),(front+width,spec['ground_end_x_m'],spec.get('far_bank_height_m',0.))):
        rough_left,rough_right = max(left,rough_start),min(right,rough_end)
        if rough_left>=rough_right:
            patch(np.array([left,right]),np.array([-1.,1.]),False,bank_height)
            patch(np.array([left,right]),np.array([-4.,-1.]),False,bank_height)
            patch(np.array([left,right]),np.array([1.,4.]),False,bank_height)
            continue
        if spec.get("full_width_rough",False):
            patch(np.linspace(rough_left,rough_right,int(np.ceil((rough_right-rough_left)/.025))+1),np.linspace(-4.,4.,321),True,bank_height)
            if left < rough_left:patch(np.array([left,rough_left]),np.array([-4.,4.]),False,bank_height)
            if rough_right < right:patch(np.array([rough_right,right]),np.array([-4.,4.]),False,bank_height)
            continue
        patch(np.linspace(rough_left,rough_right,int(np.ceil((rough_right-rough_left)/.025))+1),np.linspace(-1.,1.,81),True,bank_height)
        if left < rough_left: patch(np.array([left,rough_left]),np.array([-1.,1.]),False,bank_height)
        if rough_right < right: patch(np.array([rough_right,right]),np.array([-1.,1.]),False,bank_height)
        for bottom,top in ((-4.,-1.),(1.,4.)):
            patch(np.array([left,right]),np.array([bottom,top]),False,bank_height)
    if 'land_bridge_y_interval_m' in spec:
        lo,hi=spec['land_bridge_y_interval_m']
        if not 1.<lo<hi<=4. or spec.get('far_bank_height_m',0.)!=0.:
            raise ValueError('The lateral land bridge requires same-height banks and 1 < y_min < y_max <= 4')
        patch(np.array([front,front+width]),np.array([lo,hi]),False,0.)
    mesh = (np.concatenate(vertices).astype(np.float32),np.concatenate(triangles).astype(np.int32))
    return (*mesh, patches) if return_patches else mesh


def split_flat_lips(patches, near, far):
    """Keep the sampled rough mesh and split only its constant-height lip rows."""
    fields, boxes = [], []
    for x, y, z in patches:
        if len(x) > 2 and (np.isclose(x[-1], near) or np.isclose(x[0], far)):
            lip = -1 if np.isclose(x[-1], near) else 0
            level = z[lip, 0]
            uneven = np.flatnonzero((z != level).any(axis=1))
            cut = (uneven[-1] + 1 if lip == -1 else uneven[0] - 1) if len(uneven) else None
            if cut is not None and 0 < cut < len(x) - 1 and np.all(z[lip] == level):
                left, right = sorted((x[cut], x[lip]))
                boxes.append((left, right, y[0], y[-1], level))
                kept = slice(None, cut + 1) if lip == -1 else slice(cut, None)
                x, z = x[kept], z[kept]
        fields.append((x, y, z))
    return fields, boxes


def ditch_support_mask(wheels, forces, roll, pitch, forward_velocity, spec):
    on = ((wheels[:,:,0] > spec['front_x_m']+spec['width_m'])
          & (wheels[:,:,0] < spec['ground_end_x_m'])
          & (wheels[:,:,1].abs() < spec.get('lateral_limit_m',.9))
          & (wheels[:,:,2] >= .045+spec.get('far_bank_height_m',0.))
          & (wheels[:,:,2] <= .095+spec['stone_height_max_m']+spec.get('far_bank_height_m',0.))).all(-1)
    return on & (forces[:,:,2]>1.).all(-1) & (roll.abs()<.15) & (pitch.abs()<.15) & (forward_velocity>=1.)

"""One known-map, pre-takeoff planning decision on continuous entry curves and alpha."""
from pathlib import Path
import sys,time
import numpy as np
import torch
from continuous_approach import Boundary,generate_reference
from continuous_departures import score_approach
P=Path(__file__).resolve().parents[1];W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path[:0]=[str(P/'export'),str(P/'model'),str(W/'learning/src'),str(W/'learning/cli'),'/home/qy/DVGC/JIT/src']
from export_prefixes import decision_inputs as sample_corridor
from jump_outcome import decision_inputs,decode_target
from run_downstream_dev import random_draws

@torch.inference_mode()
def plan(world,raster,ground,jump,qpos,qvel,published,published_alpha,committed_s,gate_x,gate_side,*,
         population=4,iterations=2,seed=923114,speed=2.,trigger_before_edge_m=1.1,episode_s=10.,
         continuous_alpha=False,publish_window_s=None):
    """Return the reference and alpha eligible for publication at the supplied deadline. No instance, map or catalog key is an input.

    ground is the frozen scorer for world/raster. committed_s is the actual publication
    commitment supplied by the controller. Particles use the registered common P1 quantiles
    and noise across *all* candidates. Timings include every candidate and conditional exit query.
    """
    if gate_side not in (-1,1) or population<2 or iterations<1 or not 0<=published_alpha<=1:raise ValueError('Invalid gate, CEM budget or published alpha')
    t0=time.perf_counter()
    route={k:np.asarray(v) for k,v in published.items()}
    inp={k:np.asarray(route[k]).reshape(-1,2) if k=='xy' else np.asarray(route[k]).reshape(-1) for k in ('xy','heading','curvature')}
    if route['xy'].ndim==3 and len(route['xy'])!=1:raise ValueError('Expected one currently published curve')
    canonical={'s':route['s'],**{k:v[None] for k,v in inp.items()}}
    edge=world['terrain']['front_x_m'];edge_y=float(np.interp(edge,inp['xy'][:,0],inp['xy'][:,1]));edge_h=float(np.interp(edge,inp['xy'][:,0],inp['heading']))
    candidates=[];records=[];steps=[];geom_s=forecast_s=ground_s=0.;device=jump.x_center.device
    u,z=random_draws();u=u.to(device);z=z.to(device)
    rng=np.random.default_rng(seed)
    high=np.array([.225,np.deg2rad(8.),.08,1.]);low=-high.copy();low[3]=0.
    alpha_levels=np.array([0.,.5,1.]);center=(low+high)/2.;spread=(high-low)/3.
    def evaluate(curve,alpha,iteration,parameters):
        nonlocal forecast_s,ground_s
        n=len(steps);start=time.perf_counter()
        # The only "row zero" here is this newly supplied single curve; no route library is present.
        obs=sample_corridor(qpos[None],qvel[None],[0],[alpha],curve,raster,world)
        x,anchor,_,_=decision_inputs(obs);logit,logw,mu,sigma=jump(x.to(device))
        if jump.mode=='mean':latent=mu[:,0:1]
        else:
            modes=torch.searchsorted(logw[0].exp().cumsum(0).contiguous(),u).clamp_max(mu.shape[1]-1)
            latent=mu[:,modes]+sigma[:,modes]*z[None]
        state={k:v[0].cpu().numpy() for k,v in decode_target(anchor[:,None].to(device),latent*jump.y_scale+jump.y_center).items()}
        probability=float(logit.sigmoid().item());forecast_s+=time.perf_counter()-start;start=time.perf_counter()
        any_count=0;npart=len(state['query_s'])
        for particle,t in enumerate(state['query_s']):
            tick=round(float(t)/.005);seconds=max(0.,episode_s-tick*.005)
            j,(selected,passed)=score_approach(ground,curve,state['query_qpos_native'][particle],state['query_velocity_state9'][particle],
                     state['previous_velocity_state9'][particle],seconds,gate_x,gate_side,speed=speed,share_direction_rollouts=True)
            votes=passed[0];any_count+=bool(votes.any())
            records.append(dict(candidate=n,particle=particle,query_tick=tick,exit_forecast_steps=int(seconds/.02),join_index=j,
                      predicted_x_m=float(state['query_qpos_native'][particle,0]),predicted_y_m=float(state['query_qpos_native'][particle,1]),
                      allow_left=bool(votes[0]),allow_straight=bool(votes[1]),allow_right=bool(votes[2]),selected_exit=int(selected[0])))
        ground_s+=time.perf_counter()-start
        score=probability*any_count/npart
        candidates.append(curve);steps.append(dict(candidate=n,iteration=iteration,published=(n==0),alpha=float(alpha),parameters=parameters,
                    p_relock=probability,conditional_particles=npart,particles_with_exit=any_count,score=score))
        return score
    evaluate(canonical,published_alpha,-1,None)
    # The bounds are geometry/alpha search choices for this wiring check, never indexed by the map.
    blocked_before_innovation=(committed_s>route['s'][-1] or
        inp['xy'][min(len(route['s'])-1,np.searchsorted(route['s'],committed_s)),0]>=edge-trigger_before_edge_m)
    for i in range(iterations if not blocked_before_innovation else 0):
        draws=np.clip(rng.normal(center,spread,(population,4)),low,high);scores=[]
        if not continuous_alpha:
            draws[:,3]=alpha_levels[np.abs(draws[:,3,None]-alpha_levels).argmin(axis=1)]
        for a in draws:
            start=time.perf_counter();curve,_=generate_reference(canonical,committed_s,edge,trigger_before_edge_m,
                Boundary(edge_y+a[0],edge_h+a[1],a[2]),edge_y,edge_h)
            geom_s+=time.perf_counter()-start;scores.append(evaluate(curve,a[3],i,a.tolist()))
        if np.ptp(scores)>0:
            elite=draws[np.argsort(-np.asarray(scores),kind='stable')[:max(2,population//2)]]
            center=elite.mean(0);spread=np.maximum(elite.std(0),.07*(high-low))
    winner=int(np.argmax([r['score'] for r in steps]))   # preexisting route wins an exact tie
    if steps[winner]['score']<=0:winner=0;decision='all_vetoed_keep_published'
    elif not winner:decision='published_best_or_tied'
    else:decision='new_reference_selected'
    if blocked_before_innovation:decision='commitment_reaches_trigger_keep_published';winner=0
    # The proposal is never a transmitted command. A missed or unspecified deadline keeps the current reference.
    elapsed=time.perf_counter()-t0
    deadline_met=publish_window_s is not None and elapsed<=publish_window_s
    applied=winner if deadline_met else 0
    if not winner:publish_decision=decision
    elif publish_window_s is None:publish_decision='deadline_unspecified_keep_published'
    elif deadline_met:publish_decision='new_reference_eligible_for_publication'
    else:publish_decision='deadline_missed_keep_published'
    log=dict(decision=decision,selected=winner,alpha=steps[winner]['alpha'],candidate_count=len(steps),particles_evaluated=len(records),
             alpha_mode='continuous' if continuous_alpha else 'three_levels',publish_window_s=publish_window_s,
             publish_decision=publish_decision,deadline_met=deadline_met,publishable_candidate=applied,publishable_alpha=steps[applied]['alpha'],
             gate_x_m=gate_x,gate_side=gate_side,committed_s_m=committed_s,threshold='positive estimated joint probability in this CPU wiring example',
             total_s=elapsed,geometry_s=geom_s,jump_and_input_s=forecast_s,ground_s=ground_s,
             candidate_log=steps,particle_log=records)
    return (published if applied==0 else candidates[applied]),steps[applied]['alpha'],log,candidates

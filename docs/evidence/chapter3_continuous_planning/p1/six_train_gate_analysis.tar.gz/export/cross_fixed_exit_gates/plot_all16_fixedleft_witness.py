"""Recorded fixed-left trajectories, one scored gate and all 16 entrance actions at TRAIN root 1251."""
from pathlib import Path
import json,sys
import pandas as pd
import numpy as np
OUT=Path(__file__).resolve().parent;P=OUT.parents[1]
sys.path.insert(0,str(OUT.parent/'train_shared_entry'))
from plot_witness import render

raw=pd.read_csv(P/'export/train/train_00/suffix_index.csv')
raw=raw[(raw.root==1251)&raw.arm.eq('left')].rename(columns={'section':'assigned_section','target_side':'assigned_side','section_x':'assigned_x_m','physical_task_done':'assigned_task_done','hidden_force_N_grouping_only':'force_n'})
cross=pd.read_csv(OUT/'train_00_crossings.csv.gz')
cross=cross[(cross.root==1251)&cross.arm.eq('left')&cross.section.eq('near')&cross.side.eq(1)].rename(columns={'action':'action_slot','force':'force_n','done':'actual_left','cross_s':'near_cross_s','cross_y':'near_cross_y_m','assigned':'target_matches_assigned'})
d=raw.merge(cross.drop(columns=['arm','root','alpha']),on=['lane','force_n','action_slot'],validate='one_to_one')
assert len(d)==48 and d.action_slot.nunique()==16 and d.groupby('action_slot').force_n.apply(lambda f:set(f)=={-5,0,5}).all()
completed=d.verified_relock & d.near_cross_y_m.between(.06,3.9) & d.physical_goal & ~d.physical_wall
assert completed.equals(d.actual_left) and d.target_matches_assigned.equals(d.assigned_section.eq('near')&d.assigned_side.eq(1))
bank=pd.read_csv(P/'actions/action_slots.csv')[['action_slot','role','name']]
d=d.merge(bank,on='action_slot',validate='many_to_one');d['scored_gate_x_m']=12.7
rows=[]
for slot,sub in d.groupby('action_slot',sort=True):
    s=sub.sort_values('force_n');r=s.iloc[0]
    rows.append(dict(action_slot=slot,role=r.role,name=r['name'],alpha=r.alpha,geometry=r.geometry,assigned_section=r.assigned_section,assigned_side=r.assigned_side,
                     scored_section='near',scored_x_m=12.7,scored_side=1,target_matches_assigned=r.target_matches_assigned,
                     success_minus5=int(s.actual_left.iloc[0]),success_zero=int(s.actual_left.iloc[1]),success_plus5=int(s.actual_left.iloc[2]),
                     total_completed=int(s.actual_left.sum()),outcomes=3))
scores=pd.DataFrame(rows)
assert scores.query("role=='legacy_anchor'").total_completed.max()==1 and scores.query("role=='interpolated'").total_completed.max()==3
assert set(scores.query("role=='legacy_anchor' and total_completed==1").action_slot)=={1,4} and scores.query('total_completed==3').action_slot.tolist()==[11]
full=pd.read_csv(OUT/'all_actions.csv.gz');full=full[(full['map']=='train_00')&(full.root==1251)&(full.section=='near')&(full.side==1)].set_index('action')
assert np.array_equal(full.loc[scores.action_slot,'left'].to_numpy(),scores.total_completed)
scores.to_csv(OUT/'train00_1251_fixedleft_all16_scores.csv',index=False)
show=d[d.action_slot.isin([1,11])].sort_values(['action_slot','force_n'])
show['left_trajectory']=show.trajectory
fig=OUT/'train00_1251_nearleft_fixedleft_xy.png'
render(show,json.loads((P/'maps/train_00/world.json').read_text()),(1,11),'训练图 train_00 · 起点 1251 · 固定左出口 · 所有实跑轨迹统一按近左门离线评分',fig)
fields=['map_id','root','action_slot','geometry','alpha','force_n','lane','assigned_section','assigned_x_m','assigned_side',
        'scored_gate_x_m','target_matches_assigned','verified_relock','near_cross_s','near_cross_y_m','physical_goal','physical_wall','termination','assigned_task_done','actual_left','trajectory']
show[fields].to_csv(OUT/'train00_1251_fixedleft_six_sources.csv',index=False)

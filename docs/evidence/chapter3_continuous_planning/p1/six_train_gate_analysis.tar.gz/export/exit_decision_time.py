"""Finite-panel value of observing handback before selecting a fixed left/right route."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd

out = Path(__file__).resolve().parent
tables = []
switches = []
sums = []
for name in sys.argv[1:]:
    folder = out/'train'/name
    pr = pd.read_csv(folder/'prefix_index.csv').sort_values('row').reset_index(drop=True)
    sf = pd.read_csv(folder/'suffix_index.csv')
    y = sf.pivot(index='row', columns='arm', values='physical_task_done').reindex(pr.row)
    meta = sf[sf.arm=='left'].set_index('row').loc[pr.row]
    pr = pr.assign(section_x=meta.section_x.to_numpy(), target_side=meta.target_side.to_numpy(),
                   left=y.left.to_numpy(), right=y.right.to_numpy())
    keys = ['root','action_slot','section_x','target_side']
    grouped = pr.groupby(keys,sort=True)
    assert len(grouped)==192 and len(pr)==576 and pr.cross_suffix_certified.all()
    assert all(set(v)=={-5,0,5} for _,v in grouped.hidden_force_N_grouping_only)
    with np.load(folder/'observed_inputs.npz') as z: observed = [z[k] for k in z.files]
    with np.load(folder/'measured_targets.npz') as z:
        tick = np.where(z['observed_query'], np.rint(z['query_s']/.005), -1).astype(int)
        pose = z['query_qpos_native']
    # At this level even a perfect decision at departure sees identical inputs on all three trials.
    action_observations = set()
    entries = []
    for key, g in grouped:
        ids = g.index.to_numpy()
        assert all(np.array_equal(a[ids],np.broadcast_to(a[ids[0]],a[ids].shape)) for a in observed)
        obs = tuple(a[ids[0]].tobytes() for a in observed) + tuple(key[-2:])
        action_observations.add(obs)
        l, r = g.left.to_numpy(), g.right.to_numpy()
        L,R,B = int((l&~r).sum()),int((r&~l).sum()),int((l&r).sum())
        def optimal_by(labels):
            partitions={}
            for a,b,k in zip(l,r,labels):
                count=partitions.setdefault(k,[0,0]);count[0]+=int(a);count[1]+=int(b)
            return sum(max(count) for count in partitions.values())
        t=tick[ids]
        by_time=optimal_by(t)
        by_state=optimal_by([(int(t[j]),pose[i].tobytes() if t[j]>=0 else None) for j,i in enumerate(ids)])
        start=B+max(L,R); future=B+L+R
        assert start<=by_time<=by_state<=future and not (g.loc[t<0,['left','right']].any(axis=1).any())
        row=dict(map=name,root=key[0],action_slot=key[1],section_x=key[2],target_side=key[3],
                 left_only=L,right_only=R,both=B,neither=3-future,starts=3,
                 observed_left=int(l.sum()),observed_right=int(r.sum()),
                 gate_side=int((l if key[3]>0 else r).sum()),opposite_side=int((r if key[3]>0 else l).sum()),
                 best_at_departure=start,best_with_handoff_tick=by_time,best_with_tick_and_pose=by_state,
                 best_with_outcomes=future,possible_gain=min(L,R))
        entries.append(row)
        if min(L,R):
            switches.append(sf[sf.row.isin(g.row)])
    assert len(action_observations)==len(entries)
    df=pd.DataFrame(entries);tables.append(df)
    keep = len(df)//4
    allowed = int(df.best_with_outcomes.nlargest(keep).sum())
    sums.append(dict(map=name,root_actions=len(df),groups_requiring_switch=int(df.possible_gain.gt(0).sum()),
                     admitted_at_25pct=3*keep, max_feasible_at_25pct=allowed, min_false_feasible_at_25pct=3*keep-allowed,
                     **df.iloc[:,5:].sum().to_dict()))
dest=out/'exit_decision_time';dest.mkdir(exist_ok=True)
pd.concat(tables).to_csv(dest/'by_root_action.csv',index=False)
pd.DataFrame(sums).to_csv(dest/'by_map.csv',index=False)
pd.concat(switches).to_csv(dest/'switching_cases.csv',index=False)
print(pd.DataFrame(sums)[['map','gate_side','best_at_departure','best_with_handoff_tick','best_with_tick_and_pose','best_with_outcomes','groups_requiring_switch']].to_string(index=False))

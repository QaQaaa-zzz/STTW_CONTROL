"""Show actual and reference paths for all three pushes in the first observed switching group."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

base=Path(__file__).resolve().parents[1]
out=base/'export/exit_decision_time'
data=pd.read_csv(out/'switching_cases.csv')
first=data.sort_values(['map_id','root','action_slot']).iloc[0]
rows=data[(data.map_id==first.map_id)&(data.root==first.root)&(data.action_slot==first.action_slot)]
world=json.loads((base/'maps'/first.map_id/'world.json').read_text())
plt.rcParams.update({'font.family':'Noto Sans CJK JP','axes.unicode_minus':False,'font.size':10})
fig,axs=plt.subplots(3,1,figsize=(11.2,6),sharex=True,sharey=True)
fig.subplots_adjust(top=.83,bottom=.16,hspace=.63,left=.095,right=.965)
colors={'left':'#007774','right':'#b24822'}
reasons={'forbidden_obstacle_contact':'碰墙','tracking_domain_exit':'超出跟踪范围','timeout':'超时','goal':'到终点但错门'}
for ax,(force,group) in zip(axs,rows.groupby('hidden_force_N_grouping_only')):
    labels=[]
    for r in group.sort_values('arm').itertuples():
        arm='左路线' if r.arm=='left' else '右路线'
        labels.append(arm+('完成' if r.physical_task_done else reasons[r.termination]))
        with np.load(r.trajectory) as z:
            tr=z['trace'];ap=z['reference_xy'];ref=z['published_reference_xy']
        xy=tr[:,1:3];join=xy[int(r.assigned_tick),0]
        pre=ap[(ap[:,0]>9.45)&(ap[:,0]<=join)]
        post=ref[(ref[:,0]>=join)&(ref[:,0]<22.3)]
        ax.plot(pre[:,0],pre[:,1],ls=':',lw=1.0,color='#676d70',alpha=.8)
        ax.plot(post[:,0],post[:,1],ls=':',lw=1.0,color=colors[r.arm],alpha=.8)
        ax.plot(xy[:,0],xy[:,1],color=colors[r.arm],lw=2)
        ax.plot(*xy[-1],marker='o' if r.physical_task_done else 'X',color=colors[r.arm],ms=7)
    ax.plot(*tr[round(r.native_handoff_s/.005),1:3],marker='D',ms=5,mfc='white',mec='#4d3d6a')
    for x0,x1,y0,y1 in world['terrain']['forbidden_rectangles']:
        ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,color='#7a4536',zorder=0))
    goal=world['goal']
    ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],fc='#dcecd9',zorder=0))
    side=r.target_side
    ax.plot([r.section_x,r.section_x],[side*.06,side*.58],color='#546898',lw=2)
    ax.set(xlim=(9.45,22.3),ylim=(-.69,.69),aspect='equal',ylabel='横向 y (m)')
    ax.grid(color='#d8dbdc',lw=.5)
    ax.set_title(('横推 %+d N'%force if force else '无横推')+'     '+ '，'.join(labels),loc='left',fontsize=11)
axs[-1].set_xlabel('前进方向 x (m)')
fig.suptitle(f'同一个起点 {first.root}、接近动作 {first.action_slot}、同一道左门',fontsize=16,y=.975)
fig.text(.5,.906,'三行是三种横推条件。每行两辆车落稳前的动作相同，图中放大台阶附近至各自终点。',ha='center')
legend=[Line2D([],[],color=col,lw=2,label=n) for n,col in [('实走左路线',colors['left']),('实走右路线',colors['right'])]]
legend.extend([Line2D([],[],ls=':',color='#555',label='参考路线'),Line2D([],[],ls='',marker='D',mfc='white',mec='#4d3d6a',label='落稳'),Line2D([],[],ls='',marker='o',color='#555',label='任务完成'),Line2D([],[],ls='',marker='X',color='#555',label='失败终点'),Line2D([],[],color='#546898',lw=2,label='指定门侧')])
legend.extend([Rectangle((0,0),1,1,fc='#7a4536',label='墙'),Rectangle((0,0),1,1,fc='#dcecd9',label='目标区')])
fig.legend(handles=legend,loc='lower center',ncol=9,frameon=False,fontsize=9)
fig.savefig(out/'same_gate_three_pushes.png',dpi=175)
plt.close(fig)

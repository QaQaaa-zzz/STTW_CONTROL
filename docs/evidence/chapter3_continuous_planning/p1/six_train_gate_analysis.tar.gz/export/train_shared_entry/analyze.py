"""TRAIN same-root/same-instructed-gate entrance capacity under an unknown, equiprobable three-push treatment."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
P=OUT.parents[1]
G=['map_id','root','section','target_side']; X=G+['action_slot']
catalog=pd.read_csv(P/'actions/action_slots.csv').set_index('action_slot')
maps=sorted(d for d in (P/'export/train').glob('train_*') if (d/'export_receipt.json').is_file())
raw=[]
for d in maps:
    rec=json.loads((d/'export_receipt.json').read_text())
    assert rec['role']=='train' and rec['stage']=='complete' and rec['prefixes']==576 and not rec['benchmark_only']
    left0=pd.read_csv(d/'prefix_index.csv')
    with np.load(d/'observed_inputs.npz') as z:
        for k in ('t0_qpos_native','t0_qvel_native','t0_velocity_state9'):
            a=z[k]
            for ix in left0.groupby('root').indices.values():assert np.array_equal(a[ix],np.broadcast_to(a[ix[0]],a[ix].shape))
    sf=pd.read_csv(d/'suffix_index.csv')
    for row,ss in sf.groupby('row',sort=True):
        a,b=(ss.set_index('arm').loc[arm] for arm in ('left','right'))
        assert all(a[k]==b[k] for k in G+['action_slot','alpha','geometry','hidden_force_N_grouping_only','section_x'])
        pr=left0.iloc[row];assert pr.row==row and pr.lane==a.lane and pr.right_lane==b.lane
        success=lambda v:bool(v.verified_relock and v.correct_gate and v.physical_goal and not v.physical_wall)
        left,right=success(a),success(b);assert left==bool(a.physical_task_done) and right==bool(b.physical_task_done)
        cert=bool(pr.cross_suffix_certified);eligible=bool(a.verified_relock and a.observed_query)
        lo=int(left or (cert and right));hi=int(bool(lo) or (eligible and not cert))
        if not eligible:lo=hi=int(left)
        raw.append(dict(**{k:a[k] for k in G+['section_x','action_slot','geometry','alpha']},force_n=a.hidden_force_N_grouping_only,
                        family=catalog.loc[a.action_slot,'role'],name=catalog.loc[a.action_slot,'name'],primary_relock=a.verified_relock,
                        actual_left=left,actual_right_replica=right,matched_right=cert,any_exit_lo=lo,any_exit_hi=hi,
                        left_trajectory=a.trajectory,right_trajectory=b.trajectory,left_termination=a.termination,right_termination=b.termination))
raw=pd.DataFrame(raw);raw.to_csv(OUT/'physical_evidence.csv',index=False)
actions=[];groups=[]
for k,d in raw.groupby(X,sort=True):
    d=d.sort_values('force_n');assert d.force_n.tolist()==[-5,0,5] and d.alpha.nunique()==1 and d.geometry.nunique()==1
    a=d.iloc[0];v={**dict(zip(X,k)),**{f:a[f] for f in ('geometry','alpha','section_x','family','name')},'force_count':3}
    for i,r in enumerate(d.itertuples()):
        force=('minus5','zero','plus5')[i]
        v['outcome_'+force]='LR' if r.actual_left and r.actual_right_replica and r.matched_right else 'L' if r.actual_left else 'R' if r.actual_right_replica and r.matched_right else '?' if r.any_exit_hi else '-'
    v.update(success_count_lo=int(d.any_exit_lo.sum()),success_count_hi=int(d.any_exit_hi.sum()),relocks=int(d.primary_relock.sum()),
             left_fixed_success=int(d.actual_left.sum()),right_fixed_success_lo=int((d.actual_right_replica&d.matched_right).sum()))
    actions.append(v)
action=pd.DataFrame(actions);action.to_csv(OUT/'per_entry.csv',index=False)
for k,d in action.groupby(G,sort=True):
    old=d[d.family.eq('legacy_anchor')];new=d[d.family.eq('interpolated')];assert len(d)==4 and len(old) in (1,2) and len(old)+len(new)==4
    v={**dict(zip(G,k)),'old_n':len(old),'new_n':len(new),'n_hidden_pushes':3,'old_slots':','.join(map(str,old.action_slot)),'new_slots':','.join(map(str,new.action_slot))}
    for side,g in [('old',old),('new',new),('expanded',d)]:
        for term in ['lo','hi']:v[side+'_'+term]=int(g['success_count_'+term].max())
        v[side+'_best_lower_slots']=','.join(str(i) for i in g.loc[g.success_count_lo==v[side+'_lo'],'action_slot'])
    v['extra_lo']=max(0,v['new_lo']-v['old_hi']);v['extra_hi']=max(0,v['new_hi']-v['old_lo'])
    v['new_only_minus_old_lo']=v['new_lo']-v['old_hi'];v['new_only_minus_old_hi']=v['new_hi']-v['old_lo']
    groups.append(v)
groups=pd.DataFrame(groups);groups.to_csv(OUT/'root_gate_results.csv',index=False)
def total(x):
    lo,hi=(int(x['extra_'+f].sum()) for f in ('lo','hi'))
    return dict(roots=x.root.nunique(),root_gates=len(x),push_denominator=3*len(x),
                old_lo=int(x.old_lo.sum()),old_hi=int(x.old_hi.sum()),expanded_lo=int(x.expanded_lo.sum()),expanded_hi=int(x.expanded_hi.sum()),
                new_only_lo=int(x.new_lo.sum()),new_only_hi=int(x.new_hi.sum()),added_lo=lo,added_hi=hi,
                gain_pp_lo=100*lo/(3*len(x)),gain_pp_hi=100*hi/(3*len(x)),strict_wins=int(x.extra_lo.gt(0).sum()),
                new_only_strict_losses=int(x.new_only_minus_old_hi.lt(0).sum()),ties=int(((x.new_lo==x.new_hi)&(x.old_lo==x.old_hi)&(x.old_lo==x.new_lo)).sum()))
aggregate=[]
for k,g in groups.groupby(['map_id']):aggregate.append(dict(scope='map',map_id=k[0],**total(g)))
for (sec,side),g in groups.groupby(['section','target_side']):aggregate.append(dict(scope='gate',section=sec,target_side=side,**total(g)))
for (mapid,sec,side),g in groups.groupby(['map_id','section','target_side']):aggregate.append(dict(scope='map_gate',map_id=mapid,section=sec,target_side=side,**total(g)))
aggregate.append(dict(scope='all',**total(groups)));pd.DataFrame(aggregate).to_csv(OUT/'summary_by_map_gate.csv',index=False)
circuits=action.groupby(['map_id','action_slot','family','section','target_side']).root.nunique().rename('distinct_roots').reset_index()
circuits.to_csv(OUT/'slot_gate_coverage.csv',index=False)
print(pd.DataFrame(aggregate).query("scope in ['map','all']").to_string(index=False));print('witness options')
print(groups.query('extra_lo>=2').sort_values(['old_n','extra_lo','map_id','root'],ascending=[False,False,False,True]).head(8).to_string(index=False))
print('certified',raw.matched_right.sum(),'of',len(raw))
# Count-matched comparisons on the physically assigned gate. Preserve ties and cancellations within a root.
details=[]; key_groups={k:d for k,d in raw.groupby(G,sort=False)}
for keys,cell in action.groupby(G,sort=True):
    cell=cell.sort_values('action_slot')
    o=cell[cell.family.eq('legacy_anchor')];n=cell[cell.family.eq('interpolated')]
    candidates=key_groups[keys].pivot(index='force_n',columns='action_slot',values='any_exit_lo').sort_index()
    exact=cell.success_count_lo.eq(cell.success_count_hi).all()
    item=dict(zip(G,keys));item.update(old_n=len(o),new_n=len(n),fully_identified=exact)
    for label,panel in [('old',o),('new',n)]:
        for j,entry in enumerate(panel.itertuples(),1):
            item[f'{label}_{j}_slot']=entry.action_slot
            item[f'{label}_{j}_score_lo']=entry.success_count_lo
            item[f'{label}_{j}_score_hi']=entry.success_count_hi
        item[label+'_uniform_count_lo']=float(panel.success_count_lo.mean());item[label+'_uniform_count_hi']=float(panel.success_count_hi.mean())
        item[label+'_best_count_lo']=panel.success_count_lo.max();item[label+'_best_count_hi']=panel.success_count_hi.max()
    if exact:
        old_w=o.loc[o.success_count_lo.eq(o.success_count_lo.max()),'action_slot'].tolist()
        new_w=n.loc[n.success_count_lo.eq(n.success_count_lo.max()),'action_slot'].tolist()
        changes=[(i,j,int((candidates[j]>candidates[i]).sum()),int((candidates[j]<candidates[i]).sum())) for i in old_w for j in new_w]
        i,j,gain,loss=changes[0]
        item.update(old_lowest_tied_slot=i,new_lowest_tied_slot=j,identity_tied=len(changes)>1,
                    per_push_rescued=gain,per_push_lost=loss,rescued_tie_min=min(v[2] for v in changes),rescued_tie_max=max(v[2] for v in changes),
                    lost_tie_min=min(v[3] for v in changes),lost_tie_max=max(v[3] for v in changes))
    details.append(item)
exact_table=pd.DataFrame(details);exact_table.to_csv(OUT/'count_matched_per_root_gate.csv',index=False)
equal=[]
for group_fields in [['old_n'],['map_id','old_n'],['section','target_side','old_n']]:
    for k,block in exact_table.groupby(group_fields,sort=True):
        if not isinstance(k,tuple):k=(k,)
        row=dict(zip(group_fields,k));row.update(scope='_'.join(group_fields),root_gates=len(block),pushes=3*len(block),all_known=block.fully_identified.all())
        for key in block.columns:
            if key.endswith(('_score_lo','_score_hi','_count_lo','_count_hi','_tie_min','_tie_max')) or key in ('per_push_rescued','per_push_lost','identity_tied'):
                if block[key].notna().all():row[key]=round(float(block[key].sum()),6)
        delta=block.new_best_count_lo-block.old_best_count_lo
        row.update(best_net_fixed_count=int(delta.sum()),positive_group_delta=int(delta.clip(lower=0).sum()),negative_group_delta=int(-delta.clip(upper=0).sum()),
                   best_new_wins=int((delta>0).sum()),best_new_losses=int((delta<0).sum()),best_ties=int((delta==0).sum()),
                   old_union_new_expanded_success=int(block[['old_best_count_lo','new_best_count_lo']].max(axis=1).sum()))
        equal.append(row)
pd.DataFrame(equal).to_csv(OUT/'count_matched_summary.csv',index=False)

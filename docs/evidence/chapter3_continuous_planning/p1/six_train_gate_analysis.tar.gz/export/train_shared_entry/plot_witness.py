"""Real XY on the same gate with the same fixed left departure, three unknown push cases."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from matplotlib import use
use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
OUT=Path(__file__).resolve().parent

def render(d,world,slots,title,output):
    plt.rcParams.update({'font.family':'Noto Sans CJK JP','font.size':10,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False})
    fig,axs=plt.subplots(3,2,figsize=(13,6.3),gridspec_kw={'width_ratios':[2.6,1.25]})
    first,second=slots
    colors={first:'#A03F13',second:'#07648C'}
    for j,force in enumerate([-5,0,5]):
        dd=d[d.force_n.eq(force)]
        for col,ax in enumerate(axs[j]):
            ax.set_aspect('equal',adjustable='box')
            ax.set_xlim((1,18.65) if col==0 else (9.9,13.7));ax.set_ylim((-.85,.95) if col==0 else (-.68,.83))
            ax.axvline(world['terrain']['front_x_m'],color='#686868',linewidth=.7,ls=':')
            ax.plot([12.7,12.7],[.06,3.9],color='#41834B',lw=2.2,alpha=.8)
            for x1,x2,y1,y2 in world['terrain']['forbidden_rectangles']:
                ax.add_patch(Rectangle((x1,y1),x2-x1,y2-y1,facecolor='#433C44',edgecolor='none'))
            goal=world['goal']
            ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],facecolor='#DDEBDC',edgecolor='none',zorder=-1))
            for r in dd.itertuples():
                color=colors[r.action_slot]
                with np.load(r.left_trajectory) as z:
                    tr=z['trace'];ref=z['published_reference_xy']
                    ax.plot(ref[:,0],ref[:,1],color=color,lw=1.0,ls='--',alpha=.8)
                    ax.plot(tr[:,1],tr[:,2],color=color,lw=1.55,zorder=4)
                    ax.scatter(*tr[-1,1:3],marker='o' if r.actual_left else 'x',s=31,zorder=6,color=color)
            ax.set_yticks([-.5,0,.5]);ax.set_ylabel('y (m)')
            if j==2:ax.set_xlabel('x (m)')
            if col==0:ax.text(.01,.95,'横推 '+('0' if force==0 else f'{force:+d}')+' N',transform=ax.transAxes,va='top',fontsize=10)
            ax.grid(alpha=.12,lw=.5)
    axs[0,0].set_title('全程 XY',loc='left',fontsize=11)
    axs[0,1].set_title('台阶至近左门局部',loc='left',fontsize=11)
    fig.subplots_adjust(left=.055,right=.99,top=.795,bottom=.09,hspace=.48,wspace=.18)
    fig.suptitle(title,y=.975,fontsize=15)
    symbols=[Line2D([],[],color=colors[first],label=f'旧入口 {first}'),Line2D([],[],color=colors[second],label=f'新入口 {second}'),Line2D([],[],color='#444',ls='--',label='控制器最后所持参考'),
             Line2D([],[],color='#444',marker='x',ls='',label='任务未完成的终点'),Line2D([],[],color='#444',marker='o',ls='',label='任务完成的终点'),Line2D([],[],color='#41834B',lw=2,label='近左门有效部分')]
    fig.legend(handles=symbols,loc='upper center',bbox_to_anchor=(.5,.92),ncol=6,frameon=False,fontsize=9)
    fig.savefig(output,dpi=160,facecolor='white')
    plt.close(fig)

if __name__=='__main__':
    data=pd.read_csv(OUT/'physical_evidence.csv')
    d=data[(data.map_id=='train_04')&(data.root==1305)&(data.section=='near')&(data.target_side==1)&data.action_slot.isin([1,13])]
    world=json.loads((OUT.parents[1]/'maps/train_04/world.json').read_text())
    render(d,world,(1,13),'训练图 train_04 · 起点 1305 · 近左门 · 落地后都固定走左出口',OUT/'train04_1305_same_gate_xy.png')
    d.to_csv(OUT/'train04_1305_witness_sources.csv',index=False)

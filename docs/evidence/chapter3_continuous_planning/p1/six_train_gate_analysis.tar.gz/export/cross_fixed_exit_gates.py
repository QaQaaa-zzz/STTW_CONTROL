"""Re-score the same two gate-independent physical routes at both sides of both registered sections."""
from itertools import combinations
from pathlib import Path
import json, sys
import numpy as np
import pandas as pd

root=Path(__file__).resolve().parents[1]
work=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path.insert(0,str(work/'learning/cli'))
from run_playground_task_reversal import crossings_by_section

dest=root/'export/cross_fixed_exit_gates';dest.mkdir(exist_ok=True)
all_options=[];tasks=[];identities=[]
subsets=np.asarray(list(combinations(range(11),5)))
for name in sys.argv[1:]:
    folder=root/'export/train'/name
    sf=pd.read_csv(folder/'suffix_index.csv')
    cfg=json.loads((root/'batches'/name/'config.json').read_text())
    assert {v['planner'] for v in cfg['ground_handoff']['handoff_variants']}=={'C'}
    assert sf.suffix_pair_status.str.startswith('matched_').all()
    issued=sf.assigned_tick.ge(0)
    assert sf.loc[issued,'online_selected_direction'].eq(sf.loc[issued,'declared_direction']).all()
    rows=[]
    for r in sf.itertuples(index=False):
        with np.load(r.trajectory) as z:tr=z['trace']
        crossings=list(crossings_by_section(tr,r.native_handoff_s if pd.notna(r.native_handoff_s) else np.inf,[12.7,13.6,15.]))
        for section,x,t,y in [crossings[0],crossings[2]]:
            for side in [1,-1]:
                correct=y is not None and .06<=y*side<=3.9
                done=bool(r.verified_relock and correct and r.physical_goal and not r.physical_wall)
                original=section==r.section and side==r.target_side
                if original:
                    assert correct==r.correct_gate and done==r.physical_task_done
                rows.append(dict(map=name,root=r.root,action=r.action_slot,alpha=r.alpha,force=r.hidden_force_N_grouping_only,arm=r.arm,
                                 lane=r.lane,section=section,side=side,assigned=original,done=done,cross_y=y,cross_s=t))
    re=pd.DataFrame(rows)
    re.to_csv(dest/(name+'_crossings.csv.gz'),index=False)
    assert re.assigned.sum()==len(sf) and len(re)==4*len(sf)
    both=re.pivot(index=['root','section','side','action','force'],columns='arm',values='done')
    both['either']=both.left|both.right
    both['toward']=np.where(both.index.get_level_values('side')==1,both.left,both.right)
    opts=both.groupby(['root','section','side','action']).sum().reset_index()
    opts['one_side_at_departure']=opts[['left','right']].max(axis=1)
    opts['map']=name;all_options.append(opts)
    for (bank,section,side),g in opts.groupby(['root','section','side']):
        g=g.sort_values('action').reset_index(drop=True)
        assert g.action.tolist()==list(range(16))
        for policy in ('toward','one_side_at_departure','either'):
            v=g[policy].to_numpy(dtype=int);old=v[:5];new=v[5:]
            oi=int(old.argmax());ni=int(new.argmax()+5);ei=int(v.argmax())
            tasks.append(dict(map=name,root=bank,section=section,side=side,post_policy=policy,draws=3,
                              old_score=int(old.max()),new_score=int(new.max()),union_score=int(v.max()),
                              expected_five_new_score=float(new[subsets].max(axis=1).mean()),
                              old_slot=oi,new_slot=ni,union_slot=ei))
    identities.append(dict(map=name,physical_records=len(sf),assigned_labels_exact=int(re.assigned.sum()),
                      offline_gate_labels=len(re),published_directions_checked=int(issued.sum()),
                      roots=sf.root.nunique(),distinct_input_gates=4,extra_physics=0))
jobs=pd.DataFrame(tasks)
jobs.to_csv(dest/'tasks.csv',index=False);pd.concat(all_options).to_csv(dest/'all_actions.csv.gz',index=False)
summary=[]
for (name,policy),t in jobs.groupby(['map','post_policy']):
    delta=t.new_score-t.old_score
    summary.append(dict(map=name,post_policy=policy,groups=len(t),task_pushes=int(t.draws.sum()),
        old_five=int(t.old_score.sum()),new_eleven=int(t.new_score.sum()),all_sixteen=int(t.union_score.sum()),
        equal_five_new_expected=t.expected_five_new_score.sum(),union_gain=int((t.union_score-t.old_score).sum()),
        new_wins=int((delta>0).sum()),old_wins=int((delta<0).sum()),tie=int((delta==0).sum())))
s=pd.DataFrame(summary)
s.to_csv(dest/'by_map.csv',index=False)
pd.DataFrame(identities).to_csv(dest/'replay.csv',index=False)
factors=[]
for (name,bank,section,side),g in pd.concat(all_options).groupby(['map','root','section','side']):
    for policy in ('toward','one_side_at_departure','either'):
        v=g.set_index('action')[policy]
        factors.append(dict(map=name,root=bank,section=section,side=side,post=policy,shared_s1=int(v[1]),
            fixed_alpha_zero_change_curve=int(v.loc[[0,1,2]].max()),fixed_curve_left_change_alpha=int(v.loc[[1,3,4]].max()),
            all_old=int(v.loc[range(5)].max())))
pd.DataFrame(factors).to_csv(dest/'old_controlled_factors.csv',index=False)
print(s[s.post_policy=='either'].to_string(index=False))

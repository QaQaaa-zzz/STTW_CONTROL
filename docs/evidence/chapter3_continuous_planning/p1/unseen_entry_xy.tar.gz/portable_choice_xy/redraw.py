"""Draw one registered map/start/gate page from the portable archive alone."""
from pathlib import Path
from functools import lru_cache
import json,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle


def main(page):
    root=Path(__file__).resolve().parent
    pages=pd.read_csv(root/'choice_xy/index.csv')
    matches=pages[pages.png.eq(page+'.png')]
    if matches.empty:raise ValueError('Page name must occur in choice_xy/index.csv (without .png).')
    tag=matches.iloc[0]
    choices=pd.read_csv(root/'choice_xy/selected_sources.csv.gz')
    choices=choices[(choices.root==tag.root)&(choices.map_id==tag.map_id)&(choices.gate_x==tag.gate_x)&(choices.side==tag.side)]
    world=json.loads((root/'world'/f'{tag.map_id}.json').read_text())
    wall=world['terrain']['forbidden_rectangles'];goal=world['goal']
    colors=['#0069a5','#bf5200','#00815d','#9a467e','#74549a','#887000','#ab353d','#007484']
    @lru_cache(maxsize=64)
    def ref(ref_id):return np.load(root/'references'/f'{ref_id}.npy')
    fig,axes=plt.subplots(3,1,figsize=(12,7.3),layout='constrained')
    fig.suptitle(f'{tag.map_id}   start {tag.root}   {"left" if tag.side>0 else "right"} gate at x = {tag.gate_x:g} m')
    for ax,force in zip(axes,[-5,0,5]):
        lines=choices[choices.force==force].drop_duplicates(['path']).sort_values('action_slot')
        for r in lines.itertuples():
            with np.load(root/r.path,allow_pickle=False) as z:
                x,y=z['xy'].T; phase=z['phase'];ticks=z['ref_tick'];ids=z['ref_id']
            ax.plot(x,y,c=colors[r.action_slot],lw=1.4,label=f'C{r.action_slot} · {r.terminal}')
            for j,begin in enumerate(ticks):
                stop=int(ticks[j+1]) if j+1<len(ticks) else len(x)
                valid=np.isin(phase[begin:stop],(0,2))&np.isfinite(x[begin:stop])&np.isfinite(y[begin:stop])
                for a,b in np.flatnonzero(np.diff(np.r_[False,valid,False])).reshape(-1,2)+begin:
                    rr=ref(str(ids[j]));lo,hi=np.clip([min(x[a:b]),max(x[a:b])],rr[0,0],rr[-1,0])
                    inside=rr[(rr[:,0]>lo)&(rr[:,0]<hi)]
                    ends=np.interp([lo,hi],rr[:,0],rr[:,1]);pts=np.vstack(([lo,ends[0]],inside,[hi,ends[1]]))
                    ax.plot(*pts.T,c=colors[r.action_slot],lw=1.15,ls=':')
            finite=np.isfinite(x)&np.isfinite(y)
            if finite.any():ax.plot(x[finite][-1],y[finite][-1],marker='o' if r.known and r.lower else 'x',c=colors[r.action_slot])
        ax.axvline(world['terrain']['front_x_m'],ls=':',color='#777')
        ax.vlines(tag.gate_x,tag.side*.06,tag.side*3.9,color='#795d8c',lw=1.6)
        for xmin,xmax,ymin,ymax in wall:ax.add_patch(Rectangle((xmin,ymin),xmax-xmin,ymax-ymin,fc='#6b584c',alpha=.6))
        ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],fc='#bfd8bd',alpha=.5))
        ax.set(xlabel='World x (m)',ylabel='World y (m)',title=f'{force:+d} N')
        ax.set_aspect('equal',adjustable='box');ax.autoscale_view()
        ax.legend(loc='upper left',bbox_to_anchor=(1,1),fontsize=8,frameon=False)
    fig.savefig(root/'choice_xy'/(page+'.png'),dpi=130)
if __name__=='__main__':main(sys.argv[1])

import hashlib,json,sys,time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import torch

out=Path(__file__).resolve().parent
p=out.parents[4]
src=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src')
sys.path[:0]=[str(p/'model'),str(p/'export'),str(src)]
from run_downstream_dev import decision_rows,SEED as PARTICLE_SEED
from jump_outcome import JumpOutcome,DIM,decode_target
from frozen_exit_value import FrozenExits
from sttw_control.playground_history_model import GroundPredictionState

torch.set_num_threads(1)
key=['map_id','root','gate_x','side']
start=time.process_time()
w=p/'model/formal_fit/seed_61123/mixture3.pt'
state=torch.load(w,map_location='cpu',weights_only=True)
net=JumpOutcome(state['input_width'],'mixture3',state['width'])
net.load_state_dict(state['state']); net.eval()
draws=np.random.default_rng(PARTICLE_SEED)
strata=(np.arange(8)+draws.random(8))/8
quantiles=torch.tensor(draws.permutation(strata),dtype=torch.float32)
noise=torch.tensor(draws.normal(size=(8,DIM)),dtype=torch.float32)
np.savez(out/'common_draws.npz',quantiles=quantiles.numpy(),noise=noise.numpy())
short=pd.read_csv(out.parent/'shortlist_before_ground.csv')
jobs=[]; rollouts=0
for name,group in short.groupby('map_id',sort=False):
    data,_=decision_rows(p/'export/dev'/name,False)
    keys=set(zip(group.root,group.action_slot))
    selected=data.subset(np.flatnonzero([tuple(pair) in keys for pair in data.index[['root','action_slot']].values]))
    with torch.inference_mode():
        logits,logw,center,scale=net(selected.x)
        nominal=logits.sigmoid()
        cdf=logw.exp().cumsum(-1).contiguous()
        modes=torch.searchsorted(cdf,quantiles.expand(len(selected.x),-1).contiguous()).clamp_max(2)
        lane=torch.arange(len(selected.x))[:,None]
        latent=center[lane,modes]+scale[lane,modes]*noise[None]
        predicted=decode_target(selected.q0[:,None,:],latent*net.y_scale+net.y_center)
    positions={(r.root,r.action_slot):i for i,r in enumerate(selected.index.itertuples())}
    engine=FrozenExits(p/'batches'/name/'physical',device='cpu')
    assert abs(engine.query.margin-.05330585315823555)<1e-10
    # Native choose expects three branch columns. All three contain precisely the requested
    # same geometry; predict its ground dynamics once and expand the duplicate references.
    model=engine.query.model
    def one_per_lane(state,s,xy,h,k,steps,req):
        global rollouts
        rollouts+=len(xy)//3
        take=slice(None,None,3)
        origin=GroundPredictionState(state.pose[take],state.velocity[take],state.previous_velocity[take],state.hidden[take])
        f=model.rollout_state(origin,s,xy[take],h[take],k[take],steps,req[take])
        return {k:f[k].repeat_interleave(3,0) for k in ('pose','velocity','domain')}
    engine.query.model=SimpleNamespace(rollout_state=one_per_lane,nominal=model.nominal)
    local=[]
    for r in group.itertuples():
        i=positions[r.root,r.action_slot]
        key_names={'q':'query_qpos_native','v':'query_velocity_state9','prev':'previous_velocity_state9'}
        for j in range(8):
            pp={k:predicted[name][i,j].numpy() for k,name in key_names.items()}
            t=float(predicted['query_s'][i,j])
            seconds=max(0.,10.-round(t/.005)*.005)
            direction=0 if r.side==1 else 2
            rid=int(engine.branch_ids(r.geometry,pp['q'])[direction])
            local.append(dict(map_id=name,root=r.root,action_slot=r.action_slot,geometry=r.geometry,alpha=r.alpha,incumbent=r.incumbent,gate_x=r.gate_x,side=r.side,p_relock=float(nominal[i]),draw=j,mode=int(modes[i,j]),predicted_query_s=t,remaining_s=seconds,steps=int(seconds/.02),route_id=rid,particle=pp))
    for _,chunk in pd.DataFrame(local).groupby('steps',sort=True):
        seconds=chunk.remaining_s.iloc[0]
        particles_for_chunk=chunk.particle.tolist()
        args=[engine.tensor(np.stack([p[k] for p in particles_for_chunk])) for k in ('q','v','prev')]
        q,v,prev=args;n=len(q)
        ids=chunk.route_id.values
        route=SimpleNamespace(s=engine.s,**{k:engine.tensor(np.asarray(engine.bank[k][ids])) for k in ('xy','heading','curvature')})
        candidates=torch.arange(n)[:,None].expand(-1,3).contiguous()
        _,passed,inc,reasons=engine.query.choose(q,v[:,0],torch.full((n,),2.),route,candidates,engine.tensor(chunk.gate_x.to_numpy()),engine.tensor(chunk.side.to_numpy()),torch.zeros(n,dtype=torch.long),seconds,v,prev,return_reasons=True)
        assert torch.equal(passed,inc)
        result=chunk.drop(columns='particle').copy()
        for k,val in reasons.items():result[k]=val.numpy()
        result['same_side_feasible']=passed.numpy()
        result['verified_score']=result.p_relock*result.same_side_feasible
        jobs.append(result)
a=pd.concat(jobs).sort_values([*key,'incumbent'],ascending=[True]*4+[False])
assert len(a)==1536 and rollouts==1536
a.to_csv(out/'verified_conditional_particles.csv.gz',index=False)
a=a.groupby(key+['incumbent','action_slot','geometry','alpha','p_relock'],as_index=False).same_side_feasible.agg(['size','sum','mean']).reset_index().rename(columns={'size':'samples','sum':'feasible_count','mean':'feasible_fraction'})
assert len(a)==192 and a.samples.eq(8).all()
a['verified_score']=a.p_relock*a.feasible_fraction
a.to_csv(out/'verified_candidates_before_outcomes.csv',index=False)
choices=[]
for k,g in a.groupby(key):
    fixed=g[g.incumbent].iloc[0];alt=g[~g.incumbent].iloc[0]
    choose=alt.verified_score>fixed.verified_score
    choices.append(dict(zip(key,k))|dict(selected=int(alt.action_slot if choose else fixed.action_slot),fixed=int(fixed.action_slot),alt=int(alt.action_slot),fixed_score=fixed.verified_score,alt_score=alt.verified_score,fixed_feasible_draws=int(fixed.feasible_count),alt_feasible_draws=int(alt.feasible_count)))
final=pd.DataFrame(choices)
final.to_csv(out/'verified_choices.csv',index=False)
identity=lambda file:hashlib.sha256(Path(file).read_bytes()).hexdigest()
receipt=dict(unique_predicted_handoffs=len(short[['map_id','root','action_slot']].drop_duplicates()),candidates=len(a),directional_ground_rollouts=rollouts,chosen=len(final),changed=int((final.fixed!=final.selected).sum()),conditional_particles=8,sample_seed=PARTICLE_SEED,choices_sha256_before_outcomes=identity(out/'verified_choices.csv'),preselection_sha256=identity(out.parent/'shortlist_before_ground.csv'),source_sha256=identity(__file__),checkpoint_sha256=identity(w),cpu_seconds_before_outcomes=time.process_time()-start)
print('Frozen decisions',receipt,flush=True)
# Only saved time-zero choices pass into the independent measured-path join.
final=pd.read_csv(out/'verified_choices.csv')
real=pd.read_csv(p/'actions/amortized_exit/development_entry/physical_conditions.csv.gz')
def physical(method):
    a=final[[*key,method]].rename(columns={method:'action_slot'}).merge(real,on=[*key,'action_slot'],validate='one_to_many')
    assert len(a)==288 and a.groupby(key).force.nunique().eq(3).all()
    return a[[*key,'force','action_slot','known','lower','upper','physical_arm','source_trajectory']].rename(columns={c:method+'_'+c for c in ['action_slot','known','lower','upper','physical_arm','source_trajectory']})
cases=physical('selected').merge(physical('fixed'),on=key+['force'],validate='one_to_one')
same_choice=cases.selected_action_slot==cases.fixed_action_slot
cases['delta_low']=np.where(same_choice,0,cases.selected_lower-cases.fixed_upper)
cases['delta_high']=np.where(same_choice,0,cases.selected_upper-cases.fixed_lower)
for s in ['selected','fixed']:
    cases[s+'_success']=cases[s+'_lower'].astype('Int64').where(cases[s+'_known'])
mean=pd.read_csv(out.parent/'verified_physical_cases.csv',usecols=[*key,'force','selected_action_slot','selected_known','selected_lower','selected_upper']).rename(columns=lambda k:k.replace('selected_','mean_'))
cases=cases.merge(mean,on=key+['force'],validate='one_to_one')
same_as_mean=cases.selected_action_slot==cases.mean_action_slot
cases['relative_to_mean_low']=np.where(same_as_mean,0,cases.selected_lower-cases.mean_upper)
cases['relative_to_mean_high']=np.where(same_as_mean,0,cases.selected_upper-cases.mean_lower)
receipt['against_mean']={'rescues_lower':int((cases.relative_to_mean_low==1).sum()),'rescues_upper':int((cases.relative_to_mean_high==1).sum()),'losses_lower':int((cases.relative_to_mean_high==-1).sum()),'losses_upper':int((cases.relative_to_mean_low==-1).sum()),'net_low':int(cases.relative_to_mean_low.sum()),'net_high':int(cases.relative_to_mean_high.sum())}
cases.to_csv(out/'verified_physical_cases.csv',index=False)
for title,grp in [('all',cases),*cases.groupby('map_id')]:
    receipt[title]={'tasks':len(grp),'selected_lower':int(grp.selected_lower.sum()),'selected_upper':int(grp.selected_upper.sum()),'fixed_lower':int(grp.fixed_lower.sum()),'fixed_upper':int(grp.fixed_upper.sum()),'known_rescues':int((grp.delta_low==1).sum()),'possible_rescues':int((grp.delta_high==1).sum()),'known_losses':int((grp.delta_high==-1).sum()),'possible_losses':int((grp.delta_low==-1).sum()),'net_low':int(grp.delta_low.sum()),'net_high':int(grp.delta_high.sum())}
receipt['cpu_seconds']=time.process_time()-start
(out/'verified_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt,flush=True)

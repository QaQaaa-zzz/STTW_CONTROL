"""Offline sampled obstacle margin on actual successful DEV laps of the two finalists."""
import argparse
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import time

import mujoco
import numpy as np
import pandas as pd
import torch

HERE=Path(__file__).resolve().parent
RUN=HERE.parents[4]
HELPER=HERE.parents[1]/'reference_controls/check.py'
spec=importlib.util.spec_from_file_location('reference_check',HELPER)
control=importlib.util.module_from_spec(spec)
spec.loader.exec_module(control)
KEY=['map_id','root','gate_x','side']

@torch.inference_mode()
def measure(legs):
    passed=legs[legs.lower.eq(1)]
    paths=[]
    for name,frame in passed.groupby('map_id'):
        folder=RUN/'batches'/name/'physical'
        q=control.FrozenExits(folder,device='cpu',load_route_bank=False).query
        assert q.margin==.05330585315823555
        model=mujoco.MjModel.from_binary_path(str(folder/'terrain.mjb'))
        names=[model.geom(i).name or f'geom_{i}' for i in range(model.ngeom) if model.geom_bodyid[i]>0 and (model.geom_contype[i] or model.geom_conaffinity[i])]
        walls=[model.geom(i).name for i in range(model.ngeom) if model.geom(i).name.startswith('planning_obstacle_')]
        meta=pd.read_csv(RUN/'export/dev'/name/'suffix_index.csv').set_index('lane')
        for source,repeated in frame.groupby('source',sort=False):
            first=repeated.iloc[0];lane=meta.loc[first.lane];tick=int(lane.query_tick)
            assert source==lane.trajectory and lane.termination=='goal' and lane.verified_relock and lane.physical_goal and not lane.physical_wall
            assert repeated.xy.nunique()==repeated.lane.nunique()==1 and tick+.0==lane.query_tick
            with np.load(source) as z:
                assert not z['world_flags'][:,2].any() and np.isclose(z['trace'][-1,0],lane.duration_s)
                with np.load(lane.query_file) as obs:
                    assert np.array_equal(obs['qpos'][int(lane.query_file_row)],z['qpos'][tick])
                extra=control.actual_clearance(z,tick,q,names,walls)
            paths.append(dict(map_id=name,root=int(first.root),slot=int(first.slot),lane=int(first.lane),force=int(first.force),
                xy=first.xy,source=source,query_tick=tick,physical_end_s=lane.duration_s,gate_rows=len(repeated),**extra))
    data=pd.DataFrame(paths)
    assert len(data)==passed.source.nunique() and not data.duplicated(['map_id','xy']).any()
    data.to_csv(HERE/'margin_paths.csv',index=False)
    return data

def compare(legs,choices,method):
    selects=pd.read_csv(choices)[KEY+['selected']]
    with_ids=legs.merge(selects,on=KEY,validate='many_to_one')
    ids=KEY+['force']
    base=with_ids[with_ids.incumbent];picked=with_ids[with_ids.slot.eq(with_ids.selected)]
    cols=ids+['slot','gate_success','strict_success','min_clearance_m','source']
    result=base[cols].merge(picked[cols],on=ids,validate='one_to_one',suffixes=('_fixed','_selected'))
    assert len(result)==288
    for kind in ('gate','strict'):
        result[kind+'_rescue']=result[kind+'_success_selected']&~result[kind+'_success_fixed']
        result[kind+'_loss']=~result[kind+'_success_selected']&result[kind+'_success_fixed']
    result.to_csv(HERE/f'margin_{method}_pairs.csv.gz',index=False)
    def summary(x):
        return dict(n=len(x),original_fixed=int(x.gate_success_fixed.sum()),original_selected=int(x.gate_success_selected.sum()),
                    original_rescue=int(x.gate_rescue.sum()),original_loss=int(x.gate_loss.sum()),
                    strict_fixed=int(x.strict_success_fixed.sum()),strict_selected=int(x.strict_success_selected.sum()),
                    strict_rescue=int(x.strict_rescue.sum()),strict_loss=int(x.strict_loss.sum()),
                    prior_rescues_still_rescues=int((x.gate_rescue&x.strict_rescue).sum()),
                    prior_losses_still_losses=int((x.gate_loss&x.strict_loss).sum()),
                    new_strict_rescues=int((~x.gate_rescue&x.strict_rescue).sum()),new_strict_losses=int((~x.gate_loss&x.strict_loss).sum()))
    all_rows=summary(result)
    if method=='mean':
        expected=json.loads((HERE.parent/'verified_physical_summary.json').read_text())['overall']
        assert [all_rows[k] for k in ['original_fixed','original_selected','original_rescue','original_loss']]==[expected[k] for k in ['baseline_lo','selected_lo','rescued','lost']]
    receipt=dict(choices=str(choices),overall=all_rows,by_map_side=[dict(map_id=m,side=s,**summary(g)) for (m,s),g in result.groupby(['map_id','side'])])
    (HERE/f'margin_{method}_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(method,all_rows)

def main():
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('--choices',type=Path,default=HERE.parent/'verified_choices.csv');cli.add_argument('--method',default='mean')
    cli.add_argument('--remeasure',action='store_true');args=cli.parse_args();t=time.process_time();torch.set_num_threads(1)
    legs=pd.read_csv(HERE/'case_legs.csv.gz');assert (legs.known & legs.lower.eq(legs.upper)).all()
    if args.remeasure or not (HERE/'margin_paths.csv').exists():
        paths=measure(legs)
        note=dict(maps=['dev_00','dev_01'],source_path_count=legs.source.nunique(),unique_saved_xy=legs.xy.nunique(),
            passed_task_rows=int(legs.lower.sum()),measured_paths=len(paths),by_map=paths.map_id.value_counts().sort_index().to_dict(),
            required_margin_m=.05330585315823555,distance='Actual first-query qpos (archive snapshot verified) to physical goal frame, both inclusive. Frozen 3D BodyEnvelope over all contact geometries including pendulum. For each primitive and obstacle take the largest signed axis gap; minimum over all box pairs and 5 ms actual poses. A geometrically clear sampled path requires strictly greater than frozen margin. 20 ms aligned minima included per path. No interpolation, continuous-time assertion or new simulation.',
            sampled_5ms_paths_above_margin=int(paths.actual_clearance_gt_frozen_margin.sum()),
            same_20ms_classification=bool(((paths.actual_min_clearance_20ms_m>paths.actual_margin_m)==paths.actual_clearance_gt_frozen_margin).all()),
            helper_sha256=sha256(HELPER.read_bytes()).hexdigest(),single_thread_cpu_s=time.process_time()-t)
        (HERE/'margin_measurement.json').write_text(json.dumps(note,indent=2)+'\n')
    else:paths=pd.read_csv(HERE/'margin_paths.csv')
    legs=legs.merge(paths[['source','actual_min_clearance_m','actual_clearance_gt_frozen_margin']],on='source',how='left',validate='many_to_one')
    legs['gate_success']=legs.lower.eq(1);assert legs.loc[legs.gate_success,'actual_min_clearance_m'].notna().all()
    legs['strict_success']=legs.gate_success & legs.actual_clearance_gt_frozen_margin.eq(True)
    legs=legs.rename(columns={'actual_min_clearance_m':'min_clearance_m'})
    legs[KEY+['incumbent','slot','force','gate_success','strict_success','min_clearance_m','source']].to_csv(HERE/'margin_legs.csv.gz',index=False)
    compare(legs,args.choices,args.method)

if __name__=='__main__':main()

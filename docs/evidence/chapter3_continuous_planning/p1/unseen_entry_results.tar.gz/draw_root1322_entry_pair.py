"""Root 1322, saved physical paths and the references actually active at each position."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from matplotlib.ticker import MultipleLocator

folder=Path(__file__).resolve().parent
pkg=folder.parent
sys.path.insert(0,'/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src')
from draw_choices import read_case,mapped_arrays

meta=pd.read_csv(folder/'entry_menu_by_task.csv.gz')
menu=meta[(meta.root==1322)&(meta.gate_x==12.7)&(meta.side==-1)&meta.target.eq('gate_goal')].iloc[0]
old_id=min(map(int,menu.old16_best_slots_lo.split('|')))
assert old_id==0 and '6' in menu.new8_best_slots_lo.split('|')
old_truth=pd.read_csv(pkg/'actions/amortized_exit/development_entry/physical_conditions.csv.gz')
new_truth=pd.read_csv(folder/'matched_physical_gate_cases.csv.gz')
runs={};data=[]
for label,base,phys,slot,truth in [('Old',pkg/'export/dev/dev_00',pkg/'batches/dev_00/physical',old_id,old_truth),('New',folder/'export/dev/dev_00',folder/'dev_00/physical',6,new_truth)]:
    cf=json.loads((phys/'resolved_config.json').read_text())
    world=json.loads(Path(cf['world_map']).read_text())
    bank=mapped_arrays(cf['paired_departures']['route_bank'])
    with np.load(cf['ground_handoff']['reference_path']) as ref: neutral=ref['xy'][0]
    suffix=pd.read_csv(base/'suffix_index.csv')
    subset=suffix[(suffix.root==1322)&(suffix.action_slot==slot)&suffix.arm.eq('right')]
    truth=truth[(truth.root==1322)&truth.map_id.eq('dev_00')&(truth.action_slot==slot)&(truth.side==-1)&(truth.gate_x==12.7)]
    for row in subset.itertuples():
        assert row.alpha==0
        case=read_case(row,neutral,bank,cf['platform_online']['latency_ticks']['start'])
        x,y=case['xy'].T
        j=np.flatnonzero((x[:-1]<12.7)&(x[1:]>=12.7)&(np.arange(1,len(x))>= (np.inf if case['hand'] is None else case['hand'])))
        gate_y=float(np.interp(12.7,x[j[0]:j[0]+2],y[j[0]:j[0]+2])) if len(j) else np.nan
        success=bool(np.isfinite(gate_y) and -.06>=gate_y>=-3.9 and case['verified'] and case['goal'] and not case['wall'])
        f=int(row.hidden_force_N_grouping_only)
        label0=truth[truth.force==f].iloc[0]
        assert label0.known and success==bool(label0.lower) and label0.lower==label0.upper
        runs[label,f]=case|dict(gate_y=gate_y,success=success)
        data.append(dict(root=1322,map='dev_00',gate_x_m=12.7,gate_right_max_y_m=-.06,entry=label,slot=slot,alpha=row.alpha,force_N=f,verified_relock=case['verified'],gate_y_m=gate_y,success=success,termination=case['terminal'],endpoint_x_m=x[-1],endpoint_y_m=y[-1],active_reference_segments=len(case['pieces']),trajectory=row.trajectory))
assert len(runs)==6 and len({tuple(q['xy'][0]) for q in runs.values()})==1
pd.DataFrame(data).to_csv(folder/'root1322_entry_pair.csv',index=False)
colors={'Old':'#A14520','New':'#006A94'}
fig=plt.figure(figsize=(14.0,7.0),dpi=160,facecolor='white')
fig.text(.062,.956,'An entry change raises near-right gate completion from 1/3 to 3/3',fontsize=19,fontweight='semibold',color='#20323B')
fig.text(.062,.911,'DEV map 00   ·   Start 1322   ·   Same initial pose, jump setting (α = 0) and fixed right exit',fontsize=11,color='#42535B')
leg=[Line2D([],[],color=colors['Old'],lw=2.6,label='Old entry 0'),Line2D([],[],color=colors['New'],lw=2.6,label='New central entry 6'),Line2D([],[],color='#37464d',lw=2.4,label='Actual path'),Line2D([],[],color='#37464d',ls=':',lw=1.4,label='Active ground reference'),Line2D([],[],marker='x',ms=8,mew=2,color='#37464d',ls='',label='Failure'),Line2D([],[],marker='o',ms=6,mfc='white',mec='#37464d',mew=1.5,ls='',label='Goal reached')]
fig.legend(handles=leg,loc='upper left',bbox_to_anchor=(.055,.888),frameon=False,ncol=6,columnspacing=1.55,handlelength=1.8,fontsize=9.4)
fig.text(.062,.797,'Whole run',weight='bold',fontsize=11,color='#273C46')
fig.text(.604,.797,'Gate detail',weight='bold',fontsize=11,color='#273C46')
fig.text(.824,.797,'Measured outcome',weight='bold',fontsize=11,color='#273C46')
for n,f in enumerate((-5,0,5)):
    yc=.690-.220*n
    header=f'{f:+d} N' if f else '0 N'
    fig.text(.013,yc+.018,header,fontsize=10,weight='bold',color='#273C46')
    for zoom,rect in [(False,(.060,yc-.082,.485,.161)),(True,(.585,yc-.086,.192,.176))]:
        ax=fig.add_axes(rect)
        ax.set_aspect('equal',adjustable='box')
        ax.set_xlim((10.05,13.75) if zoom else (.9,18.76))
        ax.set_ylim((-.88,.62) if zoom else (-1.1,1.08))
        ax.add_patch(Rectangle((16.5,-.5),2.,1.,facecolor='#dcefe5',edgecolor='#9ac6ae',lw=.8,zorder=0))
        for a,b,c,d in world['terrain']['forbidden_rectangles']:
            ax.add_patch(Rectangle((a,c),b-a,d-c,fc='#453D39',ec='#302b29',zorder=4))
        ax.axvline(10.3,color='#7c817f',ls='--',lw=.8,zorder=1)
        ax.vlines(12.7,-3.9,-.06,color='#8465A1',lw=2.2,alpha=.83,zorder=1)
        ax.scatter([12.7],[-.06],s=12,c='#8465A1',zorder=4)
        for label in ['Old','New']:
            r=runs[label,f];color=colors[label]
            for part in r['pieces']:
                ax.plot(*part.T,c=color,ls=':',lw=1.4,zorder=2)
            ax.plot(*r['xy'].T,c=color,lw=1.75,zorder=3)
            if zoom and np.isfinite(r['gate_y']):
                ax.plot(12.7,r['gate_y'],marker='s',ls='',ms=4.1,mfc=color,mec='white',mew=.45,zorder=5)
            if r['finite_end']:
                ax.plot(*r['last'],marker='o' if r['success'] else 'x',mfc='white',mec=color,mew=1.6,ms=6,zorder=6)
        for sp in ('top','right'):ax.spines[sp].set_visible(False)
        for sp in ('left','bottom'):ax.spines[sp].set_color('#a9b3b5')
        ax.tick_params(labelsize=8.1,width=.6,length=2,color='#889698',labelcolor='#45565e')
        ax.set_yticks([-.5,0,.5] if zoom else [-1,0,1])
        ax.set_xticks([10.3,11,12,12.7,13.5] if zoom else [2,4,6,8,10,12,14,16,18])
        if n==2:ax.set_xlabel('World x (m)',fontsize=9,labelpad=2)
        if not zoom:ax.set_ylabel('y (m)',fontsize=8.5,labelpad=1)
    for j,label in enumerate(('Old','New')):
        r=runs[label,f];y=yc+.034-j*.069
        if np.isfinite(r['gate_y']):desc=f'Gate y = {r["gate_y"]:.3f} m   ·   Goal'
        else:desc=f'No handback   ·   Ends at x = {r["last"][0]:.2f} m'
        fig.text(.824,y,desc,fontsize=9.2,color=colors[label],va='center')
fig.text(.062,.089,'Dashed vertical line: step edge. Purple segment: required gate at x = 12.70 m, y ≤ −0.06 m. Black rectangle: obstacle. Green area: goal.',fontsize=9,color='#43555d')
fig.text(.062,.050,'Each entry is held fixed across all three pushes. Old entries 0, 7 and 9 tied at 1/3; the lowest index is shown. This comparison uses hindsight to identify available routes.',fontsize=8.8,color='#43555d')
fig.savefig(folder/'root1322_entry_pair.png',dpi=180)

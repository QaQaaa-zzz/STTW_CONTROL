"""Compare frozen P1 choices on identical map/start/gate/push tasks."""
from pathlib import Path
import pandas as pd

folder=Path(__file__).resolve().parent
choices=pd.read_csv(folder/'pre_action_choices.csv')
key=['cohort','map_id','root','gate_x','side']
paired_choices=choices.pivot(index=key,columns='method',values='action_slot')
others=['mean','empirical_action','five_separate_roots']
registered=paired_choices.copy()
for baseline in others:
    registered['different_from_'+baseline]=registered['mixture3'].ne(registered[baseline])
registered.to_csv(folder/'paired_choice_registration.csv')
if __name__=='__main__' and (folder/'selected_cases.csv.gz').exists():
    cases=pd.read_csv(folder/'selected_cases.csv.gz')
    k=key+['force']
    out=[]
    for baseline in others:
        a=cases[cases.method.eq('mixture3')].set_index(k)
        b=cases[cases.method.eq(baseline)].set_index(k)
        frame=a[['action_slot','lower','upper']].join(b[['action_slot','lower','upper']],rsuffix='_base',validate='one_to_one')
        same=frame.action_slot.eq(frame.action_slot_base)
        assert len(frame)==864 and (frame.loc[same,'lower']==frame.loc[same,'lower_base']).all() and (frame.loc[same,'upper']==frame.loc[same,'upper_base']).all()
        frame['difference_lo']=(frame.lower-frame.upper_base).mask(same,0)
        frame['difference_hi']=(frame.upper-frame.lower_base).mask(same,0)
        frame['same_choice']=same
        frame['identified']=frame.difference_lo.eq(frame.difference_hi)
        frame['definite_rescue']=frame.difference_lo.eq(1)
        frame['definite_loss']=frame.difference_hi.eq(-1)
        frame['baseline']=baseline
        out.append(frame.reset_index())
    data=pd.concat(out)
    data.to_csv(folder/'paired_method_cases.csv.gz',index=False)
    for label,group in [('by_root',['cohort','baseline','map_id','root']),('by_gate',['cohort','baseline','map_id','gate_x','side'])]:
        data.groupby(group).agg(tasks=('force','size'),same_choices=('same_choice','sum'),identified=('identified','sum'),rescued=('definite_rescue','sum'),lost=('definite_loss','sum'),net_lo=('difference_lo','sum'),net_hi=('difference_hi','sum')).to_csv(folder/('paired_method_'+label+'.csv'))

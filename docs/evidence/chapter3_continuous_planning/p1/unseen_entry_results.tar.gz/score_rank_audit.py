"""Rank the prospective candidates and score gate outcomes at every release count."""
from pathlib import Path
import argparse

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
GATE = ['map_id', 'gate_x', 'side']
CANDIDATE = GATE + ['root', 'action_slot']
RANK = ['cohort', *GATE, 'method', 'seed']
PAIR_OK = {'matched_observed_handoff', 'matched_observed_prequery_endpoint'}


def rank_candidates(scores):
    parts = []
    for name, table in [('all8', scores), *scores.groupby('kind')]:
        table = table.sort_values(['score', 'root', 'action_slot'], ascending=[False, True, True]).copy()
        table['cohort'] = name
        groups = table.groupby(RANK)
        table['rank'] = groups.cumcount() + 1
        table['candidates'] = groups.score.transform('size')
        table['next_score'] = groups.score.shift(-1)
        table['cutoff_ties'] = table.groupby([*RANK, 'score']).score.transform('size')
        table['cut_splits_ties'] = table.score.eq(table.next_score)
        parts.append(table)
    return pd.concat(parts, ignore_index=True)


def strict_outcomes(truth, arms):
    key = ['map_id', 'root', 'action_slot', 'force', 'side']
    arms = arms.assign(side=arms.arm.map({'left':1, 'right':-1}),
                       force=arms.hidden_force_N_grouping_only)
    data = truth.merge(arms[key+['suffix_pair_status']], on=key, validate='many_to_one')
    assert len(data) == len(truth)
    matched = data.suffix_pair_status.isin(PAIR_OK)
    data['strict_lower'] = data.lower.where(matched, 0)
    data['strict_upper'] = data.upper.where(matched, 1)
    return data


def score_sweep(ranks, truth):
    fields = ['lower', 'upper', 'strict_lower', 'strict_upper']
    options = truth.groupby(CANDIDATE).agg(**{k:(k,'sum') for k in fields}, trials=('force','size')).reset_index()
    rows = ranks.merge(options, on=CANDIDATE, validate='many_to_one').sort_values(RANK+['rank'])
    assert len(rows) == len(ranks) and rows.trials.eq(3).all()
    groups = rows.groupby(RANK)
    rows['admitted_trials'] = groups.trials.cumsum()
    for label in ('', 'strict_'):
        lo, hi = label+'lower', label+'upper'
        hits_lo, hits_hi = groups[lo].cumsum(), groups[hi].cumsum()
        outside_lo = groups[lo].transform('sum') - hits_lo
        outside_hi = groups[hi].transform('sum') - hits_hi
        rows[label+'hits_lo'], rows[label+'hits_hi'] = hits_lo, hits_hi
        rows[label+'false_admission_lo'] = 1 - hits_hi / rows.admitted_trials
        rows[label+'false_admission_hi'] = 1 - hits_lo / rows.admitted_trials
        rows[label+'recall_lo'] = hits_lo / (hits_lo + outside_hi).replace(0,np.nan)
        rows[label+'recall_hi'] = hits_hi / (hits_hi + outside_lo).replace(0,np.nan)
    return rows


def main(measured):
    scores = pd.read_csv(ROOT/'pre_action_scores.csv.gz', float_precision='round_trip')
    ranks = rank_candidates(scores)
    original = pd.read_csv(ROOT/'pre_action_admissions.csv.gz')
    accepted = ranks[ranks['rank'] * 4 <= ranks.candidates]
    k = RANK+['root','action_slot']
    assert set(accepted[k].itertuples(index=False,name=None)) == set(original[k].itertuples(index=False,name=None))
    cut = ranks[ranks['rank'] * 4 == ranks.candidates].copy()
    cut['score_gap'] = cut.score - cut.next_score
    cut.to_csv(ROOT/'prospective_rank_cutoffs.csv',index=False)
    if measured:
        actual = pd.read_csv(ROOT/'real_gate_cases.csv.gz')
        arms = pd.concat([pd.read_csv(ROOT/'export/dev'/m/'suffix_index.csv') for m in scores.map_id.unique()])
        data = strict_outcomes(actual, arms)
        table = score_sweep(ranks, data)
        official = pd.read_csv(ROOT/'admitted_summary.csv')
        same = table[table['rank'] * 4 == table.candidates].merge(official,on=RANK[:-1],validate='one_to_one')
        assert len(same)==len(cut)
        np.testing.assert_array_equal(same.hits_lo,same.success_lo)
        np.testing.assert_array_equal(same.hits_hi,same.success_hi)
        for k in ['lo','hi']:
            np.testing.assert_allclose(same['false_admission_'+k],same['false_admission_rate_'+k])
            np.testing.assert_allclose(same['recall_'+k+'_x'],same['recall_'+k+'_y'],equal_nan=True)
        table.to_csv(ROOT/'matched_rank_sweep.csv.gz',index=False)
        data.to_csv(ROOT/'matched_physical_gate_cases.csv.gz',index=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--measured', action='store_true')
    main(parser.parse_args().measured)

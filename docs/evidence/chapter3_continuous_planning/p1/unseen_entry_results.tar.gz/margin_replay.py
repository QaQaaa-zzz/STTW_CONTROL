"""Apply the frozen obstacle-box margin to completed physical outcomes in the eight-entry DEV batch."""
from hashlib import sha256
import importlib.util
from itertools import combinations
import json
from pathlib import Path
import time

import mujoco
import numpy as np
import pandas as pd
import torch

R=Path(__file__).resolve().parent
P=R.parent
PRE=P/'actions/continuous_examples/continuous_entry_event_exit'
helper=PRE/'reference_controls/check.py'
spec=importlib.util.spec_from_file_location('physical_clearance',helper)
measured=importlib.util.module_from_spec(spec)
spec.loader.exec_module(measured)
ID=['map_id','root','gate_x','side','force']
METHOD=['mixture3','mean','empirical_action','five_separate_roots']
OUTCOMES=['original','margin','matched_margin']

@torch.inference_mode()
def physical(truth):
    records=[]
    for m,subset in truth[truth.lower.eq(1)].groupby('map_id'):
        folder=R/m/'physical'
        q=measured.FrozenExits(folder,device='cpu',load_route_bank=False).query
        assert q.margin==.05330585315823555
        model=mujoco.MjModel.from_binary_path(str(folder/'terrain.mjb'))
        bodies=[model.geom(j).name or f'geom_{j}' for j in range(model.ngeom) if model.geom_bodyid[j]>0 and (model.geom_contype[j] or model.geom_conaffinity[j])]
        walls=[model.geom(j).name for j in range(model.ngeom) if model.geom(j).name.startswith('planning_obstacle_')]
        meta=pd.read_csv(R/'export/dev'/m/'suffix_index.csv').set_index('trajectory')
        for path,g in subset.groupby('path'):
            row=meta.loc[path];tick=int(row.query_tick)
            assert row.verified_relock and row.physical_goal and not row.physical_wall and row.physical_target_effective
            with np.load(path) as raw, np.load(row.query_file) as obs:
                j=int(row.query_file_row)
                assert int(obs['lanes'][j])==row.lane and np.array_equal(obs['qpos'][j],raw['qpos'][tick])
                assert not raw['world_flags'][:,2].any() and np.isclose(raw['trace'][-1,0],row.duration_s)
                detail=measured.actual_clearance(raw,tick,q,bodies,walls)
            records.append(dict(map_id=m,root=row.root,action_slot=row.action_slot,force=row.hidden_force_N_grouping_only,
                    arm=row.arm,lane=row.lane,path=path,gate_rows=len(g),query_tick=tick,physical_end_s=row.duration_s,**detail))
    return pd.DataFrame(records)

def paired(cases,method,baseline,scope):
    left=cases[cases.method.eq(method)].set_index(ID).sort_index()
    right=cases[cases.method.eq(baseline)].set_index(ID).sort_index()
    assert left.index.equals(right.index) and left.index.is_unique and len(left)==288
    fields=[f'{scope}_lower',f'{scope}_upper','action_slot']
    a,b,_=fields
    data=left[fields].join(right[fields],rsuffix='_base',validate='one_to_one')
    same=data.action_slot.eq(data.action_slot_base)
    assert (data.loc[same,a]==data.loc[same,a+'_base']).all() and (data.loc[same,b]==data.loc[same,b+'_base']).all()
    data['diff_lo']=(data[a]-data[b+'_base']).mask(same,0)
    data['diff_hi']=(data[b]-data[a+'_base']).mask(same,0)
    data['rescue']=data.diff_lo.eq(1)
    data['loss']=data.diff_hi.eq(-1)
    data['possible_rescue']=data.diff_hi.eq(1)
    data['possible_loss']=data.diff_lo.eq(-1)
    data['both_known']=left[a].eq(left[b]) & right[a].eq(right[b])
    data['identified']=data.diff_lo.eq(data.diff_hi)
    data['same_choice']=same
    return data.reset_index()

def main():
    start=time.process_time();torch.set_num_threads(1)
    truth=pd.read_csv(R/'matched_physical_gate_cases.csv.gz')
    assert len(truth)==2304 and truth.path.nunique()==1152 and not truth.duplicated(ID+['action_slot']).any()
    paths=physical(truth);paths.to_csv(R/'margin_paths.csv.gz',index=False)
    t=truth.merge(paths[['path','actual_min_clearance_m','actual_clearance_gt_frozen_margin']],on='path',how='left',validate='many_to_one')
    assert len(paths)==truth[truth.lower.eq(1)].path.nunique() and t.loc[t.lower.eq(1),'actual_min_clearance_m'].notna().all()
    t['original_lower']=t.lower;t['original_upper']=t.upper
    ok=t.actual_clearance_gt_frozen_margin.eq(True)
    for inp,tag in [('', 'margin'),('strict_','matched_margin')]:
        lo,hi=t[inp+'lower'],t[inp+'upper']
        t[tag+'_lower']=(lo.eq(1)&ok).astype(int)
        # Same physical path across two gates may have a measured distance when the
        # other gate fails. Preserve unexecuted/mismatched branches as unknown.
        t[tag+'_upper']=t[tag+'_lower'].where(lo.eq(hi),1)
    t.to_csv(R/'margin_gate_cases.csv.gz',index=False)
    bounds=[f'{s}_{k}' for s in OUTCOMES for k in ('lower','upper')]
    selects=pd.read_csv(R/'selected_cases.csv.gz')
    jobs=selects.merge(t[ID+['action_slot','path','actual_min_clearance_m']+bounds],on=ID+['action_slot','path'],validate='many_to_one')
    assert len(jobs)==3456 and jobs.lower.eq(jobs.original_lower).all() and jobs.upper.eq(jobs.original_upper).all()
    assert set(jobs.method)==set(METHOD)
    jobs.to_csv(R/'margin_selected_cases.csv.gz',index=False)
    grouped=jobs.groupby(['cohort','method']).agg(tasks=('lower','size'),**{s:(s,'sum') for s in bounds}).reset_index()
    grouped.to_csv(R/'margin_selected_summary.csv',index=False)
    task_id=jobs[ID].drop_duplicates().sort_values(ID).reset_index(drop=True)
    previous=pd.read_csv(PRE/'screen_capacity/xy/margin_legs.csv.gz')[ID].drop_duplicates().sort_values(ID).reset_index(drop=True)
    same_prior_conditions=task_id.equals(previous)
    summary=[];rows=[]
    for c,g in jobs.groupby('cohort'):
        for method,base in combinations(METHOD,2):
            for outcome in OUTCOMES:
                d=paired(g,method,base,outcome)
                d['method']=method;d['baseline']=base;d['target']=outcome;d['cohort']=c
                rows.append(d)
                for (m,s),f in [(('both',0),d),*d.groupby(['map_id','side'])]:
                    summary.append(dict(cohort=c,target=outcome,method=method,baseline=base,map_id=m,side=s,
                        n=len(f),both_known=int(f.both_known.sum()),identified=int(f.identified.sum()),same_choice=int(f.same_choice.sum()),
                        rescue_lo=int(f.rescue.sum()),rescue_hi=int(f.possible_rescue.sum()),
                        loss_lo=int(f.loss.sum()),loss_hi=int(f.possible_loss.sum()),net_lo=int(f.diff_lo.sum()),net_hi=int(f.diff_hi.sum())))
    pd.concat(rows,ignore_index=True).to_csv(R/'margin_pairs.csv.gz',index=False)
    results=pd.DataFrame(summary);results.to_csv(R/'margin_paired_summary.csv',index=False)
    old=pd.read_csv(R/'paired_method_cases.csv.gz')
    merged=old.merge(pd.concat(rows).query("target=='original' and method=='mixture3'"),on=['cohort','baseline',*ID],validate='one_to_one')
    assert len(merged)==len(old) and merged.difference_lo.eq(merged.diff_lo).all() and merged.difference_hi.eq(merged.diff_hi).all()
    record=dict(maps=sorted(truth.map_id.unique()),physical_lanes=truth.path.nunique(),actual_gate_rows=len(truth),
       native_task_unknown_rows=int(truth.lower.ne(truth.upper).sum()),prefix_matched_unknown_rows=int(truth.strict_lower.ne(truth.strict_upper).sum()),
       passed_gate_rows=int(truth.lower.sum()),successful_paths_measured=len(paths),physical_paths_by_map=paths.groupby('map_id').size().to_dict(),
       measured_paths_gt_frozen_margin=int(paths.actual_clearance_gt_frozen_margin.sum()),confirmed_gate_and_margin_rows=int(t.margin_lower.sum()), 
       by_method_condition_set_equal=True,condition_count=len(task_id),same_named_map_root_gate_side_push_as_old_16option_replay=same_prior_conditions,
       previous_and_current_action_sets='different: prior two finalists from historical 16; this study four or eight new interpolated entries, new physics',
       samples='Every stored 5 ms qpos from verified first-query snapshot to original physical finish inclusive, with original map 3D component-wise obstacle-box distance and margins >0.05330585315823555 m; 20 ms aligned distance also retained. Unknown branches keep [0,1].',
       geometry='Continuous-time clearance between 5 ms frames has not been evaluated. Axis-aligned envelope gaps can be negative on trajectories with no simulated contact.',
       choice_pairing='Within each cohort all four frozen methods choose on the same 24 roots x four gate instructions x three pushes (288 per method); the three search spaces reuse these same tasks. Difference is zero for identical chosen option, including when outcome is unknown.',
       geometry_helper_sha256=sha256(helper.read_bytes()).hexdigest(),single_thread_cpu_s=time.process_time()-start)
    (R/'margin_receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    print(grouped.to_string(index=False))
    print(results.query("cohort=='all8' and target=='margin' and map_id=='both'")[['method','baseline','n','both_known','rescue_lo','rescue_hi','loss_lo','loss_hi','net_lo','net_hi']].to_string(index=False))

if __name__=='__main__':main()

"""Capacity of the eight measured entries when a gate choice must precede its push."""
from pathlib import Path

import pandas as pd

base = Path(__file__).resolve().parent
actual = pd.read_csv(base / "margin_gate_cases.csv.gz")
group = ["map_id", "root", "gate_x", "side"]
action = group + ["action_slot"]
assert not actual.duplicated(action + ["force"]).any()
assert actual.groupby(action).size().eq(3).all()
curves = pd.read_csv(base / "curves.csv").rename(columns={"slot": "action_slot"})
actual = actual.merge(curves[["action_slot", "kind"]], validate="many_to_one")
results = []
for cohort in ("all8", "same_edge", "center_edge"):
    cases = actual if cohort == "all8" else actual[actual.kind == cohort]
    for target, lo, hi in [("gate_finish", "strict_lower", "strict_upper"),
                           ("gate_finish_clearance", "matched_margin_lower", "matched_margin_upper")]:
        per_action = cases.groupby(action)[[lo, hi]].sum()
        capacity = per_action.groupby(group).max().rename(columns={lo: "lo", hi: "hi"})
        capacity = capacity.reset_index().assign(cohort=cohort, target=target, pushes=3)
        results.append(capacity)
per_task = pd.concat(results, ignore_index=True)
per_task.to_csv(base / "shared_entry_capacity.csv", index=False)
print(per_task.groupby(["cohort", "target"])[["lo", "hi", "pushes"]].sum().to_string())

"""Hindsight capacity with one pre-push entry per map/start/instructed gate."""
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parent
P=R.parent
D=P/'actions/amortized_exit/development_entry'
FIX=P/'actions/continuous_examples/continuous_entry_event_exit/screen_capacity/xy/margin_legs.csv.gz'
KEY=['map_id','root','gate_x','side']

def audit(m):
    old=P/'batches'/m/'physical';new=R/m/'physical'
    def digest(path):return sha256(path.read_bytes()).hexdigest()
    hashes=[digest(f/'terrain.mjb') for f in [old,new,P/'maps'/m]]
    assert len(set(hashes))==1
    configs=[json.loads((w/'resolved_config.json').read_text()) for w in [old,new]]
    a,b=configs
    for f in ['approach_initial_bank','ground_physics','world_map','world_map_spec','platform_online','task_evaluation','native_rb_entry_context','shared_adapters']:
        assert a[f]==b[f],f
    assert {k:v for k,v in a['ground_handoff'].items() if k not in ['handoff_variants','reference_path']}=={k:v for k,v in b['ground_handoff'].items() if k not in ['handoff_variants','reference_path']}
    # New generator copies old lanes 0..7 and changes only the entry geometry and alpha.
    av=[v for v in a['ground_handoff']['handoff_variants'] if v['action_slot']<8];bv=b['ground_handoff']['handoff_variants']
    assert len(av)==len(bv)==576 and all({**x,'geometry':x['action_slot'],'approach_alpha':0.,'alpha_numerator_24':0}==y for x,y in zip(av,bv))
    for c in configs:
        vs=c['ground_handoff']['handoff_variants']
        assert c['paired_departures']['direction_ids']==[i['planned_departure'] for i in vs] and set(c['paired_departures']['direction_ids'])=={0,2}
        assert {(i['arm'],i['planned_departure']) for i in vs}=={('left',0),('right',2)}
        assert set(i['continuation_speed_m_s'] for i in vs)=={2.}
    initial={}
    for folder in (P/'export/dev'/m,R/'export/dev'/m):
        rows=pd.read_csv(folder/'prefix_index.csv')
        with np.load(folder/'observed_inputs.npz') as z:
            for k,g in rows.groupby('root'):
                qv=np.concatenate([z['t0_qpos_native'][g.row],z['t0_qvel_native'][g.row]],axis=1)
                assert np.array_equal(qv,np.broadcast_to(qv[:1],qv.shape))
                if k in initial:assert np.array_equal(initial[k],qv[0])
                initial[k]=qv[0]
    return {'map_id':m,'terrain_mjb_sha256':hashes[0],'identical_t0_qpos_qvel_roots':len(initial),
            'latency_ticks':b['platform_online']['latency_ticks'],'captured_force_N':sorted(set(i['force_y_N'] for i in bv))}

def support(df,mask,tag,cols,slots):
    d=df.loc[mask,KEY+['force','action_slot']+cols]
    assert len(d)==96*3*slots and not d.duplicated(KEY+['force','action_slot']).any()
    gr=d.groupby(KEY+['action_slot'])
    assert gr.force.agg(lambda s:set(s)=={-5,0,5}).all()
    scores=gr[cols].sum().astype('int64').reset_index().sort_values(KEY+['action_slot'])
    ends=scores.groupby(KEY)[cols].max();ends.columns=[tag+'_lo',tag+'_hi']
    for col,name in zip(cols,['lo','hi']):
        best=scores[scores[col].eq(scores.groupby(KEY)[col].transform('max'))]
        ends[tag+'_best_slots_'+name]=best.groupby(KEY).action_slot.agg(lambda x:'|'.join(x.astype(str)))
    return ends

def main():
    audits=[audit(m) for m in ['dev_00','dev_01']]
    old=pd.read_csv(D/'physical_conditions.csv.gz')
    choices=pd.read_csv(D/'time_zero_choices.csv').query("method=='old_train_rule'")[KEY+['selected']]
    old=old.merge(choices,on=KEY,validate='many_to_one')
    assert (old.physical_arm.eq('left')==old.side.eq(1)).all()
    new=pd.read_csv(R/'margin_gate_cases.csv.gz')
    registration=pd.concat([pd.read_csv(R/'export/dev'/m/'suffix_index.csv')[['trajectory','arm']] for m in ['dev_00','dev_01']])
    new=new.merge(registration,left_on='path',right_on='trajectory',validate='many_to_one')
    assert new.arm.eq('left').eq(new.side.eq(1)).all()
    curves=pd.read_csv(R/'curves.csv').rename(columns={'slot':'action_slot'})
    new=new.merge(curves[['action_slot','kind']],on='action_slot',validate='many_to_one')
    fixedm=pd.read_csv(FIX).query('incumbent').rename(columns={'slot':'action_slot'})
    f=old[old.action_slot.eq(old.selected)].merge(fixedm,on=KEY+['force','action_slot'],validate='one_to_one')
    assert len(f)==288 and f.lower.eq(f.gate_success).all() and f.known.all() and f.source.eq(f.source_trajectory).all()
    allrows=lambda a:pd.Series(True,index=a.index)
    data=[];summary=[]
    for target in ['gate_goal','gate_goal_and_margin']:
        if target=='gate_goal':
            lower,upper='original_lower','original_upper'
            tables=[support(old,old.action_slot.eq(old.selected),'fixed',['lower','upper'],1),
                    support(old,allrows(old),'old16',['lower','upper'],16),
                    support(old,old.alpha.eq(0.),'old_alpha0',['lower','upper'],3)]
            bases=['fixed','old16','old_alpha0']
        else:
            lower,upper='margin_lower','margin_upper'
            ff=fixedm.assign(lo=fixedm.strict_success,hi=fixedm.strict_success)
            tables=[support(ff,allrows(ff),'fixed',['lo','hi'],1)];bases=['fixed']
        for tag,mask,n in [('new8',allrows(new),8),('new_same_edge4',new.kind.eq('same_edge'),4),('new_center_edge4',new.kind.eq('center_edge'),4)]:
            tables.append(support(new,mask,tag,[lower,upper],n))
        d=pd.concat(tables,axis=1,verify_integrity=True).sort_index()
        assert len(d)==96 and d.notna().all().all()
        menus=bases+['new8','new_same_edge4','new_center_edge4']
        joins={}
        for b in bases:
            for n in ['new8','new_same_edge4','new_center_edge4']:
                tag=b+'_plus_'+n;menus.append(tag);joins[tag]=(b,n)
                for x in ('lo','hi'):d[tag+'_'+x]=d[[b+'_'+x,n+'_'+x]].max(axis=1)
                d[tag+'_gain_lo']=(d[n+'_lo']-d[b+'_hi']).clip(lower=0)
                d[tag+'_gain_hi']=(d[n+'_hi']-d[b+'_lo']).clip(lower=0)
        for tag in menus:
            for name,s in [('both',d),*d.groupby(level='map_id')]:
                row=dict(target=target,map_id=name,menu=tag,root_gate_tasks=len(s),push_tasks=3*len(s),
                         lower=int(s[tag+'_lo'].sum()),upper=int(s[tag+'_hi'].sum()))
                if tag in joins:
                    definite=s[s[tag+'_gain_lo']>0];possible=s[s[tag+'_gain_hi']>0]
                    row.update(base=joins[tag][0],gain_lo=int(s[tag+'_gain_lo'].sum()),gain_hi=int(s[tag+'_gain_hi'].sum()),
                           guaranteed_improved_tasks=len(definite),possibly_improved_tasks=len(possible),
                           guaranteed_improved_roots=definite.index.get_level_values('root').nunique(),possibly_improved_roots=possible.index.get_level_values('root').nunique())
                summary.append(row)
        if target=='gate_goal':
            orig=pd.read_csv(D/'groups.csv').query("method=='oracle_all16'").set_index(KEY).sort_index()
            assert orig.lower.equals(d.old16_lo) and orig.upper.equals(d.old16_hi)
        data.append(d.reset_index().assign(target=target))
    summary=pd.DataFrame(summary);summary.to_csv(R/'entry_menu_summary.csv',index=False)
    pd.concat(data,ignore_index=True).to_csv(R/'entry_menu_by_task.csv.gz',index=False)
    note=dict(maps=audits,denominator='24 roots, four gate instructions, three hidden pushes per task. First sum each slot across pushes, then maximize those three-push totals per root/gate. Report separate best lower and upper values; all tied guaranteed/possible best slots are stored.',
        fixed='Original TRAIN rule: old slot 0, alpha 0 for right; old slot 4, alpha 1 for left. Old slot numbers and new slot numbers belong to separate banks.',
        bounds='Gain lower=max(0,new_lower-base_upper) and upper=max(0,new_upper-base_lower), then sum by root/gate. Union retains the base route. A hindsight benchmark using three realized pushes; it does not supply a pre-push selector.',
        old_unknown_rows=int(old.lower.ne(old.upper).sum()),new_unknown_rows=int(new.lower.ne(new.upper).sum()),
        common='Actual initial pose/velocity verified per root. Both use same per-map compiled MJB and native 10s clock, 1ms physics/5ms control. Same commanded 2m/s, frozen lower/RB, 3-tick entry and exit publication, side-specific left/right fixed branches and goal / gate scoring. Original selected arms use measured gate crossing .06 <= side*y <= 3.9 and physical goal after relock without wall. Unknown arms kept.',
        limits='Old 16 combine fixed and variable alphas; all new 8 use alpha zero. Left/right exit family is generated by original offset +/-0.36m, 1.6m blend and fade at x=15 to goal from 16.5m; actual committed join, reference and state depend on approach. Old16 and new8 are two physical batches and geometry families. Matched-alpha diagnostic old_alpha0 consists of the three historical alpha-zero slots. No full old16 margin recomputation.',
        data=['actions/amortized_exit/development_entry/physical_conditions.csv.gz','actions/amortized_exit/development_entry/time_zero_choices.csv','continuous_interpolation/margin_gate_cases.csv.gz','actions/continuous_examples/continuous_entry_event_exit/screen_capacity/xy/margin_legs.csv.gz'])
    (R/'entry_menu_receipt.json').write_text(json.dumps(note,indent=2)+'\n')
    print(summary.query("map_id=='both'")[['target','menu','lower','upper','gain_lo','gain_hi','guaranteed_improved_tasks','guaranteed_improved_roots']].to_string(index=False))

if __name__=='__main__':main()

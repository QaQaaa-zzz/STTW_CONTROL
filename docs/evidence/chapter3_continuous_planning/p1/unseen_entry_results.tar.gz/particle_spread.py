"""Empirical marginal coverage of the eight-approach panel's frozen, pre-action particles."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import torch

R=Path(__file__).resolve().parent
MODEL=R.parent/'model'
sys.path.insert(0,'/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src')
from sttw_control.playground_prediction import euler

KEY=['map_id','root','action_slot']
ID=KEY+['method','seed']
METHODS=('mean','mixture3','empirical_action','five_separate_roots')
QUANTITIES=('landing_x_m','landing_y_m','query_time_s','roll_deg','yaw_deg','body_forward_m_s')
ANGULAR={'roll_deg','yaw_deg'}
DT=.005

def wrap(degrees):
    return (degrees+180.)%360.-180.

def points(q,v,t):
    angles=np.rad2deg(euler(torch.as_tensor(q,dtype=torch.float64)[:,3:7]).numpy())
    return np.column_stack((q[:,0],q[:,1],t,angles[:,0],angles[:,2],v[:,0]))

def intervals(values):
    center=values.mean(axis=0)
    deviations=values-center
    for j in (3,4):
        a=np.deg2rad(values[:,j])
        center[j]=np.rad2deg(np.arctan2(np.sin(a).mean(),np.cos(a).mean()))
        deviations[:,j]=wrap(values[:,j]-center[j])
    lower,upper=np.quantile(deviations,[.05,.95],axis=0,method='linear')
    return center,lower,upper

def forecasts():
    receipt=json.loads((R/'prediction_receipt.json').read_text())['hashes']
    for name in ('pre_action_states.jsonl','pre_action_scores.csv.gz'):
        assert hashlib.sha256((R/name).read_bytes()).hexdigest()==receipt[name],name
    a=pd.read_csv(R/'pre_action_scores.csv.gz',dtype={'seed':str})
    plans=a[ID+['kind','p_relock']].drop_duplicates()
    assert len(plans)==768 and not plans.duplicated(ID).any()
    assert all(set(g.method)==set(METHODS) for _,g in plans.groupby(KEY))
    # State file has one pre-action sample set per map/root/curve/method; no push field.
    p=pd.DataFrame(json.loads(x) for x in (R/'pre_action_states.jsonl').open())
    p['seed']=p.seed.astype(str)
    assert not p.duplicated(ID+['particle']).any() and not {'force','push','hidden_force_N_grouping_only'}.intersection(p.columns)
    bands=[]
    for ids,g in p.groupby(ID,sort=False):
        qt=g.query_s.to_numpy();ticks=np.rint(qt/DT)
        assert np.all(np.abs(qt-DT*ticks)<1e-6)
        pp=points(np.stack(g.q),np.stack(g.velocity),ticks*DT)
        center,lo,hi=intervals(pp)
        for j,name in enumerate(QUANTITIES):
            bands.append(dict(zip(ID,ids),quantity=name,particles=len(g),center=center[j],
                low_offset=lo[j],high_offset=hi[j],width90=hi[j]-lo[j]))
    b=pd.DataFrame(bands)
    sizes=p.groupby(ID).size().rename('n_particles').reset_index()
    plans=plans.merge(sizes,on=ID,how='left',validate='one_to_one');plans['n_particles']=plans.n_particles.fillna(0).astype(int)
    assert (plans.n_particles.eq(0)==plans.p_relock.eq(0)).all()
    return plans,b

def truths(export):
    rows=[]
    for name in ('dev_00','dev_01'):
        d=export/name
        ix=pd.read_csv(d/'prefix_index.csv').sort_values('row').reset_index(drop=True)
        assert (ix.map_id==name).all() and np.array_equal(ix.row,np.arange(len(ix)))
        with np.load(d/'measured_targets.npz') as z:
            mask=z['regression_valid'];verified=z['verified_relock']
            assert np.array_equal(mask,verified&z['observed_query']) and np.array_equal(verified,ix.verified_relock)
            ticks=np.rint(z['query_s'][mask]/DT)
            assert np.all(np.abs(ticks*DT-z['query_s'][mask])<1e-6)
            values=np.full((len(ix),len(QUANTITIES)),np.nan)
            values[mask]=points(z['query_qpos_native'][mask],z['query_velocity_state9'][mask],ticks*DT)
        frame=ix[KEY+['hidden_force_N_grouping_only','row']].copy()
        frame['verified']=verified;frame['observed_state']=mask
        for j,k in enumerate(QUANTITIES):frame[k]=values[:,j]
        rows.append(frame)
    obs=pd.concat(rows,ignore_index=True)
    assert not obs.duplicated(KEY+['hidden_force_N_grouping_only']).any()
    assert all(set(g.hidden_force_N_grouping_only)=={-5,0,5} for _,g in obs.groupby(KEY))
    return obs

def score(plans,bands,obs):
    # Every one of the three hidden pushes joins the same frozen forecast.
    base=obs.merge(plans,on=KEY,how='left',validate='many_to_many')
    assert len(base)==len(obs)*len(METHODS) and base.method.notna().all()
    base['scored']=base.observed_state & base.n_particles.gt(0)
    obskey=KEY+['hidden_force_N_grouping_only']
    base['common']=base.groupby(obskey).scored.transform('all')
    d=base.melt(id_vars=[k for k in base if k not in QUANTITIES],value_vars=QUANTITIES,
                var_name='quantity',value_name='observed').merge(bands,on=ID+['quantity'],how='left',validate='many_to_one')
    d['signed_error']=d.observed-d.center
    angle=d.quantity.isin(ANGULAR)
    d.loc[angle,'signed_error']=wrap(d.loc[angle,'signed_error'])
    d['abs_error']=d.signed_error.abs()
    # Floating roundoff at an inclusive endpoint is only resolved at machine precision.
    eps=8*np.finfo('float64').eps*np.maximum(1.,d[['observed','center']].abs().max(axis=1))
    covered=d.signed_error.ge(d.low_offset-eps)&d.signed_error.le(d.high_offset+eps)
    d['covered90']=covered.where(d.scored)
    records=[]
    keys=['map_id','kind','method','seed','quantity']
    for ids,g in d.groupby(keys,sort=False):
        for label,mask in [('method_available',g.scored),('common_four',g.common)]:
            use=g[mask]
            records.append(dict(zip(keys,ids),scope=label,prefixes=len(g),verified_relocks=int(g.verified.sum()),
                verified_state_observations=int(g.observed_state.sum()),zero_probability_prefixes=int(g.p_relock.eq(0).sum()),
                observed_zero_probability=int((g.observed_state&g.p_relock.eq(0)).sum()),
                scorable_prefixes=len(use),distinct_roots_scored=use.root.nunique(),covered_count=int(use.covered90.eq(True).sum()),
                coverage90=use.covered90.eq(True).mean(),mean_width90=use.width90.mean(),mae=use.abs_error.mean()))
    return d,pd.DataFrame(records)

def check(plans,bands):
    obs=truths(R.parent/'export/dev')
    row=obs[obs.observed_state].iloc[0]
    # One actual archived DEV first-query state, with a hand-defined symmetric distribution.
    truth=row[list(QUANTITIES)].to_numpy(dtype=float)
    offsets=np.array([1.,.4,.1,2.,1.,.3]);samples=np.stack((truth-offsets,truth+offsets))
    center,lo,hi=intervals(samples)
    assert np.allclose(hi-lo,1.8*offsets) and np.allclose(center,truth)
    vals=np.zeros((2,6));vals[:,4]=[179.,-179.]
    cc,lc,hc=intervals(vals)
    assert np.isclose(abs(cc[4]),180.) and np.isclose(hc[4]-lc[4],1.8)
    one=intervals(truth[None,:]);assert np.allclose(one[2]-one[1],0.)
    # Compare the inherited three interval definitions with the existing P1 metric.
    sys.path.insert(0,str(MODEL))
    from development_metrics import add_state_errors
    qq=np.zeros((1,12),dtype=np.float64);qq[0,3]=1.;qq[0,:2]=truth[:2]
    qp=np.broadcast_to(qq[:,None,:],(1,2,12)).copy();qp[0,:,:2]=samples[:,:2]
    tt=torch.tensor(truth[2:3]);op=dict(query_qpos_native=torch.tensor(qq),relock_s=tt)
    cen=dict(query_qpos_native=torch.tensor(qq[:,None,:]),relock_s=tt[:,None])
    pts=dict(query_qpos_native=torch.tensor(qp),relock_s=torch.tensor(samples[:,2][None,:]))
    old=pd.DataFrame(index=[0]);add_state_errors(old,torch.tensor([True]),op,cen,pts)
    for j,n in enumerate(('landing_x','landing_y','relock_time')):
        assert old.loc[0,n+'_covered90']==1 and np.isclose(old.loc[0,n+'_width90'],hi[j]-lo[j])
    # Use two distinct old DEV observation rows (one verified, one unverified) for denominator mechanics,
    # plus a zero-particle forecast. All repeated observations in this fixture are tests, never panel results.
    missing=plans[plans.n_particles.eq(0)].iloc[0];regular=plans[plans.method.eq('five_separate_roots')&plans.n_particles.gt(0)].iloc[0]
    fixtures=[]
    for item in (regular,missing):
        g=obs[obs.map_id.eq(item.map_id)].iloc[:3].copy()
        for k in KEY:g[k]=item[k]
        g['hidden_force_N_grouping_only']=[-5,0,5];g['observed_state']=[True,True,False];g['verified']=[True,True,False]
        for j,k in enumerate(QUANTITIES):g[k]=[truth[j],truth[j],np.nan]
        fixtures.append(g)
    f=pd.concat(fixtures,ignore_index=True)
    dd,summary=score(plans,bands,f)
    assert dd[dd.quantity.eq('landing_x_m') & dd.method.eq('mean')].scored.sum()==4
    assert dd[dd.quantity.eq('landing_x_m') & dd.method.eq('mean')].common.sum()==2
    assert dd[dd.quantity.eq('landing_x_m') & dd.method.eq('five_separate_roots')].scored.sum()==2
    return dict(test='schema and formulas only; no held-out trajectory scores claimed',old_DEV_prefixes=len(obs),
        observed_old_DEV_states=int(obs.observed_state.sum()),old_DEV_fixture=dict(map=row.map_id,root=int(row.root),action_slot=int(row.action_slot),force=int(row.hidden_force_N_grouping_only)),
        hand_computable_intervals='x,y and the time quantile formula match development_metrics.add_state_errors on the hand-defined sample; linear quantiles, zero-width single particle, yaw across 180 degrees and common-method denominators checked',
        frozen_plans=plans.groupby('method').size().to_dict(),frozen_particles_distribution=plans.groupby('method').n_particles.value_counts().to_string(),
        zero_probability_observable_actions=plans[plans.n_particles.eq(0)][ID+['kind']].to_dict('records'))

def main():
    arg=argparse.ArgumentParser(description=__doc__);arg.add_argument('--check',action='store_true');args=arg.parse_args()
    plans,bands=forecasts()
    if args.check:
        check_result=check(plans,bands);(R/'particle_spread_check.json').write_text(json.dumps(check_result,indent=2)+'\n')
        print(json.dumps(check_result,indent=2));return
    obs=truths(R/'export/dev')
    assert len(obs)==576
    detail,summary=score(plans,bands,obs)
    detail.to_csv(R/'particle_spread_cases.csv.gz',index=False)
    summary.to_csv(R/'particle_spread_summary.csv',index=False)
    assumptions=dict(panel='DEV: two maps; 12 starts each, four same-edge and four center-edge paths, 3 pushes. Preassigned left replica per prefix. Each push joins one shared pre-action forecast. No calibration or fitting.',
        intervals='Nominal 90% marginal 5th/95th percentiles, linearly interpolated from existing equally weighted particles; means are across those same particles. Landing x/y means first post-relock query x/y. Time is the frozen query_s compared with the first observed query_s, both represented on their recorded 5 ms tick grid. These are not simultaneous 6D prediction regions.',
        fields='P1 quantile definition is reused for landing x/y and time; this panel reports the stored first-query clock. Additional marginals: signed body-forward speed, yaw and roll in degrees. Angles use original quaternion-to-Euler and shortest signed deviations around circular mean; stored low/high offsets from center define the interval across the angle cut.',
        support='Mean is the single stored point, yielding a zero-width interval; mixture3 and both empirical forecasts use up to 16 stored draws, as distinct from original development_metrics fit diagnostics that sampled 128. No draws synthesized for zero conditional mass.',
        denominator='method_available includes verified relock with actual observed query state and a nonempty method forecast. common_four intersects these rows across all four methods. zero_probability_prefixes counts all repeated push observations, observed_zero_probability counts verified state observations only. MAE uses conditional particle mean, circular for roll/yaw. Differential exclusions and denominators appear in every summary row.',
        files=['particle_spread_cases.csv.gz','particle_spread_summary.csv'])
    (R/'particle_spread_receipt.json').write_text(json.dumps(assumptions,indent=2)+'\n')
if __name__=='__main__':main()

"""Draw the archived actual XY, active references and observed ends for one training start."""
import argparse
import json
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D

def draw(root, dest):
    base=Path(__file__).resolve().parent
    rows=pd.read_csv(base/'case_index.csv.gz').query('root==@root')
    assert len(rows)==24
    name=rows.map_id.iloc[0]
    world=json.loads((base/(name+'_world.json')).read_text())
    fig,axes=plt.subplots(4,2,figsize=(15,8))
    colors={-5:'#0072b2',0:'#94621b',5:'#009e73'}
    with np.load(base/rows.portable_file.iloc[0]) as data:
        pts=np.concatenate([data[k] for k in data.files if k.endswith('_xy')])
        pts=pts[np.isfinite(pts).all(axis=1)]
        for s,part in rows.groupby('action_slot'):
            ax=axes[s//2,s%2]; b=part.iloc[0]
            for l,r,bottom,top in world['terrain']['forbidden_rectangles']:
                ax.add_patch(Rectangle((l,bottom),r-l,top-bottom,color='#ab6e4c',alpha=.5))
            ax.axvline(10.3,c='#777',ls=':',lw=.8)
            for r in part.itertuples():
                key=r.portable_key; col=colors[r.force_N]; xy=data[key+'_xy'];t=data[key+'_time']
                ax.plot(*xy.T,c=col,lw=1.2)
                for j in range(int(r.active_reference_pieces)):
                    ref=data[key+f'_ref{j}'];ax.plot(*ref.T,c=col,ls='--',lw=.85)
                if r.verified_relock:
                    i=np.argmin(np.abs(t-r.native_handoff_s));ax.plot(*xy[i],'D',c=col,ms=3)
                if r.finite_physical_endpoint:
                    ax.plot(*xy[-1],'o' if r.physical_goal else 'x',c=col,mfc='white',ms=5)
                else:
                    ax.plot(r.last_finite_x_m,r.last_finite_y_m,'^',c=col,mfc='white',ms=6)
                    ax.annotate('Last finite sample',(r.last_finite_x_m,r.last_finite_y_m),xytext=(4,8),textcoords='offset points',fontsize=7)
            ax.set_title(f'C{s}  ·  {b["shape"]}  ·  {100*b.measured_trigger_y_m:+.1f} → {100*b.measured_edge_y_m:+.0f} cm  ·  {int(part.verified_relock.sum())}/3 relocked',fontsize=10,loc='left')
            ax.set(xlim=(min(1.,pts[:,0].min()-.25),max(18.35,pts[:,0].max()+.25)),ylim=(min(-1.3,pts[:,1].min()-.16),max(1.3,pts[:,1].max()+.16)),aspect='equal')
            ax.grid(alpha=.17);ax.set_ylabel('y (m)' if s%2==0 else '');ax.set_xlabel('x (m)' if s//2==3 else '')
    legend=[Line2D([],[],color=c,label=f'{f:+d} N') for f,c in colors.items()]+[Line2D([],[],color='#333',ls='--',label='Ground reference'),Line2D([],[],color='#333',ls='',marker='D',label='Relock'), Line2D([],[],color='#333',ls='',marker='o',mfc='white',label='Goal endpoint'), Line2D([],[],color='#333',ls='',marker='x',label='Other endpoint')]
    fig.suptitle(f'{name} · TRAIN start {root} · left replica · α=0',fontsize=16)
    fig.legend(handles=legend,ncol=7,loc='upper center',bbox_to_anchor=(.5,.945),fontsize=9,frameon=False)
    fig.subplots_adjust(left=.06,right=.99,top=.85,bottom=.075,hspace=.35)
    fig.savefig(dest,dpi=125);plt.close(fig)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=int)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    draw(args.root,args.output)

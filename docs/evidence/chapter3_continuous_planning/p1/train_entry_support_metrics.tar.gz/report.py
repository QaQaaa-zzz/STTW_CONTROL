"""Summarize the registered left-prefix replicas and draw original XY with active ground references."""
from pathlib import Path
import json
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

O = Path(__file__).resolve().parent
R = O.parent
sys.path.insert(0, str(R.parent/'continuous_interpolation'))
from draw_choices import read_case, mapped_arrays

FORCES = (-5, 0, 5)
COLORS = {-5:'#0072b2', 0:'#94621b', 5:'#009e73'}
ARMS = {'outward':'outward', 'turnback':'turnback'}

def decorate(ax, world, x0, x1, y0, y1):
    ax.axvline(10.3, c='#686868', ls=':', lw=.8)
    for l,r,b,t in world['terrain']['forbidden_rectangles']:
        ax.add_patch(Rectangle((l,b),r-l,t-b,facecolor='#ab6e4c',edgecolor='#935638',alpha=.5))
    ax.set(xlim=(x0,x1),ylim=(y0,y1),aspect='equal')
    ax.grid(alpha=.17, lw=.55)
    ax.spines[['right','top']].set_visible(False)

def line(ax, c, col, lw=1.1):
    xy=c['xy']
    ax.plot(xy[:,0],xy[:,1],c=col,lw=lw,zorder=4)
    for p in c['pieces']:
        ax.plot(*p.T,c=col,ls=(0,(4,3)),lw=.9,alpha=.72,zorder=3)
    if c['verified'] and c['hand'] is not None:
        ax.plot(*xy[c['hand']],'D',color=col,ms=3.5,zorder=5)
    if not c['finite_end'] and c['last'] is not None:
        ax.plot(*c['last'],marker='^',mfc='white',mec=col,ms=6,zorder=6)
        ax.annotate('Last finite sample',c['last'],xytext=(4,8),textcoords='offset points',fontsize=7,color=col)
        return
    end=xy[-1]
    if end is not None:ax.plot(*end,'o' if c['goal'] else 'x',mfc='white',mec=col,ms=5.5,zorder=5)

def bound(cases):
    pts=np.concatenate([k['xy'] for k in cases]);finite=np.isfinite(pts).all(axis=1);pts=pts[finite]
    return min(1.,pts[:,0].min()-.25),max(18.35,pts[:,0].max()+.25),min(-1.30,pts[:,1].min()-.16),max(1.30,pts[:,1].max()+.16)

def legend():
    return [Line2D([],[],color='#333',label='Actual XY'),Line2D([],[],color='#555',ls='--',label='Active ground reference'),
            Line2D([],[],ls='',marker='D',ms=4,color='#333',label='Verified handback'),
            Line2D([],[],ls='',marker='o',ms=5,mfc='white',mec='#333',label='Goal endpoint'),
            Line2D([],[],ls='',marker='x',ms=5,color='#333',label='Other physical endpoint')]

def main():
    maps=sorted(k.name for k in (R/'export/train').iterdir() if (k/'prefix_index.csv').exists())
    assert maps==[f'train_{i:02}' for i in range(6)]
    curves=pd.read_csv(R/'curves.csv').set_index('slot')
    all_rows=[]
    for m in maps:
        prefix=pd.read_csv(R/'export/train'/m/'prefix_index.csv')
        suffix=pd.read_csv(R/'export/train'/m/'suffix_index.csv')
        left=suffix[suffix.arm=='left'].copy()
        key=['map_id','root','action_slot','hidden_force_N_grouping_only','lane','trajectory','arm','verified_relock','observed_query']
        assert len(left)==len(prefix)==288 and prefix.role.eq('train').all() and prefix.arm.eq('left').all()
        left=left.merge(prefix[key+['cross_suffix_certified']],on=key,validate='one_to_one')
        assert len(left)==288 and left.alpha.eq(0).all()
        all_rows.append(left)
    all_rows=pd.concat(all_rows,ignore_index=True).rename(columns={'hidden_force_N_grouping_only':'force_N'}).merge(curves[['shape','side','edge_magnitude_m','measured_trigger_y_m','measured_edge_y_m']],left_on='action_slot',right_index=True)
    all_rows['map_id']=all_rows.map_id.astype(str)
    keys=['map_id','root','action_slot','force_N']
    assert not all_rows.duplicated(keys).any() and len(all_rows)==1728
    def summarize(keys):
        d=all_rows.groupby(keys,sort=True)
        return d.agg(prefixes=('lane','size'),verified_relocks=('verified_relock','sum'),first_queries=('observed_query','sum'),physical_goals=('physical_goal','sum')).reset_index()
    for name,axes in [('map',['map_id']),('slot',['action_slot','shape','side','edge_magnitude_m']),('force',['force_N']),('map_slot_force',['map_id','action_slot','force_N']),('root_slot',['map_id','root','action_slot'])]:
        summarize(axes).to_csv(O/(name+'_summary.csv'),index=False)
    pairkey=['map_id','root','force_N','side','edge_magnitude_m']
    pairs=all_rows.pivot(index=pairkey,columns='shape',values='verified_relock').reset_index()
    assert len(pairs)==864 and not pairs.isna().any().any()
    pairs['turnback_only']=pairs.turnback & ~pairs.outward
    pairs['outward_only']=pairs.outward & ~pairs.turnback
    pairs['both']=pairs.outward & pairs.turnback
    pairs['neither']=~pairs.outward & ~pairs.turnback
    pairs['net']=pairs.turnback.astype(int)-pairs.outward.astype(int)
    pairs.to_csv(O/'matched_shape_pairs.csv.gz',index=False)
    q=['turnback','outward','turnback_only','outward_only','both','neither','net']
    pairs.groupby('map_id')[q].sum().to_csv(O/'paired_by_map.csv')
    src=all_rows.sort_values(keys).copy()
    folder=O/'profiles';folder.mkdir(exist_ok=True)
    pages=[];cases_read=0; finite_ends=0; samples=0;ref_rows=0
    arrays={}
    for m, map_rows in src.groupby('map_id'):
        cfg=json.loads((R/m/'config.json').read_text());world=json.loads(Path(cfg['world_map']).read_text())
        (O/(m+'_world.json')).write_text(json.dumps(world,indent=2)+'\n')
        bank=mapped_arrays(cfg['paired_departures']['route_bank'])
        with np.load(cfg['ground_handoff']['reference_path']) as z:neutral=z['xy'][0]
        for root,part in map_rows.groupby('root'):
            name=f'{m}_{int(root)}';pool={};rawrefs={}
            fig,axs=plt.subplots(4,2,figsize=(15,8))
            for row in part.itertuples():
                case=read_case(row,neutral,bank,cfg['platform_online']['latency_ticks']['start'])
                k=(int(row.action_slot),int(row.force_N));pool[k]=case
                rk=f'c{k[0]}_f{k[1]:+d}';arrays[rk+'_xy']=case['xy'];arrays[rk+'_time']=case['time']
                for j,v in enumerate(case['pieces']):arrays[rk+f'_ref{j}']=v
                with np.load(row.trajectory) as z:
                    assert np.array_equal(case['xy'],z['qpos'][:,:2],equal_nan=True)
                    if root==1250:rawrefs[k]=z['reference_xy'].copy()
                assert np.allclose(case['last'],case['xy'][-1],equal_nan=True) if case['finite_end'] else True
                idx=row.Index
                src.at[idx,'portable_key']=rk
                src.at[idx,'portable_file']='profiles/'+name+'.npz'
                src.at[idx,'samples']=len(case['xy'])
                src.at[idx,'active_reference_pieces']=len(case['pieces'])
                src.at[idx,'finite_physical_endpoint']=case['finite_end']
                if case['last'] is not None:src.at[idx,'last_finite_x_m'],src.at[idx,'last_finite_y_m']=case['last']
                cases_read+=1;finite_ends+=int(case['finite_end']);samples+=len(case['xy']);ref_rows+=len(case['pieces'])
            assert len(pool)==24
            np.savez_compressed(folder/(name+'.npz'),**arrays);arrays.clear()
            extent=bound(pool.values())
            for slot in range(8):
                ax=axs[slot//2,slot%2]; b=curves.loc[slot];qsum=0
                decorate(ax,world,*extent)
                for force in FORCES:
                    c=pool[(slot,force)];line(ax,c,COLORS[force]);qsum+=int(c['verified'])
                ax.set_title(f'C{slot}  ·  {b["shape"]}  ·  trigger {100*b.measured_trigger_y_m:+.1f} → edge {100*b.measured_edge_y_m:+.0f} cm  ·  {qsum}/3 relocked',fontsize=10,loc='left')
                if slot%2==0:ax.set_ylabel('y (m)',fontsize=9)
                if slot//2==3:ax.set_xlabel('x (m)',fontsize=9)
            fig.suptitle(f'{m}   /   TRAIN start {root}   /   fixed left-exit replica, α=0',fontsize=16,y=.98)
            labs=[Line2D([],[],c=COLORS[f],label=f'{f:+d} N') for f in FORCES]+legend()
            fig.legend(handles=labs,ncol=8,loc='upper center',bbox_to_anchor=(.5,.945),fontsize=8,frameon=False)
            fig.subplots_adjust(left=.055,right=.99,bottom=.07,top=.855,wspace=.13,hspace=.34)
            fig.savefig(folder/(name+'.png'),dpi=125);plt.close(fig)
            pages.append(dict(map_id=m,root=int(root),file='profiles/'+name+'.png',numeric_file='profiles/'+name+'.npz'))
            if m=='train_00' and root==1250:
                fig,axs=plt.subplots(4,1,figsize=(11,8.3),gridspec_kw={'height_ratios':[1.15,1,1,1]})
                colors=['#d55e00','#0072b2']
                for slot,color in zip([1,3],colors):
                    v=rawrefs[(slot,0)]
                    k=(v[:,0]>=8.95)&(v[:,0]<=10.55)
                    axs[0].plot(*v[k].T,c=color,lw=2,label=f'C{slot} {curves.loc[slot,"shape"]}')
                for x,t in [(9.2,'Trigger'),(10.3,'Step edge')]:
                    axs[0].axvline(x,c='#555',ls=':',lw=1);axs[0].text(x,.075,t,ha='center',fontsize=8)
                axs[0].set(xlim=(8.95,10.55),ylim=(-.17,.10),aspect='equal',ylabel='y (m)',title='Two approach references at the same −4 cm step-edge point')
                axs[0].grid(alpha=.15);axs[0].legend(loc='lower left',ncol=2,fontsize=8,frameon=False)
                for i,f in enumerate(FORCES):
                    ax=axs[i+1];decorate(ax,world,*extent)
                    for slot,color in zip([1,3],colors):line(ax,pool[(slot,f)],color,lw=1.65)
                    ax.set_title(f'{f:+d} N  ·  C1 {pool[(1,f)]["terminal"].replace("_"," ")}  /  C3 {pool[(3,f)]["terminal"].replace("_"," ")}',fontsize=10,loc='left')
                    ax.set_ylabel('y (m)')
                axs[-1].set_xlabel('world x (m)');fig.suptitle('Same start, two approaches  ·  verified handbacks C1 0/3, C3 3/3',fontsize=15,y=.985)
                fig.legend(handles=legend(),ncol=5,loc='upper center',bbox_to_anchor=(.5,.95),frameon=False,fontsize=9)
                fig.subplots_adjust(top=.86,bottom=.075,hspace=.44);fig.savefig(O/'overview.png',dpi=145);plt.close(fig)
    src.to_csv(O/'case_index.csv.gz',index=False)
    pd.DataFrame(pages).to_csv(O/'index.csv',index=False)
    (O/'index.html').write_text('<meta charset="utf-8"><title>TRAIN 左副本实走轨迹</title><h1>TRAIN 左副本实走轨迹</h1><p>每个起点八条路线，三种推力。实线是实走，虚线是当时的地面参考，菱形是复锁。</p><p><a href="overview.png">1250 号同侧轨迹对照</a> · <a href="case_index.csv.gz">逐次终点、首查与数据索引</a></p>'+''.join('<h2>'+m+'</h2>'+''.join(f'<a href="{e["file"]}">{e["root"]}</a>　' for e in pages if e['map_id']==m) for m in maps))
    receipt=dict(role='TRAIN',roots=src.root.nunique(),maps=len(maps),prefixes=cases_read,verified=int(src.verified_relock.sum()),queries=int(src.observed_query.sum()),finite_ends=finite_ends,actual_samples=samples,reference_pieces=ref_rows,figures=len(pages),new_physics=0)
    (O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(receipt)

if __name__=='__main__':main()

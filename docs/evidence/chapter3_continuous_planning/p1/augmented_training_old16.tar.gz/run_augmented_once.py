"""Score the supplemented old-entry menus once after the primary augmented comparison completes."""
import json
from pathlib import Path
import subprocess
import sys

here = Path(__file__).resolve().parent
training = here.parent / 'augmented_fit'
status = json.loads((training / 'pipeline_status.json').read_text())
assert status['stage'] == 'complete' and status['fits'] == 6
assert (training / 'nine_option_training_comparison.csv').is_file()
for seed in (61123, 61124, 61125):
    folder = training / f'seed_{seed}'
    assert json.loads((folder / 'summary.json').read_text())['steps'] == 540
    assert (folder / 'mean.pt').is_file() and (folder / 'mixture3.pt').is_file()

destination = here / 'augmented'
if not (destination / 'training_arm_summary.csv').exists():
    command = [sys.executable, '-B', str(here / 'compare.py')]
    if not (destination / 'choice_receipt.json').is_file():
        subprocess.run([*command, 'freeze', '--arm', 'augmented'], check=True)
    subprocess.run([*command, 'score', '--arm', 'augmented'], check=True)
print(destination / 'training_arm_summary.csv', flush=True)

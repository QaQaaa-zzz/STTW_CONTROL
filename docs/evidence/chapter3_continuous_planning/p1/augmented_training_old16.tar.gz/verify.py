"""Recompute choices, gate/clearance outcomes, paired gains and whole-menu hindsight from portable CSV inputs."""
from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
K=['map_id','root','gate_x','side'];M=['menu','method','seed']
Y={'gate':('lower','upper'),'matched_gate':('strict_lower','strict_upper'),'margin':('margin_lower','margin_upper'),
   'matched_margin':('matched_margin_lower','matched_margin_upper')}
def run():
    truth=pd.read_csv(HERE/'physical_inputs.csv.gz')
    measured=truth.actual_min_clearance_m.notna()
    truth['margin_lower']=(truth.lower.eq(1)&truth.actual_min_clearance_m.gt(.05330585315823555)).astype(int)
    truth['margin_upper']=truth.margin_lower.mask(truth.lower.ne(truth.upper)|(~measured&truth.upper.eq(1)),1)
    certified=truth.suffix_pair_status.isin(['matched_observed_handoff','matched_observed_prequery_endpoint'])
    truth['strict_lower']=truth.lower.where(certified,0);truth['strict_upper']=truth.upper.where(certified,1)
    truth['matched_margin_lower']=truth.margin_lower.where(truth.strict_lower.eq(truth.strict_upper),0)
    truth['matched_margin_upper']=truth.margin_upper.where(truth.strict_lower.eq(truth.strict_upper),1)
    results={}
    for arm in ('original','augmented'):
        dst=HERE/arm;receipt=json.loads((dst/'choice_receipt.json').read_text())
        for name,k in [('pre_action_scores.csv.gz','score_sha256'),('pre_action_choices.csv','choices_sha256')]:
            assert hashlib.sha256((dst/name).read_bytes()).hexdigest()==receipt[k]
        s=pd.read_csv(dst/'pre_action_scores.csv.gz',dtype={'seed':str},float_precision='round_trip')
        saved=pd.read_csv(dst/'pre_action_choices.csv',dtype={'seed':str},float_precision='round_trip')
        scored=pd.read_csv(dst/'physical_pairs.csv.gz',dtype={'seed':str})
        for menu,pool in [('old16',s),('old_alpha0',s[s.action_slot.isin([0,1,2])])]:
            group=pool.sort_values(['score','action_slot'],ascending=[False,True],kind='stable').drop_duplicates(K+['method','seed'])
            chosen=group.merge(saved[saved.menu.eq(menu)],on=K+['method','seed'],validate='one_to_one')
            assert len(chosen)==768 and chosen.action_slot_x.eq(chosen.action_slot_y).all()
        actual=saved.merge(truth,on=K+['action_slot'],validate='many_to_many')
        joined=actual.merge(scored,on=M+K+['force'],suffixes=('_calc','_arch'),validate='one_to_one')
        assert len(joined)==4608 and joined.action_slot_calc.eq(joined.action_slot_arch).all()
        assert all(joined[k+'_calc'].eq(joined[k+'_arch']).all() for lohi in Y.values() for k in lohi)
        for menu,pool in [('old16',truth),('old_alpha0',truth[truth.action_slot.isin([0,1,2])])]:
            for t,(lo,hi) in Y.items():
                opt=pool.groupby(K+['action_slot'])[[lo,hi]].sum().groupby(K).max()
                if arm=='augmented':
                    archived=pd.read_csv(dst/'hindsight_by_root_gate.csv').query('menu==@menu and target==@t').set_index(K).sort_index()
                    assert np.array_equal(opt[[lo,hi]],archived[['hindsight_lo','hindsight_hi']])
        results[arm]=actual
    g=results['augmented'].merge(results['original'],on=M+K+['force'],suffixes=('_aug','_orig'),validate='one_to_one')
    same=g.action_slot_aug.eq(g.action_slot_orig)
    expected=pd.read_csv(HERE/'augmented/training_arm_summary.csv',dtype={'seed':str})
    n=0
    for t,(lo,hi) in Y.items():
        g['dlo']=(g[lo+'_aug']-g[hi+'_orig']).mask(same,0);g['dhi']=(g[hi+'_aug']-g[lo+'_orig']).mask(same,0)
        for row in expected[expected.target.eq(t)].itertuples():
            v=g[g.menu.eq(row.menu)&g.method.eq(row.method)&g.seed.eq(row.seed)]
            if row.map_id!='both':v=v[v.map_id.eq(row.map_id)]
            if row.side:v=v[v.side.eq(row.side)]
            assert (len(v),v.dlo.sum(),v.dhi.sum(),v.dlo.eq(1).sum(),v.dhi.eq(-1).sum())==(row.n,row.net_lo,row.net_hi,row.rescued_lo,row.lost_lo)
            n+=1
    print('Verified both sets of 12,288 candidate scores against their digests, 3,072 choices, 9,216 selected outcomes,',n,
          'paired summary rows and all augmented per-root gate/clearance hindsight bounds.')
if __name__=='__main__':run()

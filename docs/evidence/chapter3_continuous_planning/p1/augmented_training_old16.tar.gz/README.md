# 旧16入口与固定 α=0 的三入口

每种方法按地图、起点、门选择一次，三种隐藏推力共用选择。每个菜单覆盖两张已打开的 DEV 地图、24 根、96 个指令和 288 个物理结果。旧16平分选最小槽号，固定线路为左门旧4、右门旧0。α=0 的菜单仅有旧0、1、2，固定线路为左门旧1、右门旧0。均值和三成分分别使用三个实际主权重；两种经验模型共享 TRAIN 支持集与固定抽样序列。各自冻结时先在观测、地图和出口曲线预测上评分，不使用开发标签。

在本目录分别运行以下两条；扩充训练的三个种子各自两项正式权重和末次拟合回执齐备后，参数换成 `augmented`。

```bash
CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 /home/qy/mujoco_playground/.venv/bin/python -B compare.py freeze --arm original
CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 /home/qy/mujoco_playground/.venv/bin/python -B compare.py score --arm original
```

- `pre_action_scores.csv.gz`、`pre_action_choices.csv` 和 `choice_receipt.json` 包含候选分数、事前选择及实用权重身份。
- `physical_pairs.csv.gz` 保留每个推力下两方物理轨迹和原门、净空、严格前缀标签的上下界。`relative_to_fixed.csv` 为相对两菜单各自固定规则的配对。扩充组另生成相对同种子原训练的 `training_arm_pairs.csv.gz`、`training_arm_summary.csv`。合计取 `map_id=both,side=0`，按侧取 −1 右、+1 左，按地图与侧看四格。
- 净空采用冻结车体／摆体包络，从首查起按每个5 ms原生姿态到真实终点要求严格大于0.05330585315823555 m。`measured_paths.csv.gz` 每条物理轨迹一行，复用历史已算值，补算所有选中且原门成功的轨迹及相应固定轨迹。
- `hindsight_by_root_gate.csv` 每根门先分别求每个槽三推成绩之和，再取可选槽最大值。无法判定的物理标签和未测净空的未选成功轨迹给出上下界。槽间的最优净空范围会随已测轨迹增多而收窄。各候选集使用完全相同的归约。

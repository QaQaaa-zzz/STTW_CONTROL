"""Prospective old-menu selection, followed by CPU-only paired scoring on the two open DEV maps."""
import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import torch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import nine_option_comparison as base
sys.path.append(str(base.NEW))
from score_rank_audit import strict_outcomes

P=base.P
FIT=base.fit
SEEDS=FIT.PLAN['shared_neural']['seeds']
KEY=base.KEY
ROW=KEY+['action_slot']
METHOD=['method','seed']
SCOPES={'gate':('lower','upper'),'matched_gate':('strict_lower','strict_upper'),
        'margin':('margin_lower','margin_upper'),'matched_margin':('matched_margin_lower','matched_margin_upper')}
LIMIT=.05330585315823555

def freeze(arm):
    assert FIT.registered()==json.loads((FIT.R/'augmentation_identity.json').read_text())
    training=P/'export' if arm=='original' else FIT.MERGED
    fit=FIT.MODEL/'formal_fit' if arm=='original' else FIT.R/'augmented_fit'
    # All six final native fits must be present before the arm is scored.
    nets={};identities={}
    for seed in SEEDS:
        path=fit/f'seed_{seed}'
        report=json.loads((path/'summary.json').read_text())
        assert (report['seed'],report['steps'],report['batch_size'])==(seed,540,128)
        for mode in base.MODE_NAMES:
            file=path/(mode+'.pt')
            cp=torch.load(file,map_location='cpu',weights_only=True)
            assert cp['mode']==mode
            model=base.JumpOutcome(cp['input_width'],mode,cp['width'])
            model.load_state_dict(cp['state'])
            nets[mode,str(seed)]=model.eval()
            identities[f'{seed}/{mode}']=FIT.digest(file)
    train=base.Dataset.join([base.Dataset.load(training/'train'/m) for m in FIT.PLAN['maps_train']])
    assert len(train.x)==(3456 if arm=='original' else 5184) and train.index.root.nunique()==72
    estimator=base.ExitValue(P/'actions/amortized_exit/train_model.npz')
    methods=list(nets)+[(m,'shared') for m in base.FAMILIES]
    grids=[]
    for name in FIT.PLAN['maps_dev']:
        data,_=base.decision_rows(P/'export/dev'/name,False)
        config=json.loads((P/'batches'/name/'physical/resolved_config.json').read_text())
        assert config['platform_online']['latency_ticks']=={'start':3,'departure':3}
        engine=base.FrozenExits.__new__(base.FrozenExits)
        with np.load(config['paired_departures']['approach_file']) as z:engine.approach=z['xy']
        engine.bank=base.mapped_arrays(config['paired_departures']['route_bank'])
        engine.bank_len=len(engine.bank['s'])
        world=base.KnownMap(P/'maps'/name)
        particles,options=base.predicted_states(data,nets,train,methods)
        metadata=['map_id','root','action_slot','geometry','alpha',*METHOD]
        parts=[]
        for i in range(0,len(particles),128):
            ps=particles[i:i+128]
            q,v,prev,t=[np.stack([p[k] for p in ps]) for k in ('q','v','prev','query_s')]
            branches=np.stack([engine.branch_ids(p['geometry'],p['q']) for p in ps])
            tags=pd.DataFrame([{k:p[k] for k in metadata} for p in ps])
            for gx,side in base.GATES:
                refs=[engine.bank[k][branches[:,0 if side==1 else 2]] for k in ('xy','heading','curvature')]
                parts.append(tags.assign(gate_x=gx,side=side,p_after=estimator.score(world,q,v,prev,t,gx,side,side,*refs)))
        mean=pd.concat(parts).groupby(ROW+METHOD).p_after.agg(['mean','size']).reset_index().rename(columns={'mean':'conditional_exit_probability','size':'particles'})
        opts=pd.DataFrame([{**{k:tag[k] for k in metadata},'gate_x':gx,'side':side,'p_relock':p} for tag,p,_ in options.values() for gx,side in base.GATES])
        grid=opts.merge(mean,on=ROW+METHOD,how='left',validate='one_to_one')
        assert grid.loc[grid.particles.isna(),'p_relock'].eq(0).all()
        grid['particles']=grid.particles.fillna(0).astype(int)
        grid['score']=grid.p_relock*grid.conditional_exit_probability.fillna(0)
        grids.append(grid)
    scores=pd.concat(grids,ignore_index=True)
    assert len(scores)==12288 and scores.groupby(KEY+METHOD).size().eq(16).all()
    dst=HERE/arm;dst.mkdir(exist_ok=True)
    parity={}
    if arm=='original':
        cache=pd.read_csv(base.OLD/'time_zero_scores.csv.gz',float_precision='round_trip')
        orig=scores[scores.seed.eq('61123')].merge(cache,on=ROW+['method'],validate='one_to_one',suffixes=('','_old'))
        assert len(orig)==len(cache)==3072
        for k in ('p_relock','conditional_exit_probability','score'):
            np.testing.assert_allclose(orig[k],orig[k+'_old'],atol=1e-7,rtol=1e-6)
            parity[k]=float((orig[k]-orig[k+'_old']).abs().max())
    scores.to_csv(dst/'pre_action_scores.csv.gz',index=False)
    selection=[]
    for menu,subset in [('old16',scores),('old_alpha0',scores[scores.action_slot.isin([0,1,2])])]:
        if menu=='old_alpha0':assert subset.alpha.eq(0).all()
        order=subset.sort_values(['score','action_slot'],ascending=[False,True],kind='stable')
        selected=order.groupby(KEY+METHOD,as_index=False).head(1)
        fixed=subset[subset.action_slot.eq(np.where(subset.side.eq(1),4 if menu=='old16' else 1,0))]
        fixed=fixed[KEY+METHOD+['action_slot','score']].rename(columns={'action_slot':'fixed_slot','score':'fixed_score'})
        selection.append(selected.merge(fixed,on=KEY+METHOD,validate='one_to_one').assign(menu=menu,family='old'))
    winners=pd.concat(selection,ignore_index=True)
    assert len(winners)==1536
    if arm=='original':
        prior=pd.read_csv(base.OLD/'time_zero_choices.csv')
        old=prior[prior.method.isin(['mean_all16','mixture3_all16'])].copy()
        old['method']=old.method.str.removesuffix('_all16')
        matched=winners.query('menu=="old16" and seed=="61123"').merge(old,on=KEY+['method'],validate='one_to_one')
        assert len(matched)==192 and matched.action_slot.eq(matched.selected).all()
        parity['exact_original_primary_choices']=192
    winners.to_csv(dst/'pre_action_choices.csv',index=False)
    (dst/'choice_receipt.json').write_text(json.dumps(dict(arm=arm,seeds=SEEDS,weights=identities,
        draw_seed=732611,forecasts=len(scores),choices=len(winners),score_sha256=FIT.digest(dst/'pre_action_scores.csv.gz'),
        choices_sha256=FIT.digest(dst/'pre_action_choices.csv'),old_primary_comparison=parity),indent=2)+'\n')
    print(arm,'choices frozen',len(winners),parity,flush=True)

def margins(required):
    # Reuse already measured curves, including the primary alpha=0 panel and earlier two-finalist screen.
    path=HERE/'measured_paths.csv.gz'
    tables=[]
    if path.exists():tables.append(pd.read_csv(path))
    for f in sorted((FIT.R/'nine_option').glob('original_*/physical_pairs.csv.gz')):
        v=pd.read_csv(f,usecols=['family','path','actual_min_clearance_m','path_fixed','actual_min_clearance_m_fixed'])
        tables.append(v[v.family.eq('old')][['path','actual_min_clearance_m']])
        tables.append(v[['path_fixed','actual_min_clearance_m_fixed']].rename(columns={'path_fixed':'path','actual_min_clearance_m_fixed':'actual_min_clearance_m'}))
    cached=pd.concat(tables).dropna().drop_duplicates('path')
    new=required[~required.path.isin(cached.path)]
    # Native pre-existing implementation reads XY-bound body poses every 5 ms from first query to last frame.
    other=base.old_margin(new)[['path','actual_min_clearance_m']].dropna()
    found=pd.concat([cached,other],ignore_index=True)
    diff=found.groupby('path').actual_min_clearance_m.agg(['min','max'])
    assert (diff['max']-diff['min']).abs().max()<1e-7
    found=found.drop_duplicates('path')
    assert required[required.lower.eq(1)].path.isin(found.path).all()
    found.to_csv(path,index=False)
    return found

def score(arm):
    dst=HERE/arm
    receipt=json.loads((dst/'choice_receipt.json').read_text())
    assert receipt['choices_sha256']==FIT.digest(dst/'pre_action_choices.csv')
    winners=pd.read_csv(dst/'pre_action_choices.csv',dtype={'seed':str})
    truth=pd.read_csv(base.OLD/'physical_conditions.csv.gz').rename(columns={'source_trajectory':'path'})
    index=pd.concat([pd.read_csv(P/'export/dev'/m/'suffix_index.csv') for m in FIT.PLAN['maps_dev']])
    truth=strict_outcomes(truth,index)
    assert len(truth)==4608
    selected=winners[ROW].drop_duplicates()
    fixed=winners[KEY+['fixed_slot']].rename(columns={'fixed_slot':'action_slot'}).drop_duplicates()
    requested=truth.merge(pd.concat([selected,fixed]).drop_duplicates(),on=ROW,validate='many_to_one')
    known=margins(requested)
    truth=truth.merge(known,on='path',how='left',validate='many_to_one')
    observed=truth.actual_min_clearance_m.notna()
    truth['margin_lower']=(truth.lower.eq(1)&truth.actual_min_clearance_m.gt(LIMIT)).astype(int)
    truth['margin_upper']=np.where(truth.lower.ne(truth.upper)|(~observed&truth.upper.eq(1)),1,truth.margin_lower)
    truth['matched_margin_lower']=truth.margin_lower.where(truth.strict_lower.eq(truth.strict_upper),0)
    truth['matched_margin_upper']=truth.margin_upper.where(truth.strict_lower.eq(truth.strict_upper),1)
    fields=['force','lower','upper','strict_lower','strict_upper','margin_lower','margin_upper','matched_margin_lower','matched_margin_upper',
            'actual_min_clearance_m','path']
    chosen=winners.merge(truth[ROW+fields],on=ROW,validate='many_to_many')
    fx=truth[ROW+fields].rename(columns={'action_slot':'fixed_slot'})
    pairs=chosen.merge(fx,on=KEY+['fixed_slot','force'],suffixes=('','_fixed'),validate='many_to_one')
    assert pairs.groupby(METHOD+['menu']).size().eq(288).all()
    pairs.to_csv(dst/'physical_pairs.csv.gz',index=False)
    ref=pairs.copy();ref['action_slot']=pairs.fixed_slot
    for col in fields:
        if col!='force':ref[col]=pairs[col+'_fixed']
    comparable,summary=base.compare_training_arms(ref,pairs)
    summary.rename(columns={'original_lo':'fixed_lo','original_hi':'fixed_hi','augmented_lo':'selected_lo','augmented_hi':'selected_hi'}).to_csv(dst/'relative_to_fixed.csv',index=False)
    comparable.rename(columns={'action_slot_orig':'fixed_slot','action_slot_aug':'selected_slot'}).to_csv(dst/'fixed_deltas.csv.gz',index=False)
    # The gate hindsight is fully enumerated. A physically successful but unmeasured clearance can be either side of the margin.
    records=[]
    for menu,pool in [('old16',truth),('old_alpha0',truth[truth.action_slot.isin([0,1,2])])]:
        for target,(lo,hi) in SCOPES.items():
            group=pool.groupby(ROW)[[lo,hi]].sum().reset_index()
            byroot=group.groupby(KEY)[[lo,hi]].max().rename(columns={lo:'hindsight_lo',hi:'hindsight_hi'}).reset_index()
            cnt=pool.assign(unmeasured_gate_success=pool.lower.eq(1)&pool.actual_min_clearance_m.isna()).groupby(KEY).unmeasured_gate_success.sum()
            byroot=byroot.join(cnt,on=KEY)
            records.append(byroot.assign(menu=menu,target=target))
    oracle=pd.concat(records,ignore_index=True)
    oracle.to_csv(dst/'hindsight_by_root_gate.csv',index=False)
    if arm=='original':
        registered=pd.read_csv(base.OLD/'groups.csv')
        for method in ['mean','mixture3']:
            s=pairs.query('method==@method and seed=="61123" and menu=="old16"').groupby(KEY)[['lower','upper']].sum()
            old=registered[registered.method.eq(method+'_all16')].set_index(KEY)
            assert s.sort_index().equals(old[s.columns].sort_index())
        old=registered[registered.method.eq('oracle_all16')].set_index(KEY).sort_index()
        new=oracle.query('menu=="old16" and target=="gate"').set_index(KEY).sort_index()
        assert np.array_equal(old[['lower','upper']],new[['hindsight_lo','hindsight_hi']])
    if arm=='augmented':
        original=pd.read_csv(HERE/'original/physical_pairs.csv.gz',dtype={'seed':str})
        paired,totals=base.compare_training_arms(original,pairs)
        paired.to_csv(dst/'training_arm_pairs.csv.gz',index=False)
        totals.to_csv(dst/'training_arm_summary.csv',index=False)
    print(summary.query("target in ['gate','margin'] and map_id=='both' and side==0 and seed=='61123'").to_string(index=False),flush=True)
    print('hindsight bounds (native gate and clearance)\n',oracle.groupby(['menu','target'])[['hindsight_lo','hindsight_hi']].sum().to_string(),flush=True)

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('stage',choices=['freeze','score'])
    cli.add_argument('--arm',choices=['original','augmented'],required=True)
    a=cli.parse_args();torch.set_num_threads(1)
    if a.stage=='freeze':freeze(a.arm)
    else:score(a.arm)

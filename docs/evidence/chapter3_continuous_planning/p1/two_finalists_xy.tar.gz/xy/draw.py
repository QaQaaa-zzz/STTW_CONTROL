"""Create the portable two-finalist DEV XY figures from archived physical records."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
from subprocess import check_output

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from matplotlib.font_manager import FontProperties,fontManager
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
KEY=['map_id','root','gate_x','side']
C=['#145b84','#bf4c26']
ROLE=['原固定','待验证候选']
OUTCOMES={'forbidden_obstacle_contact':'碰墙','tracking_domain_exit':'越出跟踪范围','goal':'抵达终点但错过指定门','timeout':'超时','physical_failure':'物理失败'}

def export():
    run=HERE.parents[4]
    choices=pd.read_csv(HERE.parent/'shortlist_before_ground.csv')
    truth=pd.read_csv(run/'actions/amortized_exit/development_entry/physical_conditions.csv.gz')
    both=choices.merge(truth,on=KEY+['action_slot','alpha'],validate='one_to_many')
    assert len(both)==576 and both.groupby(KEY+['incumbent']).size().eq(3).all()
    assert choices.groupby(KEY).action_slot.nunique().eq(2).all()
    maps={};arrays={};sources={};records=[]
    def intern(a):
        # Exact float arrays, no thinning or rounding. Repeated paths and references have a single entry.
        a=np.ascontiguousarray(a); name='a'+sha256(a.dtype.str.encode()+str(a.shape).encode()+a.tobytes()).hexdigest()[:20]
        if name in arrays:assert np.array_equal(arrays[name],a,equal_nan=True)
        else:arrays[name]=a
        return name
    with np.load(run/'shared/neutral.npz') as z:neutral=intern(z['xy'][0])
    for m,g in both.groupby('map_id'):
        scene=json.loads((run/'maps'/m/'world.json').read_text())
        maps[m]=dict(step=scene['terrain']['front_x_m'],walls=scene['terrain']['forbidden_rectangles'],goal=scene['goal'])
        meta=pd.read_csv(run/'export/dev'/m/'suffix_index.csv').set_index('lane')
        for r in g.itertuples():
            lane=meta.loc[r.lane]; assert lane.trajectory==r.source_trajectory and lane.arm==r.physical_arm
            if lane.trajectory not in sources:
                with np.load(lane.trajectory) as z:
                    xy=z['qpos'][:,:2];t=z['trace'][:,z['columns'].tolist().index('time')]
                    assert np.isclose(t[-1],lane.duration_s) and np.array_equal(xy,z['trace'][:,1:3],equal_nan=True)
                    finish=np.flatnonzero(np.isfinite(xy).all(axis=1))[-1]
                    sources[lane.trajectory]=dict(xy=intern(xy),time=intern(t),initial_ref=intern(z['reference_xy']),
                        exit_ref=intern(z['published_reference_xy']) if lane.physical_target_effective else '',
                        last_xy_tick=int(finish),last_xy_time_s=float(t[finish]),physical_end_s=float(t[-1]))
            records.append(dict(**{k:getattr(r,k) for k in KEY},incumbent=r.incumbent,slot=r.action_slot,geometry=r.geometry,alpha=r.alpha,
                         force=r.force,known=r.known,lower=r.lower,upper=r.upper,arm=r.physical_arm,lane=r.lane,
                         relocked=r.relocked,assigned_tick=int(lane.assigned_tick) if lane.physical_target_effective else -1,
                         termination=lane.termination,source=r.source_trajectory,**sources[lane.trajectory]))
    meta=pd.DataFrame(records);meta.to_csv(HERE/'case_legs.csv.gz',index=False)
    np.savez_compressed(HERE/'tracks.npz',**arrays)
    (HERE/'map.json').write_text(json.dumps(dict(neutral=neutral,maps=maps,entry_issue_tick=3,role='two historical DEV maps, original vs shortlisted entry, three physical pushes; fixed instructed-side exit'),indent=2)+'\n')

def cut_xy(ref,start,end):
    x=ref[:,0]
    lo,hi=max(x[0],start),min(x[-1],end)
    if hi<=lo:return ref[:0]
    part=ref[(x>lo)&(x<hi)]
    return np.vstack(([lo,np.interp(lo,x,ref[:,1])],part,[hi,np.interp(hi,x,ref[:,1])]))

def verdict(row):
    if not row.known:return '结果未知'
    if row.lower:return '完成'
    if not row.relocked:return '未落稳'
    return OUTCOMES.get(row.termination,row.termination)

def draw():
    meta=pd.read_csv(HERE/'case_legs.csv.gz')
    cfg=json.loads((HERE/'map.json').read_text())
    with np.load(HERE/'tracks.npz') as z:arrays={k:z[k] for k in z}
    font=check_output(['fc-match','-f','%{file}','Noto Sans CJK SC'],text=True)
    fontManager.addfont(font)
    plt.rcParams.update({'font.family':FontProperties(fname=font).get_name(),'font.size':10,'axes.unicode_minus':False})
    index=[]
    for key,g in meta.groupby(KEY,sort=True):
        m,root,gate,side=key;scene=cfg['maps'][m];goal=scene['goal'];order=g.sort_values('incumbent',ascending=False).drop_duplicates('incumbent')
        fig,axes=plt.subplots(3,1,figsize=(12,6.8),sharex=True,sharey=True)
        fig.subplots_adjust(left=.075,right=.978,top=.828,bottom=.108,hspace=.55)
        fig.suptitle(f'{m}　·　起点 {root}　·　'+('近' if gate==12.7 else '远')+('左门' if side==1 else '右门')+f'　x = {gate:g} m',y=.987,fontsize=16)
        handles=[Line2D([],[],lw=2,color=C[i],label=f'{ROLE[i]}　入口 {r.slot}（α={r.alpha:.3g}）') for i,r in enumerate(order.itertuples())]
        handles+= [Line2D([],[],color='#48515a',lw=1.3,ls=(0,(2,2)),label='控制器参考线'),
                   Line2D([],[],color='#48515a',marker='o',ls='',ms=5,label='完成时车位'),
                   Line2D([],[],color='#48515a',marker='X',ls='',ms=6,label='失败时车位')]
        fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.941),ncol=5,frameon=False,fontsize=9.4,columnspacing=1.3)
        ys=[];xs=[]
        for ax,(force,rr) in zip(axes,g.groupby('force')):
            ax.axvline(scene['step'],c='#7d8588',ls=':',lw=1)
            ax.plot([gate,gate],[side*.06,side*3.9],color='#52946b',lw=2.2,zorder=1)
            ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],fc='#e3eddc',zorder=0))
            for x0,x1,y0,y1 in scene['walls']:ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc='#9c8271',alpha=.75,zorder=0))
            statuses=[]
            for i,row in enumerate(rr.sort_values('incumbent',ascending=False).itertuples()):
                xy=arrays[row.xy];last=row.last_xy_tick;end=xy[last];t=arrays[row.time];idx=cfg['entry_issue_tick'];lead=xy[idx,0]
                cut=xy[row.assigned_tick,0] if row.assigned_tick>=0 else np.nanmax(xy[:,0])
                piece=[cut_xy(arrays[cfg['neutral']],xy[0,0],lead),cut_xy(arrays[row.initial_ref],lead,cut)]
                if row.assigned_tick>=0:piece.append(cut_xy(arrays[row.exit_ref],cut,goal['x_max_m']))
                for line in piece:
                    if len(line):
                        ax.plot(*line.T,ls=(0,(2,2)),c=C[i],lw=1.35,alpha=.9,zorder=4)
                        ys.append(line[:,1])
                ys.append(xy[:,1]);xs.append(xy[:,0])
                ax.plot(*xy.T,c=C[i],lw=2.35 if i==0 else 1.5,zorder=2+i)
                ax.plot(*end,marker='s' if not row.known else 'o' if row.lower else 'X',ls='',ms=7.5-i,c=C[i],mec='white',mew=.65,zorder=6+i)
                msg=verdict(row)
                if last!=len(t)-1:msg+='（末帧位置缺失）'
                statuses.append(f'{ROLE[i]} {msg}（{row.physical_end_s:.2f} s）')
            ax.set_title(f'横推 {force:+d} N　　'+ '　　 '.join(statuses),loc='left',fontsize=10)
            ax.set_ylabel('y（m）');ax.set_aspect('equal',adjustable='box');ax.grid(lw=.4,alpha=.25)
            ax.spines[['top','right']].set_visible(False)
        ys=np.concatenate(ys);xs=np.concatenate(xs)
        axes[-1].set(xlim=(min(1.,np.nanmin(xs)-.2),max(goal['x_max_m']+.2,np.nanmax(xs)+.25)),ylim=(min(-.9,np.nanmin(ys)-.15),max(.9,np.nanmax(ys)+.15)),xlabel='世界 x（m）')
        fig.text(.5,.023,'每行是同一推力下两次历史实跑。竖虚线标台阶，绿色竖线标门口，棕色是墙，浅绿是终点区。两轴等比例。',ha='center',fontsize=9)
        name=f'{m}_root{root}_gate{gate:g}_'+('L' if side==1 else 'R')+'.png'
        fig.savefig(HERE/name,dpi=120,metadata={'Description':'Two archived physical DEV approaches, three common pushes, original references and actual endpoints.'})
        plt.close(fig);index.append(dict(zip(KEY,key),file=name))
    frames=pd.DataFrame(index);frames.to_csv(HERE/'figures.csv',index=False)
    rows=[]
    for (m,root),group in frames.groupby(KEY[:2]):
        lookup=group.set_index(['gate_x','side']).file
        links=''.join(f'<td><a href="{lookup[x,s]}">{label}</a></td>' for x,s,label in [(12.7,1,'近左'),(12.7,-1,'近右'),(15.,1,'远左'),(15.,-1,'远右')])
        rows.append(f'<tr><td>{m}</td><td>{root}</td>{links}</tr>')
    (HERE/'index.html').write_text('<!doctype html><html lang="zh"><meta charset="utf-8"><title>开发图的两候选实走轨迹</title><style>body{font:16px sans-serif;max-width:62rem;margin:2rem auto}td,th{padding:.35rem 1rem;text-align:left}tr:nth-child(even){background:#edf4f6}</style><h1>两种入口的实走轨迹</h1><p>两张开发图，24 个起点，每个起点四道门。每张图对照固定规则和待验证候选在三种推力下的实走。</p><table><tr><th>地图</th><th>起点</th><th colspan=4>门的位置</th></tr>'+''.join(rows)+'</table></html>')
    print(f'{len(frames)} figures from {len(meta)} indexed case/role/push records')

def representatives(selected,column):
    raw=pd.read_csv(selected);groups=raw[KEY+[column]].rename(columns={column:'selected'});assert len(groups)==96
    figs=pd.read_csv(HERE/'figures.csv')
    records=pd.read_csv(HERE/'case_legs.csv.gz').merge(groups,on=KEY,validate='many_to_one')
    inc=records[records.incumbent]
    test=records[records.slot.eq(records.selected)]
    assert len(test)==len(inc)==288
    pairs=inc.merge(test,on=KEY+['force'],suffixes=('_base','_final'),validate='one_to_one')
    out=[]
    for key,g in pairs.groupby(KEY):
        known=g.known_base & g.known_final
        gain=((g.lower_base==0)&(g.lower_final==1)&known).sum()
        loss=((g.lower_base==1)&(g.lower_final==0)&known).sum()
        out.append(dict(zip(KEY,key),incumbent=int(g.slot_base.iloc[0]),selected=int(g.selected_final.iloc[0]),gain=gain,loss=loss,net=gain-loss,unknown=(~known).sum()))
    scored=pd.DataFrame(out).merge(figs,on=KEY,validate='one_to_one')
    scored.to_csv(HERE/'chosen_effects.csv',index=False)
    change=scored[scored.incumbent!=scored.selected].sort_values(KEY)
    lines=['# 最终选择的实走对照','',f'96 个地图／起点／门任务共更换 {len(change)} 个入口。逐推力比较有 {scored.gain.sum()} 次救回、{scored.loss.sum()} 次损失，{scored.unknown.sum()} 对结果未知。三种推力共用同一次跳前选择。','']
    for key,col,head in [('rescued','gain','净救回'),('lost','loss','净损失')]:
        bucket=change[change.net>0] if key=='rescued' else change[change.net<0]
        lines.extend([f'## {head}',''])
        if bucket.empty:
            lines+=['没有此类起点和门组合。',''];continue
        r=bucket.sort_values(['net',col]+KEY,ascending=[key!='rescued',False]+[True]*4).iloc[0]
        dst=f'{key}.png';shutil.copyfile(HERE/r.file,HERE/dst)
        lines += [f'{r.map_id}，起点 {r.root}，x={r.gate_x:g} m '+('左门' if r.side==1 else '右门')+f'。固定入口 {r.incumbent}，最终采用入口 {r.selected}。三推中救回 {r.gain} 次、损失 {r.loss} 次。', '', f'![{head}代表病例]({dst})','']
    if not len(change[change.net!=0]) and len(change):
        r=change.sort_values(['gain']+KEY,ascending=[False]+[True]*4).iloc[0]
        lines+=['## 更换入口但净变化为零','',f'{r.map_id}／{r.root}，固定入口 {r.incumbent}，最终入口 {r.selected}，三推中各有 {r.gain} 次救回和损失。','',f'![更换入口]({r.file})','']
    lines+=['[全部 96 组轨迹](index.html)　·　[全部选择与逐组变化](chosen_effects.csv)','']
    (HERE/'representatives.md').write_text('\n'.join(lines))
    print('observed switches, gains, losses',len(change),scored.gain.sum(),scored.loss.sum())

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('--export',action='store_true',help='read original archives and refresh the portable inputs')
    cli.add_argument('--selected',type=Path);cli.add_argument('--selection-column',default='selected')
    a=cli.parse_args()
    if a.export:export()
    index=HERE/'figures.csv'
    if not a.selected or not index.exists() or not all((HERE/name).exists() for name in pd.read_csv(index).file):draw()
    selection=a.selected or HERE.parent/'verified_choices.csv'
    if selection.exists():representatives(selection,a.selection_column)

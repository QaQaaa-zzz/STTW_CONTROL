"""Extract lossless plotting coordinates and cross-check the original four B2 physics runs."""
import zipfile
import struct
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def exact(a, b):
    return a.shape == b.shape and a.dtype == b.dtype and a.tobytes() == b.tobytes()


def main():
    r = Path(sys.argv[1]).resolve()
    dest = Path(__file__).resolve().parent
    p = r.parent / 'chapter3_continuous_p1_20261123'
    contract = json.loads((r / 'collection_contract.json').read_text())
    ready = json.loads((r / 'collection_ready.json').read_text())
    assert ready['collection_contract_sha256'] == sha(r / 'collection_contract.json')
    assert ready['protocol_sha256'] == sha(r / 'protocol.md')
    assert contract['allocation_sha256'] == sha(r / 'allocation.csv')
    assert contract['map_freeze_sha256'] == sha(r / 'map_freeze.json')
    assert sha(r / 'native_test_handoff.py') == contract['native_test_sha256']
    assert all(sha(Path(f)) == s for f,s in contract['shared_files'].values())
    assert all(sha(Path(f)) == s for f,s in contract['weight_hashes'].items())
    plan = pd.read_csv(r / 'allocation.csv')
    pairs = pd.read_csv(r / 'analysis/paired_tasks.csv.gz')
    keys = ['map_id','root','force','gate_x','side']
    assert len(plan)==2304 and len(pairs)==1152 and not plan.duplicated(keys+['arm']).any() and not pairs.duplicated(keys).any()
    assert pairs.groupby('map_id').root.nunique().eq(16).all()
    bank_path=p/'shared/departures.npz'
    with zipfile.ZipFile(bank_path) as bank_zip,bank_path.open('rb') as f:
        member=bank_zip.getinfo('xy.npy')
        assert member.compress_type==zipfile.ZIP_STORED
        f.seek(member.header_offset+26); n,m=struct.unpack('<HH',f.read(4)); f.seek(n+m,1)
        version=np.lib.format.read_magic(f)
        shape,fortran,dtype=(np.lib.format.read_array_header_1_0 if version==(1,0) else np.lib.format.read_array_header_2_0)(f)
        bank=np.memmap(bank_path,mode='r',dtype=dtype,offset=f.tell(),shape=shape,order='F' if fortran else 'C')
    neutral = np.load(p/'shared/neutral.npz')['xy'][0]
    refs = {'neutral': neutral}
    raw = {}; telemetry = {}; xy_ids = {}; raw_ids = {}; index = []; verifications = []
    for m in contract['maps']:
        name = m['name']; physical = r/name/'physical'
        dec = json.loads((physical/'declaration.json').read_text()); status = json.loads((physical/'status.json').read_text())
        config = json.loads((r/name/'config.json').read_text()); used = json.loads((physical/'resolved_config.json').read_text())
        assert status['stage']=='complete' and len(status['results'])==status['completed']==status['total']==576
        assert (dec['physics_dt'],dec['physics_substeps'],dec['lower_dt'],dec['upper_dt'],dec['episode_s'])==(.001,5,.005,.02,10)
        assert dec['world_map']==json.loads((r/name/'world.json').read_text())
        assert all(dec['skills']['rb_run1'][k]==v for k,v in contract['rb_identity'].items())
        assert dec['ground_model']['files']['actor.npz'] in contract['weight_hashes'].values()
        assert sha(r/name/'terrain.mjb')==sha(physical/'terrain.mjb')==m['mjb_sha256']
        assert sha(r/name/'world.json')==m['world_sha256'] and sha(r/name/'terrain.npz')==m['raster_sha256']
        assert sha(r/name/'config.json')==m['config_sha256']
        assert sha(physical/'source/playground_handoff_evaluation.py')==contract['native_test_sha256']
        front=dec['world_map']['terrain']['front_x_m']
        hand=config['ground_handoff']
        hand['goal']=dec['world_map']['goal']
        hand['approach']['jump_start_x_m']=front+config['planned_activation_offset_m']
        for variant in hand['handoff_variants']:
            variant['jump_start_x_m']=front+variant['activation_offset_m']
        assert all(config[k]==used[k] for k in config)
        scheduled = plan[plan.map_id==name].set_index('lane')
        with np.load(physical/'p1_applied_controls.npz') as f:
            targets, valid = f['targets'],f['valid']
        logs = {}
        for path in sorted((physical/'p1_query').glob('tick_*.npz')):
            with np.load(path) as f:
                data = {k:f[k] for k in f if k not in ('lanes','tick','previous_tick','remaining_s')}
                for j, lane in enumerate(f['lanes']):
                    logs[int(lane)] = int(f['tick']),{k:v[j] for k,v in data.items()}
        for row in pairs[pairs.map_id==name].itertuples():
            arrs=[]; states=[]
            for arm in ('original','new'):
                item=lambda field:getattr(row,field+'_'+arm)
                lane=item('lane'); a=scheduled.loc[lane]; sr=status['results'][lane]; variant=sr['variant']
                assert (variant['bank_row'],variant['force_y_N'],variant['section_x'],variant['side'],variant['test_margin_m'])==(a.root,a.force,a.gate_x,a.side,contract['methods'][arm=='new'])
                assert (sr['route'],variant['action_slot'],variant['approach_alpha'],sr['initial_release_tick'])==((1,4,1.,3) if a.side==1 else (0,0,0.,3))
                with np.load(physical/sr['case_dir']/'trajectory.npz') as f:
                    q,v,world,wheel,contact,tr,published=[f[k] for k in ('qpos','qvel','world_flags','wheel_contact_flags','contact_substep','trace','published_reference_xy')]
                assert exact(q[:,:2],tr[:,1:3]) and len(q)==len(v)==item('terminal_tick')+1
                assert np.isfinite(tr[:,:3]).all()
                assert bool(world[:,2].any())==item('wall')==(sr['forbidden_contact_steps']>0)
                assert sr['goal']==item('goal')==(sr['termination']=='goal')==(sr['goal_hold_s']>=.5)
                assert sr['termination']==item('terminal') and exact(q[-1,:2],np.array(sr['final_xy'],dtype=q.dtype))
                h=item('handback_tick'); tq=item('query_tick'); ta=item('assigned_tick'); d=item('issued_direction')
                assert (sr['handoff_s'] is not None)==(h>=0) and ta==sr['departure_applied_tick']
                state={}
                if tq>=0:
                    tq_logged,state=logs[lane]; assert tq==tq_logged==h+1 and ta==tq+3
                    assert exact(state['qpos'],q[tq]) and exact(state['previous_qpos'],q[tq-4])
                    assert d==(int(state['shadow_choice']) if state['shadow_any_admitted'] else 1)==sr['selected_departure']
                    assert sr['proposed_departure']==d and int(state['incumbent_direction'])==1
                    assert (state['branch_ids']==[item(s+'_ref') for s in ('left','straight','right')]).all()
                else:
                    assert lane not in logs and ta==-1
                selected_ref = [item(k+'_ref') for k in ('left','straight','right')][d] if ta>=0 else int(a.geometry)
                assert exact(published,bank[selected_ref].astype(published.dtype))
                for key in (int(a.geometry),item('straight_ref'),selected_ref):
                    if key>=0: refs['r'+str(key)]=bank[key]
                txy=tr[:,:3].copy()
                bits=np.stack((tr[:,10].astype(bool),tr[:,16].astype(bool),world[:,2]),axis=1)
                xy_hash=hashlib.sha256(txy.tobytes()).digest()
                bits_hash=hashlib.sha256(bits.tobytes()).digest()
                xy_key=xy_ids.setdefault(xy_hash,'t'+str(len(xy_ids))); raw[xy_key]=txy
                flags_key=raw_ids.setdefault(bits_hash,'f'+str(len(raw_ids))); telemetry[flags_key]=bits
                index.append(dict(map_id=name,lane=lane,txy=xy_key,flags=flags_key,goal_hold_s=sr['goal_hold_s'],terminal_native=sr['termination'],selected_ref=selected_ref))
                arrs.append((q,v,world,wheel,contact)); states.append(state)
            c=row.assigned_tick_original if row.assigned_tick_original>=0 else min(row.terminal_tick_new,row.terminal_tick_original)
            assert all(exact(a[:c+1],b[:c+1]) for a,b in zip(arrs[0][:4],arrs[1][:4]))
            a,b=(x[-1][:c+1] for x in arrs)
            assert exact(a[:,:,:3]<=1e-5,b[:,:,:3]<=1e-5) and exact(a[:,:,3]==0,b[:,:,3]==0)
            assert exact(a,b)==row.raw_loads_equal_original
            s0,s1=states; assert s0.keys()==s1.keys()
            assert all(exact(s0[k],s1[k]) for k in s0.keys()-{'shadow_choice','shadow_any_admitted','shadow_incumbent_admitted'})
            l1,l2=row.lane_original,row.lane_new
            assert exact(targets[:c,l1],targets[:c,l2]) and exact(valid[:c,l1],valid[:c,l2])
            diff=np.flatnonzero(valid[:,l1]&valid[:,l2]&(targets[:,l1,:2]!=targets[:,l2,:2]).any(1))
            assert (int(diff[0]) if len(diff) else -1)==row.first_different_wheel_command_tick_original
            verifications.append(dict(map_id=name,pair=row.pair,cut_tick=c))
    pd.DataFrame(index).to_csv(dest/'records.csv',index=False)
    np.savez_compressed(dest/'coordinates.npz',**raw)
    np.savez_compressed(dest/'flags.npz',**telemetry)
    np.savez_compressed(dest/'references.npz',**refs)
    print('Raw verified:',len(verifications),'pairs;',len(raw),'unique time-XY sequences;',len(refs),'references.',flush=True)

if __name__=='__main__':
    main()

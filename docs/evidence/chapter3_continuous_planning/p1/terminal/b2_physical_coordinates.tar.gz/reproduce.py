"""Recalculate held-out B2 endpoints, paired estimates and trajectories using portable artifacts."""
import argparse
import io
import json
import tarfile
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

HERE=Path(__file__).resolve().parent
PREFIX='chapter3_b2_margin_test_20261124/'
DARK=['#174d83','#c9541f']
GATES=[12.7,13.6,15.0]


def statistics(p):
    rng=np.random.default_rng(20261124)
    draws={name:rng.integers(0,16,(10000,16)) for name in sorted(p.map_id.unique())}
    result=[]
    for dimensions in [[],['map_id'],['side'],['gate_x'],['force'],['map_id','side'],['map_id','side','gate_x'],['map_id','side','gate_x','force']]:
        groups=[((),p)] if not dimensions else p.groupby(dimensions)
        for label,g in groups:
            if not isinstance(label,tuple): label=(label,)
            boot=np.zeros((10000,2))
            record=dict(level='/'.join(dimensions) or 'all',**dict(zip(dimensions,label)),tasks=len(g),roots=g.root.nunique())
            for name,m in g.groupby('map_id'):
                by_root=m.groupby('root')[['success_delta','wall_delta']].sum()
                assert len(by_root)==16
                boot+=by_root.to_numpy()[draws[name]].sum(1)
            for i,k in enumerate(['success','wall']):
                d=g[k+'_delta']; q=np.percentile(100*boot[:,i]/len(g),[2.5,97.5])
                for n,v in [('original',g[k+'_original'].sum()),('new',g[k+'_new'].sum()),('added',(d>0).sum()),('removed',(d<0).sum())]:
                    record[k+'_'+n]=int(v)
                record[k+'_delta_pp']=100*d.sum()/len(g)
                record[k+'_low95_pp'],record[k+'_high95_pp']=q
            result.append(record)
    return pd.DataFrame(result)


def verify(rows,records,coords,flags):
    for r in rows.itertuples():
        for arm in ('original','new'):
            val=lambda key:getattr(r,key+'_'+arm)
            item=records.loc[(r.map_id,val('lane'))]
            track=coords[item.txy]; t,x,y=track.T
            contact=flags[item['flags']][:,2]
            h=val('handback_tick')
            hit=np.where((x[:-1]<r.gate_x)&(x[1:]>=r.gate_x)&(np.arange(1,len(x))>=h))[0] if h>=0 else []
            gate_y=np.nan; gate_t=np.nan
            if len(hit):
                i=hit[0]; w=(r.gate_x-x[i])/(x[i+1]-x[i])
                gate_t=t[i]+w*(t[i+1]-t[i]); gate_y=y[i]+w*(y[i+1]-y[i])
            good=bool(.06<=r.side*gate_y<=3.9)
            assert np.isclose(gate_y,val('gate_y'),atol=3e-6,equal_nan=True)
            assert np.isclose(gate_t,val('gate_time'),atol=3e-6,equal_nan=True)
            assert len(t)==val('terminal_tick')+1 and np.allclose([x[-1],y[-1]],[val('terminal_x'),val('terminal_y')],rtol=0,atol=1e-6)
            assert good==val('gate_reached') and contact.any()==val('wall')
            assert item.terminal_native==val('terminal') and (item.goal_hold_s>=.5)==val('goal')
            assert bool(good and h>=0 and item.goal_hold_s>=.5 and not contact.any())==val('success')


def panel(ax,r,records,coords,flags,refs,world,limits,legend=False):
    for x0,x1,y0,y1 in world['terrain']['forbidden_rectangles']:
        ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,color='#707478',alpha=.82,zorder=1))
    ax.axvline(world['terrain']['front_x_m'],color='.76',lw=.8,zorder=0)
    ax.vlines(r.gate_x,r.side*.06,r.side*3.9,color='#368164',lw=1.4,zorder=1)
    for j,arm in enumerate(['original','new']):
        val=lambda key:getattr(r,key+'_'+arm)
        item=records.loc[(r.map_id,val('lane'))]; txy=coords[item.txy]; xy=txy[:,1:3]; active=flags[item['flags']][:,:2].any(1)
        n=len(xy); tq=val('query_tick'); ta=val('assigned_tick')
        intervals=[(0,3,'neutral'),(3,tq if tq>=0 else n,'r'+str(val('geometry')))]
        if tq>=0: intervals.extend([(tq,ta,'r'+str(val('straight_ref'))),(ta,n,'r'+str(item.selected_ref))])
        for i,e,key in intervals:
            good=np.flatnonzero(active[i:e])+i
            for group in np.split(good,np.flatnonzero(np.diff(good)>1)+1):
                if not len(group):continue
                ref=refs[key]; lo,hi=xy[group,0].min(),xy[group,0].max()
                a=ref[(ref[:,0]>=lo-.013)&(ref[:,0]<=hi+.013)]
                ax.plot(*a.T,color=DARK[j],ls=':',lw=1.65,zorder=2)
        ax.plot(*xy.T,color=DARK[j],lw=1.65 if j==0 else 1.1,alpha=.95,zorder=3)
        ax.plot(*xy[-1],marker='o' if val('success') else 'x',mfc='white',ms=6,color=DARK[j],ls='none',zorder=5)
    ax.set(xlim=limits[0],ylim=limits[1],aspect='equal')
    ax.spines[['right','top']].set_visible(False)
    ax.tick_params(labelsize=8)


def figures(p,records,coords,flags,refs,worlds,out,root):
    handles=[Line2D([],[],color=DARK[0],label='10.18 cm'),Line2D([],[],color=DARK[1],label='5.33 cm'),Line2D([],[],color='.23',ls='-',label='Body XY'),Line2D([],[],color='.23',ls=':',label='Active ground reference'),Line2D([],[],color='#368164',label='Requested gate'),Line2D([],[],ls='none',marker='o',mfc='white',color='.25',label='Success'),Line2D([],[],ls='none',marker='x',color='.25',label='Other endpoint')]
    cases=[
        (p[(p.root==1378)&(p.force==0)&(p.side==1)&(p.gate_x==12.7)],'Collision avoided; task completed'),
        (p[(p.root==1386)&(p.force==-5)&(p.side==1)&(p.gate_x==12.7)],'Same task outcome for both settings'),
        (p[(p.root==1370)&(p.force==5)&(p.side==1)&(p.gate_x==12.7)],'New straight exit leaves tracking domain'),
        (p[(p.root==1410)&(p.force==0)&(p.side==-1)&(p.gate_x==12.7)],'New left exit leaves tracking domain'),
        (p[(p.root==1425)&(p.force==0)&(p.side==-1)&(p.gate_x==12.7)],'Both cross gate; new right exit hits wall'),
        (p[(p.root==1425)&(p.force==0)&(p.side==-1)&(p.gate_x==15.0)],'Both miss gate; new right exit hits wall')]
    if root is None:
        fig,axes=plt.subplots(3,2,figsize=(13,6.6))
        fig.subplots_adjust(top=.86,bottom=.13,hspace=.66,wspace=.16)
        fig.suptitle('Four held-out maps  |  Paired physical trajectories',weight='bold',fontsize=17,y=.98)
        for ax,(frame,title) in zip(axes.flat,cases):
            r=next(frame.itertuples()); panel(ax,r,records,coords,flags,refs,worlds[r.map_id],((10.6,18.1),(-.95,1.0)))
            ax.set_title(f'{r.map_id} / start {r.root} / {r.force:+} N / '+('left' if r.side==1 else 'right')+f' gate at {r.gate_x:.1f} m\n{title}',fontsize=10,loc='left',pad=4)
        for ax in axes[-1,:]: ax.set_xlabel('World x (m)',fontsize=9)
        for ax in axes[:,0]: ax.set_ylabel('World y (m)',fontsize=9)
        fname='b2_counterexample_xy.png'
    else:
        g=p[p.root==root].sort_values(['force','gate_x','side'],ascending=[True,True,False])
        assert len(g)==18
        fig,axes=plt.subplots(3,6,figsize=(21,7))
        fig.subplots_adjust(top=.89,bottom=.15,hspace=.3,wspace=.17)
        fig.suptitle(f'{g.map_id.iloc[0]} / start {root} / 18 matched tasks; full recorded path',fontsize=16)
        for ax,r in zip(axes.flat,g.itertuples()):
            panel(ax,r,records,coords,flags,refs,worlds[r.map_id],((1.1,18.6),(-1.3,1.3)))
            ax.set_title(f'{r.force:+} N / '+('left' if r.side==1 else 'right')+f' / {r.gate_x:.1f} m',fontsize=9)
        fname=f'root_{root}_xy.png'
    fig.legend(handles=handles,loc='lower center',ncol=7,frameon=False,fontsize=9,bbox_to_anchor=(.5,.004)); fig.savefig(out/fname,dpi=185,facecolor='white');plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source_archive',type=Path,help='Existing, unmodified b2_source_and_results.tar.gz')
    parser.add_argument('--output',type=Path,default=Path('b2_reproduction'))
    parser.add_argument('--root',type=int,help='Redraw every pairing for one registered start, 1370–1433')
    args=parser.parse_args(); args.output.mkdir(parents=True,exist_ok=True)
    with tarfile.open(args.source_archive,'r:gz') as archive:
        p=pd.read_csv(io.BytesIO(archive.extractfile(PREFIX+'analysis/paired_tasks.csv.gz').read()),compression='gzip')
        worlds={m:json.load(archive.extractfile(PREFIX+m+'/world.json')) for m in p.map_id.unique()}
    records=pd.read_csv(HERE/'records.csv').set_index(['map_id','lane'])
    assert records.index.is_unique
    with np.load(HERE/'coordinates.npz') as a,np.load(HERE/'flags.npz') as b,np.load(HERE/'references.npz') as c:
        coords={k:a[k] for k in a}; flags={k:b[k] for k in b}; refs={k:c[k] for k in c}
    assert len(records)==2304 and len(p)==1152 and p.pair_ok_original.all() and p.pair_ok_new.all()
    verify(p,records,coords,flags)
    table=statistics(p); table.to_csv(args.output/'b2_paired_intervals.csv',index=False,float_format='%.9g')
    risks=p[(p.success_delta<0)|(p.wall_delta>0)].copy()
    risks=risks[['map_id','pair','root','force','side','gate_x','success_delta','wall_delta']+[v+'_'+a for v in ('issued_direction','gate_y','terminal','terminal_tick','terminal_x','terminal_y') for a in ('original','new')]]
    risks.to_csv(args.output/'counterexamples.csv',index=False)
    figures(p,records,coords,flags,refs,worlds,args.output,args.root)
    total=table.iloc[0]
    print(f'{len(records)} trajectories re-scored, {len(p)} pairs; {p.root.nunique()} starts; {total.success_added} successes gained, {total.success_removed} lost; {total.wall_removed} collisions avoided, {total.wall_added} added.')


if __name__=='__main__':
    main()

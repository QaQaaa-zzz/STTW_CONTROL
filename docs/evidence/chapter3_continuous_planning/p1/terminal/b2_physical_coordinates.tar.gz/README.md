# Portable B2 trajectory data

Keep the existing b2_source_and_results.tar.gz with this supplement. From an extracted supplement run the following with Python, NumPy, pandas and Matplotlib.

```sh
python reproduce.py ../b2_source_and_results.tar.gz --output review
python reproduce.py ../b2_source_and_results.tar.gz --output review --root 1425
```

The default regenerates the representative XY figure, stratified 95% intervals and individual counterexample table. A root argument redraws all 18 matched conditions at full longitudinal extent. All 2,304 histories retain their native 5 ms sample times, body centre XY and final observations. records.csv maps (map_id, physical lane) to the exact arrays. Byte-identical time/XY histories share one entry in coordinates.npz. The arrays in flags.npz record ground_active, approaching and forbidden_obstacle_contact at each sample. references.npz contains the neutral reference and the exact frozen bank rows used in the display. The retained direction-specific bank row, gate, clock and reason are stored in the original pair table. Plots draw the ground references clipped to the recorded interval of ground use. Goal hold and contact are native simulated observations.

The offline extractor extract_physical.py additionally verifies the full qpos/qvel histories and actual controls up to the first possible different actuation, recorded decision inputs, frozen identifiers, and all tasks against the original per-map physics journals. It requires the original physics folders and model assets. All default figure/table reproduction works without them or the simulator.

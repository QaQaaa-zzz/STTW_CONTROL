"""Reconstruct only six TRAIN maps' matched fixed-side physical labels and actual archived 5 ms clearance."""
from pathlib import Path
import importlib.util
from multiprocessing import Pool
import numpy as np
import pandas as pd
import mujoco
import torch

O=Path(__file__).resolve().parent
P=O.parent/'chapter3_continuous_p1_20261123';T=P/'continuous_train_support'
spec=importlib.util.spec_from_file_location('clearance',P/'actions/continuous_examples/continuous_entry_event_exit/reference_controls/check.py')
cl=importlib.util.module_from_spec(spec);spec.loader.exec_module(cl)

@torch.inference_mode()
def one(i):
    torch.set_num_threads(1)
    m=f'train_{i:02d}'
    old=pd.read_csv(P/f'export/cross_fixed_exit_gates/{m}_crossings.csv.gz')
    old=old.loc[old.arm.eq('left')==old.side.eq(1)].rename(columns={'action':'slot','done':'gate'})
    old['gate_x']=old.section.map({'near':12.7,'far':15.})
    new=pd.read_csv(T/f'pair_{i//2}_gate_cases.csv.gz')
    new=new[new.map_id.eq(m)].copy();new['slot']=new.action_slot+16
    new['gate']=new.lower.astype(bool)
    cols=['root','slot','force','lane','side','gate_x','gate']
    allrows=[];paths=[]
    model=mujoco.MjModel.from_binary_path(str(P/f'maps/{m}/terrain.mjb'))
    body=[model.geom(j).name or f'geom_{j}' for j in range(model.ngeom) if model.geom_bodyid[j]>0 and (model.geom_contype[j] or model.geom_conaffinity[j])]
    walls=[model.geom(j).name for j in range(model.ngeom) if model.geom(j).name.startswith('planning_obstacle_')]
    phys=cl.FrozenExits(P/f'batches/{m}/physical',device='cpu',load_route_bank=False).query
    for panel,cases,source in [('old',old,P),('new',new,T)]:
        sf=pd.read_csv(source/f'export/train/{m}/suffix_index.csv')
        sf['known']=(~sf.verified_relock)|(sf.suffix_pair_status.eq('matched_observed_handoff')&sf.physical_target_effective&sf.declared_direction.eq(sf.online_selected_direction))
        c=cases[cols].merge(sf[['lane','known','query_tick','trajectory','physical_goal','verified_relock','physical_wall']],on='lane',validate='many_to_one')
        passed=c[c.gate & c.known].drop_duplicates('lane')
        values={}
        for r in passed.itertuples():
            assert r.verified_relock and r.physical_goal and not r.physical_wall
            with np.load(r.trajectory) as raw:
                detail=cl.actual_clearance(raw,int(r.query_tick),phys,body,walls)
            values[r.lane]=detail['actual_min_clearance_m']
            paths.append(dict(map_id=m,panel=panel,lane=r.lane,trajectory=r.trajectory,minimum=values[r.lane]))
        c['minimum']=c.lane.map(values)
        c['margin']=(c.gate & c.minimum.gt(.05330585315823555))
        c['map_id']=m;c['panel']=panel
        allrows.append(c)
    c=pd.concat(allrows)
    assert len(c)==12*24*3*4 and not c.duplicated(['root','slot','side','gate_x','force']).any()
    out=O/'train';out.mkdir(exist_ok=True)
    c.to_csv(out/(m+'_labels.csv.gz'),index=False);pd.DataFrame(paths).to_csv(out/(m+'_paths.csv.gz'),index=False)
    print(m,len(c),len(paths),int(c.known.sum()),flush=True)
if __name__=='__main__':
    with Pool(3) as workers:list(workers.map(one,range(6)))

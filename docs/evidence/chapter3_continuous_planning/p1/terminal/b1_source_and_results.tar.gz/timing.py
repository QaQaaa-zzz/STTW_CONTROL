from pathlib import Path
import json,sys,time
import numpy as np
import pandas as pd
import torch
import b1
sys.path.insert(0,str(b1.P/'export'))
from export_prefixes import decision_inputs as corridor

@torch.inference_mode()
def main():
    frozen=json.loads((b1.O/'train_freeze.json').read_text())['selected'];expected=pd.read_csv(b1.O/'dev_choices.csv').set_index(b1.KEY)
    cp=torch.load(b1.O/'value.pt',map_location='cpu',weights_only=True)
    net=b1.Value(cp['xd'],cp['gd']);net.load_state_dict(cp['state']);net.eval()
    with np.load(b1.P/'actions/approaches.npz') as z:bank=dict(z)
    batches=[]
    for k in range(2):
        m=f'dev_{k:02d}';folder=b1.P/f'export/dev/{m}';meta=pd.read_csv(folder/'prefix_index.csv',usecols=['row','root','geometry','action_slot','alpha'])
        world=json.loads((b1.P/f'maps/{m}/world.json').read_text())
        with np.load(b1.P/f'maps/{m}/terrain.npz') as z:ras=dict(z)
        with np.load(folder/'observed_inputs.npz') as z:q,v=z['t0_qpos_native'],z['t0_qvel_native']
        for root,g in meta.groupby('root'):
            c=g.sort_values('row').drop_duplicates('action_slot').sort_values('action_slot')
            assert c.action_slot.tolist()==list(range(16))
            for gx,side in b1.GATES:
                batches.append((m,root,gx,side,q[c.row.iloc[0]],v[c.row.iloc[0]],c.geometry.to_numpy(),c.alpha.to_numpy(),ras,world))
    records=[]
    for rep in range(6):
        for m,root,gx,side,q,v,geo,alpha,ras,world in batches:
            t0=time.perf_counter_ns()
            inp=corridor(np.repeat(q[None],16,0),np.repeat(v[None],16,0),geo,alpha,bank,ras,world)
            x,g=b1.feature(inp,world,[(gx,side)]);a=b1.tensor(x);b=b1.tensor(g)
            t1=time.perf_counter_ns()
            r,p=net(a,b);rp=r.sigmoid().numpy();pp=p.reshape(16).sigmoid().numpy();t2=time.perf_counter_ns()
            fixed=4 if side==1 else 0
            alt=pp.copy();alt[fixed]=-np.inf;j=int(alt.argmax())
            pick=j if pp[j]-pp[fixed]>frozen['gain'] and rp[j]>=frozen['lock'] else fixed
            t3=time.perf_counter_ns()
            one_start=time.perf_counter_ns();r1,p1=net(a[:1],b[:1]);r1.sigmoid();p1.sigmoid();one_stop=time.perf_counter_ns()
            assert pick==expected.loc[(m,root,gx,side),'slot']
            records.append(dict(repetition=rep,map_id=m,root=root,gate_x=gx,side=side,one_forward_ms=(one_stop-one_start)*1e-6,
                batch_forward_ms=(t2-t1)*1e-6,raw_to_choice_ms=(t3-t0)*1e-6))
    out=pd.DataFrame(records);warm=out[out.repetition>0];out.to_csv(b1.O/'timing.csv.gz',index=False)
    fields=['one_forward_ms','batch_forward_ms','raw_to_choice_ms'];stats={f:dict(p50=float(warm[f].median()),p95=float(warm[f].quantile(.95)),maximum=float(warm[f].max())) for f in fields}
    b1.save('timing_receipt.json',dict(samples=len(warm),first_complete_request_ms=float(out.raw_to_choice_ms.iloc[0]),
        warmup_requests=96,verified_frozen_choices=96,stats=stats,complete_under_5ms=int(warm.raw_to_choice_ms.lt(5).sum()),
        scope='One CPU thread. 16 registered resident base curves, map raster/walls and raw t0 q/v ready. Includes 65-point corridor sampling, velocity conversion, map and route features, both heads, all scores and selected slot. No simulation I/O, network/bus or actuator latency. One-pass timing only counts a single candidate neural forward with input ready.'))
    print(stats)
if __name__=='__main__':main()

"""Actual paired development trajectories for one saved recovery and one loss."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
O=Path(__file__).resolve().parent
P=O.parent/'chapter3_continuous_p1_20261123'
data=pd.read_csv(O/'dev_paired.csv.gz')
cases=[('Additional completion','dev_00',1330,12.7,0),('Lost completion','dev_01',1336,15.,0)]
fig,axs=plt.subplots(2,1,figsize=(12.2,6.4));fig.subplots_adjust(left=.068,right=.97,top=.78,bottom=.13,hspace=.75)
fig.suptitle('Two left-gate decisions: one additional finish and one loss',x=.07,y=.97,ha='left',fontsize=18,weight='semibold')
fig.text(.071,.89,'Previously driven trajectories. Both panels show the zero-push draw; each departure choice was shared by all three pushes.',fontsize=10)
fig.legend(handles=[Line2D([],[],c='#525961',lw=2.2,label='Fixed entry'),Line2D([],[],c='#007388',lw=2.2,label='B1 entry'),Line2D([],[],c='#646464',ls='--',label='Issued reference'),Line2D([],[],c='#646464',marker='o',mfc='white',ls='',label='Task complete'),Line2D([],[],c='#646464',marker='x',ls='',label='Failure endpoint')],ncol=5,loc='upper left',bbox_to_anchor=(.06,.865),frameon=False)
arrays={}
for i,(ax,(title,m,root,gx,force)) in enumerate(zip(axs,cases)):
    r=data[(data.map_id==m)&(data.root==root)&(data.gate_x==gx)&(data.side==1)&(data.force==force)].iloc[0]
    meta=pd.read_csv(P/f'export/dev/{m}/suffix_index.csv').set_index('trajectory');world=json.loads((P/f'maps/{m}/world.json').read_text());labels=[]
    for suf,col in [('_fixed','#525961'),('','#007388')]:
        fn=r['path'+suf];rr=meta.loc[fn]
        with np.load(fn) as f:
            xy=f['qpos'][:,:2];xy=xy[np.isfinite(xy).all(1)];ref=f['reference_xy'];posted=f['published_reference_xy']
        if int(rr.assigned_tick)>=0 and rr.assigned_tick<len(xy):
            x0=xy[int(rr.assigned_tick),0];paths=[ref[ref[:,0]<=x0],posted[(posted[:,0]>=x0)&(posted[:,0]<=world['goal']['x_max_m'])]]
        else:paths=[ref[ref[:,0]<=xy[-1,0]]]
        for line in paths:ax.plot(*line.T,c=col,ls='--',lw=1.1,zorder=2)
        ax.plot(*xy.T,c=col,lw=2.,alpha=.9,zorder=3)
        ax.plot(*xy[-1],'o' if r['margin_lo'+suf] else 'x',c=col,mfc='white',ms=7,mew=1.7,zorder=5)
        labels.append(('Fixed' if suf else 'B1')+' '+('complete' if r['margin_lo'+suf] else rr.termination.replace('_',' ')))
        nm=('fixed' if suf else 'b1')+str(i);arrays[nm+'_xy']=xy
        for n,line in enumerate(paths):arrays[nm+'_ref'+str(n)]=line
    goal=world['goal'];ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],fc='#e1eee3',ec='#a4b8a6'))
    for lo,hi,a,b in world['terrain']['forbidden_rectangles']:ax.add_patch(Rectangle((lo,a),hi-lo,b-a,color='#554a44'))
    ax.axvline(10.3,color='#7b837c',ls=':',lw=1);ax.vlines(gx,.06,3.9,color='#824d7d',lw=2)
    ax.set(xlim=(8.6,18.55),ylim=(-.85,.85),aspect='equal',ylabel='world y (m)')
    ax.set_title(f'{title}    |    {m}, start {root}, left gate at {gx:g} m    |    '+', '.join(labels),loc='left',fontsize=11)
axs[-1].set_xlabel('world x (m)');fig.savefig(O/'first_xy.png',dpi=165);np.savez_compressed(O/'first_xy.npz',**arrays)

"""One fixed, supervised predictor. The train/freeze/score boundaries are separate processes."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F

O=Path(__file__).resolve().parent;P=O.parent/'chapter3_continuous_p1_20261123';T=P/'continuous_train_support'
GATES=[(12.7,1),(12.7,-1),(15.,1),(15.,-1)]
KEY=['map_id','root','gate_x','side']; ACT=KEY+['slot']
RKEY=['map_id','root','slot']
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(name,x):(O/name).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def tensor(x):return torch.as_tensor(np.asarray(x),dtype=torch.float32)
torch.set_num_threads(1);torch.set_num_interop_threads(1)

def feature(obs,world,gates):
    q=obs['t0_qpos_native'];profile=obs['approach_profile']
    w,x,y,z=q[:,3:7].T
    angles=np.column_stack((np.arctan2(2*(w*x+y*z),1-2*(x*x+y*y)),np.arcsin(np.clip(2*(w*y-z*x),-1,1)),np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z))))
    step=obs['step_geometry'];off=np.linspace(-4.,0.,13)
    # The raw profile is sampled on the same 65 equally spaced x locations at each departure.
    fraction=((step[:,0:1]+off)/step[:,0:1]*64).clip(0,64)
    lower=np.minimum(fraction.astype(int),63);alpha=(fraction-lower)[:,:,None]
    i=np.arange(len(q))[:,None]
    geom=profile[i,lower,1:]*(1-alpha)+profile[i,lower+1,1:]*alpha
    terrain=[obs[k][:,:64].reshape(len(q),8,8,3).mean(2).reshape(len(q),24) for k in ('approach_corridor_height_m','approach_corridor_support')]
    state=np.column_stack((q[:,:3],angles,q[:,[8,10,11]],obs['t0_velocity_state9'],step,obs['alpha'],geom.reshape(len(q),-1),*terrain))
    rect=np.array(world['terrain']['forbidden_rectangles'])
    downstream=[]
    for gx,side in gates:
        order=np.argsort(np.abs(rect[:,:2].mean(1)-gx),kind='stable')[:2]
        r=rect[order];wfeat=np.zeros((2,5));wfeat[:len(r),0]=1
        wfeat[:len(r),1:3]=r[:,:2]-gx
        wfeat[:len(r),3:5]=np.sort(r[:,2:]*side,axis=1)
        g=np.column_stack((gx-q[:,0],np.full(len(q),side),np.full(len(q),world['goal']['x_min_m']-gx),np.tile(wfeat.ravel(),(len(q),1))))
        downstream.append(g)
    return state.astype(np.float32),np.stack(downstream,1).astype(np.float32)

def inputs(role):
    x=[];g=[];tags=[]
    for n in range(6 if role=='train' else 2):
        m=f'{role}_{n:02d}';path=(T/'augmented_export' if role=='train' else P/'export')/role/m
        ix=pd.read_csv(path/'prefix_index.csv',usecols=['row','root','action_slot','geometry','alpha'])
        ix['map_id']=m
        ix=ix.sort_values(['root','action_slot','row']);first=ix.groupby(['root','action_slot'],sort=False).head(1)
        idx=first.row.to_numpy();all_ids=ix.row.to_numpy().reshape(-1,3)
        with np.load(path/'observed_inputs.npz') as z:
            obs={k:z[k][idx] for k in z.files}
            for k in z.files:assert np.array_equal(z[k][all_ids],np.repeat(obs[k][:,None],3,axis=1))
        args=feature(obs,json.loads((P/f'maps/{m}/world.json').read_text()),GATES)
        x.append(args[0]);g.append(args[1]);tags.append(first.rename(columns={'action_slot':'slot'}))
    return tensor(np.concatenate(x)),tensor(np.concatenate(g)),pd.concat(tags,ignore_index=True)

class Value(nn.Module):
    def __init__(self,xd,gd):
        super().__init__()
        self.trunk=nn.Sequential(nn.Linear(xd,48),nn.SiLU(),nn.Linear(48,24),nn.SiLU())
        self.relock=nn.Linear(24,1)
        self.task=nn.Sequential(nn.Linear(24+gd,24),nn.SiLU(),nn.Linear(24,1))
        for k,dim in [('xm',xd),('xs',xd),('gm',gd),('gs',gd)]:self.register_buffer(k,torch.zeros(dim))
    def forward(self,x,g):
        h=self.trunk((x-self.xm)/self.xs)
        z=torch.cat((h[:,None].expand(-1,g.shape[1],-1),(g-self.gm)/self.gs),dim=-1)
        return self.relock(h).view(-1),self.task(z).squeeze(-1)

def fit(x,g,yr,yp,wt,train):
    torch.manual_seed(61123)
    net=Value(x.shape[-1],g.shape[-1])
    net.xm.copy_(x[train].mean(0));net.xs.copy_(x[train].std(0,unbiased=False).clamp_min(.001))
    allg=g[train].reshape(-1,g.shape[-1]);net.gm.copy_(allg.mean(0));net.gs.copy_(allg.std(0,unbiased=False).clamp_min(.001))
    opt=torch.optim.AdamW(net.parameters(),lr=.002,weight_decay=.001)
    gen=torch.Generator().manual_seed(61123)
    ids=torch.where(train)[0];track=[]
    for ep in range(64):
        loss_sum=0
        for batch in ids[torch.randperm(len(ids),generator=gen)].split(128):
            a,b=net(x[batch],g[batch]);pass_loss=F.binary_cross_entropy_with_logits(b,yp[batch],reduction='none')
            loss=F.binary_cross_entropy_with_logits(a,yr[batch])+(pass_loss*wt[batch]).sum()/wt[batch].sum()
            opt.zero_grad();loss.backward();opt.step();loss_sum+=loss.item()*len(batch)
        track.append(loss_sum/len(ids))
    return net.eval(),track

def predictions(net,x,g,tags):
    with torch.inference_mode():ra,pa=net(x,g);ra,pa=ra.sigmoid().numpy(),pa.sigmoid().numpy()
    parts=[]
    for col,(gx,side) in enumerate(GATES):parts.append(tags[RKEY].assign(gate_x=gx,side=side,p_relock=ra,p_pass=pa[:,col]))
    return pd.concat(parts,ignore_index=True)

def select(frame,gain,lock):
    frame=frame[frame.slot<16]
    fixed=frame[frame.slot.eq(np.where(frame.side.eq(1),4,0))][KEY+['slot','p_pass']].rename(columns={'slot':'fixed','p_pass':'fixed_p'})
    alt=frame.merge(fixed,on=KEY,validate='many_to_one')
    alt=alt[alt.slot.ne(alt.fixed)].sort_values(['p_pass','slot'],ascending=[False,True],kind='stable').drop_duplicates(KEY)
    use=(alt.p_pass-alt.fixed_p>gain)&(alt.p_relock>=lock)
    return alt.rename(columns={'slot':'alternative','p_pass':'alternative_p','p_relock':'alternative_relock'}).assign(slot=np.where(use,alt.slot,alt.fixed),override=use)

def pairs(chosen,truth):
    src=truth.rename(columns={'slot':'fixed'})
    fixed=chosen.merge(src,on=KEY+['fixed'],validate='one_to_many')
    p=fixed.merge(truth,on=ACT+['force'],suffixes=('_fixed',''),validate='one_to_one')
    for t in ('margin','gate'):
        p[t+'_delta_lo']=(p[t+'_lo']-p[t+'_hi_fixed']).where(p.override,0)
        p[t+'_delta_hi']=(p[t+'_hi']-p[t+'_lo_fixed']).where(p.override,0)
    return p

def training():
    x,g,tags=inputs('train')
    a=pd.concat([pd.read_csv(O/f'train/train_{n:02d}_labels.csv.gz') for n in range(6)])
    truth=a[ACT+['force','known','margin','gate']].copy()
    for target in ('margin','gate'):
        truth[target+'_lo']=(truth[target]&truth.known).astype(int);truth[target+'_hi']=(truth[target]|~truth.known).astype(int)
    sums=truth.groupby(ACT,as_index=False).agg(w=('known','sum'),v=('margin_lo','sum'))
    p=[];w=[]
    for gx,side in GATES:
        h=tags.merge(sums.query('gate_x==@gx and side==@side'),on=RKEY,validate='one_to_one')
        p.append(h.v/h.w.clip(lower=1));w.append(h.w)
    rel=a.groupby(RKEY+['force'],sort=False).verified_relock.agg(['min','max']).reset_index()
    assert rel['min'].equals(rel['max']) and len(rel)==5184
    r=tags.merge(rel.groupby(RKEY,as_index=False)['max'].mean(),on=RKEY,validate='one_to_one')
    yr=tensor(r['max']);yp=tensor(np.stack(p,1));wt=tensor(np.stack(w,1))
    pred=[];history=[]
    for m in tags.map_id.unique():
        held=torch.as_tensor(tags.map_id.eq(m).to_numpy());net,loss=fit(x,g,yr,yp,wt,~held)
        pred.append(predictions(net,x[held],g[held],tags[held.numpy()]));history.extend(dict(fold=m,epoch=i+1,loss=v) for i,v in enumerate(loss))
    pred=pd.concat(pred);pred.to_csv(O/'train_oof_predictions.csv.gz',index=False)
    grid=[]
    for gain in (0,.05,.10,.15,.2,.3,.4,.5,1.):
        for lock in (0,.5,.65,.8,.9):
            chosen=select(pred,gain,lock);v=pairs(chosen,truth)
            delta=v.groupby('side').margin_delta_lo.sum();maps=v.groupby('map_id').margin_delta_lo.sum()
            grid.append(dict(gain=gain,lock=lock,left=int(delta[1]),right=int(delta[-1]),total=int(delta.sum()),worst_map=int(maps.min()),switches=int(chosen.override.sum()),eligible=bool(delta.min()>=-2)))
    grid=pd.DataFrame(grid);grid.to_csv(O/'threshold_grid.csv',index=False)
    best=grid[grid.eligible].sort_values(['total','worst_map','switches','gain','lock'],ascending=[False,False,True,False,False]).iloc[0].to_dict()
    oof=pairs(select(pred,best['gain'],best['lock']),truth);oof.to_csv(O/'train_oof_paired.csv.gz',index=False)
    net,loss=fit(x,g,yr,yp,wt,torch.ones(len(x),dtype=torch.bool))
    history.extend(dict(fold='all',epoch=i+1,loss=v) for i,v in enumerate(loss));pd.DataFrame(history).to_csv(O/'fit_history.csv',index=False)
    torch.save(dict(xd=x.shape[-1],gd=g.shape[-1],state=net.state_dict()),O/'value.pt')
    save('train_freeze.json',dict(selected=best,unique_starts=72,prefixes=len(rel),gate_targets=len(truth),unknown=int((~truth.known).sum()),completed_fits=7,
        code_sha256=sha(__file__),protocol_sha256=sha(O/'protocol.md'),weights_sha256=sha(O/'value.pt'),training_labels={f.name:sha(f) for f in sorted((O/'train').glob('*_labels.csv.gz'))}))
    print(best,flush=True)

def freeze_choices():
    reg=json.loads((O/'train_freeze.json').read_text());assert reg['weights_sha256']==sha(O/'value.pt') and reg['code_sha256']==sha(__file__)
    x,g,tags=inputs('dev')
    f=torch.load(O/'value.pt',map_location='cpu',weights_only=True);net=Value(f['xd'],f['gd']);net.load_state_dict(f['state']);net.eval()
    pred=predictions(net,x,g,tags);t=reg['selected'];p=select(pred,t['gain'],t['lock'])
    assert len(p)==96 and len(pred)==1536 and p.override.sum()==sum(p.slot!=p.fixed)
    pred.to_csv(O/'dev_departure_predictions.csv.gz',index=False);p.to_csv(O/'dev_choices.csv',index=False)
    save('dev_choices_frozen.json',dict(choices=len(p),overrides=int(p.override.sum()),choices_sha256=sha(O/'dev_choices.csv'),predictions_sha256=sha(O/'dev_departure_predictions.csv.gz'),train_freeze_sha256=sha(O/'train_freeze.json')))
    print('96 choices frozen',int(p.override.sum()),flush=True)

if __name__=='__main__':
    args=argparse.ArgumentParser();args.add_argument('stage',choices=['train','freeze']);cmd=args.parse_args()
    (training if cmd.stage=='train' else freeze_choices)()

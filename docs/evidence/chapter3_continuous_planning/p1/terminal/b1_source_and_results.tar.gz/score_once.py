"""Read frozen DEV choices, then score their single realized comparison; no fitting or selection."""
import importlib.util
import json
from pathlib import Path
import sys
import time
import numpy as np
import pandas as pd
import mujoco
import torch
import b1

O,P,T=b1.O,b1.P,b1.T
LOCK=O/'dev_choices_frozen.json'
MARGIN=.05330585315823555
def metrics(p):
    rows=[]
    for (m,s),f in [(('both',0),p),*[(('both',i),v) for i,v in p.groupby('side')],*[((i,0),v) for i,v in p.groupby('map_id')],*p.groupby(['map_id','side'])]:
        for target in ('margin','gate'):
            lo=f[target+'_delta_lo'];hi=f[target+'_delta_hi']
            rows.append(dict(map_id=m,side=int(s),target=target,denominator=len(f),changed=int(f.override.sum()),fixed_lo=int(f[target+'_lo_fixed'].sum()),
                fixed_hi=int(f[target+'_hi_fixed'].sum()),selected_lo=int(f[target+'_lo'].sum()),selected_hi=int(f[target+'_hi'].sum()),net_lo=int(lo.sum()),
                net_hi=int(hi.sum()),rescued_lo=int(lo.eq(1).sum()),rescued_hi=int(hi.eq(1).sum()),lost_lo=int(hi.eq(-1).sum()),lost_hi=int(lo.eq(-1).sum())))
    return pd.DataFrame(rows)

def fill_distances(rows):
    filepath=P/'actions/continuous_examples/continuous_entry_event_exit/reference_controls/check.py'
    spec=importlib.util.spec_from_file_location('clearance',filepath);cl=importlib.util.module_from_spec(spec);spec.loader.exec_module(cl)
    results={}
    missing=rows[rows.lower.eq(1)&rows.actual_min_clearance_m.isna()]
    for m,group in missing.groupby('map_id'):
        meta=pd.read_csv(P/f'export/dev/{m}/suffix_index.csv').set_index('trajectory')
        model=mujoco.MjModel.from_binary_path(str(P/f'maps/{m}/terrain.mjb'))
        q=cl.FrozenExits(P/f'batches/{m}/physical',device='cpu',load_route_bank=False).query
        names=[model.geom(i).name or f'geom_{i}' for i in range(model.ngeom) if model.geom_bodyid[i]>0 and (model.geom_contype[i] or model.geom_conaffinity[i])]
        walls=[model.geom(i).name for i in range(model.ngeom) if model.geom(i).name.startswith('planning_obstacle_')]
        for path in group.path.unique():
            ref=meta.loc[path]
            with np.load(path) as z:d=cl.actual_clearance(z,int(ref.query_tick),q,names,walls)
            results[path]=d['actual_min_clearance_m']
    rows['actual_min_clearance_m']=rows.actual_min_clearance_m.fillna(rows.path.map(results))
    return len(results)

@torch.inference_mode()
def main():
    t=json.loads(LOCK.read_text());assert t['choices_sha256']==b1.sha(O/'dev_choices.csv')
    chosen=pd.read_csv(O/'dev_choices.csv')
    src=T/'supplement_old16/physical_inputs.csv.gz'
    data=pd.read_csv(src).rename(columns={'action_slot':'slot'})
    assert len(data)==4608 and not data.duplicated(b1.ACT+['force']).any()
    use=pd.concat([chosen[b1.ACT],chosen[b1.KEY+['fixed']].rename(columns={'fixed':'slot'})]).drop_duplicates()
    merged=use.merge(data,on=b1.ACT,validate='one_to_many')
    assert len(merged)==len(use)*3
    new_distances=fill_distances(merged);assert merged.loc[merged.lower.eq(1),'actual_min_clearance_m'].notna().all()
    merged['gate_lo']=merged.lower;merged['gate_hi']=merged.upper
    merged['margin_lo']=((merged.lower==1)&(merged.actual_min_clearance_m>MARGIN)).astype(int)
    merged['margin_hi']=merged.margin_lo.where(merged.lower.eq(merged.upper),1)
    p=b1.pairs(chosen,merged)
    assert len(p)==288 and p['gate_lo_fixed'].sum()==175 and p.margin_lo_fixed.sum()==123
    p.to_csv(O/'dev_paired.csv.gz',index=False)
    s=metrics(p);s.to_csv(O/'dev_results.csv',index=False)
    print(s[s.map_id.eq('both')|s.side.eq(0)].to_string(index=False),flush=True)
    # Reuse the measured native three-way selector only where it evaluated this actual gate.
    # Other gates at the same start did not necessarily request the same native route.
    f=P/'model/formal_downstream/physical_evaluation/physical_policy_outcomes.csv'
    three=pd.read_csv(f);three=three[three.policy.eq('native_three')].rename(columns={'action_slot':'slot','target_side':'side','force_n':'force'})
    three['gate_x']=three.section.map({'near':12.7,'far':15.,'mid':13.6})
    extra=['chosen_direction','success_lo','success_hi','choice_evidence','known_chosen_trajectory','known_chosen_target_effective']
    joined=merged.merge(three[b1.ACT+['force',*extra]],on=b1.ACT+['force'],how='left',validate='one_to_one')
    # Without handback, the experiment cannot finish. Otherwise, if the exact native selection is recorded,
    # use its matched physically executed leg. Missing direction or straight with no physical leg remains unknown.
    joined['gate_lo']=0;joined['gate_hi']=joined.relocked.astype(int)
    measured=joined.known_chosen_target_effective.eq(True)&joined.known_chosen_trajectory.notna()&joined.success_lo.eq(joined.success_hi)
    joined.loc[measured,'gate_lo']=joined.loc[measured,'success_lo'];joined.loc[measured,'gate_hi']=joined.loc[measured,'success_hi']
    joined['margin_lo']=0;joined['margin_hi']=joined.gate_hi
    physical_success=measured & joined.gate_lo.eq(1)
    # A differing exit side still has a physical trajectory to measure; use the known map/trajectory directly.
    paths=joined.loc[physical_success,['map_id','known_chosen_trajectory']].rename(columns={'known_chosen_trajectory':'path'}).drop_duplicates()
    cache=data[['path','actual_min_clearance_m']].dropna().drop_duplicates()
    paths=paths.merge(cache,on='path',how='left',validate='one_to_one');paths['lower']=1
    fill_distances(paths)
    distances=joined.known_chosen_trajectory.map(paths.set_index('path').actual_min_clearance_m)
    good=physical_success & distances.gt(MARGIN)
    joined.loc[physical_success,'margin_lo']=good[physical_success].astype(int);joined.loc[physical_success,'margin_hi']=good[physical_success].astype(int)
    native=b1.pairs(chosen,joined)
    native.to_csv(O/'native_three_paired_bounds.csv.gz',index=False)
    ns=metrics(native);ns.to_csv(O/'native_three_summary.csv',index=False)
    save=dict(stage='scored_once',source_sha256=b1.sha(src),frozen_decisions_sha256=b1.sha(O/'dev_choices.csv'),
        extra_distinct_primary_success_paths_measured=new_distances,recorded_native_table_sha256=b1.sha(f),
        native_rows_with_a_record=len(joined.dropna(subset=['choice_evidence'])),native_actual_eligible_retained=int(measured.sum()),
        documented_native_scope='Recorded assigned gate under archived P1 native straight-incumbent replay. Unassigned gates and missing physical branches remain interval-censored, common entry cancellation retained. Reports no independent B0 rolling-system run.',
        primary_summary=s.to_dict('records'),native_summary=ns.to_dict('records'))
    b1.save('score_receipt.json',save)
if __name__=='__main__':main()

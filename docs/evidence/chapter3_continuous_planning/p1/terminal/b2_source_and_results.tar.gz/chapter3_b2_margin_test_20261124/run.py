"""One fixed two-map GPU batch. Shared lock is acquired by launch.sh."""
from pathlib import Path
import multiprocessing as mp
from multiprocessing.connection import wait
import subprocess,sys,time
from prepare import O,read,save,sha,SRC,W
from worker import worker

def notify(stage,message):
    subprocess.run(['/usr/bin/python3',str(W/'learning/scripts/notify_chapter3_job.py'),'--title','第三章 B2 '+stage,'--message',message,'--receipt',str(O/(stage+'_bark.json'))],check=False)

def pair(index):
    manifest=read(O/'collection_contract.json');ready=read(O/'collection_ready.json')
    assert sha(O/'collection_contract.json')==ready['collection_contract_sha256'] and sha(O/'protocol.md')==ready['protocol_sha256']
    assert sha(SRC/'playground_handoff_evaluation.py')==sha(O/'native_test_handoff.py')==manifest['native_test_sha256']
    for filename in ['worker','run','audit','launch','prepare']:
        path=O/(filename+('.sh' if filename=='launch' else '.py'))
        assert sha(path)==manifest['files'].get(filename,manifest['files'].get('b2_program') if filename=='worker' else manifest['files'].get('runner' if filename=='run' else 'auditor'))
    if index:assert read(O/'physics_0.json')['lanes']==1152
    specs=manifest['maps'][index*2:index*2+2]
    for b in specs:
        assert sha(b['config'])==b['config_sha256'] and not Path(b['physical']).exists()
    heavy=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'],text=True)
    if any(x.strip() and not any(a in x.lower() for a in ('awesun','xorg','gnome-shell')) for x in heavy.splitlines()):raise RuntimeError('GPU already in use outside this lease: '+heavy)
    notify(f'第{index+1}批开始','同一物理批两张新地图，576辆/图，共1152。固定选路，在线三出口比较两个裕量。')
    ctx=mp.get_context('spawn');barrier=ctx.Barrier(2);ps=[ctx.Process(target=worker,args=(b,barrier)) for b in specs]
    start=time.monotonic()
    for p in ps:p.start()
    active={p.sentinel:p for p in ps}
    while active:
        for fd in wait(active):
            p=active.pop(fd);p.join()
            if p.exitcode:barrier.abort()
    if any(p.exitcode for p in ps):raise RuntimeError('B2 worker failed '+str([p.exitcode for p in ps]))
    for s in specs:
        status=read(Path(s['physical'])/'status.json');assert status['stage']=='complete' and len(status['results'])==576
    save(O/f'physics_{index}.json',dict(stage='complete',maps=[b['name'] for b in specs],lanes=1152,elapsed_s=time.monotonic()-start))
    notify(f'第{index+1}批物理完成','两张图1152个实际物理终点和分支已保存。')
if __name__=='__main__':
    if sys.argv[1]=='error':notify('异常','终审有界流水线中止，请查看作业日志。')
    elif sys.argv[1]=='done':notify('终审归约完成','2304条物理终点、配对得失、碰墙、封存输入和轨迹图已归档。')
    else:pair(int(sys.argv[1]))

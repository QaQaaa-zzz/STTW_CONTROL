"""Prepare the sealed 64-root allocation without stepping a simulator."""
from pathlib import Path
import importlib.util,itertools,json,hashlib,sys
import numpy as np,pandas as pd
O=Path(__file__).resolve().parent;P=O.parent/'chapter3_continuous_p1_20261123';T=P/'continuous_train_support'
W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad');SRC=W/'learning/src/sttw_control'
sys.path[:0]=[str(W/'learning/cli'),str(W/'learning/src'),'/home/qy/DVGC/JIT/src']
def read(f):return json.loads(Path(f).read_text())
def save(f,x):Path(f).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(f):
    with Path(f).open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def generate():
    from worker import build_runtime
    build_runtime()
    spec=importlib.util.spec_from_file_location('mapcompiler',P/'maps/build_maps.py')
    compiler=importlib.util.module_from_spec(spec);spec.loader.exec_module(compiler)
    compiler.OUT=O
    old=read(P/'maps/protocol.json');rng=np.random.default_rng(20261124)
    split=pd.read_csv(P/'split.csv');split=split[split.role.eq('sealed_test')]
    maps=[];thresh=[.1017768085002899,.05330585315823555]
    for i,family in enumerate(('left','right','staggered','staggered')):
        ref=next(r for r in old['records'] if r['family']==family)
        base=np.asarray(read(ref['template'])['terrain']['forbidden_rectangles'])
        seed=int(rng.integers(10000000,100000000))
        shifts=np.column_stack((rng.integers(-40,41,len(base)),rng.integers(-12,13,len(base))))/1000
        walls=np.round(base+shifts[:,[0,0,1,1]],6)
        roots=split[split.map_slot.eq(i)].sort_values('root_slot').bank_row.tolist()
        assert roots==list(range(1370+16*i,1386+16*i))
        name=f'test_{i:02d}';loc=O/name
        maps.append(dict(id=name,role='test',map_slot=i,family=family,seed=seed,template=ref['template'],template_sha256=ref['template_sha256'],wall_offsets_xy_m=shifts.tolist(),walls_xyxy_m=walls.tolist(),roots=roots,world=str(loc/'world.json'),mjb=str(loc/'terrain.mjb'),raster=str(loc/'terrain.npz')))
    assert len(set(r['seed'] for r in maps))==4 and not set(r['seed'] for r in maps)&set(r['seed'] for r in old['records'])
    save(O/'map_freeze.json',dict(split=str(P/'split.csv'),split_sha256=sha(P/'split.csv'),bank_sha256=sha(P/'initial_bank.npz'),protocol_sha256=sha(O/'protocol.md'),maps=maps))
    compiled=[compiler.build(rec) for rec in maps]
    out=[];design=[];cfg0=read(P/'batches/train_00/config.json')
    assets=read(P/'collection_ready.json')
    assert all(sha(f)==h for f,h in assets['weights'].items())
    source_controls={k:sha(v) for k,v in [('native_handoff',T/'registered_source/frozen_handoff_evaluation.py'),('original_three_scorer',SRC/'platform_online.py'),('old_select_contract',SRC/'chapter3_p0_physical.py'),('map_compiler',P/'maps/build_maps.py'),('b2_program',O/'worker.py'),('runner',O/'run.py'),('auditor',O/'audit.py'),('launch',O/'launch.sh'),('prepare',__file__)]}
    for rec in compiled:
        i=rec['map_slot'];m=rec['id'];loc=O/m;cfg=read(P/'batches/train_00/config.json')
        v0=cfg['ground_handoff']['handoff_variants'][0];vlist=[];lanes=[];margins=[]
        for root,force,(label,x),side in itertools.product(rec['roots'],(-5,0,5),(('near',12.7),('mid',13.6),('far',15.)),(1,-1)):
            slot,geom,alpha=(4,1,1.) if side==1 else (0,0,0.)
            for j,margin in enumerate(thresh):
                lane=len(vlist);v=dict(v0,bank_row=root,root_variant=root,root_slot=rec['roots'].index(root),map_id=m,map_slot=i,
                    data_split='sealed_test',action_slot=slot,geometry=geom,approach_alpha=alpha,alpha_numerator_24=int(alpha*24),planner='C-R',
                    section_x=x,side=side,bin=label,force_y_N=force,planned_departure=1,departure='straight',arm='original' if j==0 else 'recalibrated',test_margin_m=margin)
                vlist.append(v);lanes.append([geom,'h75',lane]);margins.append(margin)
                design.append(dict(map_id=m,lane=lane,pair=lane//2,root=root,force=force,section=label,gate_x=x,side=side,slot=slot,geometry=geom,alpha=alpha,arm=v['arm'],margin_m=margin))
        cfg.update(world_map=str(loc/'world.json'),role='B2 one-shot paired TEST; fixed entrance, online native three-exit margin contrast',evaluation_lanes=lanes,ccd_capacity=8*len(lanes))
        cfg['ground_handoff']['handoff_variants']=vlist
        cfg['paired_departures']['direction_ids']=[1]*len(lanes);cfg['platform_online']['relative']['raster']=str(loc/'terrain.npz')
        cfg['platform_online']['margin_m']=thresh[0]
        assert len(lanes)==576 and cfg['platform_online']['latency_ticks']=={'start':3,'departure':3}
        save(loc/'config.json',cfg)
        out.append(dict(name=m,config=str(loc/'config.json'),config_sha256=sha(loc/'config.json'),physical=str(loc/'physical'),lanes=len(lanes),mjb_sha256=rec['sha256']['mjb'],world_sha256=rec['sha256']['world'],raster_sha256=rec['sha256']['raster']))
    pd.DataFrame(design).to_csv(O/'allocation.csv',index=False);assert len(design)==2304
    shared={k:str(v) for k,v in dict(initial_bank=P/'initial_bank.npz',approaches=P/'actions/approaches.npz',departures=P/'shared/departures.npz',neutral=P/'shared/neutral.npz',initializer=cfg0['platform_online']['relative']['initializer'],rb_registry=W/'learning/configs/playground_rb_skill_sources.json').items()}
    save(O/'collection_contract.json',dict(maps=out,files=source_controls,native_test_sha256=sha(O/'native_test_handoff.py'),physical_lanes=2304,worlds_per_batch=1152,methods=thresh,allocation_sha256=sha(O/'allocation.csv'),map_freeze_sha256=sha(O/'map_freeze.json'),shared_files={k:[v,sha(v)] for k,v in shared.items()},weight_hashes=assets['weights'],rb_identity=assets['frozen_rb_identity'],frozen_h75=cfg0['ground_handoff']['bundle'],frozen_ground=cfg0['platform_online']['ground_model']))
    save(O/'collection_ready.json',dict(maps={v['name']:v for v in out},protocol_sha256=sha(O/'protocol.md'),collection_contract_sha256=sha(O/'collection_contract.json'),cpu_preparation_physics_steps=0,source=source_controls))
    print('Frozen 4 new maps / 64 previously sealed roots / 2304 physical lanes')
if __name__=='__main__':generate()

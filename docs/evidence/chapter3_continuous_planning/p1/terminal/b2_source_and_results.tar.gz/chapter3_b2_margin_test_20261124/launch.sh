#!/usr/bin/env bash
set -eu
run_dir="$(dirname "$(realpath "$0")")"
worktree=/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad
py=/home/qy/mujoco_playground/.venv/bin/python
cd "$worktree"
export PYTHONPATH="$worktree/learning/src:$worktree/learning/cli:/home/qy/DVGC/JIT/src"
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
test -f "$run_dir/collection_ready.json"
for pair_index in 0 1; do
    unset JAX_PLATFORMS
    export CUDA_VISIBLE_DEVICES=0
    if ! "$worktree/learning/scripts/gpu_queue.sh" /usr/bin/bwrap --bind / / --dev-bind /dev /dev --ro-bind "$run_dir/native_test_handoff.py" "$worktree/learning/src/sttw_control/playground_handoff_evaluation.py" -- "$py" -B -u "$run_dir/run.py" "$pair_index"; then
        "$py" -B "$run_dir/run.py" error
        exit 1
    fi
done
export CUDA_VISIBLE_DEVICES='' JAX_PLATFORMS=cpu
if ! "$py" -B -u "$run_dir/audit.py"; then
    "$py" -B "$run_dir/run.py" error
    exit 1
fi
"$py" -B "$run_dir/run.py" done

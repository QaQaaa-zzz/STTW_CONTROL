"""Check the frozen allocation, bwrap-mounted source and vector/scalar decision equivalence on one TRAIN state."""
from types import SimpleNamespace
import numpy as np,pandas as pd,torch
from prepare import O,P,SRC,W,read,sha,save
import sys
sys.path[:0]=[str(P/'model'),str(W/'learning/src')]
from frozen_exit_value import FrozenExits

def main():
    torch.set_num_threads(1)
    p=read(O/'collection_contract.json');m=read(O/'map_freeze.json')['maps']
    for b in p['maps']:
        c=read(b['config']);rows=c['ground_handoff']['handoff_variants']
        assert sha(b['config'])==b['config_sha256'] and len(rows)==576
        for a,z in zip(rows[::2],rows[1::2]):
            assert {k for k in a if a[k]!=z[k]}=={'test_margin_m','arm'} and a['planned_departure']==1 and a['planner']=='C-R'
        assert c['platform_online']['latency_ticks']=={'start':3,'departure':3} and 'veto_bank' not in c['platform_online']
    assert len({b['raster_sha256'] for b in p['maps']})==4 and not any((O/b['name']/'physical').exists() for b in p['maps'])
    fe=FrozenExits(P/'batches/train_00/physical',device='cpu')
    source=pd.read_csv(P/'export/train/train_00/suffix_index.csv')
    row=source[(source.root==1250)&source.verified_relock&source.arm.eq('left')].iloc[0]
    with np.load(row.query_file) as f:
        j=int(row.query_file_row);ids=f['branch_ids'][j];x,v,prev=[fe.tensor(f[k][j:j+1]) for k in ('qpos','velocity','previous_velocity')]
        sec,side,rem=float(f['section_x'][j]),float(f['side'][j]),min(5.1,float(f['remaining_s']))
    refs=SimpleNamespace(s=fe.s,**{k:fe.tensor(fe.bank[k][ids]) for k in ('xy','heading','curvature')})
    def score(vals,vector):
        n=len(vals);q=fe.query;q.margin=fe.tensor(vals).repeat_interleave(3) if vector else vals[0]
        out=q.choose(x.repeat(n,1),v[:,0].repeat(n),torch.full((n,),2.),refs,torch.arange(3).repeat(n,1),
            torch.full((n,),sec),torch.full((n,),side),torch.ones(n,dtype=torch.long),rem,v.repeat(n,1),prev.repeat(n,1))
        return torch.stack((torch.where(out[1],out[0],torch.ones_like(out[0])),out[1].long(),out[2].long()),1)
    a=score(p['methods'],True);b=torch.cat([score([v],False) for v in p['methods']])
    assert torch.equal(a,b)
    save(O/'cpu_check.json',dict(stage='ready',sample='original TRAIN first verified left copy, root 1250',milliseconds_control=5,milliseconds_phys=1,test_physics=0,
        comparison_native_choice_passed_straight=a.tolist(),mixed_thresholds_identical_to_two_scalar_calls=True,pairs=1152,lanes=2304,map_ids=[(v['id'],v['seed'],v['roots'][0],v['roots'][-1]) for v in m],
        frozen_contract_sha256=sha(O/'collection_contract.json'),runner_source_sha256=sha(O/'native_test_handoff.py')))
if __name__=='__main__':main()

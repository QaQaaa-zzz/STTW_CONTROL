"""Pair the two physically issued margin decisions at the recorded terminal frame."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
from prepare import O,P,W,read,save
sys.path[:0]=[str(P/'model'),str(W/'learning/cli'),str(W/'learning/src')]
from frozen_exit_value import mapped_arrays
from run_playground_task_reversal import crossings_by_section
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D

def exact(a,b):return a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes()

def one_map(b,allocation,bank):
    m=b['name'];loc=Path(b['physical']);rows=read(loc/'status.json')['results'];evidence={};logs={}
    with np.load(loc/'p1_applied_controls.npz') as f:ctl=f['targets'];valid=f['valid']
    for file in sorted((loc/'p1_query').glob('tick_*.npz')):
        with np.load(file) as f:
            tick=int(f['tick'])
            for j,i in enumerate(f['lanes']):
                logs[int(i)]=(tick,j,file)
    cache={}
    def state(e):
        t,j,file=e
        if file not in cache:
            with np.load(file) as f:cache[file]={k:f[k] for k in f if k not in ('lanes','tick','previous_tick','remaining_s')}
        return {k:v[j] for k,v in cache[file].items()}
    by_lane=[]
    for start in range(0,len(rows),2):
        armdata=[];obs=[];ep=[]
        for i in (start,start+1):
            r=rows[i];meta=allocation.iloc[i].to_dict();assert r['variant']['arm']==meta['arm'] and r['variant']['bank_row']==meta['root']
            path=loc/r['case_dir']/'trajectory.npz'
            with np.load(path) as f:arr={k:f[k] for k in ('trace','qpos','qvel','wheel_contact_flags','world_flags','contact_substep')}
            q=arr['qpos'];tr=arr['trace'];end=len(q)-1
            assert end==round(r['duration_s']/.005)
            out=state(logs[i]) if i in logs else {}
            h=round(r['handoff_s']/.005) if r['handoff_s'] is not None else -1
            tick=logs[i][0] if i in logs else -1;due=int(r['departure_due_tick']);assign=int(r['departure_applied_tick'])
            assert (tick>=0)==(h>=0 and h+1<=end)
            if tick>=0:
                assert tick==h+1 and due==tick+3 and exact(out['qpos'],q[tick]) and exact(out['previous_qpos'],q[tick-4])
                assert int(out['incumbent_direction'])==1
                direction=int(out['shadow_choice']) if bool(out['shadow_any_admitted']) else 1
                assert r['proposed_departure']==direction
                if due<=end:assert assign==due and r['selected_departure']==direction
            else:direction=-1
            gx=meta['gate_x'];side=meta['side']
            crossing=list(crossings_by_section(tr,r['handoff_s'] if h>=0 else np.inf,[12.7,13.6,15.]))[[12.7,13.6,15.].index(gx)]
            _,_,gate_t,y=crossing
            passed=bool(y is not None and .06<=side*y<=3.9);wall=bool(r['forbidden_contact_steps'])
            validxy=np.isfinite(tr[:,1:3]).all(1);exy=tr[validxy,1:3]
            c=dict(**meta,handback_tick=h,query_tick=tick,due_tick=due,assigned_tick=assign,issued_direction=direction,real_selected_direction=r['selected_departure'],
                admission=bool(out['shadow_any_admitted']) if out else None,physical_target_effective=0<=assign<end,
                query_batch_ms=r['query_batch_ms'],gate_y=y,gate_time=gate_t,gate_reached=passed,wall=wall,goal=bool(r['goal']),
                success=h>=0 and passed and not wall and bool(r['goal']),terminal=r['termination'],terminal_tick=end,terminal_x=exy[-1,0],terminal_y=exy[-1,1],trajectory=str(path))
            ref_ids=np.array(out.get('branch_ids',[-1,-1,-1]))
            c.update(left_ref=int(ref_ids[0]),straight_ref=int(ref_ids[1]),right_ref=int(ref_ids[2]))
            armdata.append(arr);obs.append(out);ep.append(c)
        u,v=ep;aa,bb=armdata;sh,sl=obs
        has=(u['assigned_tick']>=0,v['assigned_tick']>=0)
        if all(has):cut=min(u['assigned_tick'],v['assigned_tick'])
        else:cut=min([c['terminal_tick'] if c['assigned_tick']<0 else c['assigned_tick'] for c in ep])
        recorded=all(exact(aa[k][:cut+1],bb[k][:cut+1]) for k in ('qpos','qvel','world_flags','wheel_contact_flags'))
        contact_a=aa['contact_substep'][:cut+1];contact_b=bb['contact_substep'][:cut+1]
        cp=exact(contact_a[:,:,:3]<=1e-5,contact_b[:,:,:3]<=1e-5) and exact(contact_a[:,:,3]==0,contact_b[:,:,3]==0)
        same_controls=exact(ctl[:cut,start],ctl[:cut,start+1]) and exact(valid[:cut,start],valid[:cut,start+1])
        skip={'shadow_choice','shadow_any_admitted','shadow_incumbent_admitted'}
        sameobs=sh.keys()==sl.keys() and all(exact(sh[k],sl[k]) for k in sh if k not in skip)
        clocks=all(u[k]==v[k] for k in ('handback_tick','query_tick','due_tick','assigned_tick'))
        ended=all(has) or (not any(has) and u['terminal_tick']==v['terminal_tick'] and u['terminal']==v['terminal'])
        pair_ok=bool(recorded and cp and same_controls and sameobs and clocks and ended)
        both_valid=valid[:,start]&valid[:,start+1]
        diffs=np.flatnonzero(both_valid & (ctl[:,start,:2]!=ctl[:,start+1,:2]).any(1))
        for c in ep:c.update(pair_ok=pair_ok,kinematic_equal=recorded,contact_predicate_equal=cp,raw_loads_equal=exact(contact_a,contact_b),
             before_assignment_controls_equal=same_controls,query_state_equal=sameobs,clocks_equal=clocks,first_different_wheel_command_tick=int(diffs[0]) if len(diffs) else -1)
        by_lane.extend(ep)
    return pd.DataFrame(by_lane)

def draw(m,group,world,bank,path):
    geo=world['terrain'];fig,axs=plt.subplots(3,6,figsize=(23,7.2),layout='constrained')
    root=int(group.root.iloc[0])
    for row_id,force in enumerate((-5,0,5)):
        for j,(gx,side) in enumerate(( (x,s) for x in (12.7,13.6,15.) for s in (1,-1))):
            ax=axs[row_id,j];part=group[(group.force==force)&(group.gate_x==gx)&(group.side==side)]
            for u in part.itertuples():
                col='#006a8c' if u.arm=='original' else '#b44922'
                with np.load(u.trajectory) as z:xy=z['qpos'][:,:2]
                # On arcs traversed while ground control is active, clip each fixed ground reference to its actual temporal interval.
                phases=[(0,3,None),(3,u.query_tick if u.query_tick>=0 else len(xy),u.geometry)]
                if u.query_tick>=0:phases.append((u.query_tick,u.assigned_tick if u.assigned_tick>=0 else len(xy),u.straight_ref))
                if u.assigned_tick>=0:phases.append((u.assigned_tick,len(xy),[u.left_ref,u.straight_ref,u.right_ref][u.issued_direction]))
                for lo,hi,idx in phases:
                    if min(hi,len(xy))<=lo:continue
                    if idx is None:
                        with np.load(P/'shared/neutral.npz') as z:ref=z['xy'][0]
                    else:ref=bank['xy'][idx]
                    xx=xy[lo:min(hi+1,len(xy)),0];xx=xx[np.isfinite(xx)]
                    if not len(xx):continue
                    mask=(ref[:,0]>=xx.min()-.013)&(ref[:,0]<=xx.max()+.013)
                    ax.plot(*ref[mask].T,c=col,ls=':',lw=1.4,zorder=1)
                ax.plot(*xy.T,c=col,lw=1.15,alpha=.78);ax.plot(u.terminal_x,u.terminal_y,'o' if u.success else 'x',ms=5,markerfacecolor='white',c=col)
            for x0,x1,y0,y1 in geo['forbidden_rectangles']:ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,facecolor='#4d4b49',zorder=3))
            ax.axvline(10.3,lw=.65,c='#888');ax.vlines(gx,side*.06,side*3.9,color='#754982',lw=1)
            ax.set(xlim=(8.45,18.5),ylim=(-1.05,1.05),aspect='equal')
            if row_id==0:ax.set_title(f'{gx:.1f} m, '+('left' if side==1 else 'right'))
            if j==0:ax.set_ylabel(f'{force:+d} N, y (m)')
            if row_id==2:ax.set_xlabel('world x (m)')
    fig.suptitle(f'B2 TEST {m} / start {root} — actual trajectories and the issued references (view x ≥ 8.45 m)\nBlue: 10.18 cm     Orange: 5.33 cm     Solid: body XY     Dotted: active reference     Circle: task complete     Cross: physical endpoint',fontsize=13)
    fig.savefig(path,dpi=140);plt.close(fig)

def main():
    manifest=read(O/'collection_contract.json');plan=pd.read_csv(O/'allocation.csv');parts=[]
    for i in (0,1):assert read(O/f'physics_{i}.json')['lanes']==1152
    bank=mapped_arrays(P/'shared/departures.npz');dest=O/'analysis';dest.mkdir(exist_ok=True)
    for b in manifest['maps']:parts.append(one_map(b,plan[plan.map_id.eq(b['name'])].reset_index(drop=True),bank))
    lanes=pd.concat(parts,ignore_index=True);assert len(lanes)==2304 and len(lanes[lanes.arm.eq('original')])==1152
    lanes.to_csv(dest/'physical_lanes.csv.gz',index=False)
    keys=['map_id','root','pair','gate_x','side','force']
    a=lanes[lanes.arm.eq('original')];z=lanes[lanes.arm.eq('recalibrated')]
    p=a.merge(z,on=keys,suffixes=('_original','_new'),validate='one_to_one')
    for k in ('success','wall'):p[k+'_delta']=p[k+'_new'].astype(int)-p[k+'_original'].astype(int)
    p.to_csv(dest/'paired_tasks.csv.gz',index=False);rows=[]
    for maskname,f in [('all',p),('strict',p[p.pair_ok_new])]:
        for fields in ([],['map_id'],['side'],['gate_x'],['force'],['map_id','side']):
            for ident,g in ([((),f)] if not fields else f.groupby(fields)):
                if not isinstance(ident,tuple):ident=(ident,)
                record=dict(panel=maskname,stratum=','.join(fields) or 'all',**dict(zip(fields,ident)),n=len(g))
                for k in ('success','wall'):
                    d=g[k+'_delta'];record.update({k+'_original':int(g[k+'_original'].sum()),k+'_new':int(g[k+'_new'].sum()),k+'_net':int(d.sum()),k+'_added':int(d.eq(1).sum()),k+'_removed':int(d.eq(-1).sum())})
                rows.append(record)
    pd.DataFrame(rows).to_csv(dest/'outcomes.csv',index=False)
    rng=np.random.default_rng(20261124);boot=np.zeros((10000,2));nmiss=int((~p.pair_ok_new).sum())
    for _,g in p.groupby('map_id'):
        scores=g.groupby('root')[['success_delta','wall_delta']].sum().to_numpy();boot+=scores[rng.integers(0,16,(10000,16))].sum(1)
    root_harms=p.assign(harm=p.wall_delta.eq(1)).groupby(['map_id','root']).harm.any()
    save(dest/'receipt.json',dict(stage='complete',lanes=len(lanes),pairs=len(p),strict=int(p.pair_ok_new.sum()),unmatched=nmiss,
        first_figure='overview.png',raw_interval_percentage_points=np.quantile(100*boot/len(p),[.025,.975],axis=0).T.tolist(),
        ordered_interval_columns=['success','wall'],strict_all_opportunity_net_bounds={k:[int(p.loc[p.pair_ok_new,k+'_delta'].sum()-nmiss),int(p.loc[p.pair_ok_new,k+'_delta'].sum()+nmiss)] for k in ('success','wall')},
        roots_with_any_new_wall=int(root_harms.sum()),root_upper_if_zero=float(1-.05**(1/64)) if not root_harms.any() else None))
    paths=[]
    for (m,r),g in lanes.groupby(['map_id','root']):
        path=dest/f'{m}_root{r}.png';draw(m,g,read(O/m/'world.json'),bank,path);paths.append(dict(map_id=m,root=int(r),image=path.name))
    pd.DataFrame(paths).to_csv(dest/'figures.csv',index=False)
    # Prefer a root with a changed successful outcome, then changed collision, then the first registered root.
    eligible=p[p.pair_ok_new];d=eligible[eligible.success_delta.ne(0)];d=d if len(d) else eligible[eligible.wall_delta.ne(0)]
    d=d if len(d) else p;first=d.sort_values(['map_id','root','force','gate_x','side']).iloc[0]
    import shutil
    shutil.copyfile(dest/f'{first.map_id}_root{first.root}.png',dest/'overview.png')
if __name__=='__main__':main()

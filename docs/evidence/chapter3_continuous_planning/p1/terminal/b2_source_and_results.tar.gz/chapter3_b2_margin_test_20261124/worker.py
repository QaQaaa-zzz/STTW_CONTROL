"""Two frozen thresholds use the native scorer on the same batched, measured handback states."""
from contextlib import redirect_stdout,redirect_stderr
from pathlib import Path
import difflib,json,sys,time,traceback
from prepare import O,P,T,W,SRC,read,save,sha

def build_runtime():
    base=T/'registered_source/frozen_handoff_evaluation.py'
    assert sha(base)==read(T/'registered_source/source_identity.json')['frozen_handoff_evaluation.py']['sha256']
    old=base.read_text()
    start="            contracts=[variants[i] for _,_,i in lanes]"
    call="                        chosen,admitted,incumbent=query.choose(q[ids],(axis*v[ids,:3]).sum(1),nominal_continuation_speed[ids],route,choices,section[ids],side[ids],directions[ids],args.seconds-t,current,prev)"
    assert old.count(start)==old.count(call)==1
    new=old.replace(start,start+"\n            declared_margins=tensor([c['test_margin_m'] for c in contracts]).float()")
    new=new.replace(call,"                        query.margin=declared_margins[ids].repeat_interleave(3)\n"+call.replace('args.seconds-t,current,prev','min(5.1,args.seconds-t),current,prev')+"\n                        chosen=torch.where(admitted,chosen,directions[ids])")
    compile(new,'playground_handoff_evaluation.py','exec')
    (O/'native_test_handoff.py').write_text(new)
    (O/'native_logic.patch').write_text(''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='frozen_native',tofile='b2_native')))

def worker(b,barrier):
    loc=Path(b['config']).parent
    with (loc/'physics.log').open('a',buffering=1) as f,redirect_stdout(f),redirect_stderr(f):
        try:
            import torch
            sys.path.insert(0,str(T/'registered_source'))
            import observer
            observer.OUT=O
            def milestone(tick,state):
                state['data'].qpos.block_until_ready();torch.cuda.synchronize()
                t=time.monotonic_ns();barrier.wait()
                with (loc/'milestones.jsonl').open('a') as log:
                    log.write(json.dumps(dict(tick=tick,worlds=len(state['alive']),alive=int(state['alive'].sum()),arrival_ns=t,release_ns=time.monotonic_ns()))+'\n')
            observer.milestone=milestone;observer.observed_run(b)
        except BaseException:
            traceback.print_exc();barrier.abort();raise

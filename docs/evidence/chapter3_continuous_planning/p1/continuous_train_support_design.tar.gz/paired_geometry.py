"""Eight mirrored TRAIN references on the original H75 arc grid."""
from pathlib import Path
from itertools import product
import sys
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parent
P=R.parent
sys.path.insert(0,str(R/'registered_source'))
from continuous_approach import Boundary,generate_reference

FIELDS=('xy','heading','curvature')

def measured(slot,source,xy,h,k):
    x,y=xy.T
    pre=(x>=3.)&(x<=9.2);aft=(x>=9.2)&(x<=10.3)
    return dict(slot=slot,source=source,
        measured_trigger_y_m=np.interp(9.2,x,y),measured_trigger_heading_deg=np.rad2deg(np.interp(9.2,x,h)),
        measured_trigger_curvature_m_inv=np.interp(9.2,x,k),measured_edge_y_m=np.interp(10.3,x,y),
        measured_edge_heading_deg=np.rad2deg(np.interp(10.3,x,h)),measured_edge_curvature_m_inv=np.interp(10.3,x,k),
        peak_pretrigger_curvature_m_inv=np.abs(k[pre]).max(),peak_trigger_to_edge_curvature_m_inv=np.abs(k[aft]).max(),
        peak_pre_edge_curvature_m_inv=np.abs(k[(x>=3.)&(x<=10.3)]).max())

def build():
    with np.load(P/'shared/neutral.npz') as z:
        neutral={k:z[k] if k=='s' else z[k][:1] for k in ('s',*FIELDS)}
    inventory=[]
    for source,path in [('original14',P/'actions/approaches.npz'),('opened_dev8',P/'continuous_interpolation/approaches.npz')]:
        with np.load(path) as z:
            xy,h,k=[z[n] for n in FIELDS]
        inventory.extend(measured(i,source,xy[i],h[i],k[i]) for i in range(len(xy)))
        if source=='original14':old=xy
        else:opened=xy
    assert (len(old),len(opened))==(14,8)
    routes=[];rows=[];comparisons=[]
    for amp,offset in product((.04,.14),(-.075,.075)):
        for sign in (1,-1):
            edge=sign*amp;target=sign*(amp+offset);heading=sign*np.deg2rad(3.5)
            assert abs(target)<=.225 and abs(heading)<=np.deg2rad(8.)
            route,meta=generate_reference(neutral,8.,10.3,1.1,Boundary(target,heading,0.),edge,0.)
            slot=len(routes);x,y=route['xy'][0].T
            assert np.all(np.diff(x)>0)
            for k in FIELDS:np.testing.assert_array_equal(route[k][:,:meta['join_index']+1],neutral[k][:,:meta['join_index']+1])
            for bank_id,bank in [('original14',old),('opened_dev8',opened)]+([('new_previous',np.concatenate([q['xy'] for q in routes]))] if routes else []):
                for other_id,other in enumerate(bank):
                    xx,yy=other.T
                    grid=np.unique(np.r_[3.,10.3,x,xx]);grid=grid[(grid>=3.)&(grid<=10.3)]
                    delta=np.abs(np.interp(grid,x,y)-np.interp(grid,xx,yy))
                    d=float(delta.max());assert d>1e-5
                    comparisons.append(dict(slot=slot,bank=bank_id,comparison_slot=other_id,max_abs_y_difference_m=d,witness_x_m=grid[delta.argmax()]))
            assert abs(np.interp(10.3,x,y)-edge)<1e-5 and abs(np.interp(9.2,x,y)-target)<1e-5
            values=measured(slot,'new_train8',route['xy'][0],route['heading'][0],route['curvature'][0])
            assert abs(values['measured_trigger_heading_deg']-3.5*sign)<.015 and abs(values['measured_edge_heading_deg'])<.015
            rows.append(dict(**values,alpha=0,side=sign,edge_magnitude_m=amp,trigger_minus_edge_in_side_coordinate_m=offset,
                         shape='outward' if offset<0 else 'turnback',requested_edge_y_m=edge,**meta))
            inventory.append(values)
            if sign==-1:
                np.testing.assert_array_equal(x,routes[-1]['xy'][0,:,0])
                np.testing.assert_array_equal(y,-routes[-1]['xy'][0,:,1])
            routes.append(route)
    curves=dict(s=neutral['s'],**{k:np.concatenate([r[k] for r in routes]) for k in FIELDS})
    np.savez_compressed(R/'approaches.npz',**curves)
    np.savez_compressed(R/'neutral.npz',s=neutral['s'],**{k:np.repeat(neutral[k],8,axis=0) for k in FIELDS})
    pd.DataFrame(rows).to_csv(R/'curves.csv',index=False)
    pd.DataFrame(comparisons).to_csv(R/'geometry_comparisons.csv',index=False)
    pd.DataFrame(inventory).to_csv(R/'reference_geometry.csv',index=False)
    return curves,routes,rows

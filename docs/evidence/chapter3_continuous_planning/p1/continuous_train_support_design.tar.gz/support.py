"""Prepare and run the three registered TRAIN map pairs for data collection only."""
import argparse
import json
import multiprocessing as mp
from multiprocessing.connection import wait
from pathlib import Path
import shutil
import subprocess
import sys
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parent;P=R.parent
W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
CACHE=R/'registered_source'
sys.path[:0]=[str(R),str(CACHE),str(W/'learning/cli'),str(W/'learning/src'),'/home/qy/DVGC/JIT/src']
def load(p):return json.loads(p.read_text())
def save(p,item):p.write_text(json.dumps(item,indent=2,allow_nan=False)+'\n')
def sha(p):
    import hashlib
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def driver():
    import interpolation_driver as d
    d.R,d.P,d.SRC=R,P,CACHE
    sys.path[:0]=[str(R),str(CACHE)]
    return d

def prepare():
    previous=P/'continuous_interpolation'
    source={'interpolation_driver.py':previous/'experiment.py','continuous_approach.py':P/'actions/continuous_approach.py',
           'frozen_handoff_evaluation.py':P/'five_exits/frozen_handoff_evaluation.py',
           'run_platform_task_oracle.py':W/'learning/cli/run_platform_task_oracle.py'}
    lineage=load(previous/'registered_source/provenance.json')
    for name in ('observer.py','audit_arms.py','extract.py'):
        source[name]=previous/'registered_source'/name
        assert sha(source[name])==lineage[name]['sha256']
    for name,path in source.items():shutil.copyfile(path,CACHE/name)
    source_info={k:dict(source=str(v),sha256=sha(CACHE/k)) for k,v in source.items()}
    save(CACHE/'source_identity.json',source_info)
    driver().geometry()
    import extract
    ready=load(P/'collection_ready.json');old=load(P/'collection_contract.json');maps=[]
    map_evidence={};inputs_keys=extract.OBSERVED
    for donor in (b for b in old['batches'] if b['role']=='train'):
        name=donor['name'];loc=R/name;loc.mkdir(exist_ok=True)
        source_config=Path(donor['config']);assert sha(source_config)==donor['config_sha256']
        c=load(source_config);old_variants=c['ground_handoff']['handoff_variants']
        variants=[dict(v,geometry=v['action_slot'],approach_alpha=0.,alpha_numerator_24=0) for v in old_variants if v['action_slot']<8]
        c['ground_handoff'].update(handoff_variants=variants,reference_path=str(R/'neutral.npz'))
        c['evaluation_lanes']=[[v['geometry'],'h75',i] for i,v in enumerate(variants)]
        c['ccd_capacity']=8*len(variants)
        c['paired_departures']=dict(approach_file=str(R/'approaches.npz'),route_bank=str(R/'departures.npz'),direction_ids=[v['planned_departure'] for v in variants])
        file=loc/'config.json';save(file,c)
        row=dict(donor,config=str(file),config_sha256=sha(file),source_config=str(source_config),source_sha256=donor['config_sha256'],
                 physical=str(loc/'physical'),lanes=len(variants),distinct_prefixes=len(variants)//2)
        cfg,left,right=extract.config_rows(row)
        assert row['role']=='train' and len(left)==len(right)==288 and set(left.data_split)=={'train'} and set(left.map_id)=={name}
        roots=sorted(map(int,left.bank_row.unique()))
        assert roots==sorted(donor['bank_rows'])==ready['maps'][name]['root_rows'] and len(roots)==12
        for arm,frame,native_direction in [('left',left,0),('right',right,2)]:
            assert set(frame.arm)=={arm} and set(frame.planned_departure)=={native_direction} and frame.approach_alpha.eq(0).all()
            assert np.all(frame.requested_speed_m_s.eq(2.) & frame.approach_speed_m_s.eq(2.) & frame.continuation_speed_m_s.eq(2.))
        assert c['platform_online']['latency_ticks']=={'start':3,'departure':3}
        assert sha(donor['physical_model'])==ready['maps'][name]['mjb_sha256']
        with np.load(c['approach_initial_bank']) as z:
            q=z['qpos'][left.bank_row.to_numpy()].copy();v=z['qvel'][left.bank_row.to_numpy()].copy()
        q[:,0]+=float(cfg['ground_handoff']['start_x_m'])-2.5
        with np.load(R/'approaches.npz') as z,np.load(donor['raster']) as raster:
            x=extract.decision_inputs(q,v,left.action_slot,left.approach_alpha,dict(z),dict(raster),load(Path(donor['world'])))
            assert set(x)==set(inputs_keys) and all(a.shape[0]==288 and np.isfinite(a).all() for a in x.values())
        maps.append(row)
        map_evidence[name]=dict(mjb_sha256=ready['maps'][name]['mjb_sha256'],root_rows=roots,config_sha256=row['config_sha256'],
            lanes=576,prefixes=288,per_side=288,pre_action_input_shapes={k:list(a.shape) for k,a in x.items()})
    assert [m['name'] for m in maps]==[f'train_{i:02}' for i in range(6)] and len(set(root for m in maps for root in m['bank_rows']))==72
    regular={k:old[k] for k in ['all_episode_s','dt_phys_s','substeps_per_control','dt_control_s','ground_policy_dt_s','push','gate_assignment','planned_exit_publication','shadow_margin_m','motion_weights']}
    save(R/'collection_contract.json',dict(batches=maps,**regular,role='TRAIN data only, six original maps and original 72 roots, fixed alpha zero. No model fitting; no CAL/TEST.',
        budget=dict(pairs=3,maps=6,physical_lanes=3456,distinct_prefixes=1728,physical_worlds_per_pair=1152,control_steps_max=2000,physics_steps_max=10000),
        collection='Same frozen H75/RB evaluator and 20 ms history collection as original interpolation panel. Fixed left and right exit after actual first verified handback. Issuance latency 15 ms. Unexecuted/uncertified outcomes retain explicit flags.',
        geometry='2x2 mirrored quintic references. Neutral through s=8m (world x=3m), trigger x=9.2m, edge x=10.3m. In positive-side coordinates the edge is +.04 or +.14 m, trigger y=edge +/- .075 m. Negative-side routes mirror them. Trigger heading = +3.5 degrees or -3.5 degrees by side; all edge headings and both analytic junction curvatures zero. Measured grid values and peaks in reference_geometry.csv for all original 14, open DEV 8 and this TRAIN 8. Straight constant-y tail. Max trigger offset .215m, below .225m.',
        stop='Stop on an incomplete pair, mismatched model/timing or export. No replacement lanes, no retries, no training; three independently locked consecutive batches. Earlier release-clock batch must have completed its receipt first.'))
    keys=['collection_contract.json','approaches.npz','neutral.npz','departures.npz','curves.csv','geometry_comparisons.csv','reference_geometry.csv','support.py','paired_geometry.py','launch.sh','registered_source/source_identity.json']
    save(R/'collection_ready.json',dict(maps=map_evidence,files={k:sha(R/k) for k in keys},frozen_source=source_info,
        physical_lanes=3456,distinct_prefixes=1728,peak_parallel=1152,cpu_only=True,simulator_steps_executed_in_preparation=0,training_updates=0))

def worker(batch,barrier):
    driver().worker(batch,barrier)

def notify(pair,stage,message):
    subprocess.run(['/usr/bin/python3',str(W/'learning/scripts/notify_chapter3_job.py'),'--title',f'第三章 TRAIN 入口采集 {pair+1}/3 {stage}','--message',message,'--receipt',str(R/f'pair_{pair}_{stage}_bark.json')],check=False)

def run_pair(pair):
    registered=load(R/'collection_ready.json')
    for name,item in registered['frozen_source'].items():assert sha(CACHE/name)==item['sha256']
    for name,value in registered['files'].items():assert sha(R/name)==value
    assert sha(W/'learning/src/sttw_control/playground_handoff_evaluation.py')==registered['frozen_source']['frozen_handoff_evaluation.py']['sha256']
    tasks=subprocess.check_output(['nvidia-smi','-i','0','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader,nounits'],text=True)
    active=[line for line in tasks.splitlines() if line.strip() and not any(x in line.lower() for x in ('awesun','xorg','gnome-shell'))]
    if active:raise RuntimeError('Other GPU compute active at queue acquisition: '+', '.join(active))
    batches=load(R/'collection_contract.json')['batches'][2*pair:2*pair+2]
    for b in batches:
        assert sha(b['config'])==b['config_sha256']
        if Path(b['physical']).exists():raise FileExistsError(b['physical'])
    ctx=mp.get_context('spawn');barrier=ctx.Barrier(2)
    jobs=[ctx.Process(target=worker,args=(b,barrier)) for b in batches]
    notify(pair,'start','；'.join(b['name'] for b in batches)+'，576+576辆，三种隐藏推力。')
    for job in jobs:job.start()
    pending={job.sentinel:job for job in jobs}
    while pending:
        for fd in wait(list(pending)):
            job=pending.pop(fd);job.join()
            if job.exitcode:barrier.abort()
    if any(job.exitcode for job in jobs):raise RuntimeError(f'Physical workers exited {[j.exitcode for j in jobs]}')
    stamps=[[json.loads(l) for l in (R/b['name']/'milestones.jsonl').read_text().splitlines()] for b in batches]
    times=list(zip(*stamps,strict=True))
    assert all([v['tick'] for v in stamp]==[0,1,32,128,512,1024,1536,1999] for stamp in stamps)
    overlap=[dict(from_tick=prev[0]['tick'],to_tick=now[0]['tick'],overlap_s=min(z['arrived'] for z in now)-max(z['released'] for z in prev),alive=sum(z['alive'] for z in now)) for prev,now in zip(times,times[1:])]
    assert any(z['alive']==1152 and z['overlap_s']>0 for z in overlap)
    save(R/f'pair_{pair}_physics.json',dict(maps=[b['name'] for b in batches],lanes=1152,overlap=overlap))
    notify(pair,'physics','该对地图的1,152次物理仿真已完成。')

def export_pair(pair):
    import audit_arms,extract
    from run_playground_task_reversal import crossings_by_section
    out=[]
    for b in load(R/'collection_contract.json')['batches'][2*pair:2*pair+2]:
        audit_arms.audit(b['name']);extract.export_map(b)
        folder=R/'export/train'/b['name'];s=pd.read_csv(folder/'suffix_index.csv')
        for row in s.itertuples():
            with np.load(row.trajectory) as z:
                hits=list(crossings_by_section(z['trace'],row.native_handoff_s if pd.notna(row.native_handoff_s) else np.inf,[12.7,13.6,15.]))
            for i in (0,2):
                y=hits[i][-1];side=1 if row.arm=='left' else -1
                executed=row.suffix_pair_status=='matched_observed_handoff' and row.observed_query and row.physical_target_effective and row.online_selected_direction==row.declared_direction
                known=not row.verified_relock or executed
                success=bool(row.verified_relock and y is not None and .06<=side*y<=3.9 and row.physical_goal and not row.physical_wall)
                out.append(dict(map_id=row.map_id,root=row.root,action_slot=row.action_slot,force=row.hidden_force_N_grouping_only,lane=row.lane,arm=row.arm,
                                side=side,gate_x=(12.7 if i==0 else 15.),known=known,lower=int(known and success),upper=int(not known or success),
                                prefix_status=row.suffix_pair_status,query_tick=row.query_tick,terminal=row.termination,path=row.trajectory))
    gate=pd.DataFrame(out);assert len(gate)==2304
    gate.to_csv(R/f'pair_{pair}_gate_cases.csv.gz',index=False)
    save(R/f'pair_{pair}_complete.json',dict(stage='complete',maps=gate.map_id.unique().tolist(),physical_lanes=1152,distinct_prefixes=576,gate_rows=len(gate),new_training_updates=0))
    notify(pair,'complete','该对地图的真实状态、左右分支和近远门结果已导出。')
    if pair==2:
        receipts=[load(R/f'pair_{i}_complete.json') for i in range(3)]
        save(R/'result.json',dict(stage='complete',role='TRAIN',physical_lanes=sum(r['physical_lanes'] for r in receipts),prefixes=sum(r['distinct_prefixes'] for r in receipts),gate_rows=sum(r['gate_rows'] for r in receipts),new_training_updates=0))

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('stage',choices=['prepare','pair','export','error']);cli.add_argument('index',type=int,nargs='?',choices=range(3));a=cli.parse_args()
    if a.stage=='prepare':prepare()
    elif a.stage=='pair':run_pair(a.index)
    elif a.stage=='export':export_pair(a.index)
    else:notify(a.index,'error','本批物理或导出失败；详见服务日志，无额外采集。')

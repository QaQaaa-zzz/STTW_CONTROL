#!/usr/bin/env bash
set -eu
base_dir="$(dirname "$(realpath "$0")")"
worktree=/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad
py=/home/qy/mujoco_playground/.venv/bin/python
predecessor="$base_dir/../../chapter3_exit_release_dev_20261124/analysis/receipt.json"
cd "$worktree"
export PYTHONPATH="$worktree/learning/src:$worktree/learning/cli:/home/qy/DVGC/JIT/src"
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
test -f "$predecessor"
for pair_index in 0 1 2; do
    if test -f "$base_dir/pair_${pair_index}_complete.json"; then continue; fi
    if ! test -f "$base_dir/pair_${pair_index}_physics.json"; then
        unset JAX_PLATFORMS
        export CUDA_VISIBLE_DEVICES=0
        if ! "$worktree/learning/scripts/gpu_queue.sh" /usr/bin/bwrap --bind / / --dev-bind /dev /dev --ro-bind "$base_dir/registered_source/frozen_handoff_evaluation.py" "$worktree/learning/src/sttw_control/playground_handoff_evaluation.py" -- "$py" -B -u "$base_dir/support.py" pair "$pair_index"; then
            "$py" -B "$base_dir/support.py" error "$pair_index"; exit 1
        fi
    fi
    export CUDA_VISIBLE_DEVICES='' JAX_PLATFORMS=cpu
    if ! "$py" -B -u "$base_dir/support.py" export "$pair_index"; then
        "$py" -B "$base_dir/support.py" error "$pair_index"; exit 1
    fi
done

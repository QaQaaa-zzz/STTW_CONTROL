"""Score the three original departures and the declared 0.30 m geometry at each observed handback."""
from collections import Counter
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import numpy as np
import pandas as pd
import torch

R=Path(__file__).resolve().parent
SRC=Path(json.loads((R/'protocol.json').read_text())['source'])
W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src')
sys.path[:0]=[str(W),str(SRC.parent/'chapter3_continuous_p1_20261123/model')]
from frozen_exit_value import FrozenExits,mapped_arrays
from sttw_control.platform_online import velocity_state
import sttw_control.chapter3_continuous_exit as native

torch.set_num_threads(1)
KEY=['layout','root','force_N','gate','side','geometry','lane']
FIELDS=['xy','heading','curvature']
DIR=['left','straight','right']

def tensor(x):
    return torch.as_tensor(np.stack(x),dtype=torch.float32)

def native_score(solver,q,v,past,refs,sec,side,rem,hold):
    details={}
    def capture(frame,event,arg):
        if event!='return':return
        f=frame.f_locals
        if frame.f_code==native._score.__code__:
            details.update(gate_predicate=f['gate'],clear=f['safe'],domain=f['within'],held=f['held'].any(1))
        elif frame.f_code==native.ContinuousExitPlanner._smooth_score.__code__:
            details.update(curvature=f['geometry'],peak=f['peak'])
    sys.setprofile(capture)
    try:
        score,admit,clearance,valid=solver._smooth_score(q,v,past,*refs,sec,side,rem,torch.zeros(len(q),dtype=torch.long),hold)
    finally:
        sys.setprofile(None)
    assert torch.equal(admit,details['gate_predicate']&details['clear']&details['domain']&details['held']&details['curvature'])
    return dict(score=score,admitted=admit,clearance_m=clearance,valid_s=valid,**details)

@torch.inference_mode()
def score_map(layout,m,curves):
    f=SRC/layout/'physical'
    cfg=json.loads((f/'resolved_config.json').read_text())
    rows=json.loads((f/'status.json').read_text())['results']
    bank=mapped_arrays(cfg['paired_departures']['route_bank'])
    with np.load(cfg['paired_departures']['approach_file']) as z: approach=dict(z)
    obs={};inc={}
    for ln in (f/'p0_events.jsonl').open():
        e=json.loads(ln)
        if e['kind'] not in ('old_selection','query'):continue
        for i,j in enumerate(e['lanes']):
            if e['kind']=='query':
                inc.setdefault(j,(e['tick'],e['incumbent'][i]))
            else:
                obs[j]=(e['tick'],e['old_candidates'][i],e['choice'][i],e['admitted'][i],e['default_route_id'][i])
    @lru_cache(maxsize=85)
    def snapshot(t):
        ks=['lanes','physics_qpos','physics_qvel','middle_projection_progress','runtime_hold','route',f'query_pose_history_{t%4}',f'query_velocity_history_{t%4}']
        with np.load(f/'p0_handbacks'/f'tick_{t:04d}.npz') as z:return {k:z[k] for k in ks}
    ss=bank['s'];refs=[];jobs=[];tasks=[]
    solver=native.ContinuousExitPlanner(FrozenExits(f,device='cpu',load_route_bank=False).query,
         SimpleNamespace(s=tensor(ss)),mode='smooth_event',horizon_steps=255,robots_per_chunk=1,fused=False)
    for r in m.itertuples():
        base={k:getattr(r,k) for k in KEY};base['has_relock']=r.has_relock
        tasks.append(base);ar=obs.get(r.lane)
        if ar is None:
            assert not r.has_relock
            base['comparison']='no_relock';continue
        tick,ids,choice,oldpass,default=ar
        assert inc[r.lane][0]==tick==r.first_relock_tick and default==ids[1] and r.has_relock
        z=snapshot(tick);j=int(np.flatnonzero(z['lanes']==r.lane)[0])
        q,v,p,pv=[z[k][j] for k in ('physics_qpos','physics_qvel',f'query_pose_history_{tick%4}',f'query_velocity_history_{tick%4}')]
        with np.load(f/rows[r.lane]['case_dir']/'trajectory.npz') as raw:
            oq,ov=raw['qpos'],raw['qvel']
            assert all(np.array_equal(a,b) for a,b in [(q,oq[tick]),(v,ov[tick]),(p,oq[tick-4]),(pv,ov[tick-4])])
        geom=r.geometry
        progress=float(z['middle_projection_progress'][j])
        ia=int(np.searchsorted(approach['s'],progress))
        oldjoin=min(max(int(np.searchsorted(approach['xy'][geom,:,0],float(q[0])+.05)),int(np.searchsorted(ss,progress))+1),len(ss)-1)
        assert ia==r.anchor_index and r.approach_id==z['route'][j]==geom
        assert np.allclose([r.anchor_x_m,r.anchor_y_m],approach['xy'][geom,ia],atol=1e-12,rtol=0)
        assert np.array_equal(ids,len(approach['xy'])+(geom*3+np.arange(3))*len(ss)+oldjoin)
        base.update(query_tick=tick,original_anchor_index=oldjoin,prepared_anchor_index=ia,original_anchor_x=float(approach['xy'][geom,oldjoin,0]),
                    prepared_anchor_x=float(approach['xy'][geom,ia,0]),old_selected_direction=DIR[choice],original_selector_admitted=oldpass,
                    gpu_straight_incumbent=inc[r.lane][1])
        for direction,name in enumerate(DIR+['prepared']):
            old=direction<3
            rid=ids[direction] if old else int(r.curve_row)
            rr=tuple(np.array(bank[k][rid] if old else curves[k][rid],dtype='float32') for k in FIELDS)
            through=oldjoin if old else ia
            assert all(np.array_equal(x[:through+1],approach[k][geom,:through+1].astype('f4')) for k,x in zip(FIELDS,rr))
            loc=max(0,int(np.searchsorted(rr[0][:,0],q[0]))-1)
            peak=float(abs(rr[2][loc:]).max())
            refs.append(dict(**{k:getattr(r,k) for k in KEY},candidate=name,
                             curve_index=rid,anchor_index=through,observed_anchor_prefix_exact=True,raw_remaining_peak=peak))
            jobs.append((q,v,p,pv,rr,r.section_x_m,r.side,10.-tick*.005,z['runtime_hold'][j]))
    for start in range(0,len(jobs),64):
        chunk=jobs[start:start+64]
        q,v,p,pv,rr,section,side,rem,hold=zip(*chunk)
        q,v,p,pv=map(tensor,(q,v,p,pv))
        result=native_score(solver,q,velocity_state(q,v),velocity_state(p,pv),list(map(tensor,zip(*rr))),
                       *map(tensor,(section,side,rem,hold)))
        for k in range(len(chunk)):
            rr=refs[start+k]
            rr.update({name:val[k].item() for name,val in result.items()})
            assert rr['peak']==rr['raw_remaining_peak'] and rr['curvature']==(rr['peak']<=1.)
    return tasks,refs

def main():
    sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()
    native_sha=json.loads((SRC/'protocol.json').read_text())['source_files'][native.__file__]
    assert sha(native.__file__)==native_sha
    orig=pd.read_csv(R/'all_cases.csv')
    p=orig[(orig.variant=='primary')&(orig.margin_m==.30)]
    straight=orig[orig.variant=='original_straight']
    assert len(p)==288 and not p.duplicated(KEY).any()
    with np.load(R/'reference_curves.npz') as z: curves={k:z[k] for k in FIELDS}
    t=[];a=[]
    for layout,g in p.groupby('layout'):
        tasks,refs=score_map(layout,g,curves);t.extend(tasks);a.extend(refs)
        print(layout,len(refs),'candidate scores',flush=True)
    tasks=pd.DataFrame(t).set_index(KEY);long=pd.DataFrame(a)
    for candidate,g in long.groupby('candidate'):
        small=g.set_index(KEY)
        for field in ['score','admitted','peak','curvature','curve_index']:
            tasks[candidate+'_'+field]=small[field]
    for key,r in tasks[tasks.has_relock].iterrows():
        any_old=any(r[k+'_admitted'] for k in DIR);new=bool(r.prepared_admitted)
        tasks.loc[key,'any_old_admitted']=any_old
        tasks.loc[key,'old_selected_admitted']=bool(r[r.old_selected_direction+'_admitted'])
        tasks.loc[key,'old_selected_score']=r[r.old_selected_direction+'_score']
        tasks.loc[key,'comparison']=('both' if any_old and new else 'prepared_only' if new else 'old_only' if any_old else 'neither')
    tt=tasks.reset_index()
    cats=['prepared_only','old_only','both','neither','no_relock']
    counts=tt.groupby(['layout','side','comparison']).size().unstack(fill_value=0).reindex(columns=cats,fill_value=0)
    bygate=tt.groupby(['layout','gate','side','comparison']).size().unstack(fill_value=0).reindex(columns=cats,fill_value=0)
    delta={}
    for method,allow in [('straight',straight),('prepared',p)]:
        s=long[long.candidate==method].merge(allow[allow.has_relock],on=KEY,validate='one_to_one')
        print(method,len(s),s.admitted.value_counts().to_dict(),s.model_admitted.value_counts().to_dict(),(s.admitted!=s.model_admitted).sum(),(s.curvature!=s.kappa_pass).sum(),flush=True)
        assert len(s)==226 and np.array_equal(s.admitted,s.model_admitted) and np.array_equal(s.curvature,s.kappa_pass)
        assert np.array_equal(s.peak,s.peak_remaining_curvature_1_m.astype(np.float32))
        for k,n in [('gate_predicate','gate_pass'),('clear','clearance_pass'),('domain','domain_pass'),('held','goal_hold_pass')]:
            assert np.array_equal(s[k],s[n])
        delta[method]=float(abs(s.score_x-s.score_y).max())
        assert np.allclose(s.score_x,s.score_y,rtol=0,atol=1e-4)
    prior=pd.read_csv(SRC/'analysis/strict_loss_old_routes_rescored.csv').rename(columns={'map':'layout','old_arm':'candidate'})
    checks=long.merge(prior,on=['layout','root','force_N','gate','side','lane','candidate'],validate='one_to_one')
    assert len(checks)==47 and np.array_equal(checks.curve_index,checks.route_id) and np.array_equal(checks.admitted,checks.base_geometry_filtered_admission)
    assert np.array_equal(checks.peak,checks.peak_remaining_curvature_m_inv.astype(np.float32))
    old47_score_maxdiff=float(abs(checks.score_x-checks.score_y).max())
    assert np.allclose(checks.score_x,checks.score_y,rtol=0,atol=1e-4)
    check_sel=tt.merge(prior,on=['layout','root','force_N','gate','side','lane'],validate='one_to_one')
    assert len(check_sel)==47 and (check_sel.old_selected_direction==check_sel.candidate).all() and check_sel.old_selected_admitted.eq(True).all()
    scored=tt[tt.has_relock]
    assert np.array_equal(scored.gpu_straight_incumbent,scored.straight_admitted)
    assert len(tt)==288 and len(scored)==226 and len(long)==904 and scored.straight_admitted.sum()==9
    distribution=tt.comparison.value_counts().reindex(cats,fill_value=0).astype(int).to_dict()
    prefix='old_three_comparison'
    tt.to_csv(R/(prefix+'_cases.csv'),index=False);long.to_csv(R/(prefix+'_candidate_scores.csv'),index=False)
    counts.to_csv(R/(prefix+'_map_side.csv'));bygate.to_csv(R/(prefix+'_map_gate_side.csv'))
    sb=scored.groupby(['layout','side']).agg(observed=('lane','size'),old_any=('any_old_admitted','sum'),old_selected=('old_selected_admitted','sum'),
                    prepared=('prepared_admitted','sum'),old_left=('left_admitted','sum'),old_straight=('straight_admitted','sum'),old_right=('right_admitted','sum'))
    sb.to_csv(R/(prefix+'_selectors.csv'))
    dx=scored.original_anchor_x-scored.prepared_anchor_x
    receipt=dict(total=288,relocked=226,no_relock=62,counts=distribution,old_direction_admitted={k:int(scored[k+'_admitted'].sum()) for k in DIR},
        old_any=int(scored.any_old_admitted.sum()),old_selected=int(scored.old_selected_admitted.sum()),prepared=int(scored.prepared_admitted.sum()),
        old_selected_historical_admitted=int(scored.original_selector_admitted.sum()),straight_GPU_and_prepared_CPU_reproduced=226,
        old47_actual_directions_and_scores_reproduced=len(checks),old47_prepared_and_any=check_sel.comparison.value_counts().to_dict(),
        old47_max_abs_score_difference=old47_score_maxdiff,prepared_file_max_abs_score_difference=delta,
        anchors=dict(old_native_join_independently_rebuilt=226,prepared_anchor_independently_rebuilt=226,
                     complete_unmodified_prefixes_across_all_geometry=904,old_minus_prepared_x_m=dx.agg(['min','median','max']).to_dict(),
                     old_minus_prepared_nodes=(scored.original_anchor_index-scored.prepared_anchor_index).astype(int).value_counts().sort_index().to_dict()),
        curvature=dict(native_vs_independent_peak_and_predicate_equal=904,cap_per_m=1.0,old_all_three_pass_tasks=int(scored[[k+'_curvature' for k in DIR]].eq(True).all(axis=1).sum())),
        identity={'smooth_scorer':native_sha,'prepared_source_results':sha(R/'all_cases.csv'),'prepared_curves':sha(R/'reference_curves.npz'),
                  'procedure':sha(__file__)},scope='Observed first-query handbacks, paired offline initial scoring with the frozen CPU 255-step model. Old any is the existential upper envelope over the three original rows under this scorer. The actual old selector column refers to the original online three-way pick with straight fallback, re-evaluated by the same scorer. No release or new vehicle trajectory.')
    (R/(prefix+'_receipt.json')).write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()

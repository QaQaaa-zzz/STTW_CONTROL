"""Analytic extreme references with horizontal tangents and a one-metre minimum radius."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

out=Path(__file__).resolve().parent
table=pd.read_csv(out/'curvature_bound_cases.csv')
r=table[table.root.eq(1172) & table.force.eq(-5) & table.side.eq(-1) & table.section.eq('near')].iloc[0]
assert r.anchor_heading==0.
direction=np.sign(r.target_y-r.anchor_y)
K=1.
distance=abs(r.target_y-r.anchor_y)
min_length=np.sqrt(4*distance/K-distance**2)
x1=r.corridor_start_x
plt.rcParams.update({'font.family':'Noto Sans CJK JP','axes.unicode_minus':False})
fig,ax=plt.subplots(figsize=(9,3.6),layout='constrained')
for length, color,style,label in [(min_length,'#236d5e','--','若提前 42.0 厘米开始转'),(r.dx_to_corridor,'#a74b22','-','从原锚点开始，尽可能向右转')]:
    t=np.linspace(0,length,401);h=K*length/2
    y=np.empty_like(t);first=t<=length/2
    y[first]=(1-np.sqrt(1-(K*t[first])**2))/K
    y[~first]=(1+np.sqrt(1-(K*(length-t[~first]))**2)-2*np.sqrt(1-h*h))/K
    y=r.anchor_y+direction*y
    ax.plot(x1-length+t,y,color=color,lw=2.4,ls=style,label=label)
    ax.scatter([x1-length,x1],[y[0],y[-1]],c=color,s=26,zorder=4)
ax.axvline(x1,c='#79747b',lw=1)
ax.plot([x1,x1+.21],[r.target_y]*2,c='#236d5e',label='要求进入的通道',lw=3)
ax.annotate('原锚点',xy=(r.anchor_x,r.anchor_y),xytext=(-9,11),textcoords='offset points',ha='center')
ax.annotate('最多横移 15.95 厘米',xy=(x1,r.anchor_y+direction*r.max_lateral_shift),xytext=(7,7),textcoords='offset points',color='#a74b22')
ax.annotate('所需横移 40.20 厘米',xy=(x1,r.target_y),xytext=(7,-15),textcoords='offset points',color='#236d5e')
ax.set(xlim=(x1-min_length-.10,x1+.52),ylim=(-.75,-.08),xlabel='前进位置 x（米）',ylabel='横向位置 y（米）')
ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.18)
ax.set_title('右偏墙 · 起点 1172 · 近右门：给定半径与始末朝向时，参考线能转多远？',fontsize=12)
fig.legend(*ax.get_legend_handles_labels(),loc='outside lower center',ncol=3,frameon=False,fontsize=9)
fig.savefig(out/'reference_curvature_bound.png',dpi=155)

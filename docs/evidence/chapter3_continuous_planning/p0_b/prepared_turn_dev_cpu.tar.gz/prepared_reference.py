"""A precomputed map corridor, followed by a scalar-progress bind at the relock."""
import numpy as np


def prepare(world, section, side, margin=0.30):
    goal = world["goal"]
    obstacles = [rect for rect in world["terrain"]["forbidden_rectangles"] if rect[0] < goal["x_min_m"]]
    outer = [side * (rect[3] if side == 1 else rect[2]) for rect in obstacles]
    return (side * (max([.06, *outer]) + margin),
            min([section, *(rect[0] for rect in obstacles)]) - .25,
            max([section, *(rect[1] for rect in obstacles)]) + .25,
            goal["x_max_m"] - 2. * goal["hold_s"])


def _segment(u, length, initial_y, derivative, second, final_y):
    d1, d2 = derivative * length, .5 * second * length**2
    displacement = final_y - initial_y
    c3 = 10. * displacement - 6. * d1 - 3. * d2
    c4 = -15. * displacement + 8. * d1 + 3. * d2
    c5 = 6. * displacement - 3. * d1 - d2
    return initial_y + u * (d1 + u * (d2 + u * (c3 + u * (c4 + u * c5))))


def bind(approach, geometry, progress, prepared):
    s = approach["s"]
    original_xy = approach["xy"][geometry]
    original_h, original_k = approach["heading"][geometry], approach["curvature"][geometry]
    idx = min(int(np.searchsorted(s, progress)), len(s)-1)
    x0, y0 = original_xy[idx]
    target, arrive, leave, finish = prepared
    if not (x0 < arrive <= leave < finish):
        return idx, None
    slope = np.tan(original_h[idx])
    second = original_k[idx] * (1.+slope*slope)**1.5
    # Sampling in world x at the original route knots, plus exact named junctions.
    x = np.unique(np.r_[original_xy[idx:,0], arrive, leave, finish])
    y = np.zeros_like(x)
    first = x <= arrive
    y[first] = _segment((x[first]-x0)/(arrive-x0), arrive-x0, y0, slope, second, target)
    y[(x>arrive)&(x<=leave)] = target
    last = (x>leave)&(x<finish)
    y[last] = _segment((x[last]-leave)/(finish-leave), finish-leave, target, 0., 0., 0.)
    arc = s[idx] + np.r_[0., np.cumsum(np.hypot(np.diff(x), np.diff(y)))]
    xy = original_xy.copy()
    nxt = s[idx+1:]
    xy[idx+1:,0] = np.interp(nxt, arc, x) + np.maximum(nxt-arc[-1],0.)
    xy[idx+1:,1] = np.interp(nxt, arc, y)
    h = np.arctan2(np.gradient(xy[:,1]),np.gradient(xy[:,0]))
    k = np.gradient(h,s)
    h[:idx+1], k[:idx+1] = original_h[:idx+1], original_k[:idx+1]
    return idx, (xy.astype('f4'),h.astype('f4'),k.astype('f4'))

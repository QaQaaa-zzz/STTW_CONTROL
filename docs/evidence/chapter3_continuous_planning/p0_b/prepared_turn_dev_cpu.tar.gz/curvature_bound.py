"""Analytic necessary condition for any forward graph reaching the frozen corridor horizontally."""
from pathlib import Path
import json,math
import numpy as np
import pandas as pd
from prepared_reference import prepare

root=Path(__file__).resolve().parent
prior=root.parent/'chapter3_smooth_exit_dev_20261124'
K=1.0
def bound(x0,y0,theta,x1,y1):
    length=x1-x0
    distance=abs(y1-y0)
    if length<=0: return 'no_forward_interval',None
    u=math.copysign(1.0,y1-y0)*math.sin(theta)
    if abs(u)>K*length:return 'end_tangent_unreachable',None
    peak=.5*(K*length+u)
    if peak>=1:return 'unbounded_by_this_test',None
    maximum=(1+math.sqrt(1-u*u)-2*math.sqrt(1-peak*peak))/K
    return ('impossible_with_curvature_limit' if distance>maximum+1e-8 else 'within_outer_bound'),maximum

def main():
    tasks=pd.read_csv(prior/'analysis/selected_tasks.csv.gz')
    all_rows=[]
    for layout,t in tasks[tasks.primary & tasks.method.eq('event')].groupby('layout'):
        cfg=json.loads((prior/layout/'run.json').read_text())
        world=json.loads(Path(cfg['world_map']).read_text())
        with np.load(cfg['paired_departures']['approach_file']) as z:approach=dict(z)
        first={}
        for s in (prior/layout/'physical/p0_events.jsonl').open():
            e=json.loads(s)
            if e['kind']=='old_selection':first.update({int(l):e['tick'] for l in e['lanes']})
        for a in t.itertuples():
            section=12.7 if a.section=='near' else 15.
            target,arrive,leave,finish=prepare(world,section,a.side)
            info=dict(layout=layout,root=a.root,force=a.force,geometry=a.geometry,side=a.side,section=a.section,lane=a.lane,
                      target_y=target,corridor_start_x=arrive,corridor_end_x=leave,finish_x=finish,strict=a.pair_ok)
            tick=first.get(a.lane)
            if tick is None:info.update(approach_condition='no_handback',return_condition='no_handback')
            else:
                with np.load(prior/layout/f'physical/p0_handbacks/tick_{tick:04d}.npz') as z:
                    j=np.flatnonzero(z['lanes']==a.lane)[0]; progress=z['middle_projection_progress'][j]
                idx=min(np.searchsorted(approach['s'],progress),len(approach['s'])-1)
                x,y=approach['xy'][a.geometry,idx]
                theta=approach['heading'][a.geometry,idx]
                status,cap=bound(x,y,theta,arrive,target)
                end_status,end_cap=bound(leave,target,0.,finish,0.)
                info.update(tick=tick,anchor_x=x,anchor_y=y,anchor_heading=theta,dx_to_corridor=arrive-x,dy_to_corridor=abs(target-y),
                            approach_condition=status,max_lateral_shift=cap,return_condition=end_status,return_max_shift=end_cap)
            all_rows.append(info)
    data=pd.DataFrame(all_rows)
    assert len(data)==288
    data.to_csv(root/'curvature_bound_cases.csv',index=False)
    count=data.groupby(['layout','side','section','approach_condition','return_condition']).size()
    count.to_csv(root/'curvature_bound_counts.csv',header=['tasks'])
    print(data.groupby(['approach_condition','return_condition']).size().to_string())
    print(data[data.approach_condition.eq('impossible_with_curvature_limit')][['layout','root','side','section','dx_to_corridor','dy_to_corridor','max_lateral_shift']].head(5).to_string(index=False))
if __name__=='__main__':main()

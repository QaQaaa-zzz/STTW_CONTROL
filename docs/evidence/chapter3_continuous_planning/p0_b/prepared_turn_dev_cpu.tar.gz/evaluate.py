from collections import defaultdict
from functools import lru_cache
from pathlib import Path
from types import SimpleNamespace
from time import perf_counter
import hashlib
import json
import sys

import numpy as np
import pandas as pd
import torch

import prepared_reference as geometry


out = Path(__file__).resolve().parent
spec = json.loads((out/'protocol.json').read_text())
source = Path(spec['source'])
work = Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src')
helper = source.parent/'chapter3_continuous_p1_20261123/model'
sys.path[:0] = [str(work), str(helper)]
from frozen_exit_value import FrozenExits, mapped_arrays
import sttw_control.chapter3_continuous_exit as native
from sttw_control.platform_online import velocity_state

torch.set_num_threads(1)
to_tensor = lambda a: torch.as_tensor(np.asarray(a),dtype=torch.float32)
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
expected_sha = json.loads((source/'protocol.json').read_text())['source_files'][native.__file__]
assert sha(native.__file__) == expected_sha
manifest = pd.read_csv(source/'analysis/selected_tasks.csv.gz',usecols=['layout','root','force','section','side','geometry','lane','method','primary'])
manifest = manifest[manifest.primary & (manifest.method=='event')].reset_index(drop=True)
assert len(manifest)==288
rows,curves,headings,curvatures,directives = [],[],[],[],[]
versions = [('primary',.30),('sensitivity_low',.20),('sensitivity_high',.40),('original_straight',None)]


def capture_scores(solver,q,cur,prev,ref,section,side,rem,hold):
    details={}
    def on_return(frame,event,arg):
        if event!='return':return
        if frame.f_code == native._score.__code__:
            env=frame.f_locals
            for key,values in [('gate_pass',env['gate']),('clearance_pass',env['safe']),('domain_pass',env['within']),('goal_hold_pass',env['held'].any(1)),('gate_crossed',env['crosses'].any(1)),('gate_y_forecast_m',env['at'])]:
                details[key]=values.numpy()
        elif frame.f_code==native.ContinuousExitPlanner._smooth_score.__code__:
            details['kappa_pass']=frame.f_locals['geometry'].numpy()
            details['peak_remaining_curvature_1_m']=frame.f_locals['peak'].numpy()
    sys.setprofile(on_return)
    try:
        score,admit,clear,valid=solver._smooth_score(q,cur,prev,*ref,section,side,rem,torch.zeros(len(q),dtype=torch.long),hold)
    finally:sys.setprofile(None)
    details.update(score=score.numpy(),model_admitted=admit.numpy(),min_body_clearance_m=clear.numpy(),forecast_window_s=valid.numpy())
    return details


@torch.inference_mode()
def process(layout,group):
    physical=source/layout/'physical'
    cfg=json.loads((physical/'resolved_config.json').read_text())
    world=json.loads(Path(cfg['world_map']).read_text())
    with np.load(cfg['paired_departures']['approach_file']) as f: approach=dict(f)
    original=mapped_arrays(cfg['paired_departures']['route_bank'])
    s=approach['s']
    solver=native.ContinuousExitPlanner(FrozenExits(physical,device='cpu',load_route_bank=False).query,SimpleNamespace(s=to_tensor(s)),mode='smooth_event',fused=False)
    observed={}
    with (physical/'p0_events.jsonl').open() as f:
        for line in f:
            e=json.loads(line)
            if e['kind']=='old_selection':
                for lane,straight in zip(e['lanes'],e['default_route_id']):
                    observed[lane]=(e['tick'],straight)
    @lru_cache(maxsize=100)
    def snapshot(tick):
        with np.load(physical/'p0_handbacks'/f'tick_{tick:04d}.npz') as z:
            return {k:z[k] for k in ('lanes','middle_projection_progress','physics_qpos','physics_qvel','route','runtime_hold',f'query_pose_history_{tick%4}',f'query_velocity_history_{tick%4}')}
    variants={}
    for section in ['near','far']:
        section_x={'near':12.7,'far':15.}[section]
        for side in [-1,1]:
            for variant,margin in versions[:-1]:
                t0=perf_counter()
                prepared=geometry.prepare(world,section_x,side,margin)
                elapsed=1e3*(perf_counter()-t0)
                variants[section,side,variant]=prepared
                directives.append(dict(layout=layout,section=section,side=side,variant=variant,margin_m=margin,prepared_y_m=prepared[0],arrive_x_m=prepared[1],leave_x_m=prepared[2],finish_x_m=prepared[3],prepare_sample_ms=elapsed))
    jobs=[]
    for event in group.itertuples():
        obs = observed.get(event.lane)
        section_x={'near':12.7,'far':15.}[event.section]
        if obs:
            tick,straight=obs
            snap=snapshot(tick)
            i=int(np.flatnonzero(snap['lanes']==event.lane)[0])
            original_id=int(snap['route'][i])
            assert original_id==event.geometry
            progress=float(snap['middle_projection_progress'][i])
        for variant,margin in versions:
            row=dict(layout=layout,root=event.root,force_N=event.force,gate=event.section,side=event.side,section_x_m=section_x,geometry=event.geometry,lane=event.lane,variant=variant,margin_m=margin,has_relock=bool(obs),constructed=False,geometry_reason='no_relock',curve_row=-1)
            rows.append(row)
            if variant!='original_straight':
                directive=variants[event.section,event.side,variant]
                row.update(target_y_m=directive[0],arrive_x_m=directive[1],leave_x_m=directive[2],finish_x_m=directive[3])
            if not obs:continue
            row.update(first_relock_tick=tick,progress_m=progress,approach_id=original_id)
            if variant=='original_straight':
                idx=int(np.searchsorted(s,progress))
                ref=tuple(np.asarray(original[key][straight],'f4') for key in ('xy','heading','curvature'))
                row['original_straight_id']=straight
            else:
                t0=perf_counter()
                idx,ref=geometry.bind(approach,original_id,progress,directive)
                row['bind_cpu_single_ms']=1000*(perf_counter()-t0)
            row.update(anchor_index=idx,anchor_x_m=float(approach['xy'][original_id,idx,0]),anchor_y_m=float(approach['xy'][original_id,idx,1]))
            if ref is None:
                row['geometry_reason']='nonpositive_interval'
                continue
            xy,h,k=ref
            if variant!='original_straight':
                assert np.array_equal(xy[:idx+1],np.asarray(approach['xy'][original_id,:idx+1],dtype='f4'))
                assert np.array_equal(h[:idx+1],np.asarray(approach['heading'][original_id,:idx+1],dtype='f4'))
                assert np.array_equal(k[:idx+1],np.asarray(approach['curvature'][original_id,:idx+1],dtype='f4'))
            assert np.all(np.diff(xy[:,0])>0)
            row.update(constructed=True,geometry_reason='ok',curve_row=len(curves),reference_y_at_gate_m=np.interp(section_x,xy[:,0],xy[:,1]),geometric_gate_pass=event.side*np.interp(section_x,xy[:,0],xy[:,1])>=.06,absolute_max_curvature_1_m=float(np.max(np.abs(k))))
            curves.append(xy);headings.append(h);curvatures.append(k)
            q=snap['physics_qpos'][i];v=snap['physics_qvel'][i]
            assert q[0]<section_x
            row['observed_vehicle_x_m']=float(q[0])
            jobs.append((row,q,v,snap[f'query_pose_history_{tick%4}'][i],snap[f'query_velocity_history_{tick%4}'][i],ref,section_x,event.side,10.-tick*.005,snap['runtime_hold'][i]))
    for start in range(0,len(jobs),64):
        batch=jobs[start:start+64]
        _,q,v,p,vp,references,sec,side,rem,hold=zip(*batch)
        q,v,p,vp=map(to_tensor,(q,v,p,vp))
        ref=list(map(to_tensor,zip(*references)))
        results=capture_scores(solver,q,velocity_state(q,v),velocity_state(p,vp),ref,*map(to_tensor,(sec,side,rem,hold)))
        for n,(row,*_) in enumerate(batch):
            row.update({k:values[n].item() for k,values in results.items()})
            if not row['gate_crossed']:row['gate_y_forecast_m']=None
    print(layout,len(jobs),'scored',flush=True)


for layout,group in manifest.groupby('layout',sort=False):process(layout,group)
cases=pd.DataFrame(rows)
cases.to_csv(out/'all_cases.csv',index=False)
pd.DataFrame(directives).to_csv(out/'map_directives.csv',index=False)
np.savez_compressed(out/'reference_curves.npz',s=mapped_arrays(json.loads((source/'right_offset/physical/resolved_config.json').read_text())['paired_departures']['route_bank'])['s'],xy=np.stack(curves),heading=np.stack(headings),curvature=np.stack(curvatures))
summary={}
for index,sub in [('all',cases),*cases.groupby('layout')]:
    grouped={}
    for v,g in sub.groupby('variant',sort=False):
        count=lambda key:int(g[key].eq(True).sum())
        gg=g[g.constructed]
        grouped[v]=dict(tasks=len(g),relocked=count('has_relock'),geometry=count('constructed'),nonpositive_intervals=int(g.geometry_reason.eq('nonpositive_interval').sum()),reference_gate_pass=count('geometric_gate_pass'),model_admitted=count('model_admitted'),kappa_pass=count('kappa_pass'),clearance_pass=count('clearance_pass'),domain_pass=count('domain_pass'),goal_hold_pass=count('goal_hold_pass'),predicted_gate_pass=count('gate_pass'),worst_remaining_curvature_1_m=float(gg.peak_remaining_curvature_1_m.max()))
        if v!='original_straight':grouped[v]['bind_CPU_ms_p50_p95_max']=gg.bind_cpu_single_ms.quantile([.5,.95,1]).to_list()
    summary[index]=grouped
summary['implementation']={'source_sha':{str(p):sha(p) for p in [out/'protocol.json',out/'prepared_reference.py',out/'evaluate.py',helper/'frozen_exit_value.py',Path(native.__file__)]},'operator':'CPU float32 native, one thread, one 255-step assessment per geometry per observed handback; geometry is bound before accessing pose or twist. Archive float32 equality checked at every original prefix knot. No steering-command or physical trial.'}
(out/'receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['all'],indent=2))

"""Render two previously executed DEV trajectories from the accompanying compact arrays."""
from pathlib import Path
import json
from subprocess import check_output
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties,fontManager
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

ROOT=Path(__file__).resolve().parent
MEASURED='#155777'
REFERENCE='#C16D27'
CAP='#AE2948'
GATE='#58916D'
FAIL='#943A43'

def draw():
    font=check_output(['fc-match','-f','%{file}','Noto Sans CJK SC'],text=True)
    fontManager.addfont(font);family=FontProperties(fname=font).get_name()
    plt.rcParams.update({'font.family':family,'font.size':12,'axes.unicode_minus':False})
    with np.load(ROOT/'cap_witness_data.npz') as z:
        m=json.loads(z['metadata_json'].item())
        fig=plt.figure(figsize=(12.6,6.85),dpi=150)
        fig.text(.065,.957,'参考线超过曲率门槛，两辆车实际都走到了终点',fontsize=22,weight='bold',color='#182E39')
        fig.text(.065,.911,'右偏墙开发图　·　指定正侧门　·　同一次实走分别按近门和远门计分',fontsize=12.2,color='#435865')
        legend=[Line2D([],[],c=MEASURED,lw=2.4,label='实测车体轨迹'),
                Line2D([],[],c=REFERENCE,lw=2.2,ls='--',label='发布后的参考线'),
                Line2D([],[],c=CAP,ls='',marker='o',mfc='none',mew=1.3,ms=6,label='参考曲率超过 1/m 的节点'),
                Line2D([],[],c=MEASURED,marker='o',ls='',ms=6,label='发布时车体位置'),
                Line2D([],[],c=MEASURED,marker='X',ls='',ms=7,label='真实终点')]
        fig.legend(handles=legend,ncol=5,bbox_to_anchor=(.064,.891),loc='upper left',frameon=False,
                   fontsize=10.2,handlelength=1.9,columnspacing=1.45,borderaxespad=0)
        for j,(c,base) in enumerate(zip(m['cases'],(.516,.137))):
            prefix=f'r{c["root"]}_'
            t,xy,ref,k=[z[prefix+a] for a in ('t','xy','ref','k')]
            p=c['published_tick'];q=c['query_tick'];off=c['first_remaining_route_node']
            assert abs(t[p]-t[q]-.015)<1e-6 and np.isclose(abs(k[off:]).max(),c['remaining_peak_per_m'])
            mask=(np.arange(len(k))>=off)&(abs(k)>1.)
            assert mask.sum()==c['exceedances']
            end=xy[-1];near,far=m['gates']
            ax=fig.add_axes([.065,base,.895,.225])
            ax.set(xlim=(.98,18.48),ylim=(-1.00,1.24),aspect='equal',ylabel='y（m）',xlabel='世界 x（m）' if j else '')
            ax.set_xticks([2,4,6,8,10,12,14,16,18]);ax.set_yticks([-1,0,1]);ax.tick_params(length=3,labelsize=9.7)
            ax.spines[['right','top']].set_visible(False);ax.spines[['bottom','left']].set_color('#A5B1B9')
            ax.grid(axis='x',lw=.6,color='#E7ECEE',zorder=0)
            term=c['true_end_s'];dir_name='直行出口' if c['old_direction']=='straight' else '左出口'
            fig.text(.065,base+.258,f'起点 {c["root"]}　·　侧向力 {c["force_N"]:+g} N'.replace('+0','0'),fontsize=15,weight='bold',color='#182E39')
            fig.text(.348,base+.262,f'{dir_name}　·　参考线 {c["route_id"]}　·　峰值 |κ| = {c["remaining_peak_per_m"]:.3f}/m',fontsize=12.2,color='#435865')
            ax.axvline(m['step_x_m'],c='#85969A',lw=.85,ls=(0,(2,3)),zorder=1)
            ax.text(m['step_x_m']-.1,-.84,'台阶边',ha='right',color='#697C83',fontsize=9.2)
            goal=m['goal'];ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],fc='#E9EFF1',zorder=0))
            ax.text(goal['x_min_m']+.17,-.79,'终点区',fontsize=9.3,color='#63747D')
            for x0,x1,y0,y1 in m['walls']:
                ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,color='#38383A',zorder=6))
                ax.annotate('墙',xy=((x0+x1)/2,(y0+y1)/2),xytext=(x1+.22,-.55),fontsize=8.7,color='#49484A',arrowprops=dict(arrowstyle='-',lw=.65,color='#57585B'))
            for gate,cy,correct,label in zip(m['gates'],c['gate_y'],c['gate_ok'],('近门','远门')):
                ax.plot([gate,gate],[m['gate_y_min'],m['gate_y_max']],color=GATE,alpha=.86,lw=1.65,zorder=1)
                ax.plot(gate,m['gate_y_min'],marker='_',c=GATE,ms=6,zorder=1)
                col='#236246' if correct else FAIL
                ax.scatter(gate,cy,s=36,marker='D' if correct else 'x',facecolor=col,
                           linewidth=1.6 if not correct else .6,edgecolor=None if not correct else 'white',zorder=7)
                ax.text(gate,1.05,label,ha='center',va='center',color='#345644',fontsize=10.2)
                y_label=-.74 if label=='近门' else -.36
                ax.annotate(('通过' if correct else '未通过')+f'  {cy:+.3f} m',xy=(gate,cy),xytext=(gate-.16,y_label),
                            fontsize=9.2,ha='right' if label=='近门' else 'left',va='center',color=col,
                            arrowprops=dict(arrowstyle='-',color=col,lw=.64,shrinkA=2,shrinkB=4))
            # Only show the actual published route ahead of the car at release, ending at its observed terminal x.
            grid=ref[:,0];rx=np.r_[xy[p,0],grid[(grid>xy[p,0])&(grid<end[0])],end[0]]
            ax.plot(*xy.T,lw=2.3,c=MEASURED,zorder=3)
            ax.plot(rx,np.interp(rx,grid,ref[:,1]),lw=1.9,c=REFERENCE,ls=(0,(3.4,2.4)),zorder=4)
            ax.scatter(*ref[mask].T,s=19,facecolors='none',edgecolors=CAP,linewidths=1.0,zorder=5)
            peak=off+np.argmax(abs(k[off:]))
            ax.annotate(f'{c["exceedances"]} 个超限节点',xy=ref[peak],xytext=(ref[peak,0]-.65,.96),fontsize=9.1,color=CAP,ha='right',
                        arrowprops=dict(arrowstyle='-',color=CAP,lw=.78,shrinkB=3))
            ax.plot(*xy[p],marker='o',ms=6,color=MEASURED,mec='white',mew=.65,zorder=6)
            ax.plot(*end,marker='X',ms=8,color=MEASURED,mec='white',mew=.65,zorder=6)
            ax.text(end[0],.69,f'{term:.3f} s 抵达',ha='center',fontsize=9,color=MEASURED)
        fig.text(.065,.039,'两道门均要求 y ≥ +0.06 m。红圈标记冻结评分器检查的参考线节点；曲率数值取自发布的参考线。世界 x 和 y 等比例。',fontsize=10.2,color='#435865')
        fig.savefig(ROOT/'cap_witness_xy.png',dpi=160,facecolor='white',
                    metadata={'Description':'Two measured P0-B DEV trajectories, verified published references, excessive reference-curvature nodes, two scored gate crossings, and physical endpoints.'})
        plt.close(fig)
if __name__=='__main__':draw()

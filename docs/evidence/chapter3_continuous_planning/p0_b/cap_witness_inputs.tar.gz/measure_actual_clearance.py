"""Check original task successes against the frozen margin, using archived physical poses."""
import hashlib
import importlib.util
import json
from pathlib import Path

import mujoco
import numpy as np
import pandas as pd
import torch

HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
helper=BASE/'chapter3_continuous_p1_20261123/actions/continuous_examples/continuous_entry_event_exit/reference_controls/check.py'
spec=importlib.util.spec_from_file_location('reference_check',helper)
control=importlib.util.module_from_spec(spec)
spec.loader.exec_module(control)

@torch.inference_mode()
def main():
    torch.set_num_threads(1)
    key=['layout','root','force_N','gate','side','geometry']
    raw=pd.read_csv(HERE/'cap_only_15.csv')
    candidates=pd.read_csv(HERE.parent/'old_three_comparison_candidate_scores.csv')
    scores=pd.read_csv(HERE.parent/'old_three_comparison_cases.csv')
    cases=raw.merge(scores[key+['query_tick']],on=key,validate='one_to_one')
    selected=candidates.rename(columns={'candidate':'arm','curve_index':'chosen_curve_idx','clearance_m':'forecast_clearance_m'})
    cols=key+['arm','chosen_curve_idx']
    cases=cases.merge(selected[cols+['forecast_clearance_m','gate_predicate','clear','domain','held','curvature']],on=cols,validate='one_to_one')
    assert len(cases)==len(raw)==15 and (cases.clear & cases.gate_predicate & cases.domain & cases.held & ~cases.curvature).all()
    evaluated={}
    for layout,b in cases[cases.pair_ok&cases.success].groupby('layout'):
        physical=Path(b.iloc[0].path).parents[1]
        cfg=json.loads((physical/'resolved_config.json').read_text())
        frozen=control.FrozenExits(physical,device='cpu',load_route_bank=False).query
        model=mujoco.MjModel.from_binary_path(str(physical/'terrain.mjb'))
        bodies=[model.geom(i).name or f'geom_{i}' for i in range(model.ngeom) if model.geom_bodyid[i]>0 and (model.geom_contype[i] or model.geom_conaffinity[i])]
        walls=[model.geom(i).name for i in range(model.ngeom) if model.geom(i).name.startswith('planning_obstacle_')]
        bank=control.mapped_arrays(cfg['paired_departures']['route_bank'])
        for path,group in b.groupby('path'):
            row=group.iloc[0];tick=int(row.query_tick)
            assert group.query_tick.nunique()==group.chosen_curve_idx.nunique()==1
            assert row.departure_applied_tick==tick+3 and row.termination=='goal' and row.phys_goal and not row.wall
            with np.load(path) as z:
                assert np.array_equal(z['published_reference_xy'],bank['xy'][row.chosen_curve_idx])
                assert np.isclose(z['trace'][-1,0],row.duration_s) and np.isclose(z['trace'][tick,0],tick*.005)
                assert not z['world_flags'][:,2].any()
                evaluated[path]=control.actual_clearance(z,tick,frozen,bodies,walls)
    records=[]
    for row in cases.to_dict('records'):
        rec={k:row[k] for k in key+['class','arm','physical_lane','chosen_curve_idx','chosen_peak','query_tick','pair_ok','success','wall','gate_y','duration_s','termination','forecast_clearance_m','path']}
        rec['scope']='matched physical success' if row['pair_ok'] and row['success'] else ('unmatched' if not row['pair_ok'] else 'matched task failure')
        if rec['scope']=='matched physical success':
            rec.update(evaluated[row['path']])
        records.append(rec)
    results=pd.DataFrame(records)
    results.to_csv(HERE/'actual_clearance.csv',index=False)
    success=results[results.scope=='matched physical success']
    others=results[results.scope!='matched physical success']
    passed=success[success.actual_clearance_gt_frozen_margin.eq(True)]
    def count(frame):
        return {'gate_tasks':len(frame),'trajectories':frame.path.nunique(),'roots':frame.root.nunique()}
    receipt=dict(definition='Same float32 frozen BodyEnvelope 3D axis-aligned primitive bounds against the map planning-obstacle boxes. For each time/primitive/wall, take max over xyz of max(body_low - wall_high, wall_low - body_high); then minimum over pairs and all archived frames from first query through observed terminal goal. No inter-frame or exact-shape distance guarantee. Strict margin comparison is min > 0.05330585315823555 m. The 20 ms sensitivity uses every fourth pose from the same first-query tick.',
        actual_sample_step_s=.005,sampled_margin_m=0.05330585315823555,
        matched_physical_success=count(success),actual_strict_margin_and_task_success=count(passed),
        actual_gt_zero_and_task_success=count(success[success.actual_clearance_gt_zero.eq(True)]),
        actual_strict_margin_and_task_success_20ms=count(success[success.actual_min_clearance_20ms_m>success.actual_margin_m]),
        all_three_rejected_and_task_and_margin=count(passed[passed['class']=='all_three_rejected']),
        rows_outside_scored_subset=others.scope.value_counts().to_dict(),
        sources=[str(HERE/'cap_only_15.csv'),str(HERE.parent/'old_three_comparison_cases.csv'),str(HERE.parent/'old_three_comparison_candidate_scores.csv'),str(helper)],
        helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),raw_trajectory_paths='actual_clearance.csv path field; one execution may be used for two gate tests')
    (HERE/'actual_clearance_receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    print(success[['root','force_N','gate','actual_min_clearance_m','actual_min_clearance_time_s','actual_min_clearance_20ms_m','actual_clearance_gt_frozen_margin']].to_string(index=False))
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':
    main()

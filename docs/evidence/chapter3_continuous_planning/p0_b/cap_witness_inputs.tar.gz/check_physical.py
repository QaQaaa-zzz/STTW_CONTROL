"""Compare a post-hoc reference curvature cap with outcomes of the original, executed controller."""
from pathlib import Path
from functools import lru_cache
import json
import sys

import numpy as np
import pandas as pd

here=Path(__file__).resolve().parent
old=here.parents[1]/'chapter3_smooth_exit_dev_20261124'
sys.path[:0]=[str(here.parents[1]/'chapter3_continuous_p1_20261123/model'),
              '/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src']
from frozen_exit_value import mapped_arrays

@lru_cache(maxsize=2)
def route_bank(layout):
    cfg=json.loads((old/layout/'physical/resolved_config.json').read_text())
    return mapped_arrays(cfg['paired_departures']['route_bank'])

def main():
    score=pd.read_csv(here.parent/'old_three_comparison_cases.csv').query('has_relock')
    tasks=pd.read_csv(old/'analysis/selected_tasks.csv.gz').query("primary and method=='old'")
    tasks=tasks.rename(columns={'section':'gate','force':'force_N','lane':'physical_lane'})
    keys=['layout','root','force_N','gate','side','geometry']
    both=score.merge(tasks,on=keys,validate='one_to_one')
    assert len(both)==226 and both.old_selected_direction.eq(both.arm).all()
    records=[]
    for a in both.itertuples():
        direction=a.old_selected_direction
        rec={k:getattr(a,k) for k in keys+['pair_ok','has_relock','old_selector_observed','original_selector_admitted',
            'any_old_admitted','old_selected_admitted','arm','success','wall','phys_goal','correct_gate','gate_y','handoff_s',
            'gate_time','departure_applied_tick','duration_s','termination','physical_lane','path']}
        rec['chosen_peak']=getattr(a,direction+'_peak')
        rec['chosen_curve_idx']=int(getattr(a,direction+'_curve_index'))
        # Only matching physical prefixes locate the same remaining reference that was scored.
        if a.pair_ok and a.original_selector_admitted and not a.old_selected_admitted:
            bank=route_bank(a.layout)
            xy=bank['xy'][rec['chosen_curve_idx']]
            k=bank['curvature'][rec['chosen_curve_idx']]
            with np.load(a.path) as f:
                tr=f['trace']
                assert np.array_equal(f['published_reference_xy'],xy)
                qt=int(a.query_tick)
                start=max(0,int(np.searchsorted(xy[:,0],tr[qt,1]))-1)
                peak=start+int(np.argmax(np.abs(k[start:])))
                assert np.isclose(abs(k[peak]),rec['chosen_peak'],rtol=1e-6)
                ticks=np.flatnonzero((tr[:-1,1] < xy[peak,0]) & (tr[1:,1] >= xy[peak,0]))
                loc=ticks[ticks>=qt]
                rec.update(peak_x=xy[peak,0],peak_y=xy[peak,1],query_x=tr[qt,1],
                    gate_x=12.7 if a.gate=='near' else 15.,end_x=tr[-1,1],crossed_peak_x=bool(len(loc)),
                    first_time_at_peak_x=np.interp(xy[peak,0],tr[loc[0]:loc[0]+2,1],tr[loc[0]:loc[0]+2,0]) if len(loc) else np.nan)
        records.append(rec)
    df=pd.DataFrame(records);df.to_csv(here/'selected_old_trajectories.csv',index=False)
    dropped=df[df.original_selector_admitted.eq(True)&df.old_selected_admitted.eq(False)].copy()
    dropped['class']=np.select([~dropped.pair_ok, dropped.any_old_admitted.eq(True)],
                               ['unmatched','changed_choice_available'],default='all_three_rejected')
    dropped.to_csv(here/'cap_only_15.csv',index=False)
    print(dropped.groupby(['pair_ok','any_old_admitted','success']).size().to_string())
    print(dropped[dropped.pair_ok&dropped.success][['root','force_N','gate','chosen_peak','peak_x','gate_x','end_x','crossed_peak_x']].to_string(index=False))

if __name__=='__main__':main()

"""Grade the two already executed fixed exits on the original physical gate definition."""
from pathlib import Path
import json
import sys

import numpy as np
import pandas as pd

out=Path(__file__).resolve().parent
p1=out.parents[1]/'chapter3_continuous_p1_20261123'
sys.path.insert(0,'/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/cli')
from run_playground_task_reversal import crossings_by_section

keys=['map','root','force','gate_x','side']
labels=pd.read_csv(out/'anchors.csv')
pairs=pd.read_csv(out/'matched_conditions.csv')
labels=labels.merge(pairs.loc[pairs.opposite,keys],on=keys)
labels=labels[labels.status.isin(['excluded','constructible'])]
rows=[]
for map_id, group in labels.groupby('map'):
    data=pd.read_csv(p1/'export/dev'/map_id/'suffix_index.csv').query('action_slot<=2')
    cfg=json.loads((p1/'batches'/map_id/'config.json').read_text())
    assert all(v['planner']=='C' for v in cfg['ground_handoff']['handoff_variants'])
    assigned=data[data.assigned_tick.ge(0)]
    assert assigned.declared_direction.eq(assigned.online_selected_direction).all()
    data=data.set_index(['root','hidden_force_N_grouping_only','geometry']).sort_index()
    for a in group.itertuples():
        physical=data.loc[(a.root,a.force,a.geometry)]
        assert len(physical)==2 and set(physical.arm)=={'left','right'}
        for r in physical.itertuples():
            assert r.verified_relock and r.suffix_pair_status=='matched_observed_handoff'
            with np.load(r.trajectory) as t: trace=t['trace']
            hits=list(crossings_by_section(trace,r.native_handoff_s,[12.7,13.6,15.]))
            h=hits[0 if a.gate_x==12.7 else 2]
            y=h[-1]
            correct=y is not None and 0.06<=a.side*y<=3.9
            done=bool(correct and r.physical_goal and not r.physical_wall)
            if a.side==r.target_side and h[0]==r.section:
                assert done==r.physical_task_done and correct==r.correct_gate
            rows.append(dict(map=map_id,root=a.root,force=a.force,gate_x=a.gate_x,
                side=a.side,status=a.status,geometry=a.geometry,exit=r.arm,
                crossing_y=y,goal=r.physical_goal,wall=r.physical_wall,done=done,
                trajectory=r.trajectory))
df=pd.DataFrame(rows)
df.to_csv(out/'physical_fixed_exits.csv',index=False)
v=df.groupby(keys+['status']).done.any().unstack()
v.to_csv(out/'geometry_vs_task.csv')
print(v.reset_index().groupby(['force','constructible','excluded']).size())
print(df.query('root==1323 and force==0 and gate_x==12.7')[['side','geometry','exit','crossing_y','goal','wall','done']].to_string(index=False))

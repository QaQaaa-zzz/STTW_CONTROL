"""Draw two gate assignments at the same observed start; dashed extensions are purely geometric."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties,fontManager
from subprocess import check_output
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
COLORS=['#00689A','#B64917']

def cubic(x,x0,y0,m,x1,y1):
    length=x1-x0
    t=(x-x0)/length
    return (2*t**3-3*t**2+1)*y0+(t**3-2*t**2+t)*length*m+(-2*t**3+3*t**2)*y1

def max_ypp(x0,y0,m,x1,y1):
    length=x1-x0
    return max(abs(6*(y1-y0)/length**2-4*m/length),abs(-6*(y1-y0)/length**2+2*m/length))

def draw():
    font=check_output(['fc-match','-f','%{file}','Noto Sans CJK SC'],text=True)
    fontManager.addfont(font)
    family=FontProperties(fname=font).get_name()
    plt.rcParams.update({'font.family':family,'font.size':13,'axes.unicode_minus':False,'svg.fonttype':'none'})
    case=pd.read_csv(OUT/'anchors.csv')
    case=case[case['map'].eq('dev_00')&case.root.eq(1323)&case.force.eq(0)&case.gate_x.eq(12.7)&case.geometry.isin([0,1])]
    assert len(case)==4 and case.verified.all()
    world=json.loads((OUT/'example_map.json').read_text());terrain=world['terrain'];goal=world['goal']
    records=pd.read_csv(OUT/'physical_fixed_exits.csv')
    records=records[records['map'].eq('dev_00')&records.root.eq(1323)&records.force.eq(0)&records.gate_x.eq(12.7)&records.done&records.status.eq('constructible')]
    assert len(records)==2
    actual={};suffixes={}
    with np.load(OUT/'example_xy.npz') as sample:
        for g in (0,1):
            actual[g]=sample[f'g{g}_approach_xy_m']
            suffixes[g]=sample[f'g{g}_fixed_exit_xy_m']
            relock=sample[f'g{g}_relock_s'].item()
            assert np.isclose(sample[f'g{g}_approach_time_s'][-1],relock)
            assert np.isclose(sample[f'g{g}_fixed_exit_time_s'][0],relock)
            assert np.array_equal(actual[g][-1],suffixes[g][0])
    fig=plt.figure(figsize=(12.2,6.55),dpi=160)
    fig.patch.set_facecolor('white')
    fig.text(.065,.952,'同一起点，两条接近路线为落稳后的转弯留下了不同空间',fontsize=22,weight='bold',color='#142F3A')
    fig.text(.065,.905,'开发图 dev_00　·　起点 1323　·　外推力 0 N　·　跳前 α = 0　·　两条接近路线均已实际落稳',fontsize=12.2,color='#445664')
    handles=[Line2D([],[],c=COLORS[0],lw=2.4,label='入口 0 实走'),
             Line2D([],[],c=COLORS[1],lw=2.4,label='入口 1 实走'),
             Line2D([],[],ls='',c='#243949',marker='o',ms=6,label='车体落稳位置'),
             Line2D([],[],ls='',marker='s',c='#243949',mfc='none',mew=1.6,ms=7,label='参考路线锚点'),
             Line2D([],[],c='#243949',lw=2,ls=(0,(5,3)),label='可构造曲线（未执行）'),
             Line2D([],[],c='#F2CB6A',lw=8,alpha=.8,label='规定通道中心线')]
    fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.064,.884),ncol=6,frameon=False,columnspacing=1.15,handlelength=2,handletextpad=.42,fontsize=10.3,borderaxespad=0)
    fig.text(.069,.827,'淡色实线 = 已执行的原固定出口　　◆ = 实测过门点　　× = 实走终点',color='#485865',fontsize=10.7)
    for side,y0,header in [(-1,.493,'近右门'),(1,.113,'近左门')]:
        group=case[case.side==side];ok=group[group.status.eq('constructible')].iloc[0];bad=group[group.status.eq('excluded')].iloc[0]
        assert bad.required>bad.max_shift and ok.first_cap<=1 and ok.last_cap<=1
        a=fig.add_axes([.066,y0,.89,.247])
        a.set(xlim=(.98,18.08),ylim=(-1.17,1.20),aspect='equal',xlabel='世界 x（m）' if side==1 else '',ylabel='y（m）')
        a.set_xticks([2,4,6,8,10,12,14,16,18]);a.set_yticks([-1,0,1]);a.tick_params(labelsize=10.2,pad=2,length=3)
        a.grid(axis='x',color='#E6EBEF',lw=.7,zorder=0)
        a.spines[['top','right']].set_visible(False);a.spines[['left','bottom']].set_color('#9AA7AE')
        fig.text(.065,y0+.27,header,fontsize=16.2,weight='bold',color='#142F3A')
        fig.text(.175,y0+.275,f'入口 {int(ok.geometry)} 有构造解；入口 {int(bad.geometry)} 需横移 {bad.required:.3f} m，理论最多 {bad.max_shift:.3f} m。',fontsize=12,color='#344956')
        a.axvline(terrain['front_x_m'],c='#67777B',lw=.9,ls=(0,(2,3)),zorder=1)
        a.text(terrain['front_x_m']-.10,-.99,'台阶边',ha='right',fontsize=9.5,color='#546367')
        a.plot([world['gate']['x_m']]*2,[side*world['gate']['min_abs_y_m'],side*world['gate']['max_abs_y_m']],color='#674968',lw=1.8,zorder=2)
        a.text(ok.gate_x-.13,side*.96,'指定门',ha='right',va='center',color='#674968',fontsize=9.5)
        for xmin,xmax,ymin,ymax in terrain['forbidden_rectangles']:
            a.add_patch(Rectangle((xmin,ymin),xmax-xmin,ymax-ymin,fc='#30292A',zorder=5))
            a.annotate('墙',xy=((xmin+xmax)/2,(ymin+ymax)/2),xytext=(xmax+.34,.78),
                       arrowprops=dict(arrowstyle='-',color='#4A3E3B',lw=.8),fontsize=9.5,color='#4A3E3B')
        a.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],fc='#EDF1F3',zorder=0))
        a.text(17.0,-.78,'终点区',color='#61727B',fontsize=9.5)
        measured=records[records.side.eq(side)].iloc[0]
        g=int(ok.geometry)
        assert measured.geometry==g and not measured.wall and measured.goal
        suffix=suffixes[g]
        c=('#77A8BF','#D79B7C')[g]
        a.plot(*suffix.T,c=c,lw=2.2,zorder=3)
        a.scatter(*suffix[-1],marker='x',s=37,lw=1.5,c=c,zorder=6)
        a.scatter(ok.gate_x,measured.crossing_y,marker='D',s=36,edgecolors='white',linewidth=.7,facecolors=COLORS[g],zorder=7)
        a.annotate(f'实测过门 y = {measured.crossing_y:+.3f} m', xy=(ok.gate_x,measured.crossing_y),
                   xytext=(14.15,side*.96),color=COLORS[g],fontsize=9.6,
                   arrowprops=dict(arrowstyle='-',color=c,lw=.9),va='center')
        a.plot([ok.start_x,ok.end_x],[ok.target_y]*2,color='#F2CB6A',lw=8,alpha=.8,solid_capstyle='butt',zorder=2)
        xx=np.linspace(ok.x,ok.start_x,151);uu=np.linspace(ok.end_x,ok.finish_x,231)
        yy=cubic(xx,ok.x,ok.y,np.tan(ok.theta),ok.start_x,ok.target_y)
        vv=cubic(uu,ok.end_x,ok.target_y,0.,ok.finish_x,0.)
        assert np.isclose(max_ypp(ok.x,ok.y,np.tan(ok.theta),ok.start_x,ok.target_y),ok.first_cap)
        assert np.isclose(max_ypp(ok.end_x,ok.target_y,0.,ok.finish_x,0.),ok.last_cap)
        a.plot(np.r_[xx,uu],np.r_[yy,vv],lw=2.1,c=COLORS[int(ok.geometry)],ls=(0,(4,2.6)),zorder=4)
        for row in group.itertuples():
            gd=row.geometry;xy=actual[gd];c=COLORS[gd]
            a.plot(*xy.T,lw=2.1,c=c,zorder=4)
            a.plot(*xy[-1],marker='o',c=c,mec='white',mew=.6,ms=6.8,zorder=6)
            a.plot(row.x,row.y,marker='s',c=c,mfc='none',mew=1.45,ms=9.5,zorder=7)
    fig.text(.065,.026,'深色实线停在首次落稳位置。淡色实线为原固定出口；虚线为从参考锚点出发的数学构造。曲率上限 1/m，排除结论仅针对图示水平接入通道。',fontsize=10,color='#435765')
    fig.savefig(OUT/'paired_entry_xy.png',dpi=164,facecolor='white',metadata={'Description':'DEV root 1323. Two observed approach paths stop at physical relock. Dashed candidate curves are mathematical constructions only.'})
    plt.close(fig)
if __name__=='__main__':draw()

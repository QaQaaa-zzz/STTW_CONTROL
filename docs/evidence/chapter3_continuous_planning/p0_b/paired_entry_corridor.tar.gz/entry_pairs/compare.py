"""Apply frozen negative and constructive curvature certificates to measured handback anchors."""
from itertools import combinations, product
from pathlib import Path
import json
import math
import sys

import numpy as np
import pandas as pd

out = Path(__file__).resolve().parent
sys.path.insert(0, str(out.parent))
from curvature_bound import bound
from prepared_reference import prepare

p1 = out.parents[1] / 'chapter3_continuous_p1_20261123'


def hermite_cap(length, displacement, slope):
    # For endpoint slopes slope and zero, y'' is affine and its extrema are at endpoints.
    first = 6 * displacement / length**2 - 4 * slope / length
    last = -6 * displacement / length**2 + 2 * slope / length
    return max(abs(first), abs(last))


def collect(map_id):
    batch = p1 / 'batches' / map_id
    cfg = json.loads((batch / 'config.json').read_text())
    world = json.loads(Path(cfg['world_map']).read_text())
    export = p1 / 'export/dev' / map_id
    prefixes = pd.read_csv(export / 'prefix_index.csv').query('action_slot <= 2')
    with np.load(export / 'observed_inputs.npz') as inp:
        for _, group in prefixes.groupby(['root','hidden_force_N_grouping_only']):
            assert sorted(group.geometry) == [0,1,2] and (group.alpha == 0).all()
            for name in ('t0_qpos_native', 't0_qvel_native'):
                native = inp[name][group.row]
                assert np.array_equal(native, np.repeat(native[:1],3,axis=0))
    with np.load(cfg['paired_departures']['approach_file']) as curves:
        arc, xy, heading = (curves[k] for k in ('s','xy','heading'))
    records = []
    for a in prefixes.itertuples():
        anchor_idx = None
        if a.verified_relock and a.observed_query:
            with np.load(a.handback_snapshot) as snap:
                lane = np.flatnonzero(snap['lanes'] == a.lane).item()
                assert int(snap['route_at_query'][lane]) == a.geometry
                progress = snap['middle_projection_progress'][lane]
            anchor_idx = min(int(np.searchsorted(arc, progress)),len(arc)-1)
        for gate, side in product((12.7,15.),(-1,1)):
            target, start, end, finish = prepare(world,gate,side)
            r = dict(map=map_id, root=a.root, force=a.hidden_force_N_grouping_only,
                     geometry=a.geometry, gate_x=gate, side=side, target_y=target,
                     start_x=start, end_x=end, finish_x=finish, verified=a.verified_relock,
                     trajectory=a.trajectory, handback=a.handback_snapshot)
            if anchor_idx is None:
                r['status'] = 'no_verified_anchor'
            else:
                x,y=xy[a.geometry,anchor_idx]
                theta=heading[a.geometry,anchor_idx]
                status, limit=bound(x,y,theta,start,target)
                first=hermite_cap(start-x,target-y,math.tan(theta)) if start>x else math.inf
                last=hermite_cap(finish-end,-target,0)
                if status in ('impossible_with_curvature_limit','end_tangent_unreachable','no_forward_interval'):
                    assert max(first,last) > 1.-1e-6
                    verdict='excluded'
                elif max(first,last) < 1. - 1e-8:
                    verdict='constructible'
                else:
                    verdict='undetermined'
                r.update(status=verdict,x=x,y=y,theta=theta,required=abs(target-y),
                         max_shift=limit,first_cap=first,last_cap=last,geom_condition=status)
            records.append(r)
    return records


if __name__ == '__main__':
    all_rows=pd.DataFrame(collect('dev_00') + collect('dev_01'))
    all_rows.to_csv(out/'anchors.csv',index=False)
    groups=[]
    for key,g in all_rows.groupby(['map','root','force','gate_x','side']):
        counts=g.status.value_counts()
        change=(counts.get('excluded',0)>0 and counts.get('constructible',0)>0)
        pairs=sum({a.status,b.status}=={'excluded','constructible'}
                  for a,b in combinations(g.itertuples(),2))
        groups.append(dict(zip(['map','root','force','gate_x','side'],key),
                           num_verified=g.verified.sum(),excluded=counts.get('excluded',0),
                           constructive=counts.get('constructible',0),opposite=change,
                           signed_pairs=pairs))
    result=pd.DataFrame(groups)
    result.to_csv(out/'matched_conditions.csv',index=False)
    print(all_rows.groupby(['map','status']).size())
    print(result.groupby(['map','force']).agg(cases=('root','size'),two_anchors=('num_verified',lambda a:(a>=2).sum()),
          opposite=('opposite','sum'),pairs=('signed_pairs','sum')))
    print(result[result.opposite].groupby(['map','force']).root.nunique().to_dict())
    print(result[(result.opposite)&(result.force==0)].head(8).to_string(index=False))

#!/usr/bin/env bash
set -eu
base_dir="$(dirname "$(realpath "$0")")"
worktree=/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad
py=/home/qy/mujoco_playground/.venv/bin/python
cd "$worktree"
export PYTHONPATH="$worktree/learning/src:$worktree/learning/cli:/home/qy/DVGC/JIT/src"
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 CUDA_VISIBLE_DEVICES=0
unset JAX_PLATFORMS
"$worktree/learning/scripts/gpu_queue.sh" "$py" -u "$base_dir/run.py"
export CUDA_VISIBLE_DEVICES='' JAX_PLATFORMS=cpu
if "$py" "$base_dir/score.py" && "$py" "$base_dir/draw.py"; then
    /usr/bin/python3 "$worktree/learning/scripts/notify_chapter3_job.py" --title "第三章出口延时归约完成" --message "288项主门任务配对、三个时钟、逐根XY图已生成。" --receipt "$base_dir/analysis_bark.json"
else
    /usr/bin/python3 "$worktree/learning/scripts/notify_chapter3_job.py" --title "第三章出口延时归约异常" --message "物理已完成，详见本批服务日志。" --receipt "$base_dir/analysis_error_bark.json"
    exit 1
fi

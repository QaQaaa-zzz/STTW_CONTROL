"""Freeze the controlled release clock and the two matched DEV batches."""
import csv
import hashlib
import itertools
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parent
OLD = R.parent / 'chapter3_smooth_exit_dev_20261124'
W = Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
LAYOUTS = ('right_offset', 'staggered')
ARMS = ('early', 'middle', 'late')
DIRECTIONS = ('left', 'straight', 'right')

def read(path):
    return json.loads(Path(path).read_text())

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def due_tick(query_tick, clock):
    return (query_tick + 3, query_tick + 7, ((query_tick + 12 + 3)//4)*4)[clock]

def prepare():
    sources = [W/'learning/src/sttw_control'/name for name in (
        'chapter3_p0_physical.py','playground_handoff_evaluation.py','platform_online.py',
        'playground_snapshot.py')]
    sources += [W/'learning/cli'/n for n in ('evaluate_playground_handoff.py','analyze_chapter3_continuous_p0_branches.py','run_playground_task_reversal.py')]
    sources += [R/n for n in ('prepare.py','release_runtime.py','run.py','score.py','draw.py','launch.sh')]
    latency_path = OLD/'single_robot_latency.csv'
    samples = [float(r['ms']) for r in csv.DictReader(latency_path.open()) if r['kind']=='search']
    assert len(samples)==100 and {math.ceil(s/5) for s in samples}=={12}
    maps, catalog, initial_searches, search_receipts = [], [], 0, 0
    for layout in LAYOUTS:
        d=R/layout
        d.mkdir(exist_ok=True)
        original=OLD/layout/'run.json'
        cfg=read(original)
        base=cfg['ground_handoff']['handoff_variants']
        old=OLD/layout/'physical'
        events={}
        for line in (old/'p0_events.jsonl').open():
            e=json.loads(line)
            if e['kind']!='query':
                continue
            for i,lane in enumerate(e['lanes']):
                if lane%11<7:
                    continue
                search=e['searched'][i]
                if search:
                    assert due_tick(e['tick'],2)==e['due'][i]
                    search_receipts+=1
                events.setdefault(lane,[]).append((e['tick'],e['due'][i],search))
        lanes=[]; variants=[]; directions=[]
        for g in range(72):
            orig=base[g*11]
            geom=orig['geometry'];side=1 if geom==1 else -1
            for b,sec in enumerate(('near','far')):
                oldlane=g*11+7+b*2+(side==-1)
                ev=events.get(oldlane,[])
                first=next((e for e in ev if e[2]),None)
                initial_searches+=bool(ev and ev[0][2])
                catalog.append(dict(layout=layout,group=g,root=orig['bank_row'],force=orig['force_y_N'],geometry=geom,
                    section=sec,side=side,historical_lane=oldlane,first_tick=ev[0][0] if ev else None,
                    first_due=ev[0][1] if ev else None,first_search_tick=first[0] if first else None,
                    first_search_due=first[1] if first else None,
                    original_kind=('no_handback' if not ev else 'search_first' if ev[0][2] else 'monitor_then_search' if first else 'monitor_only')))
            for clock,direction in itertools.product(range(3),range(3)):
                id=len(lanes)
                v=dict(base[g*11+direction],arm=f'{ARMS[clock]}_{DIRECTIONS[direction]}',side=side,
                       section_x=12.7,bin='near',release_clock=ARMS[clock],clock_index=clock)
                variants.append(v);directions.append(direction);lanes.append([geom,'h75',id])
        assert len(lanes)==648 and len({(v['geometry'],v['bank_row'],v['force_y_N'],v['arm']) for v in variants})==648
        cfg['role']='Controlled original-direction publication experiment, DEV'
        cfg['evaluation_lanes']=lanes;cfg['ground_handoff']['handoff_variants']=variants
        cfg['paired_departures']['direction_ids']=directions;cfg['ccd_capacity']=len(lanes)*8
        cfg['p0_branches']={'group_size':9,'roots':cfg['p0_branches']['roots']}
        save(d/'run.json',cfg)
        maps.append(dict(layout=layout,config=str(d/'run.json'),sha256=sha(d/'run.json'),
                         original_sha256=sha(original),terrain_sha256=sha(old/'terrain.mjb'),original_events=sha(old/'p0_events.jsonl')))
    with (R/'original_clocks.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=catalog[0]);writer.writeheader();writer.writerows(catalog)
    save(R/'protocol.json',dict(role='Original paired DEV only; post hoc mechanism test; no training and no TEST',utc=datetime.now(timezone.utc).isoformat(),
        maps=maps,total_worlds=1296,worlds_per_map=648,primary_contracts=288,roots_per_map=12,
        design='Two original maps x 12 roots x 0/-5/+5 N x two entry geometries (1 left gate, 0 right gate) x three fixed original directions x three release clocks. Each direction scores both near and far gates; every world is a specified intervention. Finish once at 10 s max, 5 substeps per 5 ms. No new physics after the paired batch.',
        exposure='At the first actual post-relock tick t, score the original three directions for each gate using its observed current/past twist, old margin, old horizon, fallback straight. All three directions run independently in the same physical batch. Keep identical straight reference until publication. Old routes are generated natively at the observed handoff. Publish early t+3 ticks, intermediate t+7 ticks, late 4*ceil((t+12)/4). Intermediate tests sensitivity between the original clocks. Late is an experimentally controlled search-equivalent delay, also for original monitors; unrelocked cases remain failures.',
        endpoints='Verify flight then cross assigned near/far gate on the proper side, reach native goal and no wall. Report all 288 by method, directions, no-relock, incorrect gates, wall/goal and true terminals. Strict matched comparisons require native bit-identical pre-handback state for all 9 and equal handback time, route IDs and selector choice. Audit original t0 trajectories and archived handback separately before attribution to original losses. Original search-first subset prespecified. Report timing and occupancy plus actual steering/rear control divergence vs same-clock straight, route publication, pursuit and H75 actor events.',
        original_kind_counts=dict(Counter(r['original_kind'] for r in catalog)),warm_search_samples=len(samples),warm_ms_range=[min(samples),max(samples)],
        original_first_search_receipts_verified=initial_searches,all_event_search_receipts_verified=search_receipts,
        source_files={str(s):sha(s) for s in sources},timing_source=str(latency_path),timing_sha256=sha(latency_path)))
if __name__=='__main__':
    prepare()

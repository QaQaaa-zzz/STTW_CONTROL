"""Replay a true recorded handback through both actual CPU selector calls and release callbacks."""
from contextlib import contextmanager
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import numpy as np
import pandas as pd
import torch
from prepare import R,W,OLD,read,save,due_tick
sys.path[:0]=[str(W/'learning/src'),str(R.parent/'chapter3_continuous_p1_20261123/model')]
from frozen_exit_value import FrozenExits,mapped_arrays
from release_runtime import ReleaseBranches
from sttw_control.platform_online import velocity_state
from score import read_events,physical_trace,equivalent_prefix,first_changed_command

class BankField:
    def __init__(self, data):
        self.data=data
    def __getitem__(self, rows):
        return torch.from_numpy(np.array(self.data[rows.numpy()],dtype=np.float32))

def main():
    torch.set_num_threads(1)
    old=OLD/'right_offset/physical';cfg=read(OLD/'right_offset/run.json')
    cases=pd.read_csv(OLD/'analysis/strict_loss_decisions.csv')
    rr=cases[(cases.root==1178)&(cases.force_N==0)&(cases.side==-1)&(cases.gate=='near')].iloc[0]
    qtick=int(rr.query_tick);lane=int(rr.new_lane);events=read_events(old/'p0_events.jsonl')
    records=read(old/'status.json')['results'];path=str(old/records[lane]['case_dir']/'trajectory.npz')
    assert equivalent_prefix(path,old,lane,qtick,path,old,lane,qtick)==(True,True)
    tr,qp,qv=physical_trace(path)
    v=records[lane]['variant'];approach=int(v['geometry']);n=9
    tensor=lambda x:torch.from_numpy(np.asarray(x).copy()).float()
    cur_q=tensor(qp[qtick]).repeat(n,1);cur_v=tensor(qv[qtick]).repeat(n,1)
    prev=velocity_state(tensor(qp[qtick-4]).repeat(n,1),tensor(qv[qtick-4]).repeat(n,1))
    bank=mapped_arrays(cfg['paired_departures']['route_bank'])
    routes=events[lane]['old_selection']['old_candidates']
    with np.load(cfg['paired_departures']['approach_file']) as z:approach_count=len(z['xy'])
    join=routes[0]-approach_count-(approach*3)*len(bank['s'])
    route=SimpleNamespace(s=tensor(bank['s']),route_ids=torch.full((n,),routes[1],dtype=torch.long),
                          **{key:BankField(bank[key]) for key in ('xy','heading','curvature')})
    ind=torch.arange(n);direction=ind%3;pending=torch.as_tensor(routes)[direction]
    env=dict(q=cur_q,v=cur_v,route=route,join=torch.full((n,),join),approach_x=range(approach_count),
             approach_ids=torch.full((n,),approach),arc64=route.s,alive=torch.ones(n,dtype=torch.bool),
             pending_route=pending,release=torch.full((n,),qtick+3),applied_tick=torch.full((n,),-1),
             directions=torch.ones(n,dtype=torch.long),nominal_continuation_speed=torch.full((n,),float(v['continuation_speed_m_s'])))
    with TemporaryDirectory() as d:
        b=ReleaseBranches({'group_size':9},Path(d),FrozenExits(old,device='cpu',load_route_bank=False).query,
                          route,[dict(clock_index=i//3,side=-1) for i in range(9)],cur_q,cur_v)
        b.step(qtick,env,env['alive'],prev)
        for tick in range(qtick+1,qtick+17):
            apply=env['alive']&(env['release']==tick)&(b.arm<3)
            route.route_ids=torch.where(apply,env['pending_route'],route.route_ids)
            env['directions']=torch.where(apply,direction,env['directions'])
            env['applied_tick']=torch.where(apply,tick,env['applied_tick'])
            b.step(tick,env,torch.zeros(n,dtype=torch.bool),prev)
            middle=SimpleNamespace(lane_ticks=torch.full((n,),tick),follower={'command':torch.zeros(n,2)},pose=env['q'])
            b.actor_command(tick,env['alive'],torch.full((n,),2),middle,torch.zeros(n,4))
            middle.lane_ticks+=1;b.pursuit_read(tick+1,env['alive'],torch.full((n,),2),middle)
        b.finish();out=read_events(Path(d)/'p0_events.jsonl')
    for i in range(9):
        assert out[i]['publication']['tick']==due_tick(qtick,i//3)
        assert out[i]['publication']['actual_route']==routes[i%3]
        for sec in ('near','far'):
            orig=events[lane+2*int(sec=='far')]['old_selection']
            a=out[i]['selection_'+sec]
            assert (a['choice'],a['admitted'])==(orig['choice'],orig['admitted'])
        assert all(k in out[i] for k in ('pursuit_consumed','h75_actor_consumed'))
    c=first_changed_command(rr.old_path,rr.straight_path,qtick)
    assert c[0]==rr.old_first_different_held_steer_trace_tick-1
    save(R/'cpu_receipt.json',dict(fixture='right_offset/root1178/no push; real recorded handback q/v and 20ms-earlier velocity, frozen original chooser, CPU only',
        query_tick=qtick,native_past_qv_replay_equal=True,first_early_prior_control_change_tick=c[0],directions=routes,
        near_choice=out[0]['selection_near']['choice'],far_choice=out[0]['selection_far']['choice'],
        clock_due_ticks=[out[i]['publication']['tick'] for i in (0,3,6)],
        clock_delay_ms=[(out[i]['publication']['tick']-qtick)*5 for i in (0,3,6)],
        all_nine_receipts=True,both_actual_old_gate_choices_reproduced=True,
        scope='Callback and native scoring replay only. Batched physics, actual controller reads, endpoints and GPU concurrency are pending.'))
if __name__=='__main__':main()

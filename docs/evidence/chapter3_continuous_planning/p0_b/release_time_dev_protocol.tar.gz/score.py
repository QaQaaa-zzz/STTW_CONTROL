"""Outcomes for every fixed direction, gate, selected direction and paired clock."""
from collections import defaultdict
from functools import lru_cache
import json
from pathlib import Path
import sys
import mujoco
import numpy as np
import pandas as pd
from prepare import R,W,OLD,LAYOUTS,ARMS,DIRECTIONS,read,save,due_tick
sys.path[:0]=[str(W/'learning/src'),str(W/'learning/cli')]
from analyze_chapter3_continuous_p0_branches import prefix_flight_force
from run_playground_task_reversal import crossings_by_section


def read_events(path):
    by=defaultdict(dict)
    for ln in Path(path).open():
        e=json.loads(ln)
        for i,j in enumerate(e['lanes']):
            by[j][e['kind']]={k:(v[i] if isinstance(v,list) else v) for k,v in e.items() if k!='lanes'}
    return by

@lru_cache(maxsize=48)
def physical_trace(path):
    with np.load(path) as z:
        return z['trace'],z['qpos'],z['qvel']

@lru_cache(maxsize=12)
def archived_state(directory,tick):
    if tick<0:return {}
    path=Path(directory)/'p0_handbacks'/f'tick_{tick:04d}.npz'
    if not path.exists():return {}
    with np.load(path) as z:
        keys=[k for k in z.files if k not in ('lanes','packed_contact_indices') and not k.startswith('native_')]
        values={k:z[k] for k in keys}
        return {int(l):{k:val[i] for k,val in values.items()} for i,l in enumerate(z['lanes'])}

def exact(a,b):
    return a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes()

def equivalent_prefix(current_path,current_dir,current_lane,current_tick,old_path,old_dir,old_lane,old_tick):
    if current_tick<0 or current_tick!=old_tick:return False,False
    a=archived_state(str(current_dir),current_tick).get(current_lane)
    b=archived_state(str(old_dir),old_tick).get(old_lane)
    hand=bool(a and b and a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a))
    c=physical_trace(current_path);o=physical_trace(old_path)
    # Before query t (inclusive of the state and previous held controls at t).
    tr=all(len(x)>current_tick and len(y)>current_tick and exact(x[:current_tick+1],y[:current_tick+1]) for x,y in zip(c,o))
    return tr,hand

def first_changed_command(path,straight_path,query):
    if query<0:return (None,None)
    tr=physical_trace(path)[0];s=physical_trace(straight_path)[0]
    end=min(len(tr),len(s));out=[]
    for col in [12,13]:
        x,y=tr[query+1:end,col],s[query+1:end,col]
        diff=np.flatnonzero(np.isfinite(x)&np.isfinite(y)&(x!=y))
        out.append(int(query+diff[0]) if len(diff) else None)
    return tuple(out)

def summarize():
    O=R/'analysis';O.mkdir(exist_ok=True)
    hist=pd.read_csv(R/'original_clocks.csv').set_index(['layout','group','section'])
    lanes=[]; gates=[]; selected=[]; controls=[]
    for name in LAYOUTS:
        cfg=read(R/name/'run.json'); f=R/name/'physical'; old=OLD/name/'physical'
        terrain=read(cfg['world_map'])['terrain'];model=mujoco.MjModel.from_binary_path(str(f/'terrain.mjb'))
        rec=read(f/'status.json')['results'];old_rec=read(old/'status.json')['results']
        assert len(rec)==648
        with np.load(f/'p0_branch_audit.npz') as z: audit=z['pair_ok'];bad=z['first_bad_tick']
        with np.load(old/'p0_branch_audit.npz') as z: old_audit=z['pair_ok']
        ev=read_events(f/'p0_events.jsonl')
        oldev=read_events(old/'p0_events.jsonl')
        trace_path=lambda j:str(f/rec[j]['case_dir']/'trajectory.npz')
        for group in range(72):
            lo=9*group;root=rec[lo]['variant']['bank_row'];geom=rec[lo]['variant']['geometry']
            side=1 if geom else -1
            base=dict(layout=name,group=group,root=root,force=rec[lo]['variant']['force_y_N'],geometry=geom,side=side)
            native=bool(audit[group]) and len({r['handoff_s'] for r in rec[lo:lo+9]})==1
            bygate={};table={}
            for i,row in enumerate(rec[lo:lo+9]):
                slot=i//3; direction=i%3; j=lo+i;p=trace_path(j);v=row['variant'];h=row['handoff_s'];e=ev[j]
                request=e.get('request',{});pub=e.get('publication',{});qt=request.get('tick',-1)
                assert h is None and qt==-1 or h is not None and qt==round(h/.005)+1
                assert (v['force_y_N'],v['geometry'],v['bank_row'])==(base['force'],geom,root)
                due=request.get('due',-1);actual=pub.get('tick',-1)
                if qt>=0:
                    assert due==due_tick(qt,slot)==row['departure_due_tick'] and request['requested_route']==request['original_candidates'][direction]
                    assert request['default_route']==request['original_candidates'][1]
                    if actual>=0:
                        assert actual_route_matches(pub,actual,due,request,direction,row)
                if i==0 or not native:good=prefix_flight_force(row,p,model,terrain)['verified']
                tr=physical_trace(p)[0];txy=np.flatnonzero(np.isfinite(tr[:,1:3]).all(1))
                steer,rear=first_changed_command(p,trace_path(lo+slot*3+1),qt)
                before_publication=actual>=0 and any(k is not None and k<actual for k in (steer,rear))
                b=dict(**base,lane=j,clock=ARMS[slot],direction=direction,arm=DIRECTIONS[direction],native_prefix=native,
                    native_first_bad_tick=int(bad[group]),verified=bool(good),handoff_s=h,query_tick=qt,due_tick=due,publication_tick=actual,
                    query_to_release_ms=(actual-qt)*5 if actual>=0 else None,default_route=request.get('default_route'),
                    requested_route=request.get('requested_route'),actual_route=pub.get('actual_route'),
                    pursuit_read_tick=e.get('pursuit_consumed',{}).get('tick'),
                    h75_read_tick=e.get('h75_actor_consumed',{}).get('tick'),
                    first_changed_steer_interval_tick=steer,first_changed_rear_interval_tick=rear,command_difference_before_publication=before_publication,
                    first_changed_steer_ms=(steer-qt)*5 if steer is not None else None,first_changed_rear_ms=(rear-qt)*5 if rear is not None else None,
                    duration_s=row['duration_s'],termination=row['termination'],goal=bool(row['goal']),wall=bool(row['forbidden_contact_steps']),
                    terminal_x=float(tr[txy[-1],1]),terminal_y=float(tr[txy[-1],2]),path=p)
                lanes.append(b);table[j]=b
                for sec,_,t,y in crossings_by_section(tr,h if h is not None else np.inf,[12.7,13.6,15.]):
                    if sec=='mid':continue
                    hit=y is not None and .06<=side*y<=3.9
                    q=e.get('selection_'+sec,{})
                    g=dict(**b,section=sec,correct_gate=bool(hit),gate_time=t,gate_y=y,
                           success=bool(good and hit and row['goal'] and not b['wall']),choice=q.get('choice',1),admitted=q.get('admitted',False))
                    gates.append(g);bygate[j,sec]=g
            control_rows=[lo+1,lo+4,lo+7]
            ctrl=[physical_trace(trace_path(j)) for j in control_rows]
            control_equal=[all(exact(t[0][:,12:16],ctrl[0][0][:,12:16]) for t in ctrl),
                           all(all(exact(t[k],ctrl[0][k]) for k in (1,2)) for t in ctrl),
                           len({(table[j]['termination'],table[j]['duration_s'],table[j]['terminal_x'],table[j]['terminal_y']) for j in control_rows})==1]
            for sec in ('near','far'):
                source=hist.loc[name,group,sec];ol=int(source.historical_lane);oldpath=str(old/old_rec[ol]['case_dir']/'trajectory.npz')
                oh=old_rec[ol]['handoff_s'];oq=-1 if oh is None else round(oh/.005)+1
                trio=[];selections=[];source_selection=oldev[ol].get('old_selection',{})
                full=set()
                for i in range(9):
                    me=ev[lo+i];request=me.get('request',{})
                    s=me.get('selection_'+sec,{})
                    full.add((request.get('tick'),tuple(request.get('original_candidates',())),s.get('choice'),s.get('admitted')))
                native_match=native and len(full)==1
                for slot in range(3):
                    donor=lo+slot*3+1
                    d=bygate[donor,sec];j=lo+slot*3+d['choice']
                    item=bygate[j,sec];qt=item['query_tick']
                    prefix,hand=equivalent_prefix(item['path'],f,j,qt,oldpath,old,ol,oq)
                    as_original=bool(prefix and hand and old_audit[group] and
                        source_selection.get('choice')==d['choice'] and
                        ev[j].get('request',{}).get('original_candidates')==source_selection.get('old_candidates'))
                    chosen=dict(item,selector_lane=donor,selected_direction=d['choice'],selected_admitted=d['admitted'],
                        selection_matches_all=native_match,historical_kind=source.original_kind,historical_gate_lane=ol,
                        historical_prefix_trace_equal=prefix,historical_handback_equal=hand,
                        historical_group_strict=bool(old_audit[group]),historical_choice_routes_match=as_original)
                    trio.append(chosen);selected.append(chosen);selections.append(d['choice'])
                controls.append(dict(**base,section=sec,strict=native_match,all_observed=all(t['query_tick']>=0 for t in trio),
                    all_selected_straight=selections==[1,1,1],commands_identical=control_equal[0],qv_identical=control_equal[1],
                    terminals_identical=control_equal[2],all_three_match=all(control_equal)))
    ll=pd.DataFrame(lanes);gg=pd.DataFrame(gates);ss=pd.DataFrame(selected);cc=pd.DataFrame(controls)
    assert (len(ll),len(gg),len(ss),len(cc))==(1296,2592,864,288)
    for nm,frame in [('physical_lanes',ll),('fixed_direction_gates',gg),('selected_tasks',ss),('straight_negative_controls',cc)]:
        frame.to_csv(O/(nm+'.csv.gz'),index=False)
    keys=['layout','group','root','geometry','side','force','section'];pairs=[]
    old_changes=pd.read_csv(OLD/'analysis/strict_outcome_changes.csv')
    orig_loss={(r.layout,r.root,r.geometry,r.force,r.section,r.side) for r in old_changes[old_changes.change=='lost'].itertuples()}
    for arm,base in [('late','early'),('middle','early'),('late','middle')]:
        panel=ss[ss.clock==arm].merge(ss[ss.clock==base],on=keys,suffixes=('','_base'),validate='one_to_one')
        for a in panel.itertuples():
            delta=int(a.success)-int(a.success_base)
            strict=bool(a.selection_matches_all and a.query_tick>=0)
            failed=a.query_tick<0 and a.query_tick_base<0 and not a.success and not a.success_base
            ident=strict or failed
            pairs.append({**{k:getattr(a,k) for k in keys},'clock':arm,'baseline':base,'strict':strict,'common_unrelocked_zero':failed,
                'result':a.success,'base_result':a.success_base,'observed_delta':delta,'paired_lower':delta if ident else -1,'paired_upper':delta if ident else 1,
                'strict_rescue':strict and delta==1,'strict_loss':strict and delta==-1,'historical_kind':a.historical_kind,
                'original_prefix_choice_routes_equal':bool(strict and a.historical_choice_routes_match and a.historical_choice_routes_match_base),
                'in_original_47':(a.layout,a.root,a.geometry,a.force,a.section,a.side) in orig_loss})
    pp=pd.DataFrame(pairs); pp.to_csv(O/'paired_cases.csv.gz',index=False)
    ss.groupby(['layout','side','section','clock']).agg(tasks=('lane','size'),passed=('success','sum'),walls=('wall','sum'),
         wrong_or_missed_gate=('correct_gate',lambda x:(~x).sum()),goal=('goal','sum'),physical_relocks=('query_tick',lambda x:(x>=0).sum())).to_csv(O/'by_gate.csv')
    pp.groupby(['layout','side','clock','baseline']).agg(tasks=('strict','size'),strict=('strict','sum'),rescues=('strict_rescue','sum'),
         losses=('strict_loss','sum'),lower=('paired_lower','sum'),upper=('paired_upper','sum')).to_csv(O/'by_gate_paired.csv')
    st=cc[cc.strict & cc.all_observed & cc.all_selected_straight]
    save(O/'receipt.json',dict(worlds=len(ll),contracts=288,strict_relocked=int(pp[(pp.clock=='late')&(pp.baseline=='early')].strict.sum()),
         success=ss.groupby('clock').success.sum().astype(int).to_dict(),straight_controls_observed_strict=len(st),
         straight_controls_mismatching=int((~st.all_three_match).sum()),original_loss_tasks=47))

def actual_route_matches(pub,actual,due,request,direction,row):
    return (actual==due==row['departure_applied_tick'] and pub['actual_route']==request['requested_route'] and pub['direction']==direction)
if __name__=='__main__':
    summarize()

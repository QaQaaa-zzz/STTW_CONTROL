"""Paired actual and released-reference XY for every scheduled case."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from prepare import R,LAYOUTS,ARMS,DIRECTIONS,read
sys.path.insert(0,str(R.parent/'chapter3_continuous_p1_20261123/model'))
from frozen_exit_value import mapped_arrays

def draw():
    O=R/'analysis'; dest=O/'xy';dest.mkdir(exist_ok=True)
    fixed=pd.read_csv(O/'fixed_direction_gates.csv.gz');selected=pd.read_csv(O/'selected_tasks.csv.gz')
    colors=['#225986','#b3521e','#3d7155'];index=[]
    for m in LAYOUTS:
        cfg=read(R/m/'run.json');world=read(cfg['world_map']);bank=mapped_arrays(cfg['paired_departures']['route_bank'])
        with np.load(cfg['ground_handoff']['reference_path']) as z:neutral=z['xy'][0]
        for (root,sec,side),frame in fixed[fixed.layout==m].groupby(['root','section','side']):
            sel=selected[(selected.layout==m)&(selected.root==root)&(selected.section==sec)&(selected.side==side)]
            gx={'near':12.7,'far':15.}[sec]
            fig,axes=plt.subplots(3,4,figsize=(18,6.7),sharex=True,sharey=True)
            for row,(force,g) in enumerate(frame.groupby('force',sort=True)):
                for col in range(4):
                    ax=axes[row,col]
                    ax.plot([gx,gx],[side*.06,side*3.9],lw=2,color='#864c78')
                    ax.axvline(world['terrain']['front_x_m'],lw=.7,color='#4a4a4a',ls=':')
                    for x0,x1,y0,y1 in world['terrain']['forbidden_rectangles']:
                        ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,color='#735f4e',alpha=.5))
                    goal=world['goal'];ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],2*goal['abs_y_max_m'],fc='#e1eadb'))
                    sub=g[g.direction==col] if col<3 else sel[sel.force==force]
                    for r in sub.itertuples():
                        c=colors[ARMS.index(r.clock)]
                        with np.load(r.path) as z:
                            xy=z['qpos'][:,:2];start=z['reference_xy'];final=z['published_reference_xy']
                        end=np.flatnonzero(np.isfinite(xy).all(1))[-1]
                        xy=xy[:end+1]
                        seg=[(0,neutral),(3,start)]
                        if r.query_tick>=0:seg.append((r.query_tick,bank['xy'][int(r.default_route)]))
                        if r.publication_tick>=0:seg.append((r.publication_tick,final))
                        for j,(tick,ref) in enumerate(seg):
                            if tick>end:continue
                            ahead=xy[min(seg[j+1][0],end) if j+1<len(seg) else end,0]
                            part=ref[(ref[:,0]>=xy[tick,0])&(ref[:,0]<=ahead)]
                            ax.plot(*part.T,ls=':',color=c,lw=1.15)
                        ax.plot(*xy.T,color=c,lw=.9,alpha=.8)
                        ax.plot(*xy[-1],color=c,marker='o' if r.success else 'x',markersize=4,fillstyle='none')
                    if row==0:ax.set_title(DIRECTIONS[col]+' reference' if col<3 else 'Gate selector',fontsize=10)
                    if col==0:ax.set_ylabel(f'{force:+g} N\ny (m)')
                    if row==2:ax.set_xlabel('x (m)')
                    ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.15)
            fig.suptitle(f'{m} · DEV start {root} · {sec} '+('left' if side==1 else 'right')+' gate')
            fig.legend(handles=[Line2D([],[],c=c,label=lab) for c,lab in zip(colors,['15 ms','35 ms','search-equivalent'])]+
                [Line2D([],[],c='#333',ls=':',label='active reference'),Line2D([],[],c='#333',marker='o',fillstyle='none',ls='',label='task success'),
                 Line2D([],[],c='#333',marker='x',ls='',label='task failure')],loc='upper center',bbox_to_anchor=(.5,.945),ncol=6)
            fig.subplots_adjust(top=.84,hspace=.15,wspace=.12,bottom=.08)
            fn=f'{m}_{root}_{sec}_{side:+g}.png';fig.savefig(dest/fn,dpi=130);plt.close(fig)
            index.append(dict(layout=m,root=root,section=sec,side=side,file=fn))
    assert len(index)==96
    pd.DataFrame(index).to_csv(dest/'index.csv',index=False)
    (dest/'index.html').write_text('<meta charset="utf-8"><h1>DEV release clocks, actual and reference XY</h1>'+
        ''.join(f'<p><a href="{a["file"]}">{a["file"]}</a></p>' for a in index))
if __name__=='__main__':draw()

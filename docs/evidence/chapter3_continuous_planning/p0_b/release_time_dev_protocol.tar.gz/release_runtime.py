"""Controlled, clock-only intervention at the native physical handback."""
import numpy as np
import torch
from sttw_control.chapter3_p0_physical import P0Branches
from sttw_control.platform_online import velocity_state
from prepare import due_tick


class ReleaseBranches(P0Branches):
    def __init__(self, cfg, out, query, route, contracts, q, v):
        self.out, self.query = out, query
        self.g = cfg['group_size']
        self.n = len(q)
        # All nine rows are fixed-direction controls in the native evaluator.
        self.arm = torch.zeros(self.n, device=q.device, dtype=torch.long)
        self.clocks = self.arm.new_tensor([c['clock_index'] for c in contracts])
        self.side = q.new_tensor([c['side'] for c in contracts])
        self.pair_ok = torch.ones(self.n//self.g,device=q.device,dtype=torch.bool)
        self.audit_done = torch.zeros_like(self.pair_ok)
        self.first_bad = torch.full_like(self.pair_ok,-1,dtype=torch.int64)
        self.anchor_dir = out/'p0_handbacks'
        self.anchor_dir.mkdir()
        self.log = (out/'p0_events.jsonl').open('w',buffering=1)
        self.xy = q[:,:2].clone()
        self.distance = torch.zeros_like(q[:,0])
        self.start_distance = self.distance.clone()
        self.route_observed_distance = self.distance.clone()
        self.version = self.arm.clone()
        self.changed_tick = torch.full_like(self.arm,-1)
        self.route_observed_tick = self.changed_tick.clone()
        self.request = self.changed_tick.clone()
        self.await_actor = self.arm.bool()
        self.await_pursuit = self.arm.bool()

    def step(self, tick, env, just_locked, previous):
        q,v,route = env['q'],env['v'],env['route']
        self.distance += (q[:,:2]-self.xy).norm(dim=1)
        self.xy = q[:,:2].clone()
        ids = torch.where(just_locked)[0]
        if len(ids):
            self.request[ids] = tick
            self.start_distance[ids] = self.distance[ids]
            due = self.arm.new_tensor([due_tick(tick,k) for k in range(3)])[self.clocks[ids]]
            env['release'][ids] = due
            anchor = env['join'][ids,None].clamp_max(len(route.s)-1)
            candidates = len(env['approach_x'])+(env['approach_ids'][ids,None]*3+
                            torch.arange(3,device=q.device))*len(env['arc64'])+anchor
            current = velocity_state(q[ids],v[ids])
            fallback = torch.ones_like(ids)
            self.event(kind='request',tick=tick,lanes=ids.tolist(),due=due.tolist(),
                       original_candidates=candidates.tolist(),default_route=route.route_ids[ids].tolist(),
                       requested_route=env['pending_route'][ids].tolist(),qpos=q[ids].tolist(),
                       qvel=v[ids].tolist(),current_twist=current.tolist(),previous_twist=previous[ids].tolist())
            for name,x in [('near',12.7),('far',15.)]:
                choice,admitted,inc = self.query.choose(q[ids],current[:,0],env['nominal_continuation_speed'][ids],
                    route,candidates,q.new_full((len(ids),),x),self.side[ids],fallback,min(5.1,10.-tick*.005),
                    current,previous[ids])
                chosen=torch.where(admitted,choice,fallback)
                self.event(kind='selection_'+name,tick=tick,lanes=ids.tolist(),choice=chosen.tolist(),
                           admitted=admitted.tolist(),incumbent_admitted=inc.tolist(),
                           route=candidates.gather(1,chosen[:,None]).flatten().tolist())
        rows = torch.where(env['alive'] & (env['applied_tick']==tick))[0]
        if len(rows):
            self.record_change(tick,rows,self.request[rows],self.start_distance[rows])
            self.event(kind='publication',tick=tick,lanes=rows.tolist(),observation_tick=self.request[rows].tolist(),
                       actual_route=route.route_ids[rows].tolist(),direction=env['directions'][rows].tolist(),
                       travel_m=(self.distance[rows]-self.start_distance[rows]).tolist())

    def finish(self):
        self.log.close()
        np.savez_compressed(self.out/'p0_branch_audit.npz',pair_ok=self.pair_ok.cpu().numpy(),
                            first_bad_tick=self.first_bad.cpu().numpy())

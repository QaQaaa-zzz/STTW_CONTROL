"""Run both DEV maps using the native evaluator in one synchronized GPU allocation."""
import json
import multiprocessing as mp
from multiprocessing.connection import wait
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
from contextlib import redirect_stdout,redirect_stderr
from datetime import datetime,timezone
from prepare import R,W,read,save,sha

TICKS=(0,1,8,32,256,1024)

def state(stage,**fields):
    save(R/'status.json',dict(stage=stage,utc=datetime.now(timezone.utc).isoformat(),**fields))

def bark(stage,message):
    subprocess.run(['/usr/bin/python3',str(W/'learning/scripts/notify_chapter3_job.py'),'--title','第三章原出口延时 '+stage,
                    '--message',message,'--receipt',str(R/(stage+'_bark.json'))])

def worker(spec,barrier):
    loc=R/spec['layout'];out=loc/'physical'
    with (loc/'physics.log').open('a',buffering=1) as f, redirect_stdout(f), redirect_stderr(f):
        try:
            import torch
            import sttw_control.chapter3_p0_physical as native
            import sttw_control.playground_handoff_evaluation as handoff
            import evaluate_playground_handoff as evaluator
            from release_runtime import ReleaseBranches
            original=handoff.evaluate_handoff
            def evaluate(model,*args):
                assert model.opt.timestep==.001 and sha(out/'terrain.mjb')==spec['terrain_sha256']
                return original(model,*args)
            class Paired(ReleaseBranches):
                def audit(self,tick,env,just_locked):
                    if tick in TICKS:
                        env['data'].qpos.block_until_ready();torch.cuda.synchronize()
                        row=dict(tick=tick,worlds=len(env['q']),alive=int(env['alive'].sum()),arrived_ns=time.monotonic_ns(),pid=os.getpid())
                        barrier.wait();row['released_ns']=time.monotonic_ns()
                        with (loc/'gpu_milestones.jsonl').open('a') as stream:
                            stream.write(json.dumps(row)+'\n')
                    super().audit(tick,env,just_locked)
            native.P0Branches=Paired;handoff.evaluate_handoff=evaluate
            sys.argv=[evaluator.__file__,'--config',str(loc/'run.json'),'--output',str(out),'--skills','rb_run1',
                      '--modes','h75','--routes','0','1','--physics-substeps','5','--seconds','10']
            evaluator.main()
        except BaseException:
            traceback.print_exc();barrier.abort();raise

def main():
    p=read(R/'protocol.json')
    for fn,h in p['source_files'].items():
        assert sha(fn)==h,fn
    for m in p['maps']:
        assert sha(m['config'])==m['sha256'] and not (R/m['layout']/'physical').exists()
    while True:
        gpu=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'],text=True)
        heavy=[x for x in gpu.splitlines() if x.strip() and '/awesun_desktop,' not in x]
        if not heavy:break
        state('waiting_for_external_gpu',processes=heavy);time.sleep(30)
    bark('启动','两图各648车，原左、直、右出口，同状态15ms、35ms与搜索等效时钟。')
    ctx=mp.get_context('spawn');barrier=ctx.Barrier(2)
    ps=[ctx.Process(target=worker,args=(spec,barrier)) for spec in p['maps']]
    start=time.monotonic()
    for proc in ps:proc.start()
    state('running_physics',workers=[pr.pid for pr in ps],worlds=1296)
    active={pr.sentinel:pr for pr in ps}
    while active:
        for fd in wait(list(active)):
            pr=active.pop(fd);pr.join()
            if pr.exitcode:barrier.abort()
    assert all(pr.exitcode==0 for pr in ps),[pr.exitcode for pr in ps]
    stamps=[]
    for m in p['maps']:
        loc=R/m['layout'];result=read(loc/'physical/status.json')
        assert result['stage']=='complete' and len(result['results'])==648
        marks=[json.loads(line) for line in (loc/'gpu_milestones.jsonl').read_text().splitlines()]
        assert [k['tick'] for k in marks]==list(TICKS) and marks[1]['worlds']==marks[1]['alive']==648
        stamps.append(marks)
    overlap=[(min(t[i]['arrived_ns'] for t in stamps)-max(t[i-1]['released_ns'] for t in stamps))/1.e9 for i in range(1,len(TICKS))]
    assert min(overlap)>0
    state('complete',total_physical=1296,concurrent_tick1=1296,elapsed_s=time.monotonic()-start,overlap_s=overlap)
    bark('物理完成','1,296条真实车道完成，进入CPU配对归约。')
if __name__=='__main__':
    try:main()
    except BaseException as e:
        state('failed',error=str(e));bark('异常',str(e));raise

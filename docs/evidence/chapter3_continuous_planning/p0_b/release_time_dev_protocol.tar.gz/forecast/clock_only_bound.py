"""Enumerate all eligible timing-only changes on the original strictly matched tasks."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

folder=Path(__file__).resolve().parent
prior=folder.parents[1]/'chapter3_smooth_exit_dev_20261124'
tasks=pd.read_csv(folder/'predictions.csv')
tasks=tasks[tasks.strict].copy()
events={}
for layout in tasks.layout.unique():
    for line in (prior/layout/'physical/p0_events.jsonl').open():
        event=json.loads(line)
        if event['kind']=='old_selection':
            for i,lane in enumerate(event['lanes']):
                chosen=int(event['choice'][i])
                events[layout,lane]=(chosen,event['old_candidates'][i][chosen],event['default_route_id'][i])
classes=[]
active_routes=[]
for task in tasks.itertuples():
    observation=events.get((task.layout,task.lane))
    if not task.available:
        assert observation is None and not task.physical_early_success
        cls='no_handback'
    else:
        chosen,target,active=observation
        assert task.choice==chosen and target==task.chosen_route_id
        assert (active==target)==(chosen==1)
        cls='same_active_reference' if active==target else 'directional_switch'
    classes.append(cls)
    active_routes.append(None if observation is None else observation[2])
tasks['class']=classes
tasks['active_route_id']=active_routes
tasks['low']=np.where(tasks['class'].eq('directional_switch'),0,tasks.physical_early_success.astype(int))
tasks['high']=np.where(tasks['class'].eq('directional_switch'),1,tasks.physical_early_success.astype(int))
tasks[['layout','root','geometry','force','section','side','class','active_route_id','chosen_route_id','physical_early_success','low','high']].to_csv(folder/'clock_only_case_bounds.csv',index=False)
group=tasks.groupby('class').agg(cases=('root','size'),old_completed=('physical_early_success','sum'),late_min=('low','sum'),late_max=('high','sum'))
d=group.to_dict('index')
d['all_strict']=group.sum().to_dict()
d['net_bound_vs_original_early']=[int(tasks.low.sum()-tasks.physical_early_success.sum()),int(tasks.high.sum()-tasks.physical_early_success.sum())]
d['assumptions']='Original matched initial states, identical selected reference and identical ground controller, deterministic dynamics and exogenous disturbances, intervention only changes time the same selected route is assigned. A request that reassigns the presently active route makes no change to control. Failure before any request is invariant. Bound ignores interaction guarantees for nontrivial assignments; new GPU batch must verify correspondence and no-op controls.'
(folder/'clock_only_bound.json').write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
print(group.to_string());print(d['net_bound_vs_original_early'])

"""Freeze model-only predictions for later comparison to the paired physical timing runs."""
from pathlib import Path
import hashlib,json
import pandas as pd
import numpy as np

folder = Path(__file__).resolve().parent
prior = folder.parents[1]/'chapter3_smooth_exit_dev_20261124/analysis'
p = pd.read_csv(folder/'predictions.csv')
s = p[p.available & p.strict].copy()
for name in ['early','middle','late']:
    s[name+'_admission']=s[name+'_admission'].astype(bool)
s['late_gains']=~s.early_admission & s.late_admission
s['late_losses']=s.early_admission & ~s.late_admission
s.groupby(['layout','root','side']).agg(measured=('root','size'),old_completed=('physical_early_success','sum'),early=('early_admission','sum'),middle=('middle_admission','sum'),late=('late_admission','sum'),gains=('late_gains','sum'),losses=('late_losses','sum')).to_csv(folder/'strict_per_root_side.csv')
losses=pd.read_csv(prior/'strict_outcome_changes.csv')
keys=['layout','root','section','side','force','geometry']
a=s.merge(losses[losses.change.eq('lost')][keys],on=keys,validate='one_to_one')
assert len(a)==47
phys = pd.read_csv(prior/'selected_tasks.csv.gz')
case = phys[phys.primary & phys.root.eq(1191) & phys.side.eq(-1) & phys.section.eq('near') & phys.force.eq(5)].set_index('method')
with np.load(case.loc['old','path']) as old,np.load(case.loc['single','path']) as single:
    control_match=np.array_equal(old['trace'][:,12:16],single['trace'][:,12:16])
    state_match=np.array_equal(old['qpos'],single['qpos']) and np.array_equal(old['qvel'],single['qvel'])
    frames=len(old['qpos'])
assert state_match and control_match
counts=dict(total_protocol=len(p),observed=int(p.available.sum()),unobserved=int((~p.available).sum()),strict_observed=len(s),
    strict_admissions={n:int(s[n+'_admission'].sum()) for n in ('early','middle','late')},
    admitted_early_lost_when_later=int(s.late_losses.sum()),rejected_early_admitted_late=int(s.late_gains.sum()),
    physical_early_completed=int(s.physical_early_success.sum()),early_accepted_but_failed=int((s.early_admission & ~s.physical_early_success).sum()),early_rejected_but_completed=int((~s.early_admission & s.physical_early_success).sum()),
    historic_47_new_event_physical_losses=dict(early=int(a.early_admission.sum()),middle=int(a.middle_admission.sum()),late=int(a.late_admission.sum())),
    case_1191_straight=dict(physical_duration_s=float(case.loc['old','duration_s']),frames=frames,old_vs_original_single_state_and_actuator_match=True,physical_completed=bool(case.loc['old','success'])),
    meaning='Admission is a model decision at a particular measured instant. Three physical timing arms are to be compared prospectively. Original early cases were selected by a related gate model and are not independent validation.')
for name in ['predictions.csv','protocol.json','forecast.py','staggered_forecast_xy.npz','right_offset_forecast_xy.npz']:
    counts.setdefault('frozen_sha256',{})[name]=hashlib.sha256((folder/name).read_bytes()).hexdigest()
(folder/'receipt.json').write_text(json.dumps(counts,indent=2)+'\n')
print(json.dumps({k:v for k,v in counts.items() if k not in ('frozen_sha256','meaning')}))

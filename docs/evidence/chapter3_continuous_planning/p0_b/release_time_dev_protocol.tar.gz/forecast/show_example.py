"""Compare the measured original early route with two forecasts on the same local map."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
import pandas as pd
import numpy as np

out=Path(__file__).resolve().parent
source=out.parents[1]/'chapter3_smooth_exit_dev_20261124'
data=pd.read_csv(out/'predictions.csv')
row=data[data.layout.eq('staggered') & data.root.eq(1191) & data.force.eq(5) & data.section.eq('near') & data.side.eq(-1)].iloc[0]
physical=pd.read_csv(source/'analysis/physical_lanes.csv.gz')
physical=physical[physical.layout.eq(row.layout)].set_index('lane')
with np.load(physical.loc[row.group+int(row.choice),'path']) as z:
    actual=z['qpos'][:,:2]; ref=z['published_reference_xy']
with np.load(out/(row.layout+'_forecast_xy.npz')) as z:
    early=z['xy'][int(row.early_request)];late=z['xy'][int(row.late_request)]
cfg=json.loads((source/row.layout/'run.json').read_text())
world=json.loads(Path(cfg['world_map']).read_text())
plt.rcParams.update({'font.family':'Noto Sans CJK JP','axes.unicode_minus':False})
fig,axes=plt.subplots(2,1,figsize=(8.4,4.8),layout='constrained',height_ratios=(1,1.4))
a,b=axes
for ax in axes:
    for lx,rx,ly,ry in world['terrain']['forbidden_rectangles']:
        ax.add_patch(Rectangle((lx,ly),rx-lx,ry-ly,color='#9d8c7f',zorder=1))
    ax.plot([12.7,12.7],[-1.6,-.06],c='#ac7aa6',lw=3)
    ax.plot(*ref.T,c='#777',lw=1.25,ls=':',label='两次预测使用的同一条直行参考',zorder=2)
    ax.plot(*actual.T,c='#26313d',lw=2.2,label='原直行车实走',zorder=3)
    ax.plot(*early.T,c='#2d739f',ls='--',lw=1.8,label='早发预测',zorder=4)
    ax.plot(*late.T,c='#c65a26',ls='-.',lw=1.8,label='晚发预测',zorder=5)
    ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.15);ax.set_ylabel('横向 y（米）')
a.set(xlim=(10.7,17.9),ylim=(-.85,.50));a.plot(*actual[-1],marker='o',color='#26313d',ms=5)
b.set(xlim=(13.60,15.25),ylim=(-.48,.12),xlabel='前进位置 x（米）')
a.set_title('错位双墙 · 起点 1191 · 近右门 · +5 N',fontsize=12)
b.set_title(f'同一预测器的车身净空：早发 {row.early_clearance_m*100:.1f} 厘米，晚发 {row.late_clearance_m*100:.1f} 厘米，门槛 5.33 厘米',fontsize=10)
fig.legend(*a.get_legend_handles_labels(),loc='outside lower center',ncol=2,frameon=False,fontsize=9)
fig.savefig(out/'same_route_timing_forecast.png',dpi=155)

"""Score identical route candidates when released from three measured straight-run states."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import json
import sys

import numpy as np
import pandas as pd
import torch

out = Path(__file__).resolve().parent
base = out.parents[1]
prior = base/'chapter3_smooth_exit_dev_20261124'
work = Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
sys.path[:0] = [str(base/'chapter3_continuous_p1_20261123/model'), str(work/'learning/src'), str(work/'learning/cli'), '/home/qy/DVGC/JIT/src']
from frozen_exit_value import FrozenExits, mapped_arrays
from sttw_control import chapter3_continuous_exit as native
from sttw_control.chapter3_continuous_exit import ContinuousExitPlanner
from sttw_control.platform_online import velocity_state

def tensor(data):
    return torch.tensor(np.asarray(data),dtype=torch.float32)

@torch.inference_mode()
def process(layout, tasks, physical):
    directory = prior/layout/'physical'
    config = json.loads((directory/'resolved_config.json').read_text())
    bank = mapped_arrays(config['paired_departures']['route_bank'])
    model = FrozenExits(directory,device='cpu',load_route_bank=False)
    solver = ContinuousExitPlanner(model.query,SimpleNamespace(s=tensor(bank['s'])),mode='smooth_event',candidates=64,iterations=2,horizon_steps=255,robots_per_chunk=1,fused=False)
    selections, queries = {}, {}
    for line in (directory/'p0_events.jsonl').open():
        e = json.loads(line)
        if e['kind'] not in ('old_selection','query'):
            continue
        for j,lane in enumerate(e['lanes']):
            if e['kind']=='old_selection':
                selections[lane] = (e['tick'],int(e['old_candidates'][j][e['choice'][j]]),int(e['choice'][j]))
            else:
                queries.setdefault(lane,(e['tick'],e['due'][j],e['searched'][j]))
    results = []
    requests = []
    ref_indices = []
    for row in tasks.itertuples():
        lane = row.lane
        meta = dict(layout=layout,root=row.root,force=row.force,side=row.side,section=row.section,geometry=row.geometry,lane=lane,group=row.group,verified=row.verified,strict=bool(row.pair_ok),physical_early_success=row.early_success)
        t, chosen, arm = selections.get(lane,(None,None,None))
        why = None
        if t is None:
            why = 'no observed handback'
        else:
            t_query,due,searched=queries[lane]
            assert t_query==t
            late=4*((t+12+3)//4)
            if searched: assert late==due
            meta.update(observation_tick=t,choice=arm,chosen_route_id=chosen,actual_first_query_searched=searched,original_first_due_tick=due)
            straight=physical.loc[row.group+1,'path']
            with np.load(straight) as z:
                q,v=z['qpos'],z['qvel']
            with np.load(directory/f'p0_handbacks/tick_{t:04d}.npz') as z:
                j=int(np.flatnonzero(z['lanes']==lane)[0])
                has_same_state=(t<len(q) and np.array_equal(q[t],z['physics_qpos'][j]) and np.array_equal(v[t],z['physics_qvel'][j]) and np.array_equal(q[t-4],z[f'query_pose_history_{t%4}'][j]) and np.array_equal(v[t-4],z[f'query_velocity_history_{t%4}'][j]))
            if not has_same_state:
                why='different observed handback on straight lane'
            elif len(q)<=late:
                why='straight trajectory ended before last release'
        row_index=len(results)
        meta['available']=why is None;meta['missing_reason']=why
        results.append(meta)
        if why is not None:
            continue
        gx=12.7 if row.section=='near' else 15.
        assert q[:late+1,0].max()<min(gx,model.query.goal['x_min_m'])
        for label,st in [('early',t+3),('middle',t+7),('late',late)]:
            i=len(requests)
            requests.append((q[st],v[st],q[st-4],v[st-4],gx,row.side,10.-st*.005))
            ref_indices.append(chosen)
            meta[label+'_request']=i
            meta[label+'_ms']=(st-t)*5
    q,v,pv0,pv1,section,side,remaining=map(tensor,zip(*requests))
    velocity=velocity_state(q,v);previous=velocity_state(pv0,pv1)
    admissions=[];clearances=[]
    predicted_xy = []
    score_original = native._score
    def save_xy(query, poses, *args):
        predicted_xy.append(poses[:,:,:2].detach().cpu().numpy().copy())
        return score_original(query, poses, *args)
    for i in range(0,len(q),64):
        sl=slice(i,i+64);ids=ref_indices[sl]
        xyz,h,k=[tensor(bank[key][ids]) for key in ('xy','heading','curvature')]
        with patch.object(native,'_score',save_xy):
            _,ok,clear,_=solver._smooth_score(q[sl],velocity[sl],previous[sl],xyz,h,k,section[sl],side[sl],remaining[sl],torch.zeros(len(ids),dtype=torch.long),torch.zeros(len(ids)))
        admissions.extend(ok.tolist());clearances.extend(clear.tolist())
    for m in results:
        if m['available']:
            for c in ('early','middle','late'):
                i=m[c+'_request']
                m[c+'_admission']=admissions[i]
                m[c+'_clearance_m']=clearances[i]
    np.savez_compressed(out/(layout+'_forecast_xy.npz'),xy=np.concatenate(predicted_xy),dt=.020)
    return results

torch.set_num_threads(1)
obs=pd.read_csv(prior/'analysis/selected_tasks.csv.gz')
obs = obs[obs.primary]
keys=['layout','root','force','geometry','section','side']
tasks=obs[obs.method.eq('event')].merge(obs[obs.method.eq('old')][keys+['success']].rename(columns={'success':'early_success'}),on=keys,validate='one_to_one')
phys=pd.read_csv(prior/'analysis/physical_lanes.csv.gz')
records=[]
for layout,part in tasks.groupby('layout'):
    records.extend(process(layout,part,phys[phys.layout.eq(layout)].set_index('lane')))
data=pd.DataFrame(records)
assert len(data)==288 and not data.duplicated(keys).any()
data.to_csv(out/'predictions.csv',index=False)
for label,panel in [('available',data[data.available]),('strict',data[data.available & data.strict])]:
    panel=panel.copy()
    for c in ('early','middle','late'):
        panel[c+'_admission']=panel[c+'_admission'].astype(bool)
    panel['gained_prediction']=~panel.early_admission & panel.late_admission
    panel['lost_prediction']=panel.early_admission & ~panel.late_admission
    stat=panel.groupby(['layout','side']).agg(expected_early=('early_admission','sum'),expected_middle=('middle_admission','sum'),expected_late=('late_admission','sum'),subjects=('root','size'),gained=('gained_prediction','sum'),lost=('lost_prediction','sum'),observed_early=('physical_early_success','sum'))
    stat.to_csv(out/(label+'_by_map_side.csv'))
    print(label,stat.sum().to_dict())
print('missing',data.missing_reason.value_counts().to_dict())

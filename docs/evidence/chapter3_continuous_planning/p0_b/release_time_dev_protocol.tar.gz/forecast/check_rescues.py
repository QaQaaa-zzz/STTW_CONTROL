"""Join observed paired rescues to the timing-only invariance class."""
from pathlib import Path
import pandas as pd
folder=Path(__file__).resolve().parent
prior=folder.parents[1]/'chapter3_smooth_exit_dev_20261124/analysis'
change=pd.read_csv(prior/'strict_outcome_changes.csv')
bounds=pd.read_csv(folder/'clock_only_case_bounds.csv')
keys=['layout','root','section','side','geometry','force']
rescues=change[change.change.eq('rescued')].merge(bounds,on=keys,validate='one_to_one')
assert len(rescues)==7
invariant=rescues[rescues['class'].eq('same_active_reference')]
assert len(invariant)==6 and (invariant.active_route_id==invariant.chosen_route_id).all()
assert (~invariant.old_correct_gate & invariant.correct_gate & invariant.published.gt(0) & invariant.section.eq('far') & invariant.side.eq(1)).all()
rescues[keys+['class','active_route_id','chosen_route_id','published','old_correct_gate','correct_gate','old_gate_y','gate_y','old_termination','termination','path','old_path']].to_csv(folder/'rescued_cases_by_original_action.csv',index=False)
print(invariant[['layout','root','force','old_gate_y','gate_y','published']].to_string(index=False))

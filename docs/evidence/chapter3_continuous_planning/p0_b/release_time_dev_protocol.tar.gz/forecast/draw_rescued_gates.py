"""Show the six measured rescues with a repeated, unchanged selection in the original method."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd
folder=Path(__file__).resolve().parent
prior=folder.parents[1]/'chapter3_smooth_exit_dev_20261124'
data=pd.read_csv(folder/'rescued_cases_by_original_action.csv')
data=data[data['class'].eq('same_active_reference')]
plt.rcParams.update({'font.family':'Noto Sans CJK JP','axes.unicode_minus':False,'font.size':9})
fig,axes=plt.subplots(2,3,figsize=(10,4.6),layout='constrained',sharex=True,sharey=True)
colors=['#1d5582','#c85626']
for ax,(_,r) in zip(axes.flat,data.iterrows()):
    cfg=json.loads((prior/r.layout/'run.json').read_text())
    world=json.loads(Path(cfg['world_map']).read_text())
    for lx,rx,ly,ry in world['terrain']['forbidden_rectangles']:
        ax.add_patch(Rectangle((lx,ly),rx-lx,ry-ly,color='#a99b91',zorder=1))
    ax.axvline(15,ls=':',c='.65',lw=1);ax.plot([15,15],[.06,.27],c='#9876a0',lw=4,zorder=1)
    for name,y,c in [(r.old_path,r.old_gate_y,colors[0]),(r.path,r.gate_y,colors[1])]:
        with np.load(name) as z:xy=z['qpos'][:,:2]
        ax.plot(*xy.T,c=c,lw=1.8);ax.scatter(15,y,s=17,c=c,edgecolors='white',linewidth=.45,zorder=4)
    layout={'staggered':'错位双墙','right_offset':'右偏墙'}[r.layout]
    ax.set_title(f'{layout} · 起点 {r.root} · {r.force:+d} N\n过门位置 {100*r.old_gate_y:+.1f} → {100*r.gate_y:+.1f} 厘米',fontsize=9)
    ax.set(xlim=(14.49,15.51),ylim=(-.17,.27));ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.14)
for ax in axes[:,0]:ax.set_ylabel('横向 y（米）')
for ax in axes[-1]:ax.set_xlabel('前进位置 x（米）')
fig.suptitle('六个走错远左门的任务，换线后全部通过',fontsize=14)
fig.legend(handles=[Line2D([],[],c=colors[0],label='原三出口实走'),Line2D([],[],c=colors[1],label='连续规划实走'),Line2D([],[],color='#9876a0',lw=4,label='左门允许区，从 +6 厘米开始')],loc='outside lower center',ncol=3,frameon=False)
fig.savefig(folder/'six_far_left_rescues.png',dpi=160)

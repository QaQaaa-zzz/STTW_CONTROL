"""GPU-resident batched STTW/RB/STTW inference on the native Playground chassis."""
import json
import pickle
import shutil
import sys
from pathlib import Path
import time
import math
import hashlib
from copy import deepcopy
from dataclasses import replace
import numpy as np
import jax
import jax.numpy as jp
import torch
import mujoco
from mujoco import mjx
from mujoco.mjx.warp.types import DATA_NON_VMAP
from mujoco_playground._src import mjx_env
from jit_dvgc.action_mapping import map_action
from jit_dvgc.semantics import PhaseUSignals, advance_events, initial_event_state
from jit_dvgc.geometry import build_geometry_contract, extract_geometry
from jit_dvgc.observation import initial_history, advance_history, observable_frame, actor_observation, ObservableGeometry
from .torch_controller import TorchController
from .torch_path_policy import TorchPathPolicy
from .torch_path_reference import TorchPathReference, wrap
from .torch_middle_control import TorchMiddleControl
from .playground_adapters import GroundAdapter, JumpAdapter
from .playground_rolling import RollingMotionLibrary, controller_features
from .playground_live_ground import LiveGroundCEM
from .playground_world_map import body_outside
from .playground_contact import normal_loads
from .playground_snapshot import capture as capture_snapshot, restore as restore_snapshot


def evaluate_handoff(model, mm, idx, cfg, bundle, hcfg, identity, controller_config, skills, args, brake_ids):
    source=args.output/'source';source.mkdir()
    for name in ['playground_handoff_evaluation.py','torch_controller.py','torch_path_reference.py','torch_middle_control.py','playground_adapters.py','playground_snapshot.py','playground_world_map.py','playground_contact.py']:
        shutil.copy2(Path(__file__).with_name(name),source/name)
    shutil.copy2(sys.argv[0],source/Path(sys.argv[0]).name)
    started=time.perf_counter();device='cuda:0';hand=cfg['ground_handoff'];terrain=cfg['ditch_terrain']
    to_torch=torch.utils.dlpack.from_dlpack
    to_jax=lambda x:jax.dlpack.from_dlpack(x.detach().contiguous())
    tensor=lambda x:torch.as_tensor(x,device=device)
    variants=hand.get('handoff_variants',[{}])
    lanes=[tuple(lane) for lane in cfg['evaluation_lanes']] if 'evaluation_lanes' in cfg else [(r,m,i) for i in range(len(variants)) for r in args.routes for m in args.modes];n=len(lanes)
    approach_speed=tensor([variants[i].get('approach_speed_m_s',variants[i].get('requested_speed_m_s',hand['approach']['speed_m_s'])) for r,m,i in lanes]).float()
    nominal_continuation_speed=tensor([variants[i].get('continuation_speed_m_s',variants[i].get('requested_speed_m_s',hand.get('continuation',{}).get('speed_m_s',1.5))) for r,m,i in lanes]).float()
    event=hand.get('handoff_mechanism')=='landing_state'
    landing_height=tensor([variants[i].get('landing_height_m',.35) for r,m,i in lanes]).float()
    swing_scale=jp.asarray([variants[i].get('swing_scale',1.) for r,m,i in lanes],dtype=jp.float32)
    jump_start=tensor([variants[i].get('jump_start_x_m',hand['approach']['jump_start_x_m']) for r,m,i in lanes]).float()
    recovery_wc=tensor([variants[i].get('recovery_wc',controller_config['wc']) for r,m,i in lanes]).float()
    body_feedback=tensor([variants[i].get('body_speed_feedback',False) for r,m,i in lanes])
    recovery_eso=tensor([variants[i].get('recovery_eso_scale',1.) for r,m,i in lanes]).float()
    recovery_eso_delay=tensor([variants[i].get('recovery_eso_delay_s',0.) for r,m,i in lanes]).float()
    recovery_look=tensor([variants[i].get('lookahead_scale',1.) for r,m,i in lanes]).float()
    landing_damping=tensor([variants[i].get('steering_damping',.1) for r,m,i in lanes]).float()
    landing_pitch_k=tensor([variants[i].get('landing_pitch_k',0.) for r,m,i in lanes]).float()
    landing_pitch_d=tensor([variants[i].get('landing_pitch_d',0.) for r,m,i in lanes]).float()
    height_offset=jp.asarray([variants[i].get('rb_far_height_offset_m',0.) for r,m,i in lanes],dtype=jp.float32)
    staged_native=hand.get('staged_native_handoff',False)
    nominal_homing_speed=hand.get('homing_min_forward_m_s',1.5)
    gate_roll=tensor([variants[i].get('gate_roll_rad',.08) for r,m,i in lanes]).float()
    gate_rate=tensor([variants[i].get('gate_roll_rate',.3) for r,m,i in lanes]).float()
    gate_hold=tensor([variants[i].get('gate_hold_s',0.) for r,m,i in lanes]).float()
    settle_joints=hand.get('require_settled_pendulum',False)
    home_compensation=hand.get('home_bias_compensation',False)
    require_both_wheels=hand.get('require_both_far_wheels',False)
    lock_first=hand.get('sttw_only_after_lock',False)
    native_landing=hand.get('landing_control')=='native'
    rb_guidance=tensor([variants[i].get('rb_guidance_bound_rad',0.) for r,m,i in lanes]).float()
    gate_upper=hand.get('gate_recovery_upper',False)
    gate_eso=hand.get('gate_recovery_eso',False)
    align_landing=hand.get('landing_control') in ('align','home')
    home_landing=hand.get('landing_control')=='home'
    saved=np.load(hand['reference_path']);route=TorchPathReference(dict(saved),hcfg,device,route_ids=[r for r,m,i in lanes])
    geometry=build_geometry_contract(model);brake_qpos=np.array([idx.hip_qpos_address,idx.knee_qpos_address])
    home_pose=tensor(model.key_qpos[idx.keyframe_id,brake_qpos]).float()
    joint_kp=tensor(model.actuator_gainprm[2:,0]).float()
    native_surface = terrain.get('surface') in ('native_step', 'level_gap')
    terrain_geoms=jp.asarray([(native_surface and model.geom(i).name in ('floor', 'step')) or model.geom_type[i]==mujoco.mjtGeom.mjGEOM_HFIELD or model.geom(i).name.startswith('flat_lip_') for i in range(model.ngeom)])
    forbidden_geoms=jp.asarray([model.geom(i).name.startswith('planning_obstacle_') for i in range(model.ngeom)])
    rb_model=mm.replace(opt=mm.opt.replace(timestep=jp.asarray(.005,dtype=mm.opt.timestep.dtype),integrator=type(mm.opt.integrator)(int(mujoco.mjtIntegrator.mjINT_RK4)))) if cfg.get('rb_physics') else mm
    rb_substeps=1 if cfg.get('rb_physics') else args.physics_substeps

    pulse=cfg.get('world_y_force_pulse')
    pulse_edges={} if pulse is None else {pulse['start_tick']:pulse['force_n'],pulse['stop_tick']:0.0}
    world=cfg.get('world_map_spec')
    signal_window=[terrain['front_x_m']+v for v in world['forward_obstacle']['jump_signal_offsets_m']] if world else [9.5,11.]
    jump_adapter=JumpAdapter(home_pose,joint_kp,tensor(model.actuator_ctrlrange[2:,0]).float(),tensor(model.actuator_ctrlrange[2:,1]).float(),home_compensation)

    @jax.jit
    def world_status(d):
        outside=body_outside(d,geometry,world['bounds_xy_m']) if world else jp.zeros(n,dtype=jp.bool_)
        c=d._impl;g=c.contact__geom
        valid=(jp.arange(g.shape[0])<c.nacon[0])&(c.contact__dist<=0)
        valid &= jp.any(terrain_geoms[jp.clip(g,0,model.ngeom-1)]&(g>=0),-1)
        valid &= jp.any(g[:,:,None]==geometry.body_geom_ids[None,None,:],axis=(1,2))
        world_id=jp.clip(c.contact__worldid,0,n-1)
        body_contact=jp.zeros(n,dtype=bool).at[world_id].max(valid)
        forbidden=(jp.arange(g.shape[0])<c.nacon[0])&(c.contact__dist<=0)
        forbidden &= jp.any(forbidden_geoms[jp.clip(g,0,model.ngeom-1)]&(g>=0),-1)
        forbidden &= jp.any(g[:,:,None]==geometry.robot_geom_ids[None,None,:],axis=(1,2))
        forbidden_contact=jp.zeros(n,dtype=bool).at[world_id].max(forbidden)
        return jp.stack((outside,body_contact,forbidden_contact),1)

    def contacts(d):
        c=d._impl;g=c.contact__geom
        valid=(jp.arange(g.shape[0])<c.nacon[0])&(c.contact__dist<=0)
        valid &= jp.any((g==idx.frontwheel_geom_id)|(g==idx.rearwheel_geom_id),-1)
        valid &= jp.any(terrain_geoms[jp.clip(g,0,model.ngeom-1)]&(g>=0),-1)
        far=valid&(c.contact__pos[:,0]>terrain['front_x_m']+terrain['width_m'])
        if native_surface:
            upper = jp.any(g == model.geom('step').id, -1)
            if 'rough_source' in terrain:
                upper |= jp.any(g == model.geom('platform_rough').id, -1)
            far &= upper & (c.contact__pos[:,2] >= terrain['far_bank_height_m'] - .01)
        front=far&jp.any(g==idx.frontwheel_geom_id,-1)
        rear=far&jp.any(g==idx.rearwheel_geom_id,-1)
        any_contact,front,rear=jp.zeros((n,3),dtype=bool).at[jp.clip(c.contact__worldid,0,n-1)].max(jp.stack((valid,front,rear),1)).T
        return jp.stack((any_contact,front|rear,front&rear),1)

    def ground_one(d,c,lock,damping):
        plant=mm.replace(eq_data=mm.eq_data.at[brake_ids,0].set(lock),actuator_biasprm=mm.actuator_biasprm.at[0,2].set(-damping))
        return mjx_env.step(plant,d,c,args.physics_substeps)
    ground=jax.vmap(ground_one)
    jump=jax.vmap(lambda d,c:mjx_env.step(rb_model,d,c,rb_substeps))

    @jax.jit
    def advance(data,ctrl,locks,damping,rb,locked,alive):
        data=data.replace(eq_active=data.eq_active.at[:,brake_ids].set(locked[:,None]))
        # Homogeneous phases execute only one kernel; mixed phases select each world's state.
        def mixed(_):
            gd=ground(data,ctrl,locks,damping);rd=jump(data,ctrl)
            flags=jp.where(rb[:,None],contacts(rd),contacts(gd))
            def choose(path,r,g):
                if path[-1].name in DATA_NON_VMAP:return g
                return jp.where(rb.reshape((n,)+(1,)*(r.ndim-1)),r,g)
            return jax.tree_util.tree_map_with_path(choose,rd,gd),flags
        def only_jump(_):
            d=jump(data,ctrl);return d,contacts(d)
        def only_ground(_):
            d=ground(data,ctrl,locks,damping);return d,contacts(d)
        def step(_):
            d,flags=jax.lax.cond(jp.all(rb),only_jump,lambda _:jax.lax.cond(jp.any(rb),mixed,only_ground,None),None)
            def freeze(path,new,old):
                if path[-1].name in DATA_NON_VMAP:return new
                return jp.where(alive.reshape((n,)+(1,)*(new.ndim-1)),new,old)
            return jax.tree_util.tree_map_with_path(freeze,d,data),flags
        return jax.lax.cond(jp.any(alive),step,lambda _:(data,jp.zeros((n,3),dtype=jp.bool_)),None)

    telemetry=cfg.get('contact_substep_telemetry',False)
    audit_owner=cfg.get('audit_actuator_owner',True)

    def substep_with_brakes(d,c,lock,damping):
        plant=mm.replace(eq_data=mm.eq_data.at[brake_ids,0].set(lock),actuator_biasprm=mm.actuator_biasprm.at[0,2].set(-damping))
        return mjx_env.step(plant,d,c,1)

    def prepare_substeps(data,damping,rb,locked):
        return (data.replace(eq_active=data.eq_active.at[:,brake_ids].set(locked[:,None])),
                jp.where(rb,-mm.actuator_biasprm[0,2],damping))

    @jax.jit
    def advance_with_contacts(data,ctrl,locks,damping,rb,locked,alive):
        data,damping=prepare_substeps(data,damping,rb,locked)
        def substep(d,_):
            new=jax.vmap(substep_with_brakes)(d,ctrl,locks,damping)
            loads=normal_loads(new,terrain_geoms,(idx.frontwheel_geom_id,idx.rearwheel_geom_id),geometry.body_geom_ids)
            return new,loads
        result,loads=jax.lax.scan(substep,data,None,length=args.physics_substeps)
        def freeze(path,new,old):
            if path[-1].name in DATA_NON_VMAP:return new
            return jp.where(alive.reshape((n,)+(1,)*(new.ndim-1)),new,old)
        result=jax.tree_util.tree_map_with_path(freeze,result,data)
        return result,contacts(result),jp.where(alive[:,None,None],loads.transpose(1,0,2),jp.nan)

    @jax.jit
    def probe_first_substep(data,ctrl,locks,damping,rb,locked,alive):
        data,damping=prepare_substeps(data,damping,rb,locked)
        new=jax.vmap(substep_with_brakes)(data,ctrl,locks,damping)
        fields={key:getattr(new,key) for key in (
            'qfrc_bias','qfrc_passive','qfrc_actuator','qfrc_smooth','qacc_smooth',
            'qfrc_constraint','qacc','qvel','qpos')}
        c=new._impl
        for key in ('efc__J','efc__D','efc__aref','efc__force'):
            value=getattr(c,key)
            active=jp.arange(value.shape[1])[None,:]<c.nefc[:,None]
            fields[key]=jp.where(active.reshape(active.shape+(1,)*(value.ndim-2)),value,0.)
        fields['nefc']=c.nefc
        return fields

    @jax.jit
    def observe(data):
        q=data.qpos;v=data.qvel;w,x,y,z=q[:,3:7].T
        roll=jp.arctan2(2*(w*x+y*z),1-2*(x*x+y*y));pitch=jp.arcsin(jp.clip(2*(w*y-z*x),-1,1));yaw=jp.arctan2(2*(w*z+x*y),1-2*(y*y+z*z))
        gyro=data.sensordata[:,idx.sensor_addresses[5]:idx.sensor_addresses[5]+3]
        m=jp.stack((-roll,-gyro[:,0],q[:,idx.steering_qpos_address],v[:,idx.steering_dof_address],gyro[:,2],v[:,idx.rearwheel_dof_address],v[:,idx.frontwheel_dof_address]),1)
        return q,v,m,jp.stack((q[:,0],q[:,1],yaw),1),v[:,0]*jp.cos(yaw)+v[:,1]*jp.sin(yaw),jp.stack((roll,pitch,yaw),1),data.qfrc_bias[:,[idx.hip_dof_address,idx.knee_dof_address]]

    def frame_one(d,history,last,offset,signal):
        g=extract_geometry(d,geometry)
        far_fraction=(d.qpos[0]>=terrain['front_x_m']) if terrain['width_m']==0 else jp.clip((d.qpos[0]-terrain['front_x_m'])/terrain['width_m'],0.,1.)
        relative_x = terrain['front_x_m'] - g.robot_frontmost_x if native_surface else g.obstacle_relative_x
        geom=ObservableGeometry(relative_x,d.qpos[2]+offset*far_fraction,g.roll,g.pitch,g.yaw)
        history=advance_history(history,observable_frame(d,idx,geom,last,jp.asarray(1.)))
        return history,actor_observation(history,signal)
    frame=jax.jit(jax.vmap(frame_one))
    use_apex=cfg.get('native_apex_signal',False)
    results=[];all_timing=[]
    for name,skill in skills.items():
        route=TorchPathReference(dict(saved),hcfg,device,route_ids=[r for r,m,i in lanes])
        route.config['follower']['lookahead_scale']=1.
        init_start=time.perf_counter()
        qpos=np.tile(model.key_qpos[idx.keyframe_id],(n,1));qvel=np.tile(model.key_qvel[idx.keyframe_id],(n,1))
        qpos[:,0]=hand.get('start_x_m',1.5);qvel[:,0]=hand.get('start_vx_m_s',2.)
        for lane,(_,_,i) in enumerate(lanes):
            case=variants[i];yaw=case.get('start_yaw_rad',0.);roll=case.get('start_roll_rad',0.)
            qpos[lane,1]=case.get('start_y_m',0.)
            qpos[lane,3:7]=[np.cos(yaw/2)*np.cos(roll/2),np.cos(yaw/2)*np.sin(roll/2),np.sin(yaw/2)*np.sin(roll/2),np.sin(yaw/2)*np.cos(roll/2)]
            qvel[lane,:2]=hand.get('start_vx_m_s',2.)*np.array([np.cos(yaw),np.sin(yaw)])
        if 'approach_initial_bank' in cfg:
            with np.load(cfg['approach_initial_bank']) as bank:
                ids = [variants[i]['bank_row'] for _, _, i in lanes]
                qpos, qvel = bank['qpos'][ids].copy(), bank['qvel'][ids].copy()
                qpos[:, 0] += hand['start_x_m'] - 2.5
        def make(q,v):
            d=mjx_env.make_data(model,qpos=q,qvel=v,impl='warp',naconmax=cfg.get('world_contact_capacity',4096)*n,naccdmax=cfg.get('ccd_capacity',512),njmax=256)
            plant=mm.replace(eq_data=mm.eq_data.at[brake_ids,0].set(q[brake_qpos]))
            return mjx.forward(plant,d.replace(eq_active=d.eq_active.at[brake_ids].set(True)))
        data=jax.jit(jax.vmap(make))(jp.asarray(qpos,dtype=jp.float32),jp.asarray(qvel,dtype=jp.float32))
        def infer_one(obs,knee,scale):
            action,_=skill.infer(obs,knee)
            action=action.at[2:].multiply(scale)
            return action,map_action(action,knee,skill.bundle.action_mapping)
        infer=jax.jit(jax.vmap(infer_one))
        ground_action_history=cfg.get('rb_history_from_ground_targets',False)
        action_mapping=skill.bundle.action_mapping
        if ground_action_history and action_mapping.joint_target_semantics!='keyframe_centered_absolute':
            raise ValueError('Ground history projection requires the frozen absolute joint mapping')
        if use_apex:
            event_cfg=replace(skill.up_config,events=replace(skill.up_config.events,
                jump_zone_x_min=signal_window[0],jump_zone_x_max=signal_window[1]))
            def signal_step(previous,d,failed):
                signals=PhaseUSignals(d.qpos[0],d.qpos[2],d.qvel[0],d.qvel[2],failed)
                current=advance_events(previous,signals,event_cfg)
                return current,current.jump_signal & ~current.apex_seen
            native_signal=jax.jit(jax.vmap(signal_step))
            rb_events=jax.vmap(lambda x:initial_event_state(x,event_cfg))(data.qpos[:,0])
        history=jax.tree.map(lambda x:jp.broadcast_to(x,(n,)+x.shape),initial_history())
        last=jp.zeros((n,4));obs=jax.vmap(lambda h:actor_observation(h,jp.asarray(False)))(history)
        if cfg.get('native_rb_entry_context'):
            if not use_apex:
                raise ValueError('Native RB entry context needs the native jump event signal')
            empty_history = history
            @jax.jit
            def enter_native(mask, data, previous, history, last, obs):
                fresh = jax.vmap(lambda x: initial_event_state(x,event_cfg))(data.qpos[:,0])
                first_obs = jax.vmap(actor_observation)(empty_history,fresh.jump_signal)
                def select(new,old):
                    return jp.where(mask.reshape((n,)+(1,)*(new.ndim-1)),new,old)
                return jax.tree.map(select,(fresh,empty_history,jp.zeros_like(last),first_obs),
                                    (previous,history,last,obs))
        policy=TorchPathPolicy(bundle/'actor.npz',identity['files']['actor.npz'],hcfg,n,device)
        ctl=TorchController(controller_config,n,device)
        approach_alpha=tensor([variants[i].get('approach_alpha',hand['approach']['alpha']) for _,_,i in lanes]).float()
        middle=TorchMiddleControl(policy,route,identity['frame_scales'],approach_alpha,approach_speed)
        q,v,m,pose,speed,angles,joint_bias=map(to_torch,observe(data));raw=torch.stack((speed,m[:,2]),1);previous=torch.stack((m[:,3],m[:,5]),1)
        nearest=(route.xy[route.route_ids]-pose[:,None,:2]).square().sum(-1).argmin(-1)
        middle.reset(m,pose,speed,raw,raw,previous,ctl,initial_progress=route.s[nearest])
        paired_departures=cfg.get('paired_departures')
        continuous_routes=None
        if cfg.get('continuous_handoff_routes'):
            from .continuous_handoff_routes import ContinuousHandoffRoutes
            if cfg.get('live_ground_cem') or cfg.get('rolling_planner') or cfg.get('locked_departures'):
                raise ValueError('Continuous handback uses the P2 published approach from plan_updates; a second route publisher is incompatible')
            if not paired_departures or cfg.get('p0_branches') or cfg.get('platform_online',{}).get('veto_bank'):
                raise ValueError('Continuous handback needs fixed direction IDs and supports its own generated three-exit routes')
            continuous_routes=ContinuousHandoffRoutes(route,hand['goal']['x_min_m'])
            route=continuous_routes.route
            shutil.copy2(Path(__file__).with_name('continuous_handoff_routes.py'),source/'continuous_handoff_routes.py')
        if paired_departures:
            approach_ids=tensor([r for r,_,_ in lanes]).long()
            if continuous_routes is None:
                route=TorchPathReference(dict(np.load(paired_departures['route_bank'])),hcfg,device,route_ids=approach_ids)
                approach_ref=dict(np.load(paired_departures['approach_file']))
                approach_x=tensor(approach_ref['xy'][:,:,0]).contiguous()
                arc64=tensor(saved['s'])
                world_index=torch.arange(n,device=device)
            middle.route=route
            directions=tensor(paired_departures['direction_ids']).long()
        online=cfg.get('platform_online')
        if online:
            from .platform_online import PlatformDepartureQuery, velocity_state
            from .playground_history_model import load_history_model
            query=PlatformDepartureQuery(model,load_history_model(Path(online['ground_model'])),hand['goal'],online['margin_m'],hand['road_half_width_m'],online.get('relative'))
            velocity_history = [(q,v)]*4 if query.relative else None
            contracts=[variants[i] for _,_,i in lanes]
            reselect=tensor([c['planner']=='C-R' for c in contracts])
            shadow=tensor([c['planner']=='C' for c in contracts])
            section=tensor([c['section_x'] for c in contracts]).float()
            side=tensor([c['side'] for c in contracts]).float()
            force=tensor([c['force_y_N'] for c in contracts]).float()
            fallback = None
            if online.get('veto_bank'):
                from .platform_fallback import VetoExitBank, handback_features
                with np.load(online['veto_bank']) as bank:
                    fallback = VetoExitBank(bank, device)
                use_bank = tensor([c['arm']=='veto_bank' for c in contracts])
                gate_index = tensor([('near','mid','far').index(c['bin']) for c in contracts]).long()
            pulse_start=torch.full_like(approach_ids,-1)
            pulse_ticks=torch.zeros_like(pulse_start)
            query_ms=torch.zeros_like(force)
            query_pass=torch.zeros_like(reselect)
            latency=online.get('latency_ticks')
            if latency:
                # Publish the neutral lead-in while the initial plan is pending.
                if continuous_routes is None:
                    neutral_id=len(route.xy)
                    for field in ('xy','heading','curvature'):
                        values=getattr(route,field)
                        setattr(route,field,torch.cat((values,tensor(saved[field][0:1]).to(values))))
                    route.route_ids=torch.full_like(approach_ids,neutral_id)
                release=torch.full_like(approach_ids,-1)
                pending_route=torch.zeros_like(approach_ids)
                applied_tick=torch.full_like(approach_ids,-1)
                proposed=directions.clone()
        middle.lane_ticks=torch.zeros(n,device=device,dtype=torch.long);middle.latent=torch.zeros_like(raw)
        ground_adapter=GroundAdapter(middle,ctl)
        updates={}
        for u in cfg.get('plan_updates',[]):
            if name not in u['skills']:continue
            ref=dict(np.load(u['reference_path']))
            rows=[r for r,m,i in lanes]
            if continuous_routes is not None:
                rows=u.get('reference_rows',list(range(n)) if len(ref['xy'])==n else [0]*n)
                if len(rows)!=n or (len(ref['xy']) not in (1,n) and 'reference_rows' not in u):
                    raise ValueError('Specify one candidate reference row for each physical lane')
            tick=round(u['time_s']/.005) if continuous_routes is None else 4*math.ceil(u['time_s']/.02-1e-9)
            if continuous_routes is not None and tick in updates:raise ValueError('Provide one combined approach packet per publication boundary')
            updates[tick]=(u,TorchPathReference(ref,hcfg,device,route_ids=rows))
        plan_receipts=[]
        live_ground=None
        if cfg.get('live_ground_cem'):
            if n!=1 or not args.ground_only or cfg.get('snapshot_replay_s') is not None or cfg.get('rolling_planner'):
                raise ValueError('live ground CEM integration requires one ground-only lane without rolling library or snapshot replay')
            live_ground=LiveGroundCEM(cfg['live_ground_cem'],model,route,route.config['follower'],q,v)
        p0_branches=None
        if cfg.get('p0_branches'):
            from .chapter3_p0_physical import P0Branches
            p0_branches=P0Branches(cfg['p0_branches'],args.output,query,route,contracts,q,v)
        rolling_cfg=cfg.get('rolling_planner')
        rolling=None;pending=None;rolling_events=[]
        if rolling_cfg:
            rolling=RollingMotionLibrary(rolling_cfg['state_bank'],route,rolling_cfg['clearance'],device)
            period_ticks=round(rolling_cfg['period_s']/.005)
            first_query_tick=round(rolling_cfg['first_query_s']/.005)
        phase=torch.zeros(n,device=device,dtype=torch.long);alive=torch.ones(n,device=device,dtype=torch.bool)
        recovering=torch.zeros_like(alive)
        stable_time=torch.zeros(n,device=device);upper_ready_time=torch.zeros(n,device=device)
        airborne=torch.zeros_like(alive);flags=torch.zeros(n,3,device=device,dtype=torch.bool)
        far_time=torch.full((n,),-1.,device=device);entry_time=far_time.clone();handoff_time=far_time.clone();hold=torch.zeros(n,device=device)
        lock=q[:,brake_qpos].clone();target=torch.zeros(n,4,device=device);target[:,2:]=lock
        zero=tensor([mode=='zero_middle' for _,mode,i in lanes]);lo=tensor(model.actuator_ctrlrange[:,0]).float();hi=tensor(model.actuator_ctrlrange[:,1]).float()
        codes=torch.zeros(n,device=device,dtype=torch.long);durations=torch.full((n,),args.seconds,device=device)
        applied_rows=[];applied_masks=[];rb_state_rows=[];collected_snapshots={};rows=[];poses=[];velocities=[];contact_rows=[];valid_rows=[];world_rows=[];load_rows=[];controller_rows=[];substep_loads=torch.full((n,args.physics_substeps,4),torch.nan,device=device);ownership_error=torch.zeros(n,device=device);goal=hand['goal'];data.qpos.block_until_ready();init_s=time.perf_counter()-init_start;rollout_start=time.perf_counter()
        snapshot_tick=round(cfg['snapshot_replay_s']/.005) if 'snapshot_replay_s' in cfg else None
        collection_ticks={round(t/.005) for t in cfg.get('snapshot_times_s',[])}
        stage_anchors={}
        landing_captured=torch.zeros_like(alive)
        handoff_snapshot_saved=False
        memory_repeats=cfg.get('snapshot_memory_repeats',0)
        for replay in range(2+memory_repeats if snapshot_tick is not None else 1):
            case_name=name+(f'_memory{replay}' if 0<replay<=memory_repeats else ('_replay' if replay else ''))
            homing_speed=(cfg.get('snapshot_branch_homing_min_forward_m_s',nominal_homing_speed)
                          if replay==memory_repeats+1 else nominal_homing_speed)
            continuation_speed=nominal_continuation_speed
            continuation_alpha=hand.get('continuation',{}).get('alpha',.5)
            if replay==memory_repeats+1 and 'snapshot_branch_continuation_alpha' in cfg:
                continuation_alpha=cfg['snapshot_branch_continuation_alpha']
            if replay==memory_repeats+1 and 'snapshot_branch_continuation_speed_m_s' in cfg:
                continuation_speed=torch.full_like(continuation_speed,cfg['snapshot_branch_continuation_speed_m_s'])
            start_tick=0
            if replay or cfg.get('initial_snapshot_path'):
                restore_started=time.perf_counter()
                if not replay:
                    with Path(cfg['initial_snapshot_path']).open('rb') as stream:snapshot=pickle.load(stream)
                    context=snapshot['context']
                    if context['ground_identity']!=identity or context['rb_identity']!=skill.record:
                        raise ValueError('Initial snapshot skill identity differs from active frozen skills')
                    if hashlib.sha256(Path(context['physics_model']).read_bytes()).digest()!=hashlib.sha256((args.output/'terrain.mjb').read_bytes()).digest():
                        raise ValueError('Initial snapshot physics model differs from active model')
                    if snapshot['physics'].qpos.shape!=data.qpos.shape:
                        raise ValueError('Initial snapshot lane shape differs from this run')
                    initial_snapshot=snapshot
                elif replay<=memory_repeats:snapshot=replay_snapshot
                else:
                    with (args.output/f'{name}_runtime_snapshot.pkl').open('rb') as stream:snapshot=pickle.load(stream)
                data,(history,obs,last),runtime=restore_snapshot(snapshot,ground_adapter)
                phase,alive,recovering,stable_time,upper_ready_time,airborne,flags,far_time,entry_time,handoff_time,hold,lock,target,codes,durations,ownership_error,substep_loads=(runtime[key] for key in ['phase', 'alive', 'recovering', 'stable_time', 'upper_ready_time', 'airborne', 'flags', 'far_time', 'entry_time', 'handoff_time', 'hold', 'lock', 'target', 'codes', 'durations', 'ownership_error', 'substep_loads'])
                # Live lanes inherit the new horizon when extending a short snapshot run.
                durations=torch.where(alive,torch.full_like(durations,args.seconds),durations)
                if use_apex:
                    if 'rb_events' in runtime:
                        rb_events=runtime['rb_events']
                    elif bool((phase!=0).any()) or bool((data.qpos[:,0]>=signal_window[0]).any()):
                        raise ValueError('Apex signal requires event history for a post-entry snapshot')
                    else:
                        rb_events=jax.vmap(lambda x:initial_event_state(x,event_cfg))(data.qpos[:,0])
                if rolling is not None:
                    rolling.restore(runtime['planner']['library'])
                    pending=deepcopy(runtime['planner']['pending']);rolling_events=deepcopy(runtime['planner']['events'])
                    jump_start=runtime['planner']['jump_start'].clone()
                route=middle.route
                if not replay and 'oracle_initial_speed_m_s' in cfg:
                    speed_request=torch.as_tensor(cfg['oracle_initial_speed_m_s'],dtype=middle.v_user.dtype,device=device).expand_as(middle.v_user)
                    if snapshot['tick']!=0 or not ((speed_request==1.8)|(speed_request==1.9)).all():
                        raise ValueError('Oracle approach speed must be a validated request at the initial snapshot')
                    middle.v_user=speed_request.clone()
                if not replay and 'oracle_initial_alpha' in cfg:
                    alpha=torch.as_tensor(cfg['oracle_initial_alpha'],device=device,dtype=middle.alpha.dtype).expand_as(middle.alpha)
                    if snapshot['tick']!=0 or not ((alpha>=0)&(alpha<=1)).all():
                        raise ValueError('Oracle approach alpha must be in [0,1] at the initial snapshot')
                    middle.alpha=alpha.clone()
                if not replay and cfg.get('oracle_branch_reference'):
                    # Offline counterfactual command, not an online committed-preview update.
                    # Keep all control/ESO/history/held-command tensors; next scheduled update
                    # consumes the new route using the unchanged slew and actuator contracts.
                    proposal=TorchPathReference(dict(np.load(cfg['oracle_branch_reference'])),hcfg,device,route_ids=[r for r,m,i in lanes])
                    end=torch.searchsorted(route.s,middle.projection['progress']).clamp_max(len(route.s)-1)
                    mask=torch.arange(len(route.s),device=device)[None,:]<=end[:,None]
                    old_xy=route.xy[route.route_ids];new_xy=proposal.xy[proposal.route_ids]
                    if not torch.all(torch.where(mask[...,None],(old_xy-new_xy).abs()<=1e-6,True)):
                        raise ValueError('Oracle route changes the executed geometric prefix')
                    middle.route=proposal;route=proposal;ground_adapter.plan_version+=1
                q,v,m,pose,speed,angles,joint_bias=map(to_torch,observe(data))
                if replay:rows,poses,velocities,contact_rows,valid_rows,world_rows,plan_receipts,load_rows,controller_rows,applied_rows,applied_masks,rb_state_rows=[x.copy() for x in prefix]
                start_tick=snapshot['tick']
                data.qpos.block_until_ready()
                (args.output/f'{case_name}_restore.json').write_text(json.dumps(dict(tick=start_tick,time_s=start_tick*.005,restore_s=time.perf_counter()-restore_started,runtime_fields=list(runtime),physics_leaf_count=len(jax.tree.leaves(data)),source=('in-memory' if replay and replay<=memory_repeats else 'serialized')+' full MJX data, RB FIFO/observation/action, ground controller and runner state'),indent=2))
            branch_ticks = {}
            if cfg.get('locked_departures'):
                departure = cfg['locked_departures']
                proposal = TorchPathReference(dict(np.load(departure['reference_path'])), hcfg, device)
                first_departure = len(route.xy)
                for key in ('xy', 'heading', 'curvature'):
                    setattr(route, key, torch.cat((getattr(route, key), getattr(proposal, key))))
                for tick_s, lane_numbers in departure['lanes_by_tick'].items():
                    branch_ticks[int(tick_s)] = tensor(lane_numbers).long()
            rollout_start=time.perf_counter()
            for tick in range(start_tick,round(args.seconds/.005)+1):
                t=tick*.005
                if paired_departures:
                    if continuous_routes is None and online and latency and tick==latency['start']:
                        route.route_ids=approach_ids.clone()
                    # Every departure keeps the common approach until the first tick after physical relock.
                    just_locked=alive & (phase==2) & ((handoff_time/.005).round().long()==tick-1)
                    if p0_branches is not None:
                        p0_branches.audit(tick,locals(),just_locked)
                        previous_p0_velocity=velocity_state(*velocity_history[tick%4])
                    if continuous_routes is None:
                        after_x=torch.stack([torch.searchsorted(x,q[:,0].double().contiguous()+.05) for x in approach_x])
                        join=torch.maximum(after_x[approach_ids,world_index],torch.searchsorted(arc64,middle.projection['progress'].double().contiguous())+1)
                    else:
                        locked_ids=torch.where(just_locked)[0]
                        if len(locked_ids):
                            torch.cuda.synchronize(device);start_geometry=time.perf_counter()
                            continuous_routes.at_handback(locked_ids,q[locked_ids,:2],middle.projection['progress'][locked_ids])
                            torch.cuda.synchronize(device)
                            continuous_routes.geometry_ms[locked_ids]=1000*(time.perf_counter()-start_geometry)
                            if online:query_ms[locked_ids]=continuous_routes.geometry_ms[locked_ids].to(query_ms)
                        choice_rows=continuous_routes.branch_rows
                    if online and bool((just_locked & (reselect|shadow)).any()):
                        ids=torch.where(just_locked & (reselect|shadow))[0]
                        choices=(len(approach_x)+(approach_ids[ids,None]*3+torch.arange(3,device=device))*len(arc64)+join[ids,None].clamp_max(len(arc64)-1)
                                 if continuous_routes is None else choice_rows[ids])
                        torch.cuda.synchronize()
                        start_query=time.perf_counter()
                        # Rotate world velocity into body x exactly as in the offline predictor.
                        quat=q[ids,3:7];bw,bx,by,bz=quat.T
                        axis=torch.stack((1-2*(by.square()+bz.square()),2*(bx*by+bw*bz),2*(bx*bz-bw*by)),1)
                        prev = velocity_state(velocity_history[tick%4][0][ids],velocity_history[tick%4][1][ids]) if query.relative else None
                        current = velocity_state(q[ids],v[ids]) if query.relative else None
                        chosen,admitted,incumbent=query.choose(q[ids],(axis*v[ids,:3]).sum(1),nominal_continuation_speed[ids],route,choices,section[ids],side[ids],directions[ids],args.seconds-t,current,prev)
                        if fallback is not None:
                            alternate = fallback.choose(handback_features(q[ids],v[ids]), approach_ids[ids],
                                                        gate_index[ids], chosen)
                            chosen = torch.where(use_bank[ids] & ~admitted, alternate, chosen)
                        selected=torch.where(reselect[ids],chosen,directions[ids])
                        if latency:proposed[ids]=selected
                        else:directions[ids]=selected
                        query_pass[ids]=torch.where(reselect[ids],admitted,incumbent) if online.get('committed_vote') else admitted
                        torch.cuda.synchronize()
                        query_ms[ids]=1000*(time.perf_counter()-start_query)
                        if continuous_routes is not None:query_ms[ids]+=continuous_routes.geometry_ms[ids].to(query_ms)
                    if online and query.relative:
                        velocity_history[tick%4] = (q,v)
                    branch=(len(approach_x)+(approach_ids*3+directions)*len(arc64)+join.clamp_max(len(arc64)-1)
                            if continuous_routes is None else choice_rows.gather(1,directions[:,None]).squeeze(1))
                    if online and latency:
                        if continuous_routes is None:
                            anchor=join.clamp_max(len(arc64)-1)
                            exit_branch=len(approach_x)+(approach_ids*3+proposed)*len(arc64)+anchor
                        else:exit_branch=choice_rows.gather(1,proposed[:,None]).squeeze(1)
                        pending_route=torch.where(just_locked,exit_branch,pending_route)
                        release=torch.where(just_locked,tick+latency['departure'],release)
                        # All comparators execute the same straight exit during the measured decision time.
                        branch=(len(approach_x)+(approach_ids*3+1)*len(arc64)+anchor
                                if continuous_routes is None else choice_rows[:,1])
                        directions=torch.where(just_locked,1,directions)
                        apply=alive & (release==tick)
                        if p0_branches is not None:
                            # Rolling arms start on the common straight branch and their own
                            # publication receipt controls every subsequent route assignment.
                            apply &= p0_branches.arm<3
                        route.route_ids=torch.where(apply,pending_route,torch.where(just_locked,branch,route.route_ids))
                        directions=torch.where(apply,proposed,directions)
                        applied_tick=torch.where(apply,tick,applied_tick)
                    else:
                        route.route_ids=torch.where(just_locked,branch,route.route_ids)
                    if p0_branches is not None:
                        p0_branches.step(tick,locals(),just_locked,previous_p0_velocity)
                    if tick in (1,8,32) or tick%256==0:
                        data.qpos.block_until_ready()
                        (args.output/'gpu_progress.json').write_text(json.dumps(dict(tick=tick,worlds=data.qpos.shape[0],device=str(data.qpos.device),elapsed_s=time.perf_counter()-rollout_start)))
                if tick in branch_ticks:
                    ids = branch_ticks[tick]
                    locked = alive[ids] & (phase[ids] == 2) & ((handoff_time[ids]/.005).round().long() == tick-1)
                    route.route_ids[ids] = torch.where(locked, first_departure + ids, route.route_ids[ids])
                collect_handoff=cfg.get('snapshot_ground_handoff',False) and not handoff_snapshot_saved and tick%4==0 and bool(((phase==2)|~alive).all())
                capture_stage=False
                if cfg.get('snapshot_first_locked') and not replay:
                    just_locked = alive & (phase==2) & (handoff_time>=0) & ((handoff_time/.005).round().long()==tick-1)
                    if bool(just_locked.any()):
                        collection_ticks.add(tick)
                if cfg.get('snapshot_loaded_far') and not replay:
                    loaded=alive & ~landing_captured & flags[:,2] & (substep_loads[:,-1,:2]>1e-5).all(1)
                    if bool(loaded.any()):
                        landing_captured |= loaded
                        collection_ticks.add(tick)
                if cfg.get('capture_handoff_stages') and not replay and len(stage_anchors)<3 and tick%4==0:
                    supported=substep_loads[:,-1,:2].amax(1)>1e-5
                    masks=torch.stack((alive&(phase==1)&supported&(q[:,0]>terrain['front_x_m']-.65)&(q[:,0]<terrain['front_x_m']-.15),
                                       alive&((phase==1)|(phase==3))&flags[:,1]&supported,
                                       alive&(phase==2)))
                    for stage,mask in zip(('before_takeoff','far_touch','sttw_return'),masks.cpu().numpy()):
                        if stage not in stage_anchors and mask.any():
                            stage_anchors[stage]=dict(tick=tick,lanes=np.flatnonzero(mask).tolist())
                            capture_stage=True
                if (snapshot_tick==tick or tick in collection_ticks or collect_handoff or capture_stage or (tick==0 and cfg.get('collect_model_state'))) and not replay:
                    runtime=dict(phase=phase,alive=alive,recovering=recovering,stable_time=stable_time,upper_ready_time=upper_ready_time,airborne=airborne,flags=flags,far_time=far_time,entry_time=entry_time,handoff_time=handoff_time,hold=hold,lock=lock,target=target,codes=codes,durations=durations,ownership_error=ownership_error,substep_loads=substep_loads)
                    if use_apex:runtime['rb_events']=rb_events
                    if rolling is not None:
                        runtime['planner']=dict(library=rolling.snapshot(),pending=deepcopy(pending),events=deepcopy(rolling_events),jump_start=jump_start.clone())
                    snapshot=capture_snapshot(data,ground_adapter,(history,obs,last),runtime,tick,dict(world_map=world,terrain=terrain,ground_identity=identity,rb_identity=skill.record,physics_model=str(args.output/'terrain.mjb'),resolved_config=str(args.output/'resolved_config.json')))
                    if tick==0 and cfg.get('collect_model_state'):initial_snapshot=snapshot
                    if tick in collection_ticks or collect_handoff or capture_stage:collected_snapshots[tick]=snapshot
                    if collect_handoff:handoff_snapshot_saved=True
                    if snapshot_tick==tick:replay_snapshot=snapshot
                    if snapshot_tick==tick:prefix=[rows.copy(),poses.copy(),velocities.copy(),contact_rows.copy(),valid_rows.copy(),world_rows.copy(),plan_receipts.copy(),load_rows.copy(),controller_rows.copy(),applied_rows.copy(),applied_masks.copy(),rb_state_rows.copy()]
                if live_ground is not None:
                    live_ground.step(tick,q,v,alive,ground_adapter);route=middle.route
                if continuous_routes is not None and tick in updates:
                    update,new_route=updates[tick]
                    receipt=continuous_routes.publish(ground_adapter,new_route,tensor(update['committed_until_m']).expand(n),
                        tensor(update.get('ready_s',update['time_s'])).expand(n),tensor(update['deadline_s']).expand(n),alive & (phase==0),update['expected_previous_version'])
                    route=middle.route
                    plan_receipts.append(receipt)
                elif tick in updates:
                    update,new_route=updates[tick]
                    before=ground_adapter.snapshot()
                    receipt=ground_adapter.update_plan(new_route,torch.full((n,),update['committed_until_m'],device=device),t,update['expected_previous_version'])
                    route=middle.route
                    receipt['state_preserved']=bool(torch.equal(before['middle']['frames'],middle.frames)
                        and torch.equal(before['middle']['mask'],middle.mask)
                        and torch.equal(before['middle']['lane_ticks'],middle.lane_ticks)
                        and torch.equal(before['policy']['filtered'],policy.filtered)
                        and torch.equal(before['policy']['offsets'],policy.offsets)
                        and torch.equal(before['controller']['eso'],ctl.eso)
                        and torch.equal(before['controller']['filtered_roll_rate'],ctl.filtered_roll_rate))
                    plan_receipts.append(receipt)
                if rolling is not None:
                    ground_now=alive&((phase==0)|(phase==2))
                    if pending is not None and tick==pending['due_tick']:
                        clock=time.perf_counter()
                        state=controller_features(middle,ctl,recovering,stable_time,upper_ready_time,lock)
                        history_now=torch.cat([value.reshape(n,-1).float() for value in state.values()],1)
                        required=(middle.projection['progress']+middle.follower['lookahead']+middle.v_user*.02).clamp_max(route.s[-1])
                        valid,ratio=rolling.screen(q,v,history_now,phase,required,route,jump_start)
                        selected=pending['selected'];lane=torch.arange(n,device=device)
                        accept=pending['feasible']&valid[selected,lane]&ground_now
                        changed=accept&(rolling.active!=selected)
                        receipt=dict(event='publication',query_tick=pending['query_tick'],tick=tick,time_s=t,accepted=accept.tolist(),changed=changed.tolist(),selected=selected.tolist(),charged_delay_s=(tick-pending['query_tick'])*.005,query_ms=pending['query_ms'])
                        if bool(changed.any()):
                            new_route,chosen=rolling.proposal(route,selected,changed)
                            publication=ground_adapter.update_plan(new_route,required,t,ground_adapter.plan_version)
                            route=middle.route;rolling.current_route=chosen
                            jump_start=torch.where(changed,rolling.activation[selected],jump_start)
                            rolling.active=torch.where(changed,selected,rolling.active)
                            after=controller_features(middle,ctl,recovering,stable_time,upper_ready_time,lock)
                            publication['state_preserved']=bool(torch.equal(history_now,torch.cat([value.reshape(n,-1).float() for value in after.values()],1)))
                            plan_receipts.append(publication);receipt.update(publication)
                        torch.cuda.synchronize();receipt['publication_ms']=(time.perf_counter()-clock)*1000
                        receipt['latency_covered']=receipt['charged_delay_s']*1000>=receipt['query_ms']+receipt['publication_ms']
                        rolling_events.append(receipt);pending=None
                    if tick>=first_query_tick and (tick-first_query_tick)%period_ticks==0 and bool(ground_now.any()):
                        clock=time.perf_counter()
                        state=controller_features(middle,ctl,recovering,stable_time,upper_ready_time,lock)
                        history_now=torch.cat([value.reshape(n,-1).float() for value in state.values()],1)
                        required=(middle.projection['progress']+middle.follower['lookahead']+middle.v_user*.02).clamp_max(route.s[-1])
                        selected,feasible,ratio=rolling.select(q,v,history_now,phase,required,route,jump_start)
                        feasible &= ground_now
                        initial_prefix=(rolling.active<0)&(q[:,0]<rolling_cfg['initial_valid_until_x_m'])
                        rolling.failed |= ground_now&~feasible&~initial_prefix
                        event_row=dict(event='query',tick=tick,time_s=t,selected=selected.tolist(),feasible=feasible.tolist(),active=rolling.active.tolist(),state_ratio=ratio[selected,torch.arange(n,device=device)].tolist(),planning_failed=rolling.failed.tolist())
                        torch.cuda.synchronize();query_ms=(time.perf_counter()-clock)*1000
                        delay_ticks=(math.ceil(query_ms/20)+1)*4
                        pending=dict(selected=selected,feasible=feasible,query_tick=tick,due_tick=tick+delay_ticks,query_ms=query_ms)
                        event_row.update(query_ms=query_ms,due_tick=pending['due_tick']);rolling_events.append(event_row)
                enter=alive&(phase==0)&(q[:,0]>=jump_start)&(tick%4==0)&(not args.ground_only)
                if cfg.get('native_rb_entry_context') and tick%4==0:
                    rb_events,history,last,obs=enter_native(to_jax(enter),data,rb_events,history,last,obs)
                phase=torch.where(enter,1,phase);entry_time=torch.where(enter,t,entry_time)
                airborne |= alive&((phase==1)|(phase==3))&~flags[:,0]&(q[:,0]>terrain['front_x_m']-1.5)
                supported_far=flags[:,2]&(q[:,0]>terrain['front_x_m']+terrain['width_m'])
                crossed=airborne|(supported_far&hand.get('allow_supported_far_completion',False))
                far=alive&crossed&((phase==1)|(phase==3))&flags[:,1]&(far_time<0)
                far_time=torch.where(far,t,far_time)
                if hand.get('retain_rb_after_entry', False):
                    returning = reset_control = torch.zeros_like(alive)
                elif event:
                    descending=(v[:,2]<-.1)&(q[:,2]-terrain['far_bank_height_m']<=landing_height)&(q[:,0]>terrain['front_x_m']+terrain['width_m']-.15)
                    preparing=alive&(phase==1)&((airborne&descending)|(crossed&flags[:,1]))
                    phase=torch.where(preparing,3,phase)
                    landed=flags[:,2] if require_both_wheels else flags[:,1]
                    ready=landed&(angles[:,0].abs()<.35)&(angles[:,1].abs()<.45)&(v[:,2].abs()<1.5)
                    if staged_native:
                        body_ready=landed&(angles[:,0].abs()<gate_roll)&(angles[:,1].abs()<.2)&(v[:,2].abs()<.5)&(m[:,1].abs()<gate_rate)&(speed>=homing_speed)
                        if settle_joints:
                            body_ready &= (angles[:,1].abs()<.03)&(v[:,4].abs()<.3)&((q[:,brake_qpos]-home_pose).abs().amax(-1)<.15)&(v[:,[idx.hip_dof_address,idx.knee_dof_address]].abs().amax(-1)<.5)
                        stable_time=torch.where(alive&(phase==3)&body_ready,stable_time+.005,0.)
                        taking_wheels=alive&(phase==3)&body_ready&(stable_time>=gate_hold)
                        phase=torch.where(taking_wheels,4,phase)
                    if native_landing:ready &= (angles[:,0].abs()<.08)&(angles[:,1].abs()<.15)&(v[:,2].abs()<.4)&(m[:,1].abs()<.3)
                    ready &= (v[:,5].abs()<hand.get('handoff_yaw_rate_max_rad_s',float('inf')))&(m[:,3].abs()<hand.get('handoff_steer_rate_max_rad_s',float('inf')))
                    ready &= (speed-continuation_speed).abs()<=hand.get('handoff_speed_error_max_m_s',float('inf'))
                    if home_landing or native_landing:ready &= ((q[:,brake_qpos]-home_pose).abs().amax(-1)<hand.get('lock_position_tolerance_rad',.08))&(v[:,[idx.hip_dof_address,idx.knee_dof_address]].abs().amax(-1)<hand.get('lock_velocity_tolerance_rad_s',.5))&(m[:,1].abs()<1.)
                    returning=alive&(phase==(4 if staged_native else 3))&ready
                    reset_control=returning if lock_first else taking_wheels if staged_native else returning if native_landing else preparing|far|returning
                else:
                    returning=alive&(phase==1)&(far_time>=0)&(t-far_time>=hand.get('handoff_delay_s',0.)-1e-7)
                    reset_control=returning
                phase=torch.where(returning,2,phase);handoff_time=torch.where(returning,t,handoff_time)
                lock=torch.where(returning[:,None],q[:,brake_qpos],lock)
                middle.v_user=torch.where(reset_control,continuation_speed,middle.v_user)
                middle.alpha=torch.where(reset_control,continuation_alpha,middle.alpha)
                route.config['follower']['lookahead_scale']=torch.where(phase>=2,recovery_look,1.)
                middle.reset_mask(reset_control,m,pose,speed,ctl)
                recovering |= reset_control
                target[:,0]=torch.where(reset_control,q[:,idx.steering_qpos_address],target[:,0]);target[:,2:]=torch.where(returning[:,None],lock,target[:,2:])
                ey=(route.xy[route.route_ids]-q[:,None,:2]).square().sum(-1).min(-1).values.sqrt()
                eh=wrap(middle.projection['heading']-pose[:,2]);ground_mode=((phase==0)|(phase==2)|(phase==4)) if native_landing else (phase!=1)
                world_flags=to_torch(world_status(data));world_failure=world_flags[:,0]|world_flags[:,2]
                physical=~torch.isfinite(q).all(-1)|(angles[:,0].abs()>.7)|(angles[:,1].abs()>1.309)
                outside=ground_mode&((ey>hand['road_half_width_m'])|middle.domain_exit)
                at_goal=((phase==2)|args.ground_only)&(q[:,0]>=goal['x_min_m'])&(q[:,0]<=goal['x_max_m'])&(q[:,1].abs()<=goal['abs_y_max_m'])&(v[:,0]>=goal['min_vx_m_s'])
                at_goal &= (ey<=goal.get('path_tolerance_m',float('inf')))&(eh.abs()<=goal.get('heading_tolerance_rad',float('inf')))&((speed-middle.v_user).abs()<=goal.get('speed_tolerance_m_s',float('inf')))
                hold=torch.where(alive,torch.where(at_goal,hold+.005,0.),hold)
                reached=at_goal&(hold>=goal.get('hold_s',0.))
                stop=alive&(physical|outside|world_failure|reached);codes=torch.where(stop,torch.where(physical,1,torch.where(world_flags[:,2],5,torch.where(world_failure,4,torch.where(outside,2,3)))),codes);durations=torch.where(stop,t,durations)
                rows.append(torch.cat((torch.full((n,1),t,device=device),q[:,:3],angles,v[:,:3],(phase==2)[:,None],ey[:,None],target,(phase==0)[:,None],m[:,5:6],middle.v_user[:,None],phase[:,None]),1))
                if cfg.get('collect_model_state'):
                    state=controller_features(middle,ctl,recovering,stable_time,upper_ready_time,lock)
                    controller_rows.append(torch.cat([value.reshape(n,-1).float() for value in state.values()],1))
                    rb_state_rows.append(torch.cat([to_torch(value).reshape(n,-1).float() for value in (history.frames,history.valid_count,obs,last)],1))
                    if tick==start_tick:controller_schema={key:list(value.shape[1:]) for key,value in state.items()}
                if telemetry:load_rows.append(substep_loads)
                poses.append(q);velocities.append(v);contact_rows.append(flags.clone());world_rows.append(world_flags.clone());valid_rows.append(alive.clone());alive &= ~stop
                if tick==round(args.seconds/.005):break
                upper_ready=(phase==2)&(m[:,0].abs()<.05)&(m[:,1].abs()<.2)&(eh.abs()<.15)&(ey<.2)
                upper_ready &= ((speed-middle.v_user).abs()<hand.get('upper_ready_speed_error_m_s',float('inf')))&(v[:,5].abs()<hand.get('upper_ready_yaw_rate_rad_s',float('inf')))&(m[:,3].abs()<hand.get('upper_ready_steer_rate_rad_s',float('inf')))
                upper_ready_time=torch.where(recovering&upper_ready,upper_ready_time+.005,0.)
                recovering &= ~(upper_ready&(upper_ready_time>=hand.get('upper_ready_hold_s',0.)))
                governed=middle.before(pose,zero_mask=zero|(recovering if gate_upper else False))
                ctl.config['wc']=torch.where(phase>=2,recovery_wc,controller_config['wc'])
                feedback_speed=torch.where((phase>=2)&body_feedback,speed,m[:,5]*.07)
                enable_eso=torch.full((n,),t>3.,device=device)
                enable_eso &= (phase<2)|(middle.lane_ticks*.005>=recovery_eso_delay)
                if gate_eso:enable_eso &= (phase<2)|((m[:,0].abs()<.08)&(m[:,1].abs()<.4))
                command=ctl.step(torch.stack((feedback_speed,m[:,2],m[:,3],m[:,0],m[:,1],governed[:,1]),1),enable_eso,torch.where(phase>=2,recovery_eso,1.))
                steer=command[:,0].clamp(-3,3);steer=torch.maximum(((-.8-m[:,2])/.005).clamp_min(-3),torch.minimum(((.8-m[:,2])/.005).clamp_max(3),steer))
                ground_target=torch.stack(((target[:,0]+.005*steer).clamp(-.8,.8),governed[:,0]/.07,lock[:,0],lock[:,1]),1).clamp(lo,hi)
                if tick%4==0:
                    action,rb_ctrl=infer(obs,data.qpos[:,idx.knee_qpos_address],swing_scale)
                    rb_target=to_torch(rb_ctrl).clone()
                    correction=(-.5*wrap(pose[:,2]-middle.projection['heading'])-.4*middle.projection['cross_track']).clamp(-rb_guidance,rb_guidance)
                    guide=(far_time>=0)&(m[:,0].abs()<.15)&(m[:,1].abs()<.6)
                    rb_target[:,0]=(rb_target[:,0]+torch.where(guide,correction,0.)).clamp(lo[0],hi[0])
                    delivered=to_torch(action).clone();delivered[:,0]=rb_target[:,0]/hi[0]
                    rb_controls=(phase==1)|(phase==3)|((phase==4)&lock_first)
                    last=jp.where(to_jax(rb_controls&alive)[:,None],to_jax(delivered),last)
                    target=torch.where(rb_controls[:,None],rb_target,target)
                if align_landing:
                    aligned=target[:,0]+(middle.nominal[:,1]-target[:,0]).clamp(-.015,.015)
                    ground_target[:,0]=torch.where((phase==3)&(~flags[:,0] if home_landing else True),aligned,ground_target[:,0])
                home_targets=home_pose.expand(n,2).clone()
                pitch_assist=landing_pitch_k*angles[:,1]+landing_pitch_d*v[:,4]
                home_targets[:,0]=(home_targets[:,0]+torch.where(far_time<0,pitch_assist,0.)).clamp(lo[2],hi[2])
                ground_target[:,2:]=torch.where((phase==3)[:,None],home_targets if home_landing else target[:,2:],ground_target[:,2:])
                ground_target[:,2:]=torch.where((phase==4)[:,None],home_pose,ground_target[:,2:])
                if home_compensation:
                    compensated=(home_pose+joint_bias/joint_kp).clamp(lo[2:],hi[2:])
                    ground_target[:,2:]=torch.where((phase==4)[:,None],compensated,ground_target[:,2:])
                if lock_first:
                    # RB owns wheels throughout physical homing; STTW starts only after locking.
                    ground_target[:,:2]=torch.where((phase==4)[:,None],target[:,:2],ground_target[:,:2])
                if not cfg.get('shared_adapters',False) or audit_owner:legacy_target=torch.where(ground_mode[:,None],ground_target,target)
                if cfg.get('shared_adapters',False):
                    target=jump_adapter.select(phase,ground_target,target,joint_bias)
                    if audit_owner:ownership_error=torch.maximum(ownership_error,(target-legacy_target).abs().amax(-1))
                else:target=legacy_target
                if lock_first:
                    delta=target[:,2:]-home_pose
                    span=torch.where(delta>=0,hi[2:]-home_pose,home_pose-lo[2:]).clamp_min(1e-6)
                    actual=to_torch(last).clone();actual[:,2:]=(delta/span).clamp(-1,1)
                    last=jp.where(to_jax((phase==4)&alive)[:,None],to_jax(actual),last)
                if p0_branches is not None:
                    p0_branches.actor_command(tick,alive,phase,middle,target)
                if cfg.get('collect_model_state'):
                    applied_rows.append(target.clone());applied_masks.append(alive.clone())
                if online:
                    launch=alive & ((phase==1)|(phase==3)) & (~flags[:,0]) & (substep_loads[:,-1,:3]<=1e-5).all(1) & (substep_loads[:,-1,3]==0) & (v[:,2]>0) & (q[:,0]>terrain['front_x_m']-1.5) & (pulse_start<0)
                    pulse_start=torch.where(launch,tick,pulse_start)
                    applied=alive & (pulse_start>=0) & (tick-pulse_start<20) & (force!=0)
                    data=data.replace(qfrc_applied=data.qfrc_applied.at[:,1].set(to_jax(torch.where(applied,force,0.))))
                    pulse_ticks+=applied.long()
                if tick in pulse_edges:
                    # Free-root translation uses world axes. Leave all other lanes and DOFs untouched.
                    lane=pulse['lane']
                    data=data.replace(qfrc_applied=data.qfrc_applied.at[lane,1].set(pulse_edges[tick]))
                    receipt=dict(tick=tick,time_s=tick*.005,lane=lane,world_y_force_n=float(data.qfrc_applied[lane,1]))
                    with (args.output/'applied_pulse.jsonl').open('a') as stream:
                        stream.write(json.dumps(receipt)+'\n')
                step_args=(data,to_jax(target),to_jax(lock),to_jax(torch.where(phase>=2,landing_damping,.1)),to_jax(phase==1 if align_landing else ((phase==1)|(phase==3))),to_jax((phase==0)|(phase==2)),to_jax(alive))
                if tick==start_tick and cfg.get('physics_repeat_probe'):
                    probe=cfg['physics_repeat_probe']
                    outputs=[probe_first_substep(*step_args) for _ in range(probe['repeats'])]
                    low=jax.tree.map(lambda *xs:jp.min(jp.stack(xs),axis=0),*outputs)
                    ranges=jax.tree.map(lambda lo,*xs:(jp.max(jp.stack(xs),axis=0)-lo).reshape(n,-1).max(1),low,*outputs)
                    measured={k:np.asarray(v)[probe['lanes']].tolist() for k,v in ranges.items()}
                    (args.output/'physics_repeat_probe.json').write_text(json.dumps(dict(tick=tick,**probe,span=measured),indent=2))
                if telemetry:
                    data,jflags,loads=advance_with_contacts(*step_args);substep_loads=to_torch(loads)
                else:data,jflags=advance(*step_args)
                flags=to_torch(jflags)
                q,v,m,pose,speed,angles,joint_bias=map(to_torch,observe(data))
                middle.after(m,pose,speed,governed,torch.stack((steer,target[:,1]),1),torch.zeros(n,2,device=device),ctl)
                if p0_branches is not None:
                    p0_branches.pursuit_read(tick+1,alive,phase,middle)
                if (tick+1)%4==0:
                    if ground_action_history:
                        # Last actuator target in the observed 20 ms interval, in actor units.
                        delta=target[:,2:]-home_pose
                        span=torch.where(delta>=0,hi[2:]-home_pose,home_pose-lo[2:])
                        ground_action=torch.cat((target[:,:1]/hi[0],
                            (target[:,1:2]-action_mapping.base_rear_speed)/action_mapping.rear_speed_delta,
                            delta/torch.where(delta==0,1.,span)),dim=1).clamp(-1,1)
                        last=jp.where(to_jax(alive&((phase==0)|(phase==2)))[:,None],to_jax(ground_action),last)
                    if use_apex:
                        rb_events,signal=native_signal(rb_events,data,to_jax(~alive))
                    else:
                        signal=(data.qpos[:,0]>=signal_window[0])&(data.qpos[:,0]<=signal_window[1])
                    history,obs=frame(data,history,last,height_offset,signal)
            torch.cuda.synchronize();rollout_s=time.perf_counter()-rollout_start
            if p0_branches is not None:p0_branches.finish()
            if live_ground is not None:live_ground.save(args.output)
            traces=torch.stack(rows).cpu().numpy();positions=torch.stack(poses).cpu().numpy();speeds=torch.stack(velocities).cpu().numpy();valid=torch.stack(valid_rows).cpu().numpy();contact_trace=torch.stack(contact_rows).cpu().numpy();world_trace=torch.stack(world_rows).cpu().numpy();ownership_max=ownership_error.cpu().numpy()
            if cfg.get('collect_model_state'):
                controller_trace=torch.stack(controller_rows).cpu().numpy()
                rb_state_trace=torch.stack(rb_state_rows).cpu().numpy()
                (args.output/'rb_state_schema.json').write_text(json.dumps(dict(frames=list(history.frames.shape[1:]),valid_count=[],observation=list(obs.shape[1:]),previous_action=list(last.shape[1:]),timing='pre-control, after phase events, same timestamp as qpos'),indent=2))
                applied_trace=np.full((len(rows),n,4),np.nan,dtype=np.float32);applied_valid=np.zeros((len(rows),n),dtype=bool)
                applied_trace[:len(applied_rows)]=torch.stack(applied_rows).cpu().numpy()
                applied_valid[:len(applied_masks)]=torch.stack(applied_masks).cpu().numpy()
                for anchor_tick,anchor_snapshot in collected_snapshots.items():
                    with (args.output/f'{name}_anchor_{anchor_tick:05d}.pkl').open('wb') as stream:pickle.dump(anchor_snapshot,stream,protocol=pickle.HIGHEST_PROTOCOL)
                if cfg.get('capture_handoff_stages'):
                    (args.output/f'{name}_stage_anchors.json').write_text(json.dumps(stage_anchors,indent=2))
                (args.output/'snapshot_anchors.json').write_text(json.dumps(dict(ticks=sorted(collected_snapshots),lower_dt_s=.005,timing='before events and control at tick; full batched runtime, not per-lane RB-entry snapshot'),indent=2))
                with (args.output/f'{name}_initial_snapshot.pkl').open('wb') as stream:pickle.dump(initial_snapshot,stream,protocol=pickle.HIGHEST_PROTOCOL)
                (args.output/'controller_schema.json').write_text(json.dumps(controller_schema,indent=2))
                (args.output/'model_state_schema.json').write_text(json.dumps(dict(qpos_names=['root_x','root_y','root_z','qw','qx','qy','qz']+[model.joint(i).name for i in range(1,model.njnt)],qvel_names=['world_vx','world_vy','world_vz','body_wx','body_wy','body_wz']+[model.joint(i).name for i in range(1,model.njnt)],steer_qpos=idx.steering_qpos_address,steer_dof=idx.steering_dof_address,front_dof=idx.frontwheel_dof_address,rear_dof=idx.rearwheel_dof_address,lower_dt_s=.005,model_dt_s=.02,history_timing='pre-control after phase events; prior target in trace; initial complete snapshot separately saved'),indent=2))
            load_trace=torch.stack(load_rows).cpu().numpy() if telemetry else None
            codes,durations,entry_time,far_time,handoff_time,hold,airborne=[x.cpu().numpy() for x in (codes,durations,entry_time,far_time,handoff_time,hold,airborne)]
            if online:
                online_end=torch.stack((directions,pulse_start,pulse_ticks,query_pass),1).cpu().numpy()
                query_clock=query_ms.cpu().numpy()
                if latency:delay_receipt=torch.stack((proposed,release,applied_tick),1).cpu().numpy()
            for lane,(route_id,mode,variant) in enumerate(lanes):
                case_dir=f'{case_name}_route{route_id}_{mode}'+(f'_v{variant}' if len(variants)>1 else '')
                target_dir=args.output/case_dir;target_dir.mkdir();keep=valid[:,lane];trace=traces[keep,lane];qsave=positions[keep,lane]
                contact_data={}
                if cfg.get('collect_model_state'):
                    contact_data.update(controller_state=controller_trace[keep,lane],rb_state=rb_state_trace[keep,lane],applied_targets=applied_trace[keep,lane],applied_target_valid=applied_valid[keep,lane],applied_target_timing='after phase events and controller selection, applied over [time,time+0.005); false at terminated/final rows')
                if telemetry:
                    samples=load_trace[keep,lane]
                    contact_data.update(dict(contact_substep=samples,contact_substep_columns=['front_normal_N','rear_normal_N','body_normal_N','body_contact'],contact_physics_dt_s=.005/args.physics_substeps,contact_interval_mean_N=samples[:,:,:3].mean(1),contact_interval_peak_N=samples[:,:,:3].max(1),contact_interval_impulse_Ns=samples[:,:,:3].sum(1)*(.005/args.physics_substeps)))
                np.savez_compressed(target_dir/'trajectory.npz',**contact_data,trace=trace,qpos=qsave,qvel=speeds[keep,lane],world_flags=world_trace[keep,lane],world_flag_columns=['physical_map_exit','nonwheel_terrain_contact','forbidden_obstacle_contact'],wheel_contact_flags=contact_trace[keep,lane],wheel_contact_columns=['any_terrain','any_far','both_far'],reference_xy=route.xy[lane].cpu().numpy() if continuous_routes is not None else (approach_ref['xy'] if paired_departures else saved['xy'])[route_id],published_reference_xy=route.xy[route.route_ids[lane]].cpu().numpy(),columns=['time','x','y','z','roll','pitch','yaw','vx','vy','vz','ground_active','path_distance','steer_target','rear_target','hip_target','knee_target','approaching','rear_rate_rad_s','requested_speed_m_s','phase'])
                row=dict(continuation_alpha=continuation_alpha,case_dir=case_dir,variant=variants[variant],skill=case_name,route=route_id,continuation=mode,termination=['timeout','physical_failure','tracking_domain_exit' if world else 'corridor_or_domain_exit','goal','world_boundary_exit','forbidden_obstacle_contact'][codes[lane]],actuator_owner_max_difference=float(ownership_max[lane]) if audit_owner else None,nonwheel_contact_steps=int(world_trace[keep,lane,1].sum()),forbidden_contact_steps=int(world_trace[keep,lane,2].sum()),goal=bool(codes[lane]==3),rb_entry_s=None if entry_time[lane]<0 else float(entry_time[lane]),goal_hold_s=float(hold[lane]),airborne=bool(airborne[lane]),far_contact=bool(far_time[lane]>=0),first_far_contact_s=None if far_time[lane]<0 else float(far_time[lane]),handoff_s=None if handoff_time[lane]<0 else float(handoff_time[lane]),duration_s=float(durations[lane]),final_xy=positions[-1,lane,:2].tolist())
                if continuous_routes is not None:
                    row.update(approach_published_tick=int(continuous_routes.published_tick[lane]),handoff_join=int(continuous_routes.handoff_join[lane]),handoff_geometry_batch_ms=float(continuous_routes.geometry_ms[lane]))
                if online:
                    dep,onset,ticks,admitted=online_end[lane]
                    if latency:
                        proposed_dep,due,applied=delay_receipt[lane]
                        row.update(proposed_departure=int(proposed_dep),departure_due_tick=int(due),departure_applied_tick=int(applied),
                                   initial_release_tick=latency['start'] if continuous_routes is None else int(continuous_routes.published_tick[lane]))
                    row.update(selected_departure=int(dep),air_event_tick=int(onset),applied_force_ticks=int(ticks),query_batch_ms=float(query_clock[lane]),handoff_query_feasible=bool(admitted))
                if cfg.get('collect_model_state') and not cfg.get('task_evaluation'):row['completed_slice']=bool(codes[lane]==0)
                if rolling is not None:
                    row.update(planning_failed=bool(rolling.failed[lane]),final_candidate=int(rolling.active[lane]),final_route=int(rolling.current_route[lane]),final_activation_x_m=float(jump_start[lane]))
                results.append(row)
            all_timing.append(dict(skill=case_name,lanes=n,initialization_s=0. if replay else init_s,rollout_s=rollout_s,simulated_ticks_per_lane=tick-start_tick))
            if rolling is not None:(args.output/f'{case_name}_rolling_events.json').write_text(json.dumps(rolling_events,indent=2))
            (args.output/f'{case_name}_plan_receipts.json').write_text(json.dumps(plan_receipts,indent=2))
            if snapshot_tick is not None and not replay:
                with (args.output/f'{name}_runtime_snapshot.pkl').open('wb') as stream:pickle.dump(replay_snapshot,stream,protocol=pickle.HIGHEST_PROTOCOL)
    (args.output/'status.json').write_text(json.dumps(dict(stage='complete',completed=len(results),total=len(results),elapsed_s=time.perf_counter()-started,results=results),indent=2))
    (args.output/'timing.json').write_text(json.dumps(dict(total_s=time.perf_counter()-started,batches=all_timing,execution='GPU MJX-Warp vmap, GPU H75/ECBC/ESO and RB inference, DLPack, terminal-only trajectory download'),indent=2))

"""Frozen native RB -> STTW trial using Playground MJX stepping; no learning."""
import argparse
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET
os.environ.setdefault('XLA_PYTHON_CLIENT_PREALLOCATE', 'false')
import numpy as np
import mujoco
from mujoco import mjx
# Increase per-pair heightfield contact workspace, retaining the original terrain surface.
import warp as wp
from mujoco.mjx.third_party.mujoco_warp._src import collision_convex
collision_convex.MJ_MAXCONPAIR = 512
collision_convex.vec_maxconpair = wp.types.vector(length=512, dtype=float)
collision_convex.mat_maxconpair = wp.types.matrix(shape=(512, 3), dtype=float)
import torch
from sttw_control.ditch_terrain import build_ditch_terrain, split_flat_lips
from sttw_control.runtime import configure_compilation_cache
from sttw_control.pendulum_skill import PendulumSkill
from jit_dvgc.model import _build_index


def platform_rough_sections(root, terrain):
    """Use the Chapter 3 bank grids outside the two flat metres on either side."""
    world, assets, contacts = root.find('worldbody'), root.find('asset'), root.find('contact')
    source = terrain['rough_source']
    _, _, patches = build_ditch_terrain(source, return_patches=True)
    near, far = [patch for patch in patches if len(patch[0]) > 2]
    front, height = terrain['front_x_m'], terrain['far_bank_height_m']
    width = source['width_m']
    floor, step = (world.find(f"geom[@name='{name}']") for name in ('floor','step'))
    floor.attrib.update(type='box', size='20 4 1', pos=f'{front-2+20} 0 -1')
    step.set('size','1 1 .16')
    step.set('pos',f'{front+1} 0 {height-.16}')
    cut = near[0][0]
    ET.SubElement(world,'geom',dict(floor.attrib,name='flat_lip_start',size=f'{(cut+5)/2} 4 1',pos=f'{(cut-5)/2} 0 -1'))
    def copy_pairs(src, dst):
        for pair in list(contacts):
            if pair.get('geom1') == src:
                ET.SubElement(contacts,'pair',dict(pair.attrib,geom1=dst))
    copy_pairs('floor','flat_lip_start')
    heights=[]
    for name,patch,src in [('approach_rough',near,'floor'),('platform_rough',far,'step')]:
        x,y,z=patch
        if src=='floor':
            take=x<=front-2+1e-6
            x,z=x[take],z[take]
        else:
            take=x>=front+width+2-1e-6
            inside=np.abs(y)<=1+1e-6
            x,y,z=x[take]-width,y[inside],z[take][:,inside]+height-source['far_bank_height_m']
        low=float(z.min());scale=float(z.max()-low)
        ET.SubElement(assets,'hfield',name=name,nrow=str(len(x)),ncol=str(len(y)),
                      size=f'{np.ptp(y)/2} {np.ptp(x)/2} {scale} .1')
        ET.SubElement(world,'geom',name=name,type='hfield',hfield=name,contype='1',conaffinity='15',
                      pos=f'{(x[-1]+x[0])/2} 0 {low}',quat='.7071067811865476 0 0 .7071067811865476',rgba='.46 .40 .31 1')
        copy_pairs(src,name)
        heights.append(((z[::-1]-low)/scale).astype(np.float32))
    return heights


def transplant(bundle, terrain, output, physics_substeps=1, ground_physics=None):
    """Use each original Isaac rectangular patch without resampling its heights."""
    root = ET.parse(bundle.xml_path).getroot()
    root.find('compiler').set('meshdir', str(bundle.xml_path.parent/'meshes'))
    root.find('option').set('timestep', str(.005/physics_substeps))
    root.find('option').set('ccd_iterations', '100')
    world, assets = root.find('worldbody'), root.find('asset')
    ground_physics = ground_physics or {}
    surface = terrain.get('surface')
    if surface in ('native_step', 'level_gap'):
        floor = world.find("geom[@name='floor']")
        step = world.find("geom[@name='step']")
        front = terrain['front_x_m']
        half_length, half_width, half_height = map(float, step.get('size').split())
        step.set('pos', f'{front + terrain["width_m"] + half_length} 0 {terrain["far_bank_height_m"] - half_height}')
        if surface == 'level_gap':
            floor.set('type', 'box')
            floor.set('pos', f'{front - 20} 0 -1')
            floor.set('size', '20 10 1')
        bank_names = ['floor', 'step']
        heights = platform_rough_sections(root,terrain) if 'rough_source' in terrain else []
    else:
        for name in ('floor', 'step'):
            geom = world.find(f"geom[@name='{name}']")
            geom.set('contype', '0'); geom.set('conaffinity', '0'); geom.set('rgba', '0 0 0 0')
        anchor=world.find("geom[@name='step']")
        anchor.set('pos', f"{terrain['front_x_m']+float(anchor.get('size').split()[0])} 0 0")
        # Explicit pairs bypass contype/conaffinity; remove the replaced ground contacts.
        contacts = root.find('contact')
        native_wheel_pairs=[dict(pair.attrib) for pair in contacts if pair.get('geom1')=='floor' and pair.get('geom2') in ('frontwheel_collision','rearwheel_collision')]
        for pair in list(contacts):
            if pair.tag == 'pair' and {pair.get('geom1'), pair.get('geom2')} & {'floor', 'step'}:
                contacts.remove(pair)
        vertices, triangles, patches = build_ditch_terrain(terrain, return_patches=True)
        boxes = []
        if ground_physics.get('analytic_flat_lips'):
            patches, boxes = split_flat_lips(patches, terrain['front_x_m'], terrain['front_x_m']+terrain['width_m'])
        bank_names = [f'bank{i}' for i in range(len(patches))]
        for i,(xmin,xmax,ymin,ymax,z) in enumerate(boxes):
            name=f'flat_lip_{i}';bank_names.append(name)
            ET.SubElement(world,'geom',name=name,type='box',size=f'{(xmax-xmin)/2} {(ymax-ymin)/2} .05',
                          pos=f'{(xmax+xmin)/2} {(ymax+ymin)/2} {z-.05}',contype='1',conaffinity='15',
                          friction='.8 .005 .0001',rgba='.45 .38 .25 1')
        heights = []
        for i, (xs, ys, zz) in enumerate(patches):
            bottom=float(zz.min()); scale=max(float(zz.max()-bottom),1e-6)
            ET.SubElement(assets,'hfield',name=f'bank{i}',nrow=str(len(xs)),ncol=str(len(ys)),size=f'{(ys[-1]-ys[0])/2} {(xs[-1]-xs[0])/2} {scale} .1')
            ET.SubElement(world,'geom',name=f'bank{i}',type='hfield',hfield=f'bank{i}',pos=f'{(xs[-1]+xs[0])/2} {(ys[-1]+ys[0])/2} {bottom}',quat='.7071067811865476 0 0 .7071067811865476',friction='.8 .005 .0001',contype='1',conaffinity='15',rgba='.45 .38 .25 1')
            # Rotate local grid 90 degrees so MuJoCo's cell diagonal matches Isaac.
            heights.append(((zz[::-1,:]-bottom)/scale).astype(np.float32))
        if ground_physics.get('native_wheel_contacts',False):
            for bank in bank_names:
                for pair in native_wheel_pairs:ET.SubElement(contacts,'pair',**dict(pair,geom1=bank))
    for i,(xmin,xmax,ymin,ymax) in enumerate(terrain.get('forbidden_rectangles',[])):
        height=terrain.get('obstacle_height_m',.5)
        base = terrain['far_bank_height_m'] if surface=='native_step' else 0.
        ET.SubElement(world,'geom',name=f'planning_obstacle_{i}',type='box',
            pos=f'{(xmin+xmax)/2} {(ymin+ymax)/2} {base+height/2}',
            size=f'{(xmax-xmin)/2} {(ymax-ymin)/2} {height/2}',
            contype='1',conaffinity='15',friction='.8 .005 .0001',rgba='.65 .18 .12 1')
    if 'integrator' in ground_physics:
        root.find('option').set('integrator',ground_physics['integrator'])
    if ground_physics.get('steering_velocity_gain') is not None:
        actuator=root.find("actuator/position[@joint='steering_joint']")
        actuator.tag='velocity'; actuator.attrib.pop('kp'); actuator.set('kv',str(ground_physics['steering_velocity_gain']))
        actuator.set('ctrlrange','-3 3')
    if 'friction' in ground_physics:
        for geom in root.findall('.//geom'):
            if geom.get('name') in ('frontwheel_collision','rearwheel_collision') or geom.get('name') in bank_names:
                geom.set('friction',f"{ground_physics['friction']} .005 .0001")
    if ground_physics.get('wheel_collision') == 'cylinder':
        for name in ('frontwheel_collision','rearwheel_collision'):
            geom=root.find(f".//geom[@name='{name}']")
            geom.set('type','cylinder'); geom.set('size','.07 .025')
    equality=root.find('equality')
    if equality is None:equality=ET.SubElement(root,'equality')
    for joint in ('hip_joint','knee_joint'):
        ET.SubElement(equality,'joint',name=f'ground_brake_{joint}',joint1=joint,active='false',solref='.002 1',solimp='.9999 .9999 .001 .5 2')
    path=output/'terrain.xml'; ET.ElementTree(root).write(path)
    model=mujoco.MjModel.from_xml_path(str(path))
    for i,z in enumerate(heights):
        adr=model.hfield_adr[i]; model.hfield_data[adr:adr+z.size]=z.ravel()
    mujoco.mj_saveModel(model,str(output/'terrain.mjb'),None)
    if surface not in ('native_step', 'level_gap'):
        np.savez_compressed(output/'terrain_source.npz',vertices=vertices,triangles=triangles,**{f'hfield{i}':z for i,z in enumerate(heights)})
    return model


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--registry',type=Path,default=Path('learning/configs/playground_rb_skill_sources.json'))
    p.add_argument('--config',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
    p.add_argument('--skills',nargs='+',default=['source','rb_run1','rb_run2','rb_run3'])
    p.add_argument('--modes',nargs='+',choices=['h75','zero_middle'],default=['h75','zero_middle'])
    p.add_argument('--model',type=Path,help='Reuse an existing terrain MJB from this task')
    p.add_argument('--approach', choices=['h75'], default='h75')
    p.add_argument('--routes',nargs='+',type=int,default=[60,61,62]); p.add_argument('--seconds',type=float,default=10)
    p.add_argument('--physics-substeps',type=int,default=1,choices=[1,5,25],help='Physics substeps per unchanged 5 ms controller tick')
    p.add_argument('--ground-only',action='store_true',help='Keep ground control throughout; no RB activation')
    a=p.parse_args(); configure_compilation_cache('/home/qy/STTW_CONTROL/runs/.jax_compilation_cache'); a.output.mkdir(parents=True,exist_ok=False); torch.set_num_threads(1)
    cfg=json.loads(a.config.read_text())
    if cfg.get('fixed_order_tree_reductions',False):
        from sttw_control.playground_tree_reductions import enable
        enable()
    if 'world_map' in cfg:
        world=json.loads(Path(cfg['world_map']).read_text())
        cfg=dict(cfg,world_map_spec=world,ditch_terrain=world['terrain'],ground_handoff=dict(cfg['ground_handoff'],goal=world['goal']))
        activation=world['terrain']['front_x_m']+cfg.get('planned_activation_offset_m',world['forward_obstacle']['activation_offset_m'])
        cfg['ground_handoff']['approach']['jump_start_x_m']=activation
        for variant in cfg['ground_handoff'].get('handoff_variants',[]):
            variant['jump_start_x_m']=(world['terrain']['front_x_m']+variant['activation_offset_m']
                                       if 'activation_offset_m' in variant else activation)
    hand=cfg['ground_handoff']; terrain=cfg['ditch_terrain']
    if cfg.get('shared_adapters') and not (hand['landing_control']=='native' and hand['sttw_only_after_lock'] and hand['staged_native_handoff']):
        raise ValueError('Shared adapters require the frozen native landing and lock-first completion contract')
    if 'snapshot_replay_s' in cfg and not 0<=cfg['snapshot_replay_s']<a.seconds:
        raise ValueError('snapshot time must lie within the rollout')
    if 'snapshot_branch_continuation_alpha' in cfg and ('snapshot_replay_s' not in cfg or not 0<=cfg['snapshot_branch_continuation_alpha']<=1):
        raise ValueError('Snapshot alpha branch requires a replay anchor and alpha in [0,1]')
    if 'snapshot_branch_continuation_speed_m_s' in cfg and ('snapshot_replay_s' not in cfg or cfg['snapshot_branch_continuation_speed_m_s'] not in (1.8,1.9)):
        raise ValueError('Post-handoff speed branch requires a replay anchor and a validated 1.8 or 1.9 m/s request')
    if cfg.get('verify_active_jump') and not cfg.get('contact_substep_telemetry'):
        raise ValueError('Jump verification needs substep contact telemetry')
    native_step_5ms = terrain.get('surface') == 'native_step' and a.physics_substeps == 1
    if cfg.get('contact_substep_telemetry') and (cfg.get('rb_physics') or (a.physics_substeps!=5 and not native_step_5ms)):
        raise ValueError('Contact telemetry needs shared physics at the declared terrain sampling rate')
    ground_physics=cfg.get('ground_physics',{})
    rb_physics=cfg.get('rb_physics')
    if rb_physics and rb_physics != {'integrator':'RK4','physics_dt_s':.005}:
        raise ValueError('RB native runtime requires RK4 at 5 ms')
    velocity_steering='steering_velocity_gain' in ground_physics
    if ground_physics and a.model:
        raise ValueError('Physics adaptation requires a freshly built model')
    if velocity_steering and not a.ground_only:
        raise ValueError('RB requires its native position steering actuator')
    bundle=Path(hand['bundle']); identity=json.loads((bundle/'identity.json').read_text()); hcfg=json.loads((bundle/'config.json').read_text())
    controller=json.loads(Path(json.loads(Path(hand['settings']).read_text())['controller_config']).read_text())
    if 'nominal_steer_slew_rad_s' in hand:hcfg['follower']['nominal_steer_slew_rad_s']=hand['nominal_steer_slew_rad_s']
    overrides=hand.get('follower_overrides',{})
    if set(overrides)-set(hcfg['follower']):raise ValueError('Unknown follower override')
    hcfg['follower'].update(overrides)
    skills={name:PendulumSkill(a.registry,name) for name in a.skills}
    for name,path in cfg.get('rb_adaptation_bundles',{}).items():skills[name].load_adapted_actor(path)
    original=next(iter(skills.values())).bundle; idx=original.model_index
    model=mujoco.MjModel.from_binary_path(str(a.model)) if a.model else transplant(original,terrain,a.output,a.physics_substeps,ground_physics)
    if cfg.get('contact_substep_telemetry') and model.opt.cone!=mujoco.mjtCone.mjCONE_ELLIPTIC:
        raise ValueError('Contact telemetry requires the frozen elliptic cone')
    if not np.isclose(model.opt.timestep,.005/a.physics_substeps):
        raise ValueError('Cached terrain model physics dt differs from requested substeps; rebuild it')
    if cfg.get('canonical_constraint_rows'):
        if model.opt.cone!=mujoco.mjtCone.mjCONE_ELLIPTIC:
            raise ValueError('Canonical constraint rows require the elliptic contact model')
        from sttw_control.playground_constraint_order import enable as order_constraint_rows
        order_constraint_rows()
    if cfg.get('ordered_solver_reductions'):
        if not cfg.get('canonical_constraint_rows'):
            raise ValueError('Ordered solver reductions use canonical elliptic constraint rows')
        from sttw_control.playground_solver_order import enable as order_solver
        order_solver()
    idx=_build_index(model); mm=mjx.put_model(model,impl='warp')
    brake_ids=np.array([mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_EQUALITY,f'ground_brake_{joint}') for joint in ('hip_joint','knee_joint')])
    if (brake_ids<0).any():raise ValueError('Cached model lacks STTW pendulum brakes; rebuild it')
    if 'ground_suite' in cfg:
        if not a.ground_only:raise ValueError('Ground suite does not execute RB')
        from sttw_control.playground_ground_evaluation import evaluate_ground_suite
        evaluate_ground_suite(model,mm,idx,cfg,bundle,hcfg,identity,controller,a.output,a.physics_substeps,brake_ids)
        return
    n=len(skills)*(len(cfg['evaluation_lanes']) if 'evaluation_lanes' in cfg else len(a.routes)*len(a.modes)*len(hand.get('handoff_variants',[{}])))
    if 'snapshot_replay_s' in cfg:n*=2+cfg.get('snapshot_memory_repeats',0)
    contract=dict(terrain_model=str(a.model) if a.model else str(a.output/'terrain.mjb'),role='bounded native Playground transfer DEV, no training',skills={k:s.record for k,s in skills.items()},terrain=terrain,source_config=str(a.config),routes=a.routes,episode_s=a.seconds,episodes=n,physics_steps_max=round(a.seconds/.005)*n*(a.physics_substeps+(1 if rb_physics else a.physics_substeps)),backend='MJX-Warp vmap; GPU Torch H75/ECBC/ESO; JAX RB; DLPack; final-only host export',heightfield_contact_workspace=512,physics_dt=.005/a.physics_substeps,physics_substeps=a.physics_substeps,lower_dt=.005,upper_dt=.02,ground_model=identity,goal=hand['goal'],road_half_width_m=hand['road_half_width_m'],start_x_m=hand.get('start_x_m',1.5),start_vx_m_s=hand.get('start_vx_m_s',2.),handoff=hand.get('handoff_mechanism','fixed contact delay'),handoff_delay_s=hand.get('handoff_delay_s',0.),approach=a.approach,ground_only=a.ground_only,jump_start_x_m=hand['approach']['jump_start_x_m'],scope='Declared approach controller then native RB jump then H75 or zero-middle STTW. No planning or training.',ground_physics=ground_physics,rb_physics=rb_physics,terrain_conversion='Original Isaac rectangular patches, coordinates and heights retained without interpolation; 90-degree local grid rotation matches original triangle diagonal',pendulum='STTW hip/knee equality brakes at entry posture; released during RB, relocked at measured handoff posture; native finite servos retained',observer='measured ESO initialization, empty H75 history at handoff')
    if cfg.get('collect_model_state'):
        contract.update(role=cfg['role'],scope='Bounded ground model collection; 4 s timeout denotes completed slice, not goal success. Splits are frozen in the collection manifest.',collect_model_state=True)
    if cfg.get('task_evaluation'):contract.update(scope=cfg['role'],completed_slice_semantics=False)
    if cfg.get('p0_branches'):
        # This protocol records contacts through one shared plant for ground and jump.
        contract.update(role=cfg['role'], physics_steps_max=round(a.seconds/.005)*n*a.physics_substeps,
                        unique_prefixes=n//cfg['p0_branches']['group_size'],
                        backend='MJX-Warp batched physics, Torch ground planning, JAX jump control; on-event handback and route exports')
    contract['fixed_order_tree_reductions']=cfg.get('fixed_order_tree_reductions',False)
    contract['ordered_solver_reductions']=cfg.get('ordered_solver_reductions',False)
    contract['canonical_constraint_rows']=cfg.get('canonical_constraint_rows',False)
    if terrain.get('surface') in ('native_step', 'level_gap'):
        contract['terrain_conversion'] = terrain['surface'] + ' analytic geometry, original XML collision pairs'
    contract['contact_substep_telemetry']=cfg.get('contact_substep_telemetry',False)
    contract['contact_timing']=f'Each sample is a solver load during one {5/a.physics_substeps:g} ms step; row t aggregates the preceding 5 ms, row zero has no interval and is NaN.'
    contract['snapshot_replay_s']=cfg.get('snapshot_replay_s')
    contract['planned_activation_offset_m']=cfg.get('planned_activation_offset_m')
    (a.output/'resolved_config.json').write_text(json.dumps(cfg,indent=2))
    contract.update(input_config=str(a.config),source_config=str(a.output/'resolved_config.json'),world_map=cfg.get('world_map_spec'),shared_adapters=cfg.get('shared_adapters',False))
    (a.output/'declaration.json').write_text(json.dumps(contract,indent=2))
    from sttw_control.playground_handoff_evaluation import evaluate_handoff
    evaluate_handoff(model,mm,idx,cfg,bundle,hcfg,identity,controller,skills,a,brake_ids)
    if cfg.get('verify_active_jump'):
        from audit_playground_jump import assess
        records = assess(a.output)
        (a.output/'jump_validation.json').write_text(json.dumps({
            'task_success_count': sum(row['task_success'] for row in records),
            'solid_bank_rear_launch_goal_count': sum(row['solid_bank_goal'] for row in records),
            'total': len(records), 'cases': records,
        }, indent=2) + '\n')



if __name__=='__main__':main()

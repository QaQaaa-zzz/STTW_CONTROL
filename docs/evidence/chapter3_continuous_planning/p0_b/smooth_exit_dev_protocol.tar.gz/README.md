# Chapter 3 bounded-curvature exit development experiment

The archive contains the frozen run declaration, both full lane configurations, the two map descriptions, single-vehicle timing, paired rollout, scoring, plotting and regression-test sources. The two receipts document the CPU example and service submission. Physical results are generated separately.

Keep the chapter3_* folders beside the original P0-B, P1 and margin-calibration run folders. The scripts use their recorded STTW_runs paths, the sttw-offroad project checkout, its MuJoCo/Warp, JAX and PyTorch environment and the original frozen checkpoints, route bank, initial conditions, geometry, archived trajectories and ground predictor named in the two configs. The sttw-offroad directory in this archive records the corresponding project sources; use them with the full project checkout. The native tools for project GPU scheduling and notifications come from that checkout.

Use chapter3_smooth_exit_dev_20261124/launch.sh with the frozen protocol.json in a fresh output copy at the registered location. The entry acquires the shared GPU slot, measures single-car latency, runs the two 792-world maps and then executes analyze.sh after releasing the GPU. For scoring and plotting already completed output, run analyze.sh with the same project PYTHONPATH as launch.sh. The complete declaration is protocol.json; prepare.py regenerates only the initial declaration and map configs from the historic P0-B development data.

SHA256SUMS lists the original file bytes using paths relative to the archive root.

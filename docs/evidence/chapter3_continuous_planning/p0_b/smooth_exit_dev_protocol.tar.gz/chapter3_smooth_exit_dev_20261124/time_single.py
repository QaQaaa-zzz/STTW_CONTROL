"""Measure the actual repaired planner for one vehicle with a known fixed reference."""
from copy import copy
from pathlib import Path
from time import perf_counter
from types import SimpleNamespace
import csv,json,sys
import numpy as np
import torch
from prepare import R,W,OLD,save
sys.path[:0]=[str(W/'learning/src'),str(W/'learning/cli')]
from benchmark_chapter3_continuous_exit import load_fixture
from sttw_control.chapter3_continuous_exit import ContinuousExitPlanner,committed_progress
from sttw_control.platform_online import velocity_state
from sttw_control.playground_adapters import GroundAdapter
from sttw_control.torch_middle_control import TorchMiddleControl

@torch.inference_mode()
def run():
    part=OLD/'right_offset/part_0/physical'
    traj=part/'rb_run1_route0_h75_v2/trajectory.npz'
    query,right_route,_,_,_,_,_,_=load_fixture(part,traj,torch.device('cuda'),None)
    twin=part/'rb_run1_route0_h75_v1/trajectory.npz'
    _,straight_route,_,_,_,_,_,_=load_fixture(part,twin,torch.device('cuda'),None)
    same_prefix=np.load(twin)
    with np.load(traj) as z:
        right_case=next(r for r in json.loads((part/'status.json').read_text())['results'] if r['case_dir']==traj.parent.name)
        release=right_case['departure_applied_tick']
        assert np.array_equal(same_prefix['qpos'][:release],z['qpos'][:release])
    same_prefix.close()
    route=right_route
    planner=ContinuousExitPlanner(query,route,mode='smooth_event',candidates=64,iterations=2,robots_per_chunk=1)
    middle=TorchMiddleControl.__new__(TorchMiddleControl);middle.v_user=route.s.new_tensor([2.]);middle.route=route
    adapter=GroundAdapter(middle,None)
    with np.load(traj) as z:
        q,v=[torch.as_tensor(z[key],device='cuda',dtype=torch.float32) for key in ['qpos','qvel']]
        tr=z['trace'];cols=z['columns'].tolist()
    xx=tr[:,cols.index('x')];yy=tr[:,cols.index('y')]
    sec=12.7
    hit=np.flatnonzero((xx[:-1]<sec)&(xx[1:]>=sec))[0]
    ycross=yy[hit]+(sec-xx[hit])/(xx[hit+1]-xx[hit])*(yy[hit+1]-yy[hit])
    phase=tr[:,cols.index('phase')];eligible=np.flatnonzero((phase==2)&(np.arange(len(tr))%4==0))
    ticks=[int(eligible[0]),int(eligible[-5]),int(eligible[len(eligible)//2])]
    def call(tick,side):
        route=right_route if tick>=release else straight_route
        middle.tick=tick;middle.route=route
        start=perf_counter()
        twists=velocity_state(q[[tick,tick-4]],v[[tick,tick-4]])
        i=(route.xy[0]-q[tick,:2]).square().sum(-1).argmin().view(1)
        progress=route.s[i];cfg=query.model.nominal.follower
        look=(twists[:1,0].clamp_min(cfg['lookahead_min_speed_m_s'])*cfg['lookahead_time_s']).clamp(cfg['lookahead_min_m'],cfg['lookahead_max_m'])*cfg.get('lookahead_scale',1.)
        middle.projection={'progress':progress};middle.follower={'lookahead':look}
        committed=committed_progress(progress,look,middle.v_user,.1).clamp_max(route.s[-1])
        gate=0 if tick<=hit else (1 if side*ycross>=.06 and abs(ycross)<=3.9 else -1)
        g=query.goal
        hitgoal=(xx>=g['x_min_m'])&(xx<=g['x_max_m'])&(abs(yy)<=g['abs_y_max_m'])
        # Use snapshots before terminal hold, avoiding replay of an unmeasured hold timer.
        if hitgoal[tick]:return None
        res=planner.plan(q[tick:tick+1],twists[:1],twists[1:],route,committed,sec,side,10.-tick*.005,gate_status=gate)
        accepted=bool(res.admitted[0]);kept=bool(res.incumbent_admitted[0])
        if accepted and not kept:
            replacement=copy(route);replacement.xy,replacement.heading,replacement.curvature=res.xy,res.heading,res.curvature
            adapter.update_plan(replacement,committed,middle.tick*.005,adapter.plan_version)
        torch.cuda.synchronize()
        return dict(kind='search' if bool(res.searched[0]) else 'monitor',tick=tick,gate=gate,side=side,admitted=accepted,kept=kept,ms=(perf_counter()-start)*1000)
    taps={};cold=[]
    # Prefer a still-live correct passage over an irrecoverable wrong gate for the monitor example.
    extra=eligible[(xx[eligible]>12.8)&(xx[eligible]<16.)][::20].tolist()
    for tick in ticks+extra:
        for side in (-1,1):
            v0=call(tick,side)
            if v0 is not None:
                cold.append(v0);k=v0['kind']
                if k not in taps or (k=='monitor' and v0['kept']):taps[k]=v0
        if 'monitor' in taps and taps['monitor']['kept'] and 'search' in taps:break
    assert set(taps)=={'monitor','search'}
    rows=[];times={}
    for kind,tap in sorted(taps.items()):
        repeat=[call(tap['tick'],tap['side']) for _ in range(105)]
        assert all(v['kind']==kind for v in repeat)
        times[kind]=[v['ms'] for v in repeat[5:]];rows.extend(dict(rep=i,**v) for i,v in enumerate(repeat[5:]))
    with (R/'single_robot_latency.csv').open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=rows[0]);wr.writeheader();wr.writerows(rows)
    save(R/'single_robot_latency.json',dict(fixture=str(traj),early_published_straight_fixture=str(twin),right_route_applied_tick=release,gate=sec,margin=query.margin,mode='smooth_event',robots=1,candidates=64,iterations=2,horizon_steps=255,cold_and_fixture_search=cold,selected=taps,measured_ms=times))
if __name__=='__main__':run()

"""Score the two observed DEV maps using their paired starts, original crossing and flight checks."""
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
import mujoco
from prepare import R,W,LAYOUTS,GATES,save,read
sys.path[:0]=[str(W/'learning/src'),str(W/'learning/cli')]
from analyze_chapter3_continuous_p0_branches import prefix_flight_force
from run_playground_task_reversal import crossings_by_section

def analyze():
    O=R/'analysis';O.mkdir(exist_ok=True);lanes=[];selected=[];releases=[]
    for name in LAYOUTS:
        f=R/name/'physical';cfg=read(R/name/'run.json');terrain=read(Path(cfg['world_map']))['terrain']
        model=mujoco.MjModel.from_binary_path(str(f/'terrain.mjb'))
        rows=read(f/'status.json')['results'];assert len(rows)==792
        audit=np.load(f/'p0_branch_audit.npz');old={};events={}
        for ln in (f/'p0_events.jsonl').open():
            a=json.loads(ln);k=a['kind']
            for i,j in enumerate(a['lanes']):
                rec={k:(v[i] if isinstance(v,list) else v) for k,v in a.items() if k!='lanes'}
                if k=='old_selection':old[j]=rec
                if k in ('query','publication','expired_keep_reference'):
                    events.setdefault(j,[]).append(rec)
        for file in sorted((f/'p0_published').glob('tick_*.npz')):
            tick=int(file.stem.split('_')[-1])
            with np.load(file) as z:
                for lane,curve in zip(z['lanes'],z['curvature']):
                    releases.append(dict(layout=name,lane=int(lane),tick=tick,peak_curvature=float(np.max(abs(curve))),path=str(file)))
        for lo in range(0,len(rows),11):
            group=rows[lo:lo+11];matched=bool(audit['pair_ok'][lo//11]) and len({r['handoff_s'] for r in group})==1
            paths=[f/r['case_dir']/'trajectory.npz' for r in group]
            truths=[];root=group[0]['variant']['bank_row'];geom=group[0]['variant']['geometry'];force=group[0]['variant']['force_y_N']
            for i,(r,p) in enumerate(zip(group,paths)):
                v=r['variant'];assert (root,geom,force)==(v['bank_row'],v['geometry'],v['force_y_N'])
                if i==0 or not matched:verified=prefix_flight_force(r,p,model,terrain)['verified']
                with np.load(p) as z: trace=z['trace']
                lock=r['handoff_s'];gates={a:(t,y) for a,x,t,y in crossings_by_section(trace,lock if lock is not None else np.inf,[12.7,13.6,15.])}
                lane=lo+i;ev=events.get(lane,[]);qs=[a for a in ev if a['kind']=='query'];pub=[a for a in ev if a['kind']=='publication']
                base=dict(layout=name,root=root,force=force,geometry=geom,lane=lane,arm=v['arm'],pair_ok=matched,verified=verified,
                          handoff_s=lock,departure_applied_tick=r.get('departure_applied_tick'),duration_s=r['duration_s'],phys_goal=bool(r['goal']),wall=bool(r['forbidden_contact_steps']),termination=r['termination'],path=str(p),group=lo,
                          queries=len(qs),searched=sum(a['searched'] for a in qs),renewed=sum(a['incumbent_renewed'] for a in pub),published=sum(a['published'] for a in pub),rejected=sum(not a['admitted'] for a in qs),missed=sum((a['due']-a['tick'])*5>100 for a in qs))
                lanes.append(base);bygate={}
                for g,side in GATES:
                    t,y=gates[g]
                    hit=y is not None and .06<=side*y<=3.9
                    bygate[g,side]=dict(**base,section=g,side=side,correct_gate=bool(hit),gate_time=t,gate_y=y,success=bool(verified and hit and base['phys_goal'] and not base['wall']))
                truths.append(bygate)
            for j,(sec,side) in enumerate(GATES):
                a,b=old.get(lo+3+j),old.get(lo+7+j)
                # A verified common handback must yield the same old three-exit choice on both counterfactual branches.
                consistent=(a is None and b is None) or (a and b and (a['choice'],a['admitted'])==(b['choice'],b['admitted']))
                if matched and not consistent:raise ValueError(f'Old control differs at {name}/{lo}/{j}')
                choice=int(a['choice']) if a else 1
                for method,i in [('old',choice),('single',3+j),('event',7+j)]:
                    selected.append(dict(**truths[i][sec,side],method=method,old_selector_observed=a is not None,primary=geom==(1 if side==1 else 0)))
    ll=pd.DataFrame(lanes);ll.to_csv(O/'physical_lanes.csv.gz',index=False)
    data=pd.DataFrame(selected);data.to_csv(O/'selected_tasks.csv.gz',index=False)
    pd.DataFrame(releases,columns=['layout','lane','tick','peak_curvature','path']).to_csv(O/'published_curvatures.csv',index=False)
    keys=['primary','layout','root','force','geometry','side','section'];diff=[]
    for m,b in [('single','old'),('event','old'),('event','single')]:
        v=data[data.method==m].merge(data[data.method==b],on=keys,suffixes=('','_base'),validate='one_to_one')
        for a in v.itertuples():
            delta=int(a.success)-int(a.success_base)
            same_outcome_no_exit=all(x is None or pd.isna(x) for x in [a.handoff_s,a.handoff_s_base]) and a.queries==a.queries_base==0 and not a.success and not a.success_base
            identified=bool(a.pair_ok) or same_outcome_no_exit
            diff.append({**{k:getattr(a,k) for k in keys},'method':m,'baseline':b,'strict':a.pair_ok,'observed_delta':delta,'lo':delta if identified else -1,'hi':delta if identified else 1,'definite_rescue':identified and delta==1,'definite_loss':identified and delta==-1,'same_unrelocked_zero':not a.pair_ok and same_outcome_no_exit})
    pair=pd.DataFrame(diff);pair.to_csv(O/'paired_cases.csv.gz',index=False)
    by=data.groupby(['primary','layout','side','method']).agg(tasks=('success','size'),completed=('success','sum'),walls=('wall','sum'),strict=('pair_ok','sum'),tracking_exits=('termination',lambda x:(x=='tracking_domain_exit').sum()),late=('missed','sum'),rejected=('rejected','sum'),published=('published','sum')).reset_index()
    by.to_csv(O/'by_map_side.csv',index=False)
    pair.groupby(['primary','layout','side','method','baseline']).agg(tasks=('lo','size'),known_net_lo=('lo','sum'),known_net_hi=('hi','sum'),rescues=('definite_rescue','sum'),losses=('definite_loss','sum'),strict=('strict','sum')).to_csv(O/'by_map_side_paired.csv')
    assert len(ll)==1584 and len(data[data.primary])==3*288 and len(pair)==3*576
    save(O/'receipt.json',dict(lanes=len(ll),all_conditions=576,primary=288,geometries='fixed old 1 left, 0 right; opposite geometry secondary',per_method=data[data.primary].groupby('method').success.sum().astype(int).to_dict(),strict_primary=int(data[data.primary & (data.method=='old')].pair_ok.sum()),published_curves=len(releases),max_published_curvature=max((r['peak_curvature'] for r in releases),default=None)))
if __name__=='__main__':analyze()

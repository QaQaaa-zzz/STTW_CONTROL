"""One 1584-world DEV batch. Each map advances in its own 792-world GPU process."""
from contextlib import redirect_stdout,redirect_stderr
from datetime import datetime,timezone
import json,multiprocessing as mp,os,subprocess,sys,time,traceback
from pathlib import Path
from prepare import R,W,read,save,sha

TICKS=(0,1,8,32,256,1024)
def state(name,**kw):
    save(R/'status.json',dict(stage=name,updated_utc=datetime.now(timezone.utc).isoformat(),**kw))
def bark(title,text):
    subprocess.run(['/usr/bin/python3',str(W/'learning/scripts/notify_chapter3_job.py'),'--title','第三章连续出口 '+title,'--message',text,'--receipt',str(R/(title+'_bark.json'))])
def worker(spec,barrier):
    name=spec['layout'];loc=R/name;out=loc/'physical'
    with (loc/'physics.log').open('a',buffering=1) as log,redirect_stdout(log),redirect_stderr(log):
        try:
            import torch
            import sttw_control.chapter3_p0_physical as module
            import sttw_control.playground_handoff_evaluation as handoff
            import evaluate_playground_handoff as evaluator
            native=handoff.evaluate_handoff
            def run_native(model,*args):
                assert sha(out/'terrain.mjb')==spec['terrain_sha256'] and model.opt.timestep==.001
                return native(model,*args)
            class MeasuredBranches(module.P0Branches):
                def audit(self,tick,env,just_locked):
                    if tick in TICKS:
                        env['data'].qpos.block_until_ready();torch.cuda.synchronize()
                        arrived=time.monotonic_ns();n=len(env['q']);live=int(env['alive'].sum());t=torch.from_dlpack(env['data'].time)
                        row=dict(tick=tick,worlds=n,alive=live,time_min=float(t.min()),time_max=float(t.max()),pid=os.getpid(),gpu_memory_allocated=torch.cuda.memory_allocated(),arrived_ns=arrived)
                        barrier.wait();row['released_ns']=time.monotonic_ns()
                        with (loc/'gpu_milestones.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
                    super().audit(tick,env,just_locked)
            module.P0Branches=MeasuredBranches;handoff.evaluate_handoff=run_native
            sys.argv=[evaluator.__file__,'--config',str(loc/'run.json'),'--output',str(out),'--skills','rb_run1','--modes','h75','--routes','0','1','--physics-substeps','5','--seconds','10']
            evaluator.main()
        except BaseException:
            traceback.print_exc();barrier.abort();raise

def main():
    p=read(R/'protocol.json')
    for f,h in p['source_files'].items():assert sha(f)==h
    for m in p['maps']:
        assert sha(m['config'])==m['sha256'] and not (R/m['layout']/'physical').exists()
    gpu=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'],text=True)
    heavy=[x for x in gpu.splitlines() if x.strip() and '/awesun_desktop,' not in x]
    while heavy:
        state('waiting_for_external_gpu',processes=heavy);time.sleep(30)
        gpu=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'],text=True)
        heavy=[x for x in gpu.splitlines() if x.strip() and '/awesun_desktop,' not in x]
    state('timing_single_robot')
    bark('启动','两张原开发图，各792辆车。先测修订版单车时延，再同批跑旧三出口、单次规划和事件规划。')
    subprocess.run([sys.executable,'-u',str(R/'time_single.py')],cwd=W,check=True)
    t=read(R/'single_robot_latency.json')
    for m in p['maps']:
        c=read(m['config']);c['p0_branches']['smooth_latency_ms']=t['measured_ms'];save(R/m['layout']/'run.json',c)
    ctx=mp.get_context('spawn');barrier=ctx.Barrier(2);tic=time.monotonic()
    processes=[ctx.Process(target=worker,args=(s,barrier)) for s in p['maps']]
    for pr in processes:pr.start()
    state('running_physics',worlds_per_map=792,total_lanes=1584,workers=[x.pid for x in processes])
    from multiprocessing.connection import wait
    active={pr.sentinel:pr for pr in processes}
    while active:
        for fd in wait(list(active)):
            pr=active.pop(fd);pr.join()
            if pr.exitcode:barrier.abort()
    if any(pr.exitcode for pr in processes):raise RuntimeError('Worker codes '+str([pr.exitcode for pr in processes]))
    ticks=[]
    for m in p['maps']:
        loc=R/m['layout'];status=read(loc/'physical/status.json');assert status['stage']=='complete' and len(status['results'])==792
        ticks.append([json.loads(s) for s in (loc/'gpu_milestones.jsonl').read_text().splitlines()])
    overlap=[min(x[i]['arrived_ns'] for x in ticks)-max(x[i-1]['released_ns'] for x in ticks) for i in range(1,len(TICKS))]
    assert min(overlap)>0 and all(x[1]['alive']==x[1]['worlds']==792 for x in ticks)
    state('complete',physical_lanes=1584,elapsed_physics_s=time.monotonic()-tic,concurrent_worlds_tick1=1584,synchronized_overlap_s=[o/1.e9 for o in overlap])
    bark('完成','两张原开发图1584条轨迹已实际完成，等待同起点配对过门分析。')
if __name__=='__main__':
    try:main()
    except BaseException as exc:
        state('failed',error=str(exc));bark('异常',str(exc));raise

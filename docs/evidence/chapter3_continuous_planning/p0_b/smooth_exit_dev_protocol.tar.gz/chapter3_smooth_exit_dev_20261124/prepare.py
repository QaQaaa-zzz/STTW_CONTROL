"""Build the two physical DEV maps from the registered 5.33 cm comparison."""
from pathlib import Path
import hashlib,itertools,json
from datetime import datetime,timezone

R=Path(__file__).resolve().parent
W=Path('/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad')
OLD=R.parent/'chapter3_continuous_margin_fixed_20261123'
LAYOUTS=('right_offset','staggered')
GATES=(('near',1),('near',-1),('far',1),('far',-1))
def read(file):return json.loads(Path(file).read_text())
def save(file,content):Path(file).write_text(json.dumps(content,indent=2,ensure_ascii=False)+'\n')
def sha(file):return hashlib.sha256(Path(file).read_bytes()).hexdigest()

def prepare():
    maps=[]
    for layout in LAYOUTS:
        loc=R/layout;loc.mkdir(exist_ok=True)
        base=OLD/layout/'part_0/config.json'
        cfg=read(base);rows=cfg['ground_handoff']['handoff_variants'];opts=[];lanes=[];dirs=[]
        for root,force,geom in itertools.product(cfg['p0_branches']['roots'],(0,-5,5),(0,1)):
            donor=next(x for x in rows if x['geometry']==geom and x['approach_alpha']==0)
            for a in range(11):
                sec,side=GATES[(a-3)%4] if a>=3 else ('near',1)
                direction=a if a<3 else 1
                arm=('left','straight','right')[a] if a<3 else ('single_' if a<7 else 'event_')+sec+('_left' if side==1 else '_right')
                opts.append(dict(donor,root_variant=root,bank_row=root,geometry=geom,force_y_N=force,approach_alpha=0.,arm=arm,bin=sec,side=side,section_x=12.7 if sec=='near' else 15.,planned_departure=direction,departure=('left','straight','right')[direction]))
                lanes.append([geom,'h75',len(opts)-1]);dirs.append(direction)
        cfg['role']='Two fixed P0B development maps, smooth-event exit and same-prefix single-search / three frozen exit controls'
        cfg['evaluation_lanes']=lanes;cfg['paired_departures']['direction_ids']=dirs
        cfg['ground_handoff']['handoff_variants']=opts;cfg['ccd_capacity']=len(opts)*8
        cfg['p0_branches'].update(group_size=11,planner_mode='smooth_event',candidates=64,robots_per_chunk=4,arm_schedule_ticks=[0]*7+[20]*4)
        assert len(opts)==792 and len(set(cfg['p0_branches']['roots']))==12 and cfg['platform_online']['margin_m']==.05330585315823555
        save(loc/'config.json',cfg)
        maps.append(dict(layout=layout,config=str(loc/'config.json'),sha256=sha(loc/'config.json'),original=str(base),world=cfg['world_map'],terrain_sha256=sha(OLD/layout/'terrain.mjb'),roots=cfg['p0_branches']['roots']))
    save(R/'protocol.json',dict(role='Paired engineering comparison on the two original P0B DEV maps only',registered_utc=datetime.now(timezone.utc).isoformat(),maps=maps,total_worlds=1584,worlds_per_map=792,original_prefixes=144,
        controls="Three physically executed left/straight/right references, old selector replayed by task gate. Four single and four event-triggered suffixes for each shared entry, all retaining current route on veto/expiry.",
        design="2 layouts x 12 original roots x 2 old entries (alpha0) x three original pushes x 11 arms = 1584. Primary 288 map-root-force-gate contracts, left uses geometry1 and right geometry0; 288 opposite-entry tasks secondary. 236 historical strictly paired tasks are a historical subset; assess current pairing before claiming an effect.",
        clock="5ms control, 1ms physics, 10s max. Old first publication 15ms; continuous same 100ms deadline with next 20ms policy boundary. Charge fresh measured single-car smooth-event times to corresponding monitor/search, same sample order to both schedules. After veto continue current reference.",
        optimizer="64 proposals, two CEM iterations; 1/m peak curvature cap and .05 mean squared curvature preference; same 0.05330585315823555m clearance and controller/dynamics as old.",
        stop="One paired two-map GPU batch, no retraining or extra seeds. Count actual task completion, collisions, published max curvature, tracking exits, postgate failure, vetoes and missed deadlines by map/side and paired root. Advance only after comparing to frozen fixed and single planning; TEST unopened.",
        timing="100 warm measurements for each real monitor and real search on one old DEV success trajectory, first relock / after gate snapshots and true gate status. Cold capture disclosed separately. Each timing includes receipt or choice plus generating output reference for a new admissible plan.",
        source_files={str(x):sha(x) for x in [W/'learning/src/sttw_control/chapter3_continuous_exit.py',W/'learning/src/sttw_control/chapter3_p0_physical.py',W/'learning/src/sttw_control/playground_handoff_evaluation.py']}))
if __name__=='__main__':prepare()

"""Actual and published-reference XY paths on the fixed entry matched gate tasks."""
from pathlib import Path
import json,sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from prepare import R,W,read
sys.path[:0]=[str(W/'learning/src'),str(R.parent/'chapter3_continuous_p1_20261123/model')]
from frozen_exit_value import mapped_arrays

def draw():
    out=R/'analysis';dest=out/'xy';dest.mkdir(exist_ok=True)
    rows=pd.read_csv(out/'selected_tasks.csv.gz');releases=pd.read_csv(out/'published_curvatures.csv')
    colors={'old':'#235d88','single':'#c45428','event':'#24754f'};index=[]
    from collections import defaultdict
    for mapname,part in rows[rows.primary].groupby('layout'):
        cfg=read(R/mapname/'run.json');world=read(Path(cfg['world_map']));bank=mapped_arrays(cfg['paired_departures']['route_bank'])
        with np.load(cfg['ground_handoff']['reference_path']) as z:neutral=z['xy'][0]
        selects={}
        for line in (R/mapname/'physical/p0_events.jsonl').open():
            e=json.loads(line)
            if e['kind']=='old_selection':selects.update({lane:(e['tick'],e['old_candidates'][i][1]) for i,lane in enumerate(e['lanes'])})
        refs=defaultdict(list)
        for row in releases[releases.layout.eq(mapname)].itertuples():
            with np.load(row.path) as z:refs[row.lane].append((row.tick,z['xy'][np.flatnonzero(z['lanes']==row.lane)[0]]))
        for (root,section,side),frame in part.groupby(['root','section','side']):
            gx=12.7 if section=='near' else 15.
            fig,axes=plt.subplots(3,1,figsize=(11,6.8),sharex=True,sharey=True)
            fig.subplots_adjust(top=.84,bottom=.09,hspace=.45)
            for ax,(force,cases) in zip(axes,frame.groupby('force',sort=True)):
                ax.plot([gx,gx],[side*.06,side*3.9],color='#794b83',lw=2)
                ax.axvline(world['terrain']['front_x_m'],lw=.8,color='#444',ls=':')
                for a,b,c,d in world['terrain']['forbidden_rectangles']:ax.add_patch(Rectangle((a,c),b-a,d-c,color='#735f4e',alpha=.6))
                g=world['goal'];ax.add_patch(Rectangle((g['x_min_m'],-g['abs_y_max_m']),g['x_max_m']-g['x_min_m'],2*g['abs_y_max_m'],fc='#e1eadb'))
                ends=[]
                for row in cases.itertuples():
                    col=colors[row.method]
                    with np.load(row.path) as z:xy=z['qpos'][:,:2];initial=z['reference_xy'];final=z['published_reference_xy']
                    xy=xy[:np.flatnonzero(np.isfinite(xy).all(axis=1))[-1]+1]
                    segments=[(0,neutral),(3,initial)]
                    if row.method=='old' and pd.notna(row.handoff_s):
                        # The original policy first assigns the straight row at handback and switches at +15ms.
                        meta=selects.get(row.group+3+int(section=='far')*2+int(side==-1))
                        if meta and row.pair_ok:
                            segments.append((meta[0],bank['xy'][meta[1]]))
                        else:segments.append((round(row.handoff_s/.005)+1,np.empty((0,2))))
                        if pd.notna(row.departure_applied_tick) and row.departure_applied_tick>=0:segments.append((int(row.departure_applied_tick),final))
                    elif row.lane in selects:
                        k,refid=selects[row.lane];segments.extend([(k,bank['xy'][refid]),*refs[row.lane]])
                    for i,(tick,ref) in enumerate(segments):
                        if tick>=len(xy):break
                        endx=xy[min(len(xy)-1,segments[i+1][0]),0] if i+1<len(segments) else xy[-1,0]
                        segment=ref[(ref[:,0]>=xy[tick,0])&(ref[:,0]<=endx)]
                        ax.plot(*segment.T,ls=':',lw=1.3,color=col,alpha=.9)
                    ax.plot(*xy.T,color=col,lw=1.4);ax.plot(*xy[-1],marker='o' if row.success else 'x',color=col)
                    ends.append(f'{row.method}: '+('done' if row.success else row.termination))
                ax.set_title(f'{force:+g} N     '+',  '.join(ends),loc='left',fontsize=8);ax.set_ylabel('y (m)');ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.2)
            axes[-1].set_xlabel('x (m)');fig.suptitle(f'{mapname} · start {root} · {section} '+('left' if side==1 else 'right')+' gate')
            handles=[Line2D([],[],color=c,label=m) for m,c in colors.items()]+[Line2D([],[],ls=':',c='#333',label='published reference')]
            fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.945),ncol=4)
            fn=f'{mapname}_{root}_{section}_{side:+g}.png';fig.savefig(dest/fn,dpi=120);plt.close(fig);index.append(dict(map=mapname,root=root,section=section,side=side,file=fn))
    ix=pd.DataFrame(index);assert len(ix)==96;ix.to_csv(dest/'index.csv',index=False)
    (dest/'index.html').write_text('<meta charset="utf-8"><h1>Repaired exit DEV: physical XY</h1>'+''.join(f'<p><a href="{r.file}">{r.file}</a></p>' for r in ix.itertuples()))
if __name__=='__main__':draw()

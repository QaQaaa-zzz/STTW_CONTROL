#!/usr/bin/env bash
set -eu
base_dir="$(dirname "$0")"
py=/home/qy/mujoco_playground/.venv/bin/python
notifier=/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/scripts/notify_chapter3_job.py
export CUDA_VISIBLE_DEVICES=''
export OMP_NUM_THREADS=1
if "$py" "$base_dir/score.py" && "$py" "$base_dir/draw.py"; then
    /usr/bin/python3 "$notifier" --title "第三章连续出口归约完成" --message "两图配对结果与96张逐起点实际及参考轨迹图已经生成。" --receipt "$base_dir/analysis_bark.json"
else
    /usr/bin/python3 "$notifier" --title "第三章连续出口归约异常" --message "两图物理记录保留，逐病例计分或轨迹绘图失败，需要检查服务日志。" --receipt "$base_dir/analysis_error_bark.json"
    exit 1
fi

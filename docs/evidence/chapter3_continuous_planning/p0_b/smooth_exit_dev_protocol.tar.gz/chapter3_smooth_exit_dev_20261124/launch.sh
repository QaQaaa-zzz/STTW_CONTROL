#!/usr/bin/env bash
set -eu
base_dir="$(dirname "$0")"
worktree=/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad
py=/home/qy/mujoco_playground/.venv/bin/python
cd "$worktree"
export PYTHONPATH="$worktree/learning/src:$worktree/learning/cli:/home/qy/DVGC/JIT/src"
export PYTHONUNBUFFERED=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export CUDA_VISIBLE_DEVICES=0
unset JAX_PLATFORMS
"$worktree/learning/scripts/gpu_queue.sh" "$py" -u "$base_dir/run.py"
"$base_dir/analyze.sh"

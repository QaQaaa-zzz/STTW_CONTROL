from pathlib import Path
from types import SimpleNamespace
import hashlib,json,sys
import numpy as np,pandas as pd,torch
from frozen_exit_value import FrozenExits,mapped_arrays
import sttw_control.chapter3_continuous_exit as native
from sttw_control.platform_online import velocity_state
R=Path('/media/qy/6A7E3DB07E3D75C3/STTW_runs/chapter3_smooth_exit_dev_20261124');A=R/'analysis';torch.set_num_threads(1)
contract=json.loads((R/'protocol.json').read_text())
assert contract['source_files'][native.__file__]==hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest()
data=pd.read_csv(A/'strict_loss_decisions.csv');make=lambda a:torch.tensor(np.asarray(a),dtype=torch.float32)
final=[]
@torch.inference_mode()
def run(mp,rows):
 f=R/mp/'physical';cfg=json.loads((f/'resolved_config.json').read_text())
 query=FrozenExits(f,device='cpu',load_route_bank=False).query
 bank=mapped_arrays(cfg['paired_departures']['route_bank']);s=make(bank['s']);route=SimpleNamespace(s=s)
 solver=native.ContinuousExitPlanner(query,route,mode='smooth_event',candidates=64,iterations=2,horizon_steps=255,robots_per_chunk=1,fused=False)
 q=[];v=[];preq=[];prev=[];holds=[];progress=[];look=[];requested=[];gates=[]
 for r in rows.itertuples():
  t=r.query_tick
  with np.load(f/f'p0_handbacks/tick_{t:04d}.npz') as z, np.load(r.old_path) as obs:
   ix=int(np.flatnonzero(z['lanes']==r.new_lane)[0]);current_q=z['physics_qpos'][ix];current_v=z['physics_qvel'][ix]
   last_q=z[f'query_pose_history_{t%4}'][ix];last_v=z[f'query_velocity_history_{t%4}'][ix]
   assert np.array_equal(current_q,obs['qpos'][t]) and np.array_equal(current_v,obs['qvel'][t]) and np.array_equal(last_q,obs['qpos'][t-4]) and np.array_equal(last_v,obs['qvel'][t-4])
   assert np.array_equal(bank['xy'][r.old_chosen_route_id],obs['published_reference_xy'])
   sec={'near':12.7,'far':15.}[r.gate]
   assert np.max(obs['qpos'][:t+1,0])<sec
   q.append(current_q);v.append(current_v);preq.append(last_q);prev.append(last_v);gates.append(sec)
   for col,name in [(holds,'runtime_hold'),(progress,'middle_projection_progress'),(look,'middle_follower_lookahead'),(requested,'middle_v_user')]:col.append(float(z[name][ix]))
 q=make(q);v=velocity_state(q,make(v));pv=velocity_state(make(preq),make(prev));sec=make(gates);side=make(rows.side);remain=10.-make(rows.query_tick)*.005;gate=torch.zeros(len(q),dtype=torch.long);hold=make(holds);assert torch.all(hold==0)
 bs=rows.old_chosen_route_id.to_numpy(dtype=int);straight=rows.old_straight_route_id.to_numpy(dtype=int)
 oldxy,oldh,oldk=[make(bank[name][bs]) for name in ['xy','heading','curvature']]
 straight_refs=[make(bank[name][straight]) for name in ['xy','heading','curvature']]
 args=(sec,side,remain,gate,hold)
 # Verify the native monitor against its archived GPU outcome at exactly the same physical handback.
 _,straight_ok,_,_=solver._smooth_score(q,v,pv,*straight_refs,*args)
 diag={}
 def capture(frame,event,arg):
  if event!='return':return
  if frame.f_code==native._score.__code__:
   loc=frame.f_locals
   diag.update(safe=loc['safe'].clone(),within=loc['within'].clone(),goal_hold=loc['held'].any(1),gate=loc['gate'].clone(),
               crossing=loc['crosses'].any(1),cross_y=loc['at'].clone(),clearance_m=loc['clearance'].clone(),
               scorer_admit=loc['admitted'].clone())
  elif frame.f_code==native.ContinuousExitPlanner._smooth_score.__code__:
   loc=frame.f_locals;diag.update(curvature=loc['geometry'].clone(),peak=loc['peak'].clone())
 sys.setprofile(capture)
 try:score,ok,clear,valid=solver._smooth_score(q,v,pv,oldxy,oldh,oldk,*args)
 finally:sys.setprofile(None)
 assert torch.equal(ok,diag['safe']&diag['within']&diag['goal_hold']&diag['gate']&diag['curvature'])
 commit=native.committed_progress(make(progress),make(look),make(requested),.1).clamp_max(s[-1])
 idx=torch.searchsorted(s,commit.contiguous()).clamp_max(len(s)-1)
 mask=torch.arange(len(s))[None,:]<=idx[:,None]
 change=[torch.where(mask,(a-b).abs().amax(-1) if a.ndim==3 else (a-b).abs(),0.).amax(1) for a,b in zip((oldxy,oldh,oldk),straight_refs)]
 for i,r in enumerate(rows.itertuples()):
  a=dict(map=mp,root=r.root,force_N=r.force_N,gate=r.gate,side=r.side,query_tick=r.query_tick,old_arm=r.old_arm,
   lane=r.new_lane,route_id=int(bs[i]),old_gpu_admitted=r.old_arm_admitted,new_gpu_first_search_admitted=r.new_first_admitted,
   cpu_straight_admitted=bool(straight_ok[i]),gpu_straight_admitted=r.new_first_incumbent_admitted,
   actual_old_reference_matches_run_bank=True,handback_and_previous_state_match_raw_trajectory=True,remaining_s=float(remain[i]),
   raw_scoring_window_s=float(valid[i]),base_geometry_filtered_admission=bool(ok[i]),clearance_m=float(clear[i]),
   clearance_pass=bool(diag['safe'][i]),domain_pass=bool(diag['within'][i]),goal_hold_pass=bool(diag['goal_hold'][i]),
   gate_crossed=bool(diag['crossing'][i]),gate_direction_pass=bool(diag['gate'][i]),forecast_gate_y_m=float(diag['cross_y'][i]) if diag['crossing'][i] else None,
   peak_remaining_curvature_m_inv=float(diag['peak'][i]),curvature_pass=bool(diag['curvature'][i]),score=float(score[i]),
   committed_s_m=float(commit[i]),prefix_sample_count=int(idx[i])+1,prefix_max_abs_xy_m=float(change[0][i]),
   prefix_max_abs_heading_rad=float(change[1][i]),prefix_max_abs_curvature_m_inv=float(change[2][i]),
   compatible_with_frozen_control_prefix_1e6=all(float(x[i])<=1e-6 for x in change),old_physical_success=True)
  arc=s.numpy();ox,oy=oldxy[i].numpy().T;sx,sy=straight_refs[0][i].numpy().T
  qx=float(q[i,0]);c=float(commit[i]);cx=float(np.interp(c,arc,sx));ocx=float(np.interp(c,arc,ox))
  actual_preview_x=float(np.interp(float(progress[i]+look[i]),arc,sx))
  end_common=min(cx,ocx)
  assert qx<actual_preview_x<=cx and qx<end_common
  points=np.unique(np.r_[qx,ox[(ox>qx)&(ox<end_common)],sx[(sx>qx)&(sx<end_common)],end_common])
  dy=lambda xx: np.interp(xx,ox,oy)-np.interp(xx,sx,sy)
  future_dy=dy(points);j=int(np.argmax(abs(future_dy)))
  # With piecewise linear y(x), the maximum on a common physical-x interval occurs at a knot.
  a.update(measured_vehicle_x_m=qx,pursuit_lookahead_m=look[i],s_current_m=progress[i],
      pursuit_preview_world_x_m=actual_preview_x,committed_world_x_straight_m=cx,
      committed_world_x_old_m=ocx,committed_end_sample_world_x_straight_m=float(sx[int(idx[i])]),
      forward_commit_dx_straight_m=cx-qx,forward_common_end_world_x_m=end_common,
      front_only_max_abs_y_diff_m=float(abs(future_dy[j])),front_only_max_at_x_m=float(points[j]),
      current_x_signed_y_diff_m=float(dy(qx)),pursuit_preview_signed_y_diff_m=float(dy(actual_preview_x)),
      current_ref_commit_x_signed_y_diff_m=float(dy(cx)),common_forward_end_signed_y_diff_m=float(dy(end_common)))
  for mm in (50,100,250,500,1000):
   a[f'abs_y_diff_at_{mm}mm_ahead_m']=float(abs(dy(qx+mm/1000))) if qx+mm/1000<=end_common else None
  for threshold in (.001,.01,.05):
   dd=np.abs(future_dy)
   reached=np.where(dd>=threshold)[0]
   first=None
   if len(reached):
    u=int(reached[0])
    if u==0:first=qx
    else:
     target=np.sign(future_dy[u])*threshold
     first=float(points[u-1]+(points[u]-points[u-1])*(target-future_dy[u-1])/(future_dy[u]-future_dy[u-1]))
   a[f'forward_distance_to_{int(threshold*1000)}mm_y_difference_m']=None if first is None else first-qx
  final.append(a)
for mp,rows in data.groupby('map'):
 run(mp,rows)
out=pd.DataFrame(final);out.to_csv(A/'strict_loss_old_routes_rescored.csv',index=False)
criteria=['clearance_pass','domain_pass','goal_hold_pass','gate_direction_pass','curvature_pass','base_geometry_filtered_admission','compatible_with_frozen_control_prefix_1e6']
summary=dict(total=len(out),directions={},forecast_criteria_denials={k:int((~out[k]).sum()) for k in criteria},admitted=int(out.base_geometry_filtered_admission.sum()),cpu_gpu_straight_decision_agreement=int((out.cpu_straight_admitted==out.gpu_straight_admitted).sum()),curvature_range=out.peak_remaining_curvature_m_inv.agg(['min','max']).tolist(),clearance_range=out.clearance_m.agg(['min','max']).tolist(),
    max_committed_segment_xy_difference_m=out.prefix_max_abs_xy_m.agg(['min','median','max']).to_dict(),source_sha=contract['source_files'][native.__file__],case_table='strict_loss_old_routes_rescored.csv',
    assessment='Exact saved original winner geometry, same observed first query and 20ms history, same map/height, 5.33cm, hold/gate status and 255-step native smooth score math, unfused CPU float32. Observing the true internal boolean predicates by function return exposes the gate, clearance, domain, goal and curvature checks. Prefix compatibility is a separate comparison to the straight incumbent across all xy/heading/curvature nodes through committed_progress, inclusive, with native H75 1e-6 tolerance. This is not a new physical action or a late-publication counterfactual.')
for side in [-1,1]:
 g=out[out.side==side];summary['directions'][str(side)]={'gate_side_cases':len(g),'reject_counts':{k:int((~g[k]).sum()) for k in criteria}}
front=['measured_vehicle_x_m','committed_world_x_straight_m','forward_commit_dx_straight_m',
       'front_only_max_abs_y_diff_m','current_x_signed_y_diff_m','pursuit_preview_signed_y_diff_m',
       'abs_y_diff_at_100mm_ahead_m','abs_y_diff_at_250mm_ahead_m','abs_y_diff_at_500mm_ahead_m',
       'abs_y_diff_at_1000mm_ahead_m','forward_distance_to_1mm_y_difference_m','forward_distance_to_10mm_y_difference_m',
       'forward_distance_to_50mm_y_difference_m']
summary['forward_reference_comparison']={'basis':'Interpolate both references on the same world x. Front-only maximum on [measured x, min(world x of the two curves at the committed arc)] includes both curves’ interior knots, excluding all points behind the vehicle. Preview uses measured middle.projection.progress+middle.follower.lookahead on the actually published straight reference. Deltas reported below are absolute.', 'min_med_max':{k:out[k].abs().agg(['min','median','max']).to_dict() for k in front},
      'front_only_exceeds_35cm':int((out.front_only_max_abs_y_diff_m>.35).sum())}
(A/'strict_loss_old_routes_rescored_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
print(out[(out.root.isin([1171,1178]))&(out.gate=='near')][['root','force_N','side','clearance_m','forecast_gate_y_m','peak_remaining_curvature_m_inv','base_geometry_filtered_admission','prefix_max_abs_xy_m']].to_string(index=False))

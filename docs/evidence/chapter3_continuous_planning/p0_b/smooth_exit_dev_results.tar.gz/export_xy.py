"""Export all physical center tracks and their original control-step timestamps."""
from pathlib import Path
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parent/'analysis'
lanes = pd.read_csv(root/'physical_lanes.csv.gz')
tracks = {}
for layout, part in lanes.groupby('layout'):
    chunks = []
    starts = [0]
    for lane in part.sort_values('lane').itertuples():
        with np.load(lane.path) as source:
            trajectory = np.column_stack((source['trace'][:,0], source['qpos'][:,:2]))
        chunks.append(trajectory)
        starts.append(starts[-1]+len(trajectory))
    tracks[layout] = np.concatenate(chunks)
    tracks[layout+'_offsets'] = np.asarray(starts)
np.savez_compressed(root/'actual_xy.npz', columns=['time_s','world_x_m','world_y_m'], **tracks)

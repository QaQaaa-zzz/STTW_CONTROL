"""Plot actual center trajectories at the two specified gates in the repaired DEV rollout."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import pandas as pd
import numpy as np

root = Path(__file__).resolve().parent
cases = pd.read_csv(root/'analysis/selected_tasks.csv.gz')
cfg = json.loads((root/'right_offset/run.json').read_text())
world = json.loads(Path(cfg['world_map']).read_text())
plt.rcParams.update({'font.family':'Noto Sans CJK JP', 'axes.unicode_minus':False, 'font.size':10})
fig, axes = plt.subplots(1, 2, figsize=(11, 4.05), layout='constrained')
specs = [(1178,'near',-1,12.7,(12.0,13.7),(-.82,.18),'近右门 · 两辆都过门，新方法随后碰墙'), (1174,'far',1,15.,(14.46,15.54),(-.24,.36),'远左门 · 新方法刚好从指定侧通过')]
for ax,(start,section,side,gx,xlim,ylim,title) in zip(axes,specs):
    f=cases[cases.primary & cases.layout.eq('right_offset') & cases.root.eq(start) & cases.section.eq(section) & cases.side.eq(side) & cases.force.eq(0)]
    ax.axvline(gx,ls=':',c='#8d8d8d',lw=1)
    ax.plot([gx,gx],[side*.060,ylim[int(side==1)]],c='#915fa1',lw=4,alpha=.6,zorder=1)
    for x0,x1,y0,y1 in world['terrain']['forbidden_rectangles']:
        ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,fc='#a98f7a',ec='#655040'))
    for method,color in [('old','#245988'),('event','#ca5927')]:
        row=f[f.method.eq(method)].iloc[0]
        with np.load(row.path) as z: q=z['qpos'][:,:2]
        ax.plot(q[:,0],q[:,1],c=color,lw=2)
        ax.scatter([gx],[row.gate_y],s=30,c=color,zorder=4,edgecolors='white',linewidths=.5)
        offset=(6,-19) if method=='old' else (6,9)
        ax.annotate(f'{row.gate_y*100:+.1f} cm',(gx,row.gate_y),xytext=offset,textcoords='offset points',color=color,fontsize=9)
        if row.wall:
            ax.scatter(*q[-1],s=75,c=color,marker='x',linewidths=2,zorder=6)
    ax.set(xlim=xlim,ylim=ylim,xlabel='前进位置 x（米）',ylabel='横向位置 y（米）',title=title)
    ax.set_aspect('equal');ax.grid(alpha=.16)
fig.suptitle('同一张地图、相同落稳状态、无横推时的实际行驶轨迹',fontsize=14)
fig.get_layout_engine().set(h_pad=.10)
fig.legend(handles=[Line2D([],[],c='#245988',lw=2,label='旧三出口'),Line2D([],[],c='#ca5927',lw=2,label='事件触发连续出口'),Line2D([],[],c='#915fa1',lw=4,alpha=.6,label='指定门允许通过的一侧'),Line2D([],[],marker='x',ls='none',c='#ca5927',label='车体首次碰墙时的车心')],loc='outside lower center',ncol=4,frameon=False)
fig.savefig(root/'analysis/paired_gate_examples.png',dpi=170)

"""Re-evaluate each published curvature on the same part of the reference as the planner."""
import json
from pathlib import Path
import pandas as pd
import numpy as np

source = Path(__file__).resolve().parent
out = source/'analysis'
paths = pd.read_csv(out/'physical_lanes.csv.gz').set_index(['layout','lane']).path
publications = pd.read_csv(out/'published_curvatures.csv')
samples = {}
for layout in publications.layout.unique():
    with (source/layout/'physical/p0_events.jsonl').open() as stream:
        for line in stream:
            event = json.loads(line)
            if event['kind'] == 'publication':
                for lane, sample, published in zip(event['lanes'], event['sample_tick'], event['published']):
                    if published:
                        samples[layout, lane, event['tick']] = sample
rows = []
for record in publications.itertuples():
    sample = samples[record.layout, record.lane, record.tick]
    with np.load(paths[record.layout, record.lane]) as trace:
        robot_x = trace['qpos'][sample, 0]
    with np.load(record.path) as data:
        index = np.flatnonzero(data['lanes'] == record.lane)[0]
        x = data['xy'][index,:,0]
        k = abs(data['curvature'][index])
        start = max(0, np.searchsorted(x, robot_x, side='left') - 1)
        rows.append((record.layout, record.lane, record.tick, sample, robot_x, start, k.max(), k[start:].max()))
pd.DataFrame(rows, columns=['layout','lane','published_tick','sample_tick','sample_world_x_m','first_segment','whole_peak_m_inv','remaining_peak_m_inv']).to_csv(out/'forward_reference_curvature.csv', index=False)

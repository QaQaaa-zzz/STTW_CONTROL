"""Reproduce the observed DEV vehicle paths and competing references on a common world-x axis."""
from pathlib import Path
import csv
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
def pick(file):
    d=pd.read_csv(OUT/file)
    r=d[(d["map"]=="right_offset")&(d.root==1178)&(d.force_N==0)&(d.gate=="near")&(d.side==-1)]
    assert len(r)==1
    return r.iloc[0]

def crossing(trace, x, tick):
    t,xx,yy=trace[tick:].T
    if np.isclose(x,xx[0],atol=1e-7,rtol=0):return float(t[0]), float(yy[0])
    loc=np.flatnonzero((xx[:-1]<x)&(x<=xx[1:]))
    if not len(loc):return None,None
    i=loc[0];a=(x-xx[i])/(xx[i+1]-xx[i])
    return float(t[i]+a*(t[i+1]-t[i])),float(yy[i]+a*(yy[i+1]-yy[i]))

def main():
    d=pick("strict_loss_decisions.csv");h=pick("strict_loss_old_routes_rescored.csv")
    tr=[];refs=[]
    for path in (d.old_path,d.new_path,d.straight_path):
        with np.load(path) as z:
            t=z["trace"][:,z["columns"].tolist().index("time")]
            tr.append(np.column_stack((t,z["qpos"][:,:2])))
            refs.append(z["published_reference_xy"])
    old,new,straight=tr;ro,rr=refs[:2]
    assert np.array_equal(rr,refs[2]) and np.array_equal(new,straight)
    tick=int(d.query_tick);qx,qy=old[tick,1:3];assert np.array_equal(old[:tick+1],new[:tick+1])
    cfg=json.loads((OUT.parent/'right_offset'/'config.json').read_text())
    world=json.loads(Path(cfg["world_map"]).read_text());wall=world["terrain"]["forbidden_rectangles"][0];goal=world['goal']
    gate=12.7;px=h.pursuit_preview_world_x_m;cx=h.committed_world_x_straight_m
    ahead=[("query",float(qx)),("0.25_m_ahead",float(qx)+.25),("0.50_m_ahead",float(qx)+.50),
           ("1.00_m_ahead",float(qx)+1.),("pure_pursuit_preview",px),("right_gate",gate),
           ("end_of_committed_straight",cx),("event_vehicle_body_contact",float(new[-1,1])),
           ("old_vehicle_goal",float(old[-1,1]))]
    samples=[]
    for feature,x in ahead:
        oy,sy=[float(np.interp(x,r[:,0],r[:,1])) for r in [ro,rr]]
        ot,om=crossing(old,x,tick); nt,nm=crossing(new,x,tick)
        samples.append(dict(feature=feature,world_x_m=x,old_reference_y_m=oy,straight_reference_y_m=sy,
                            old_minus_straight_reference_y_m=oy-sy,old_actual_y_m=om,old_time_s=ot,
                            event_actual_y_m=nm,event_time_s=nt))
    with (OUT/'commitment_1178.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=samples[0]);writer.writeheader();writer.writerows(samples)
    preview=samples[4]
    oy,sy=preview['old_reference_y_m'],preview['straight_reference_y_m']
    assert abs(oy-sy-h.pursuit_preview_signed_y_diff_m)<1.e-6 and abs(sy-oy-.3398063)<1.e-5
    fonts=[f.name for f in font_manager.fontManager.ttflist]
    plt.rcParams.update({'font.family':['Noto Sans CJK SC' if 'Noto Sans CJK SC' in fonts else 'Noto Sans CJK JP','DejaVu Sans'],
                         'axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig=plt.figure(figsize=(10,7))
    gs=fig.add_gridspec(2,1,left=.08,right=.96,top=.84,bottom=.12,height_ratios=[3.3,1.30],hspace=.34)
    zoom,full=[fig.add_subplot(gs[i,0]) for i in range(2)]
    oldc,newc='#12578b','#bc5425'
    fig.text(.08,.965,'起点 1178 的两车位置重合，前视参考相差 34 厘米',fontsize=17,weight='bold')
    fig.text(.08,.927,'右偏墙开发图　·　近右门　·　零横推　·　首次落稳后查询 4.860 秒',fontsize=10,color='#394754')
    for ax in (zoom,full):
        ax.axvspan(qx,cx,color='#f3ebce',alpha=.6,zorder=-2)
        ax.axvline(cx,ls=':',lw=1.1,c='#816f3b')
        ax.plot([gate,gate],[-3.9,-.06],c='#886a90',lw=2,zorder=0)
        ax.add_patch(Rectangle((wall[0],wall[2]),wall[1]-wall[0],wall[3]-wall[2],
                               facecolor='#8c817b',edgecolor='#54433f',lw=.8,zorder=-1))
        ax.add_patch(Rectangle((goal['x_min_m'],-goal['abs_y_max_m']),goal['x_max_m']-goal['x_min_m'],
                               2*goal['abs_y_max_m'],facecolor='#dfebdb',edgecolor='none',zorder=-2))
        for track,ref,c in [(new,rr,newc),(old,ro,oldc)]:
            # Fixed original right branch and the actual retained straight branch, from the common query.
            mask=ref[:,0]>=qx-.08
            ax.plot(*ref[mask].T,ls=(0,(4,2)),lw=1.7,c=c)
            ax.plot(track[tick:,1],track[tick:,2],lw=2.05,c=c)
        ax.scatter(qx,qy,s=42,c='#242424',zorder=5)
        ax.scatter(*new[-1,1:],marker='X',s=60,c=newc,edgecolors='white',linewidth=.6,zorder=6)
        ax.scatter(*old[-1,1:],marker='o',s=46,c=oldc,edgecolors='white',linewidth=.6,zorder=6)
        ax.set_ylabel('世界 y (m)');ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.16)
    zoom.set_xlim(qx-.18,wall[1]+.23);zoom.set_ylim(-.82,.29)
    zoom.annotate('',(cx,.202),(qx,.202),arrowprops=dict(arrowstyle='<->',lw=1.0,color='#75622e'))
    zoom.text((cx+qx)/2,.222,f'要求保持直行参考的前段  {cx-qx:.2f} m',ha='center',color='#705e29',fontsize=9)
    zoom.plot([px,px],[oy,sy],alpha=.8,c='#3b3b3b',lw=.8)
    zoom.scatter([px,px],[oy,sy],marker='D',facecolors='white',edgecolors=[oldc,newc],linewidth=1.2,s=31,zorder=5)
    zoom.annotate('前视点的两条参考\n相差 34.0 cm',(px,(sy+oy)/2),(px-.21,.070),
                  arrowprops=dict(arrowstyle='->',lw=.85),ha='right',va='center',fontsize=9)
    zoom.annotate('查询时两车重合',(qx,qy),(qx+.06,-.67),arrowprops=dict(arrowstyle='->',lw=.8),fontsize=9)
    zoom.annotate('冻结末端',(cx,.015),(cx+.105,.102),arrowprops=dict(arrowstyle='->',lw=.8),fontsize=9,color='#705e29')
    zoom.annotate('车身碰墙',new[-1,1:],(new[-1,1]+.08,-.60),arrowprops=dict(arrowstyle='->',lw=.8),fontsize=9,color=newc)
    zoom.text(wall[0]+.025,wall[3]+.025,'墙',fontsize=9,color='#503f39')
    zoom.text(gate+.03,-.79,'右门',fontsize=8,color='#785680')
    full.set_xlim(qx-.18,goal['x_max_m']+.1);full.set_ylim(-.75,.63);full.set_xlabel('世界 x (m)')
    full.text(16.59,.32,'目标区',fontsize=8,color='#476042')
    full.annotate('旧方法完成',old[-1,1:],(16.3,-.48),color=oldc,fontsize=8,arrowprops=dict(arrowstyle='->',lw=.75,color=oldc))
    legend=[Line2D([],[],c=oldc,lw=2,label='旧方法实际轨迹'),Line2D([],[],c=oldc,ls='--',label='旧右转参考'),
            Line2D([],[],c=newc,lw=2,label='新方法实际轨迹'),Line2D([],[],c=newc,ls='--',label='新方法保留的直行参考')]
    fig.legend(handles=legend,loc='upper left',bbox_to_anchor=(.075,.907),ncol=4,frameon=False,fontsize=9)
    fig.text(.08,.035,'菱形标在相同世界 x 的参考线上。实线为车辆中心实际运动，碰墙终点取自车身接触记录。',fontsize=9,color='#394754')
    fig.savefig(OUT/'commitment_1178.png',dpi=170,facecolor='white');plt.close(fig)

if __name__=='__main__':main()

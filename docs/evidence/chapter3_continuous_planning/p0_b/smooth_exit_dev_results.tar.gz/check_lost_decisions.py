from pathlib import Path
from collections import defaultdict
from functools import lru_cache
import json
import pandas as pd
import numpy as np
R=Path('/media/qy/6A7E3DB07E3D75C3/STTW_runs/chapter3_smooth_exit_dev_20261124');A=R/'analysis'
source=pd.read_csv(A/'strict_outcome_changes.csv')
lost=source[source.change.eq('lost')]
assert len(lost)==47 and all(lost.pair_ok&lost.primary&lost.old_success&~lost.success&lost.verified)
directions=['left','straight','right']
@lru_cache(None)
def trajectory(p):
 with np.load(p) as z:
  tr=z['trace'];names=z['columns'].tolist()
  return tr[:,[names.index(k) for k in ['time','steer_target','rear_target','x','y']]],z['qpos'],z['qvel']
by=[]
for mp,data in lost.groupby('layout'):
 f=R/mp/'physical'; rows=json.loads((f/'status.json').read_text())['results'];events=defaultdict(lambda:defaultdict(list))
 needed=set(data.lane)
 for line in (f/'p0_events.jsonl').open():
  rec=json.loads(line);k=rec['kind']
  for i,j in enumerate(rec['lanes']):
   if j in needed:
    v={key:(val[i] if isinstance(val,list) else val) for key,val in rec.items() if key!='lanes'}
    events[j][k].append(v)
 for r in data.itertuples():
  ev=events[r.lane]
  old,=ev['old_selection'];first=ev['query'][0]
  pub=next(p for p in ev['publication'] if p['sample_tick']==first['tick'])
  qt=first['tick'];due=first['due']
  assert qt==old['tick']==round(r.handoff_s/.005)+1 and pub['tick']==due and pub['in_time']
  oi=directions.index(r.old_arm);assert old['choice']==oi
  sj=r.group+1;oj=r.group+oi
  stpath=f/rows[sj]['case_dir']/'trajectory.npz'
  opath=f/rows[oj]['case_dir']/'trajectory.npz'
  assert str(opath)==r.old_path and rows[sj]['variant']['arm']=='straight'
  for row in (rows[r.lane],rows[sj],rows[oj]):
   v=row['variant'];assert (v['bank_row'],v['force_y_N'],v['geometry'])==(r.root,r.force,r.geometry)
  sc,sq,sv=trajectory(stpath);oc,oq,ov=trajectory(opath);ec,eq,evel=trajectory(r.path)
  same=all(np.array_equal(base[:qt+1],other[:qt+1]) for base,others in [(oq,[sq,eq]),(ov,[sv,evel])] for other in others)
  assert same and all(np.array_equal(oc[:qt+1,1:3],x[:qt+1,1:3]) for x in [sc,ec])
  n=min(len(oc),len(sc));delta=oc[:n,1:3].astype('float64')-sc[:n,1:3].astype('float64')
  assert np.isfinite(delta[:due+1]).all()
  def first_diff(vals,tol):
   idx=np.flatnonzero(vals>tol)
   return int(idx[0]) if len(idx) else None
  ds=first_diff(abs(delta[:,0]),0.);dr=first_diff(abs(delta[:,1]),0.)
  di=min(i for i in [ds,dr] if i is not None);at=di-1
  # At each row the evaluator stores previous target before it computes and applies the next command.
  # No additional phase reset is present during the ground-on-ground window under comparison.
  assert qt<=at and oc[di,0] <= qt*.005+.50
  events_published=[p for p in ev['publication'] if p['published']]
  new_digest=dict(new_total_queries=len(ev['query']),new_total_searches=sum(q['searched'] for q in ev['query']),
                 new_any_admitted=any(q['admitted'] for q in ev['query']),new_any_published=bool(events_published),
                 first_actual_new_publication_tick=events_published[0]['tick'] if events_published else None)
  pre_end=min(due+1,len(sc),len(ec))
  matched_before_due=np.array_equal(sc[qt:pre_end,1:3],ec[qt:pre_end,1:3])
  by.append(dict(map=mp,root=r.root,force_N=r.force,gate=r.section,side=r.side,geometry=r.geometry,group=r.group,
      old_lane=oj,new_lane=r.lane,straight_lane=sj,old_arm=r.old_arm,same_qpos_qvel_through_first_query=same,
      old_arm_phys_success=True,old_arm_admitted=old['admitted'],old_straight_incumbent_admitted=old['incumbent_admitted'],
      old_chosen_route_id=old['old_candidates'][oi],old_straight_route_id=old['old_candidates'][1],
      query_tick=qt,handoff_s=r.handoff_s,old_reference_published_tick=rows[oj]['departure_applied_tick'],
      old_reference_publication_from_query_ms=5*(rows[oj]['departure_applied_tick']-qt),
      new_first_searched=first['searched'],new_first_admitted=first['admitted'],new_first_incumbent_admitted=first['incumbent'],
      new_search_single_car_sample_ms=first['ms'],new_first_eligible_release_tick=due,new_first_release_window_from_query_ms=5*(due-qt),
      new_first_deadline_met=pub['in_time'],new_first_publication=pub['published'],new_first_renewed=pub['incumbent_renewed'],
      old_first_different_held_steer_trace_tick=ds,old_first_different_held_rear_trace_tick=dr,old_first_different_held_trace_tick=di,
      old_first_different_applied_interval_tick=at,old_first_actuator_divergence_from_query_ms=5*(at-qt),
      old_divergence_precedes_new_release_by_ms=5*(due-at),old_command_delta_steer_at_first_diff=float(delta[di,0]),
      old_command_delta_rear_at_first_diff=float(delta[di,1]),max_abs_steer_diff_before_new_release_rad=float(np.max(abs(delta[qt+1:due+1,0]))),
      max_abs_rear_diff_before_new_release_rad_s=float(np.max(abs(delta[qt+1:due+1,1]))),
      old_steer_1e4_diverges_before_new_release=bool(np.any(abs(delta[qt+1:due+1,0])>1.e-4)),
      old_steer_1e3_diverges_before_new_release=bool(np.any(abs(delta[qt+1:due+1,0])>1.e-3)),
      event_and_straight_held_commands_identical_until_new_release=matched_before_due,
      distance_while_waiting_m=pub['travel_m'],old_gate_y_m=r.old_gate_y,new_gate_y_m=r.gate_y,new_correct_gate=r.correct_gate,
      new_termination=r.termination,new_physical_goal=r.phys_goal,new_wall=r.wall,
      old_path=r.old_path,new_path=r.path,straight_path=str(stpath),**new_digest))
d=pd.DataFrame(by).sort_values(['map','root','force_N','gate','side'])
d.to_csv(A/'strict_loss_decisions.csv',index=False)
def range3(x):return [float(x.min()),float(x.median()),float(x.max())]
base=dict(panel='strictly matched primary losses of repaired event-triggered approach relative to old three-exit choice, both evaluated at the same measured handback; 47 tasks; roots and gates may repeat',
 count=len(d),distinct_roots=d.groupby(['map','root']).ngroups,distinct_handbacks=d.groupby(['map','group']).ngroups,
 old_successful_selected_direction_counts=d.old_arm.value_counts().to_dict(),
 old_successful_selected_admissions=int(d.old_arm_admitted.sum()),old_straight_incumbent_admitted=int(d.old_straight_incumbent_admitted.sum()),
 new_first_searched=int(d.new_first_searched.sum()),new_first_admissions=int(d.new_first_admitted.sum()),new_first_publications=int(d.new_first_publication.sum()),
 new_first_on_time=int(d.new_first_deadline_met.sum()),event_ever_admitted=int(d.new_any_admitted.sum()),event_ever_new_reference=int(d.new_any_published.sum()),
 old_command_precedes_first_new_release=int((d.old_divergence_precedes_new_release_by_ms>0).sum()),
 new_vs_straight_identical_before_first_new_release=int(d.event_and_straight_held_commands_identical_until_new_release.sum()),
 old_steer_delta_exceeds_1e4_before_release=int(d.old_steer_1e4_diverges_before_new_release.sum()),old_steer_delta_exceeds_1e3_before_release=int(d.old_steer_1e3_diverges_before_new_release.sum()),
 old_earliest_actuator_from_query_ms_min_med_max=range3(d.old_first_actuator_divergence_from_query_ms),
 old_actual_route_release_from_query_ms_min_med_max=range3(d.old_reference_publication_from_query_ms),
 first_new_eligible_release_from_query_ms_min_med_max=range3(d.new_first_release_window_from_query_ms),
 old_first_actuator_lead_ms_min_med_max=range3(d.old_divergence_precedes_new_release_by_ms),
 waiting_travel_m_min_med_max=range3(d.distance_while_waiting_m),
 map_counts=d.groupby('map').size().to_dict(),new_physical_terminals=d.new_termination.value_counts().to_dict(),
 provenance='p0_events.jsonl old_selection reports admission of its chosen original physical direction, not independent scores for all 3. Query clock is first tick after actual handback. New release window is the first scheduled instant the initial computed replacement could be assigned if accepted. An unaccepted candidate never changed reference. Trace steer/rear at row i contain the action held over the previous physical interval, so i-1 is reported alongside original trace indices.',
 interpretation='The two planners differ in route geometry, scoring/curvature/commitment and publication timing. These paired outcomes do not isolate delay causally; none of the hypothetical delay-matched counterfactuals was executed.')
p=d[(d['map']=='right_offset')&(d.root==1171)&(d.force_N==0)&(d.gate=='near')&(d.side==1)].iloc[0]
base['example']={k:(None if pd.isna(v) else (v.item() if isinstance(v,np.generic) else v)) for k,v in p.to_dict().items() if k not in ('old_path','new_path','straight_path')}
(A/'strict_loss_decisions_summary.json').write_text(json.dumps(base,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in base.items() if k not in ['example','provenance','interpretation','panel']},indent=2))
print('example',{k:p[k] for k in ['query_tick','old_reference_published_tick','old_first_different_applied_interval_tick','new_first_eligible_release_tick','old_gate_y_m','new_gate_y_m','new_termination','new_total_queries','new_any_admitted','new_any_published']})

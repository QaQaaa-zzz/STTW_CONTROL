"""Export actual times, XY and all reference switches of each physical clock intervention."""
import hashlib
import json
from pathlib import Path
import tarfile

import numpy as np
import pandas as pd
from draw import mapped_arrays
from prepare import R

def pack():
    out = R / 'analysis' / 'portable_paths'
    out.mkdir(exist_ok=True)
    lanes = pd.read_csv(R/'analysis/physical_lanes.csv.gz')
    refs = {}
    cases = []
    switches = []
    def reference_id(coords):
        coords = np.ascontiguousarray(coords)
        ident = hashlib.sha256(coords.dtype.str.encode()+coords.tobytes()).hexdigest()
        refs.setdefault(ident,coords)
        return ident
    for layout, block in lanes.groupby('layout'):
        cfg = json.loads((R/layout/'run.json').read_text())
        (out/(layout+'_world.json')).write_bytes(Path(cfg['world_map']).read_bytes())
        bank = mapped_arrays(cfg['paired_departures']['route_bank'])
        with np.load(cfg['ground_handoff']['reference_path']) as data:
            neutral = reference_id(data['xy'][0])
        xy, times = [], []
        k = 0
        for lane in block.itertuples():
            with np.load(lane.path) as data:
                v = data['qpos'][:,:2].copy()
                t = data['trace'][:,data['columns'].tolist().index('time')].copy()
                active = [(0,neutral),(3,reference_id(data['reference_xy']))]
                if lane.query_tick >= 0:
                    active.append((int(lane.query_tick),reference_id(bank['xy'][int(lane.default_route)])))
                if lane.publication_tick >= 0:
                    active.append((int(lane.publication_tick),reference_id(data['published_reference_xy'])))
            if not np.isclose(t[-1],lane.duration_s,atol=1.e-6):
                raise ValueError(lane.path)
            finite = np.flatnonzero(np.isfinite(v).all(axis=1))
            if not np.allclose(v[finite[-1]],[lane.terminal_x,lane.terminal_y],atol=3.e-5):
                raise ValueError(lane.path)
            cases.append(dict(layout=layout,lane=lane.lane,root=lane.root,side=lane.side,force=lane.force,clock=lane.clock,
                              arm=lane.arm,termination=lane.termination,start=k,frames=len(t),last_finite=int(finite[-1])))
            switches.extend(dict(layout=layout,lane=lane.lane,tick=tick,reference=key) for tick,key in active)
            k += len(t)
            xy.append(v)
            times.append(t)
        np.savez_compressed(out/(layout+'_paths.npz'),xy=np.concatenate(xy),time_s=np.concatenate(times))
    np.savez_compressed(out/'references.npz',**refs)
    pd.DataFrame(cases).to_csv(out/'case_index.csv',index=False)
    pd.DataFrame(switches).to_csv(out/'reference_switches.csv',index=False)
    (out/'README.md').write_text('case_index.csv gives each vehicle and its row slice [start, start+frames) in that layout’s paths.npz. XY columns are world x,y in metres; time_s is seconds. reference_switches.csv lists the control tick (5 ms) when each stored reference became current. References describe the ground segments. Original terminal frames are retained. Join selected_tasks and fixed_direction_gates on layout and lane.\n')
    assert len(cases)==1296
    with tarfile.open(R/'analysis/release_paths.tar.gz','w:gz',compresslevel=3) as tar:
        tar.add(out,arcname='paths')
    print(len(cases),sum(v['frames'] for v in cases),len(refs),(R/'analysis/release_paths.tar.gz').stat().st_size)
if __name__=='__main__':pack()

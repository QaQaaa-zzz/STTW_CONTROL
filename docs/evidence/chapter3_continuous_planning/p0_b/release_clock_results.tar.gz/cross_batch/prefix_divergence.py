"""Compare the original selected early path and the identically keyed new early path."""
from pathlib import Path
from functools import lru_cache
import hashlib,json
import mujoco
import numpy as np
import pandas as pd

r=Path(__file__).resolve().parents[1]
o=r.parent/'chapter3_smooth_exit_dev_20261124'
out=r/'cross_batch'
def load(p):return json.loads(p.read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def per_tick_equal(a,b):
    a=np.ascontiguousarray(a);b=np.ascontiguousarray(b);assert a.shape==b.shape and a.dtype==b.dtype
    return (a.view('u1').reshape(len(a),-1)==b.view('u1').reshape(len(a),-1)).all(1)
def first_bad(a,b):
    n=min(len(a),len(b));ix=np.flatnonzero(~per_tick_equal(a[:n],b[:n]));return int(ix[0]) if len(ix) else None
def agg(series):
    return {k:float(v) for k,v in series.dropna().agg(['min','median','max']).items()}
qnames=['world_x_m','world_y_m','world_z_m','quat_w','quat_x','quat_y','quat_z','rearwheel_rad','steering_rad','frontwheel_rad','hip_rad','knee_rad']
vnames=['world_vx_m_s','world_vy_m_s','world_vz_m_s','body_wx_rad_s','body_wy_rad_s','body_wz_rad_s','rearwheel_rad_s','steering_rad_s','frontwheel_rad_s','hip_rad_s','knee_rad_s']
cfgs={};facts={};maps={}
for layout in ['right_offset','staggered']:
    cfg=[];decl=[];m=[];status={}
    for label,base in [('old',o),('new',r)]:
        f=base/layout/'physical';cfg.append(load(f/'resolved_config.json'));decl.append(load(f/'declaration.json'));m.append(mujoco.MjModel.from_binary_path(str(f/'terrain.mjb')))
        status[label]=load(f/'status.json')['results']
    a,b=cfg;da,db=decl
    matched=[k for k in a if a.get(k)==b.get(k)];changed=sorted(set(a)|set(b)-set(matched))
    src=[(w/layout/'physical/source') for w in (o,r)]
    artifacts={v.name:digest(v)==digest(src[1]/v.name) for v in src[0].glob('*.py')}
    physical_fields=['timestep','integrator','solver','iterations','tolerance','ls_iterations','ls_tolerance','cone','jacobian','gravity','enableflags','disableflags']
    options={key:[np.asarray(getattr(model.opt,key)).tolist() for model in m] for key in physical_fields}
    tables={}
    for field in ['body_mass','body_inertia','body_pos','body_ipos','jnt_range','dof_damping','dof_armature','dof_frictionloss','geom_type','geom_size','geom_pos','geom_friction','geom_solref','geom_solimp','geom_contype','geom_conaffinity','actuator_gainprm','actuator_biasprm','actuator_ctrlrange','actuator_forcerange','hfield_data','hfield_size']:
        aa,bb=[getattr(model,field) for model in m];tables[field]=bool(np.array_equal(aa,bb))
    facts[layout]=dict(identical_config_sections=matched,changed_config_sections=sorted((set(a)|set(b))-set(matched)),
        changed_handoff_subkeys=[k for k in a['ground_handoff'] if a['ground_handoff'][k]!=b['ground_handoff'][k]],saved_evaluator_source_matches=artifacts,
        compiled_model_tables= tables,physics_options_old_new=options,binary_terrain_equal=digest(o/layout/'physical/terrain.mjb')==digest(r/layout/'physical/terrain.mjb'),
        terrain_xml_equal=digest(o/layout/'physical/terrain.xml')==digest(r/layout/'physical/terrain.xml'),
        rb_identity_equal=da['skills']==db['skills'],ground_identity_equal=da['ground_model']==db['ground_model'],
        rb_checkpoint=da['skills']['rb_run1']['checkpoint_identity_sha256'],rb_actor=da['skills']['rb_run1']['actor_sha256'],
        h75_actor=da['ground_model']['files']['actor.npz'],old_new_per_map_worlds=[len(c['evaluation_lanes']) for c in cfg],
        CCD_workspace=[c['ccd_capacity'] for c in cfg],contact_per_lane=[c['world_contact_capacity'] for c in cfg],contact_workspace_total=[len(c['evaluation_lanes'])*c['world_contact_capacity'] for c in cfg],old_new_group_size=[c['p0_branches']['group_size'] for c in cfg],physics_substeps=da['physics_substeps'],physics_dt=da['physics_dt'],lower_dt=da['lower_dt'],upper_dt=da['upper_dt'],
        reduction_flags={key:[c[key] for c in cfg] for key in ['fixed_order_tree_reductions','ordered_solver_reductions','canonical_constraint_rows']})
    maps[layout]=status
prefix=pd.read_csv(out/'original212_cases.csv.gz')
old_preds=pd.read_csv(r/'forecast/predictions.csv')
k=['layout','root','force','geometry','section','side']
prefix=prefix.merge(old_preds[k+['observation_tick']],on=k,validate='one_to_one')
new_selected=pd.read_csv(r/'analysis/selected_tasks.csv.gz').query('clock=="early"')
prefix=prefix.merge(new_selected[k+['query_tick']],on=k,validate='one_to_one')
rows=[]
@lru_cache(maxsize=24)
def arr(path):
    with np.load(path) as z:
        return tuple(z[k] for k in ['qpos','qvel','trace','contact_substep','wheel_contact_flags','world_flags','columns'])
for x in prefix.itertuples():
    old=maps[x.layout]['old'][x.old_selected_lane];new=maps[x.layout]['new'][x.early_lane]
    qo,vo,to,co,wo,fo,cols=arr(x.old_selected_path);qn,vn,tn,cn,wn,fn,cols1=arr(x.early_actual_path)
    assert np.array_equal(cols,cols1)
    qi=first_bad(qo,qn);vi=first_bad(vo,vn);tick=min(i for i in [qi,vi] if i is not None)
    # Magnitudes use numerical differences; bit comparisons distinguish signed zeros and NaN payloads.
    dq=np.abs(qo[tick].astype('f8')-qn[tick]);dv=np.abs(vo[tick].astype('f8')-vn[tick])
    qchanged=qo[tick].view('u4')!=qn[tick].view('u4');vchanged=vo[tick].view('u4')!=vn[tick].view('u4')
    coord=lambda a,names:'|'.join(np.asarray(names)[a].tolist())
    input_idx=[list(cols).index(n) for n in ['steer_target','rear_target','hip_target','knee_target']]
    ch=first_bad(to[:,input_idx],tn[:,input_idx]);ct=first_bad(co,cn)
    joint=list(np.flatnonzero(vchanged))
    def ulps(a,b):
        if (a==b).all():return 0
        def ordered(a):
            u=a.view('u4').astype('int64');return np.where((u&0x80000000)>0,0x80000000-(u&0x7fffffff),0x80000000+u)
        return int(np.abs(ordered(a)-ordered(b)).max())
    rec={a:getattr(x,a) for a in k};rec.update(old_lane=x.old_selected_lane,new_lane=x.early_lane,tick0_qv_equal=bool(tick>0),first_qv_diff_tick=tick,first_qpos_diff=qi,first_qvel_diff=vi,phase_at_first_old=float(to[tick,-1]),phase_at_first_new=float(tn[tick,-1]),
        first_diff_qpos_components=coord(qchanged,qnames),first_diff_qvel_components=coord(vchanged,vnames),
        max_first_position_xyz_diff_m=float(np.max(dq[:3])),max_first_base_linear_v_diff_m_s=float(np.max(dv[:3])),
        max_first_rotational_velocity_difference_rad_s=float(np.max(dv[3:])),max_first_qpos_numeric=float(np.max(dq)),max_first_qvel_numeric=float(np.max(dv)),
        max_first_qpos_ulps=ulps(qo[tick],qn[tick]),max_first_qvel_ulps=ulps(vo[tick],vn[tick]),
        first_contact_load_diff_tick=ct,first_held_command_diff_trace_tick=ch,source_commands_identical_through_first=ch is None or ch>tick,
        source_commands_identical_through_previous=ch is None or ch>=tick,reported_contact_loads_identical_before_first=ct is None or ct>=tick,first_wheel_flag_diff_tick=first_bad(wo,wn),first_world_flag_diff_tick=first_bad(fo,fn),
        prior_tick_velocity_diff_max=float(np.max(np.abs(vo[tick-1]-vn[tick-1]))),ground_initial_release_old=old['initial_release_tick'],ground_initial_release_new=new['initial_release_tick'],rb_entry_s_old=old['rb_entry_s'],rb_entry_s_new=new['rb_entry_s'],
        air_trigger_tick_old=old['air_event_tick'],air_trigger_tick_new=new['air_event_tick'],pulse_steps_old=old['applied_force_ticks'],pulse_steps_new=new['applied_force_ticks'],
        approach_alpha_old=old['variant']['approach_alpha'],approach_alpha_new=new['variant']['approach_alpha'],continuation_alpha_old=old['continuation_alpha'],continuation_alpha_new=new['continuation_alpha'],force_old=old['variant']['force_y_N'],force_new=new['variant']['force_y_N'],
        old_observed_query_tick=x.observation_tick,new_observed_query_tick=x.query_tick if x.query_tick>=0 else np.nan)
    a=old['variant'];b=new['variant'];skip={'planner','release_clock','clock_index','arm','departure','planned_departure','side','bin','section_x'}
    if ch is not None:
        ua=to[ch,input_idx];ub=tn[ch,input_idx];du=np.abs(ua.astype('f8')-ub.astype('f8'))
        rec.update(first_command_components=coord(ua.view('u4')!=ub.view('u4'),np.asarray(cols)[input_idx]),first_steer_target_difference_rad=float(du[0]),first_rear_target_difference_rad_s=float(du[1]),first_hip_target_difference_rad=float(du[2]),first_knee_target_difference_rad=float(du[3]),first_control_max_ulps=ulps(ua,ub),first_command_tick_minus_qv=ch-tick)
    rec['all_other_physical_variant_fields_equal']=all(a.get(k)==b.get(k) for k in (set(a)|set(b))-skip)
    qtime=min([int(v) for v in [x.observation_tick,x.query_tick] if pd.notna(v) and v>=0],default=None)
    if qtime is not None and qtime<min(len(qo),len(qn)): rec['xy_error_at_first_observed_query_m']=float(np.linalg.norm(qo[qtime,:2]-qn[qtime,:2]))
    rec['query_tick_delta']=rec['new_observed_query_tick']-rec['old_observed_query_tick']
    rows.append(rec)
df=pd.DataFrame(rows);df.to_csv(out/'prefix_divergence_cases.csv.gz',index=False)
fields=['first_qv_diff_tick','max_first_position_xyz_diff_m','max_first_base_linear_v_diff_m_s','max_first_rotational_velocity_difference_rad_s','max_first_qpos_numeric','max_first_qvel_numeric','max_first_qvel_ulps','first_contact_load_diff_tick','first_held_command_diff_trace_tick','xy_error_at_first_observed_query_m','query_tick_delta']
tot={'n':len(df),'unique_prejump_map_root_geometry_force':len(df.drop_duplicates(['layout','root','geometry','force'])),'stats':{key:agg(df[key]) for key in fields},'first_changed_velocities':df.first_diff_qvel_components.value_counts().to_dict(),'first_changed_positions':df.first_diff_qpos_components.value_counts().to_dict(),
    'tickzero_qv_equal':int(df.tick0_qv_equal.sum()),'same_controls_through_first_qv_divergence':int(df.source_commands_identical_through_first.sum()),
    'first_qv_change_during_ground_approach':int(((df.phase_at_first_new==0)&(df.phase_at_first_old==0)).sum()),
    'contact_telemetry_diff_before_qv':int((df.first_contact_load_diff_tick<df.first_qv_diff_tick).sum()),'contact_telemetry_diff_with_qv':int((df.first_contact_load_diff_tick==df.first_qv_diff_tick).sum()),
    'same_rb_entry_s':int((df.rb_entry_s_old==df.rb_entry_s_new).sum()),'same_air_onset_tick':int((df.air_trigger_tick_old==df.air_trigger_tick_new).sum()),'same_applied_force_steps':int((df.pulse_steps_old==df.pulse_steps_new).sum()),'both_query':int(df.query_tick_delta.notna().sum()),'same_query_tick':int(df.query_tick_delta.eq(0).sum()),'initial_release_tick_pairs':df.groupby(['ground_initial_release_old','ground_initial_release_new']).size().to_dict().__repr__(),
    'all_other_physical_variant_fields_equal':int(df.all_other_physical_variant_fields_equal.sum()),'same_alpha_and_requested_push':int(((df.approach_alpha_old==df.approach_alpha_new)&(df.continuation_alpha_old==df.continuation_alpha_new)&(df.force_old==df.force_new)).sum()),
    'declared_sources_and_models':facts}
tot['recorded_first_control_components']=df.first_command_components.value_counts().to_dict()
tot['command_vs_qv_tick_difference_counts']=df.first_command_tick_minus_qv.value_counts().sort_index().to_dict()
tot['first_held_control_ULPs']=df.first_control_max_ulps.value_counts().sort_index().to_dict()
tot['earliest_common_clock_xy_at_either_query_only_cases_with_both_queries_m']=df[df.query_tick_delta.notna()].xy_error_at_first_observed_query_m.agg(['count','min','median','max']).to_dict()
(out/'prefix_divergence_receipt.json').write_text(json.dumps(tot,indent=2)+'\n')
print(json.dumps({k:v for k,v in tot.items() if k!='declared_sources_and_models'}))

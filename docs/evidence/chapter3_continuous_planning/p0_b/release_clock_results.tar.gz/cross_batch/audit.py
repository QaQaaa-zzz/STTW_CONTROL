"""Reconcile the original 212 timing contracts with the new three-clock runs, without simulating."""
import hashlib,json,sys
from functools import lru_cache
from pathlib import Path
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parents[1]; O=R/'cross_batch'; A=R/'analysis'
H=R.parent/'chapter3_smooth_exit_dev_20261124'
sys.path.insert(0,str(R.parent/'chapter3_continuous_p1_20261123/model'))
sys.path.insert(0,'/home/qy/STTW_CONTROL/runs/worktrees/sttw-offroad/learning/src')
from frozen_exit_value import mapped_arrays
K=['layout','root','geometry','force','section','side']
clocks=['early','middle','late']
def equal(a,b):
    return a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes()
def ticks(t,i):
    return [t+3,t+7,((t+15)//4)*4][i]
@lru_cache(maxsize=32)
def saved(path):
    with np.load(path) as z:return {k:z[k] for k in ['trace','qpos','qvel','reference_xy','published_reference_xy']}
@lru_cache(maxsize=256)
def physics_equal(pa,pb,query=None):
    a,b=saved(pa),saved(pb);sl=slice(None if query is None else query+1)
    if query is not None and (len(a['trace'])<=query or len(b['trace'])<=query):return False
    return all(equal(a[k][sl],b[k][sl]) for k in ['trace','qpos','qvel'])
def route_actual(path,bank,row):
    # The physical GPU bank is float32 even if the source file uses higher precision.
    ref=saved(path)['published_reference_xy']
    return equal(ref,np.asarray(bank['xy'][int(row)],dtype=ref.dtype))
def allbank(ba,bb,x,y):
    if pd.isna(x) or pd.isna(y):return False
    return all(equal(ba[k][int(x)],bb[k][int(y)]) for k in ['xy','heading','curvature']) and equal(ba['s'],bb['s'])
def data():
    old=pd.read_csv(H/'analysis/selected_tasks.csv.gz').query('method=="old" & primary').set_index(K)
    ol=pd.read_csv(H/'analysis/physical_lanes.csv.gz').set_index(['layout','root','geometry','force','arm'])
    new=pd.read_csv(A/'selected_tasks.csv.gz').set_index(K+['clock']).sort_index()
    lanes=pd.read_csv(A/'physical_lanes.csv.gz').set_index(['layout','group','clock','arm'])
    controls=pd.read_csv(A/'straight_negative_controls.csv.gz').set_index(['layout','group','section'])
    orig=pd.read_csv(R/'forecast/clock_only_case_bounds.csv')
    orig_pred=pd.read_csv(R/'forecast/predictions.csv').set_index(K)
    bank={}
    for origin,folder in [('old',H),('new',R)]:
        for layout in orig.layout.unique():
            cfg=json.loads((folder/layout/'physical/resolved_config.json').read_text())
            bank[origin,layout]=mapped_arrays(cfg['paired_departures']['route_bank'])
    details=[]
    for item in orig.to_dict('records'):
        k=tuple(item[f] for f in K);layout,root,geom,force,section,side=k
        base=old.loc[k]; selected=new.loc[k].loc[clocks]
        pred=orig_pred.loc[k];group=int(selected.group.iloc[0])
        current=lanes.loc[(layout,group)]
        ctl=controls.loc[layout,group,section]
        bb,bn=bank['old',layout],bank['new',layout]
        no=item['class']=='no_handback'
        assert bool(item['physical_early_success'])==bool(base.success)
        strict_group=current.native_prefix.all() and selected.selection_matches_all.all()
        old_st=ol.loc[layout,root,geom,force,'straight']
        r={**item,'group':group,'old_selected_lane':int(base.lane),'old_selected_path':base.path,'historical_observer_lane':int(pred.lane),'new_nine_native_and_selector_match':bool(strict_group),'new_three_noop_full_state_controls_terminal_match':bool(ctl.all_three_match)}
        curr_selected=selected.to_dict('index')
        route_tuple_good=[];actual_old_good=not no and base.departure_applied_tick>=0 and route_actual(base.path,bb,item['chosen_route_id'])
        r['old_target_XY_actual_equals_catalog']=actual_old_good if not no else None
        r['old_straight_XY_actual_equals_catalog']=route_actual(old_st.path,bb,item['active_route_id']) if not no and old_st.departure_applied_tick>=0 else None
        r['early_equals_old_full_trace_qpos_qvel']=physics_equal(curr_selected['early']['path'],base.path)
        left,right=saved(curr_selected['early']['path']),saved(base.path)
        ln=min(len(left['qpos']),len(right['qpos']))
        matches=np.ones(ln,dtype=bool)
        for label in ('qpos','qvel'):
            x=np.ascontiguousarray(left[label][:ln]);y=np.ascontiguousarray(right[label][:ln]);assert x.dtype==y.dtype
            matches &= (x.view('u1').reshape(ln,-1)==y.view('u1').reshape(ln,-1)).all(1)
        first=np.flatnonzero(~matches)
        r['initial_qpos_qvel_bitwise_equal']=bool(matches[0])
        r['first_different_qpos_or_qvel_tick']=int(first[0]) if len(first) else None
        r['old_early_success_reproduced']=bool(curr_selected['early']['success'])==bool(base.success)
        for i,clock in enumerate(clocks):
            here=curr_selected[clock]; z=lanes.loc[layout,group,clock,'straight']
            src_q=-1 if pd.isna(pred.observation_tick) else int(pred.observation_tick)
            start=int(here['query_tick'])
            path=here['path']
            r[clock+'_new_success']=bool(here['success']);r[clock+'_lane']=int(here['lane'])
            r[clock+'_publication_tick']=here['publication_tick'];r[clock+'_first_steer_interval']=here['first_changed_steer_interval_tick']
            r[clock+'_pursuit_read_tick']=here['pursuit_read_tick'];r[clock+'_h75_read_tick']=here['h75_read_tick']
            r[clock+'_selection_same_rows_as_old']=bool(here['historical_choice_routes_match'])
            r[clock+'_actual_path']=path
            r[clock+'_query_prebranch_equal_to_historical_fixed_arm']=physics_equal(path,base.path,src_q) if not no and src_q>=0 else None
            if no:
                full=all(physics_equal(row.path,base.path) for row in current.itertuples())
                complete=all(row.termination==base.termination and np.isclose(row.duration_s,base.duration_s,atol=1e-8,rtol=0) for row in current.itertuples())
                common_failure=(bool(strict_group and current.matched_nine_unrelocked.all() and base.pair_ok and pd.isna(base.handoff_s) and curr_selected['early']['query_tick']<0 and full and complete))
                r['all_nine_vs_old_exact_to_terminal']=full;r['all_nine_vs_old_terminal_and_time_match']=complete
                r[clock+'_same_start_and_intent']=common_failure;r[clock+'_actual_intervention_verified']=None
                r[clock+'_release_checked']=None;r[clock+'_target_bank_xy_h_k_equal']=None;r[clock+'_straight_bank_xy_h_k_equal']=None
                r[clock+'_actual_selected_XY_equals_catalog']=None;r[clock+'_actual_straight_XY_equals_catalog']=None
                route_tuple_good.append(common_failure)
                continue
            target=allbank(bb,bn,item['chosen_route_id'],here['requested_route'])
            straight=allbank(bb,bn,item['active_route_id'],here['default_route'])
            input_ref=equal(saved(path)['reference_xy'],saved(base.path)['reference_xy'])
            prefix=bool(strict_group and start>=0 and start==src_q and here['historical_prefix_trace_equal'] and here['historical_handback_equal'] and
                        here['historical_choice_routes_match'] and r[clock+'_query_prebranch_equal_to_historical_fixed_arm'] and target and straight and input_ref)
            timing=(start>=0 and int(here['due_tick'])==ticks(start,i) and (i!=0 or base.departure_applied_tick==ticks(src_q,0)))
            applied=int(here['publication_tick'])>=0 and here['publication_tick']==here['due_tick'] and here['requested_route']==here['actual_route']
            # Missing release can itself be a timing effect if the matched car ended before it was due.
            pending_terminal=int(here['publication_tick'])<0 and start>=0 and round(here['duration_s']/.005)<=here['due_tick']
            explicit_actual=applied and route_actual(path,bn,here['actual_route'])
            straight_actual=z.publication_tick>=0 and z.actual_route==z.default_route and route_actual(z.path,bn,z.default_route)
            r[clock+'_historical_handback_saved_fields_equal']=bool(here['historical_handback_equal'])
            r[clock+'_actual_selected_XY_equals_catalog']=bool(explicit_actual)
            r[clock+'_actual_straight_XY_equals_catalog']=bool(straight_actual)
            r[clock+'_target_bank_xy_h_k_equal']=target;r[clock+'_straight_bank_xy_h_k_equal']=straight
            r[clock+'_prejump_reference_XY_equal']=input_ref;r[clock+'_terminal_by_due_without_release']=pending_terminal
            r[clock+'_release_checked']=bool(timing and applied)
            r[clock+'_same_start_and_intent']=bool(prefix and timing)
            r[clock+'_actual_intervention_verified']=bool(prefix and timing and explicit_actual and straight_actual and actual_old_good and r['old_straight_XY_actual_equals_catalog'])
            route_tuple_good.append(bool(prefix and timing and actual_old_good and r['old_straight_XY_actual_equals_catalog'] and (explicit_actual or pending_terminal) and (straight_actual or (z.publication_tick<0 and round(z.duration_s/.005)<=z.due_tick))))
        r['historical_identity_all_clocks']=all(route_tuple_good)
        r['old_noop_assumption_reproduced']=(bool(r['new_three_noop_full_state_controls_terminal_match']) and all(r[c+'_new_success']==bool(base.success) for c in clocks)) if item['class']=='same_active_reference' else None
        r['all_old_bound_premises_for_case']=r['historical_identity_all_clocks'] and (item['class']!='same_active_reference' or r['old_noop_assumption_reproduced'])
        details.append(r)
    df=pd.DataFrame(details);assert len(df)==212 and df.physical_early_success.sum()==85
    df.to_csv(O/'original212_cases.csv.gz',index=False)
    groups=[]
    for category,panel in [('all',df),*df.groupby(['layout','section','side'])]:
        for clock,basecl in [('middle','early'),('late','early'),('late','middle')]:
            match=panel.all_old_bound_premises_for_case
            good=panel[match];missing=panel[~match]
            delta=good[clock+'_new_success'].astype(int)-good[basecl+'_new_success'].astype(int)
            olddelta=good[clock+'_new_success'].astype(int)-good.physical_early_success.astype(int)
            # Historical early's outcome is known individually, unlike discordant new starts.
            obs=int(good[clock+'_new_success'].sum())
            groups.append(dict(group=str(category),later=clock,earlier=basecl,total=len(panel),
                exact_old_protocol=len(good),unverified=len(missing),original_early=int(panel.physical_early_success.sum()),
                new_unrestricted_later=int(panel[clock+'_new_success'].sum()),matched_new_later=obs,
                raw_full212_later_lower=obs,raw_full212_later_upper=obs+len(missing),
                full212_net_vs_old_early_lower=int(olddelta.sum()-missing.physical_early_success.sum()),
                full212_net_vs_old_early_upper=int(olddelta.sum()+(~missing.physical_early_success).sum()),
                old_theorem_conditional_full212_lower=obs+int(missing.low.sum()),old_theorem_conditional_full212_upper=obs+int(missing.high.sum()),
                paired_later_rescues=int((delta==1).sum()),paired_later_losses=int((delta==-1).sum()),paired_later_net=int(delta.sum()),
                matched_historical_early=int(good.physical_early_success.sum()),matched_new_early=int(good.early_new_success.sum())))
    table=pd.DataFrame(groups);table.to_csv(O/'original212_gate_summary.csv',index=False)
    columns=[v for v in df.columns if any(w in v for w in ('equal','match','checked','verified','premises','all_nine','same_start','reproduced','_all_clocks'))]
    flags={c:{'observed':int(df[c].notna().sum()),'true':int(df[c].eq(True).sum()),'false':int(df[c].eq(False).sum())} for c in columns}
    result={'rows':len(df),'old_early':int(df.physical_early_success.sum()),'theory_original_lower':int(df.low.sum()),'theory_original_upper':int(df.high.sum()),'flags':flags,'categories':df.groupby('class').agg(tasks=('root','size'),eligible=('all_old_bound_premises_for_case','sum'),early_matches_historical=('old_early_success_reproduced','sum')).to_dict('index'),'all':table.query('group=="all"').to_dict('records'),'definition':'Old212 historical contracts only. Cross-batch prefix compares control trace, qpos and qvel bytes through query, and score.py handback control/policy/physics saved fields (not packed native solver/contact internals). Old fixed direction physically executed; current requested routes and active straight tested on full XY/heading/curvature bank knots, emitted XY checked against actual physical API archive. Terminal no-query failures require complete three trace fields and terminal match to historical for all nine lanes. Conditional theorem columns assume the original deterministic no-op premises continue to hold for unresolved cases; raw unverified intervals use 0..1. Full equality comparison counts physical trajectories even where only task outcomes coincide.'}
    (O/'original212_receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['rows','categories','all']}))
if __name__=='__main__':data()

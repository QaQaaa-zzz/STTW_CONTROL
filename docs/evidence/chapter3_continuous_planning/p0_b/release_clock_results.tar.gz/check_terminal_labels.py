"""Verify the scoring distinction between an unobserved request and no relock."""
from pathlib import Path
import json
import hashlib
from score import handback_status, matched_unrelocked

root=Path(__file__).resolve().parent
observations=[{'handoff_s':None} for _ in range(9)]
assert matched_unrelocked(True,observations)
assert not matched_unrelocked(False,observations)
observations[8]['handoff_s']=10.
assert not matched_unrelocked(True,observations)
assert handback_status(10., -1, 10.)=='relocked_on_terminal_frame'
assert handback_status(None, -1, 10.)=='no_relock'
assert handback_status(4.855,972,8.1)=='queried'
archive=root.parent/'chapter3_smooth_exit_dev_20261124'
tally={}
for m in ['right_offset','staggered']:
    queries=set()
    for l in (archive/m/'physical/p0_events.jsonl').open():
        e=json.loads(l)
        if e['kind']=='old_selection':
            queries.update((lane,e['tick']) for lane in e['lanes'])
    events=dict(queries)
    rows=json.loads((archive/m/'physical/status.json').read_text())['results']
    for lane,r in enumerate(rows):
        if lane%11<3: continue
        label=handback_status(r['handoff_s'],events.get(lane,-1),r['duration_s'])
        tally[label]=tally.get(label,0)+1
out={'archived_original_query_arms':tally,'score_sha256':hashlib.sha256((root/'score.py').read_bytes()).hexdigest(),'tested':['matched nine-arm no-relock','failed native-prefix agreement','ninth lane relocked despite other eight having no query','terminal-frame relock without a subsequent query','ordinary observed relock']}
(root/'terminal_label_receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['archived_original_query_arms'])
